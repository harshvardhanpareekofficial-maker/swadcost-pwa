"""Bounded Windows-local shutdown protocol; no app import or network surface."""
from __future__ import annotations
from contextlib import contextmanager, ExitStack
import ctypes
from ctypes import wintypes as W
import hashlib
import json
import os
from pathlib import Path
import re
import time
import uuid

MAX_BYTES = 4096
GENERATION = re.compile(r'g-[0-9a-f]{32}\Z')
NAMES = {'owner.json', 'identity.json', 'stop.json', 'terminal.json'}

class ControlError(ValueError):
    pass

if os.name == 'nt':
    K = ctypes.WinDLL('kernel32', use_last_error=True)
    K.CreateFileW.argtypes = [W.LPCWSTR,W.DWORD,W.DWORD,ctypes.c_void_p,W.DWORD,W.DWORD,W.HANDLE]
    K.CreateFileW.restype = W.HANDLE
    K.CloseHandle.argtypes = [W.HANDLE]; K.CloseHandle.restype = W.BOOL
    K.GetFinalPathNameByHandleW.argtypes = [W.HANDLE,W.LPWSTR,W.DWORD,W.DWORD]; K.GetFinalPathNameByHandleW.restype=W.DWORD
    class Info(ctypes.Structure):
        _fields_ = [('attributes',W.DWORD),('created',W.FILETIME),('accessed',W.FILETIME),('written',W.FILETIME),('volume',W.DWORD),('size_high',W.DWORD),('size_low',W.DWORD),('links',W.DWORD),('index_high',W.DWORD),('index_low',W.DWORD)]
    K.GetFileInformationByHandle.argtypes=[W.HANDLE,ctypes.POINTER(Info)];K.GetFileInformationByHandle.restype=W.BOOL
    K.ReadFile.argtypes=[W.HANDLE,ctypes.c_void_p,W.DWORD,ctypes.POINTER(W.DWORD),ctypes.c_void_p];K.ReadFile.restype=W.BOOL
    K.OpenProcess.argtypes=[W.DWORD,W.BOOL,W.DWORD];K.OpenProcess.restype=W.HANDLE
    K.GetProcessTimes.argtypes=[W.HANDLE,*([ctypes.POINTER(W.FILETIME)]*4)];K.GetProcessTimes.restype=W.BOOL
    K.WaitForSingleObject.argtypes=[W.HANDLE,W.DWORD];K.WaitForSingleObject.restype=W.DWORD


def _nt():
    if os.name != 'nt':
        raise ControlError('windows_control_required')


def _metadata(handle):
    info=Info()
    if not K.GetFileInformationByHandle(handle,ctypes.byref(info)):
        raise ControlError('control_handle_unverified')
    final=ctypes.create_unicode_buffer(32768)
    count=K.GetFinalPathNameByHandleW(handle,final,len(final),0)
    if not count or count>=len(final):
        raise ControlError('control_path_unverified')
    value=final.value
    if value.startswith('\\\\?\\'):value=value[4:]
    return info,Path(value)


@contextmanager
def _handle(path, *, directory=False, read=False):
    _nt()
    h=K.CreateFileW(str(path),0x80000000 if (read or directory) else 0,3,None,3,0x00200000|(0x02000000 if directory else 0),None)
    if h in (None,ctypes.c_void_p(-1).value):
        raise ControlError('control_open_failed')
    try:
        info,final=_metadata(h)
        if info.attributes & 0x400 or bool(info.attributes&0x10)!=directory:
            raise ControlError('control_link_or_type_forbidden')
        if not directory and info.links!=1:
            raise ControlError('control_hardlink_forbidden')
        if os.path.normcase(str(final))!=os.path.normcase(str(path)):
            raise ControlError('control_path_mismatch')
        yield h,info
    finally:
        K.CloseHandle(h)


class ControlTree:
    def __init__(self,runtime):
        _nt()
        raw=str(runtime)
        if (raw.startswith(('\\\\','//')) or not re.match(r'^[A-Za-z]:[\\/]',raw)
                or ':' in raw[2:] or any(x in {'.','..'} for x in re.split(r'[\\/]',raw))):
            raise ControlError('invalid_runtime_path')
        self.runtime=Path(raw)
        self.root=self.runtime/'shutdown-v2'
        self.binding=hashlib.sha256(os.path.normcase(str(self.runtime)).encode()).hexdigest()

    @contextmanager
    def directories(self, *, generation=None, create=False):
        if generation is not None and not GENERATION.fullmatch(generation):
            raise ControlError('invalid_generation')
        destination=self.root/generation if generation else self.root
        with ExitStack() as stack:
            current=Path(destination.anchor)
            stack.enter_context(_handle(current,directory=True))
            for part in destination.parts[1:]:
                current=current/part
                if not current.exists() and create:
                    current.mkdir()
                # lstat before following any component, including broken links.
                try: attrs=current.lstat().st_file_attributes
                except OSError: raise ControlError('control_directory_missing') from None
                if attrs&0x400:raise ControlError('control_reparse_forbidden')
                stack.enter_context(_handle(current,directory=True))
            if self.root.exists() and sum(1 for _ in self.root.iterdir())>1025:
                raise ControlError('generation_capacity_exceeded')
            if generation and sum(1 for _ in destination.iterdir())>=32:
                raise ControlError('record_capacity_exceeded')
            yield destination

    def read(self,name, *, generation=None):
        if name not in NAMES or (name=='owner.json')!=(generation is None):
            raise ControlError('invalid_record_name')
        with self.directories(generation=generation) as directory:
            path=directory/name
            if not path.exists():return None
            with _handle(path,read=True) as (handle,info):
                if info.size_high or info.size_low>MAX_BYTES:raise ControlError('record_too_large')
                buf=ctypes.create_string_buffer(MAX_BYTES+1);count=W.DWORD()
                if not K.ReadFile(handle,buf,MAX_BYTES+1,ctypes.byref(count),None):raise ControlError('record_read_failed')
                if count.value>MAX_BYTES:raise ControlError('record_too_large')
                raw=buf.raw[:count.value]
        def pairs(rows):
            result={}
            for key,value in rows:
                if key in result:raise ControlError('duplicate_record_key')
                result[key]=value
            return result
        try:
            result=json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda _: (_ for _ in ()).throw(ControlError('nonfinite_record')))
        except (ValueError,UnicodeError):raise ControlError('invalid_record_json') from None
        if not isinstance(result,dict):raise ControlError('invalid_record_schema')
        return result

    def publish(self,name,value, *, generation=None, replace=False):
        if name not in NAMES or (name=='owner.json')!=(generation is None) or (replace and name!='owner.json'):
            raise ControlError('invalid_record_name')
        raw=json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
        if len(raw)>MAX_BYTES:raise ControlError('record_too_large')
        with self.directories(generation=generation,create=True) as directory:
            path=directory/name;tmp=directory/('.tmp-'+uuid.uuid4().hex)
            try:
                with tmp.open('xb') as stream:
                    stream.write(raw);stream.flush();os.fsync(stream.fileno())
                with _handle(tmp,read=True):pass
                if path.exists():
                    with _handle(path,read=True):pass
                if replace:os.replace(tmp,path)
                else:
                    try:os.rename(tmp,path)  # Windows non-overwriting rename.
                    except FileExistsError:
                        existing=self.read(name,generation=generation)
                        if existing!=value:raise ControlError('record_conflict') from None
                with _handle(path,read=True):pass
            finally:
                if tmp.exists():tmp.unlink()  # Only our exclusive temporary file.

    def new_generation(self):
        with self.directories(create=True) as root:
            if sum(1 for q in root.iterdir() if q.is_dir())>=1024:raise ControlError('generation_capacity_exceeded')
            generation='g-'+uuid.uuid4().hex
            (root/generation).mkdir()  # exclusive; UUID collision is an error.
        return generation


class ProcessWitness:
    def __init__(self,pid,expected=None):
        _nt()
        if type(pid) is not int or pid<=0:raise ControlError('invalid_owner_pid')
        self.handle=K.OpenProcess(0x00100000|0x1000,False,pid)
        if not self.handle:raise ControlError('owner_process_unavailable')
        created,exited,kernel,user=(W.FILETIME() for _ in range(4))
        if not K.GetProcessTimes(self.handle,*[ctypes.byref(x) for x in (created,exited,kernel,user)]):
            self.close();raise ControlError('owner_process_unverified')
        self.created=(created.dwHighDateTime<<32)|created.dwLowDateTime
        if expected is not None and self.created!=expected:
            self.close();raise ControlError('owner_process_identity_mismatch')
    def exited(self):
        result=K.WaitForSingleObject(self.handle,0)
        if result not in (0,258):raise ControlError('owner_wait_failed')
        return result==0
    def close(self):
        if self.handle:K.CloseHandle(self.handle);self.handle=None
    def __enter__(self):return self
    def __exit__(self,*_):self.close()


def _identity(tree,record, *, owner=False):
    keys={'protocol','generation','pid','created','runtime'}|({'state'} if owner else set())
    if (not isinstance(record,dict) or set(record)!=keys or type(record['protocol']) is not int or record['protocol']!=2
            or not isinstance(record['generation'],str) or not GENERATION.fullmatch(record['generation'])
            or type(record['pid']) is not int or record['pid']<=0 or type(record['created']) is not int
            or record['created']<=0 or record['runtime']!=tree.binding
            or (owner and (not isinstance(record['state'],str) or record['state'] not in {'starting','running'}))):
        raise ControlError('invalid_identity')
    return {k:v for k,v in record.items() if k!='state'}


def publish_owner(tree):
    generation=tree.new_generation()
    with ProcessWitness(os.getpid()) as process:created=process.created
    identity={'protocol':2,'generation':generation,'pid':os.getpid(),'created':created,'runtime':tree.binding}
    tree.publish('identity.json',identity,generation=generation)
    tree.publish('owner.json',{**identity,'state':'starting'},replace=True)
    return identity


def stop_record(identity):
    return {'protocol':2,'generation':identity['generation'],'runtime':identity['runtime'],'action':'stop'}


def stop_requested(tree,identity):
    value=tree.read('stop.json',generation=identity['generation'])
    if value is None:return False
    if value!=stop_record(identity) or type(value.get('protocol')) is not int:raise ControlError('invalid_stop_record')
    return True


def settled_summary(summary):
    """Recognize legacy and resource-aware terminal records, failing closed."""
    legacy = {'calls', 'bootstrap', 'unjoined', 'failures'}
    if type(summary) is not dict or set(summary) not in (legacy, legacy | {'resources', 'resource_states'}):
        return False
    if not all(type(summary[k]) is int and summary[k] == 0 for k in ('calls', 'bootstrap', 'unjoined')):
        return False
    if type(summary['failures']) is not list or not all(isinstance(x, str) for x in summary['failures']):
        return False
    if 'resources' in summary:
        return type(summary['resources']) is int and summary['resources'] == 0 and type(summary['resource_states']) is list and summary['resource_states'] == []
    return True


def request_stop(runtime,wait_seconds=110, *, captured=None):
    if type(wait_seconds) not in (int,float) or not 1<=wait_seconds<=120:
        raise ControlError('invalid_wait_bound')
    tree=ControlTree(runtime)
    try:owner=tree.read('owner.json')
    except ControlError as exc:
        if str(exc)!='control_directory_missing':raise
        owner=None
    if owner is None:
        from scripts.runtime_lock import runtime_lock
        try:
            with runtime_lock(tree.runtime):pass
        except (RuntimeError,OSError):return {'code':4,'status':'starting_or_unregistered'}
        return {'code':4,'status':'no_registered_owner'}
    identity=_identity(tree,owner,owner=True)
    if tree.read('identity.json',generation=identity['generation'])!=identity:raise ControlError('identity_mismatch')
    with ProcessWitness(identity['pid'],identity['created']) as process:
        if captured is not None:captured(identity)  # fixture barrier, never retarget.
        tree.publish('stop.json',stop_record(identity),generation=identity['generation'])
        deadline=time.monotonic()+wait_seconds
        while True:
            terminal=tree.read('terminal.json',generation=identity['generation'])
            ended=process.exited()
            if ended:
                newer=tree.read('owner.json')
                newer_observed=bool(newer and _identity(tree,newer,owner=True)['generation']!=identity['generation'])
                valid=(isinstance(terminal,dict) and set(terminal)=={'protocol','generation','runtime','outcome','summary'} and type(terminal['protocol']) is int and terminal['protocol']==2
                       and terminal['generation']==identity['generation'] and terminal['runtime']==identity['runtime']
                       and isinstance(terminal['outcome'],str) and terminal['outcome'] in {'clean','stopped_unclean'}
                       and settled_summary(terminal['summary']))
                clean=valid and terminal['outcome']=='clean' and not terminal['summary']['failures']
                return {'code':0 if clean else 3,'status':'clean' if clean else 'stopped_unclean' if valid else 'abnormal_unverified',
                        'generation':identity['generation'],'newer_owner_observed':newer_observed}
            if time.monotonic()>=deadline:
                return {'code':2,'status':'quiescent_exit_pending' if terminal else 'incomplete','generation':identity['generation']}
            time.sleep(.025)

# Darwin retains the same protocol and shutdown settlement rules.
import sys as _platform_sys
if _platform_sys.platform == "darwin":
    from native.macos.runtime_control import ControlTree, ProcessWitness
