"""Pinned, single-attempt loopback TLS hook, not enabled by the launcher.

Only public create_server delegation is changed. No global policy or SSL patch
is installed. These pins bind the experimentally reviewed Windows runtime; an
update requires new evidence instead of silently inheriting timeout behavior.
"""
import asyncio
import hashlib
import importlib
from pathlib import Path
import socket
import ssl as ssl_module
import sys


class TransportContractError(ValueError):
    pass


SOURCE_PINS = {
    'uvicorn.config': '296d63cd46a6c7f547eaf1aa7ef2f2f988accd0c82060e7ea132d4cf6b403811',
    'uvicorn.server': '7c1dbd656835c9cdd6f92078ffc80bcc6007824ab322aff15435bd89c068e0be',
    'uvicorn.loops.asyncio': '6bcc0ee1f078a4293e44b202abb0a71abfdcc5023b3012c98fe1a8e14425743f',
    'uvicorn.lifespan.on': '8844cf163e921613c33dc75e1b17dae372ca226254ecc2398bb41451ea4170f1',
    'uvicorn.protocols.http.h11_impl': '0c10c4fc79e742da96e746c06f8396ddd28a0e01004d448ebcda9f0c20c11764',
    'asyncio.base_events': '53b71bbbd79e7fb2251460119afc379ebd71bbc599d9018313cc62ef218ae795',
    'asyncio.proactor_events': '62d15e99315cae52e8548f487391ae6c46827bf8e5b4bcf3382c777a494a759b',
    'asyncio.sslproto': '6c7fa1b81dc41850281cbf284c99ca18e824939fa5778860327040f3a80f6218',
}


def _source_hash(module):
    return hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest()


def verify_tls_runtime():
    if sys.platform != 'win32' or tuple(sys.version_info[:3]) != (3, 12, 14):
        raise TransportContractError('unsupported_tls_runtime')
    import uvicorn
    if uvicorn.__version__ != '0.52.4':
        raise TransportContractError('unsupported_tls_runtime')
    try:
        valid = all(_source_hash(importlib.import_module(name)) == expected
                    for name, expected in SOURCE_PINS.items())
    except Exception:
        raise TransportContractError('tls_source_verification_failed') from None
    if not valid:
        raise TransportContractError('tls_source_verification_failed')


# Portable HTTP never imports this module. A direct import on another platform
# remains diagnosable; no usable fallback TLS loop is constructed there.
_ProactorBase = getattr(asyncio, 'ProactorEventLoop', asyncio.BaseEventLoop)


class RuntimeTLSLoop(_ProactorBase):
    def __new__(cls):
        # Reject unsupported runtimes before allocating a half-initialized loop.
        verify_tls_runtime()
        return super().__new__(cls)

    def __init__(self):
        super().__init__()
        self._tls_reserved = False

    @property
    def tls_reservations(self):
        return int(self._tls_reserved)

    async def _delegate_create_server(self, protocol_factory, host, port, **kwargs):
        return await super().create_server(protocol_factory, host, port, **kwargs)

    async def create_server(self, protocol_factory, host=None, port=None, *,
                            family=socket.AF_UNSPEC, flags=socket.AI_PASSIVE,
                            sock=None, backlog=100, ssl=None, reuse_address=None,
                            reuse_port=None, ssl_handshake_timeout=None,
                            ssl_shutdown_timeout=None, start_serving=True):
        if ssl is not None:
            if asyncio.get_running_loop() is not self:
                raise TransportContractError('tls_loop_mismatch')
            if (type(host) is not str or host != '127.0.0.1'
                    or type(port) is not int or not 1 <= port <= 65535
                    or not isinstance(ssl, ssl_module.SSLContext)
                    or ssl.protocol != ssl_module.PROTOCOL_TLS_SERVER
                    or sock is not None):
                raise TransportContractError('unsupported_tls_listener_shape')
            if (ssl_handshake_timeout is not None
                    and (type(ssl_handshake_timeout) not in (int, float)
                         or ssl_handshake_timeout != 10.0)):
                raise TransportContractError('conflicting_tls_timeout')
            if self._tls_reserved:
                raise TransportContractError('tls_listener_already_reserved')
            # Exact current loop owns this reservation before the first await;
            # failure/cancellation never creates permission for a second attempt.
            self._tls_reserved = True
            ssl_handshake_timeout = 10.0
        return await self._delegate_create_server(
            protocol_factory, host, port, family=family, flags=flags, sock=sock,
            backlog=backlog, ssl=ssl, reuse_address=reuse_address,
            reuse_port=reuse_port, ssl_handshake_timeout=ssl_handshake_timeout,
            ssl_shutdown_timeout=ssl_shutdown_timeout, start_serving=start_serving)


def make_loop():
    """Zero-argument public Uvicorn import hook, without policy mutation."""
    return RuntimeTLSLoop()
