"""Install an integrity-checked offline payload without replacing mutable runtime data.

This per-user installer needs no administrator or network. Run it with the
Python interpreter bundled beside it. Hashes detect corruption, not publisher identity.
"""
import argparse
from contextlib import contextmanager, ExitStack
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import sys
import uuid


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def member(root, name):
    return _member(root, name, root.resolve())


def _member(root, name, resolved_root):
    # A verification pass already has a canonical root. Reuse that path only;
    # every member is still resolved and every ancestor checked for links.
    # No filesystem metadata, file contents or verification results are cached.
    if not isinstance(name, str) or '\\' in name or ':' in name:
        raise ValueError('Invalid payload member')
    parts = PurePosixPath(name).parts
    if not parts or name != PurePosixPath(name).as_posix() or PurePosixPath(name).is_absolute() or any(p in ('.', '..') or p.endswith((' ', '.')) for p in parts):
        raise ValueError('Invalid payload member')
    path = root.joinpath(*parts)
    if not path.resolve().is_relative_to(resolved_root):
        raise ValueError('Payload member escaped root')
    cursor = path
    while cursor != root:
        if cursor.is_symlink() or (hasattr(cursor, 'is_junction') and cursor.is_junction()):
            raise ValueError('Linked payload member')
        cursor = cursor.parent
    return path


def verify(payload):
    payload = Path(payload).resolve(strict=True)
    manifest = json.loads((payload/'bundle-manifest.json').read_text(encoding='utf-8'))
    if manifest.get('schema_version') != 1 or manifest.get('kind') != 'windows_offline_research_candidate':
        raise ValueError('Unsupported payload manifest')
    version = manifest.get('version', '')
    if not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_.-]{0,79}', version) or version.endswith('.'):
        raise ValueError('Invalid version')
    seen = set()
    for row in manifest['files']:
        name = row['path']
        if name.casefold() in seen:
            raise ValueError('Duplicate payload member')
        seen.add(name.casefold())
        path = _member(payload, name, payload)
        if not path.is_file() or path.stat().st_size != row['bytes'] or digest(path) != row['sha256']:
            raise ValueError(f'Payload integrity mismatch: {name}')
    actual = {p.relative_to(payload).as_posix().casefold() for p in payload.rglob('*') if p.is_file()}
    if actual != seen | {'bundle-manifest.json'}:
        raise ValueError('Unexpected or omitted payload files')
    required = {'runtime/python.exe', 'source/scripts/launch_offline_source.py', 'launch.py', 'install.py'}
    if not required <= seen:
        raise ValueError('Incomplete offline payload')
    return manifest


def _target(install_dir):
    target = Path(install_dir).absolute()
    for part in (target, *target.parents):
        if part.is_symlink() or (hasattr(part, 'is_junction') and part.is_junction()):
            raise ValueError('Linked installation directory is unsupported')
    target = target.resolve()
    for name in ('versions', 'runtime-data'):
        member(target, name)
    return target


def _installation(target, *, allow_empty=False):
    marker = target/'installation.json'
    if allow_empty and (not target.exists() or not any(
            p.name != '.installation.lock' for p in target.iterdir())):
        return None
    try:
        data = json.loads(member(target, 'installation.json').read_text(encoding='utf-8'))
        if (not isinstance(data, dict) or data.get('schema_version') != 1
                or data.get('installer') != 'per_user_offline_script'
                or data.get('runtime') != 'runtime-data'):
            raise ValueError('Unsupported installation marker')
        _version(data.get('active_version'))
        return data
    except (OSError, ValueError, TypeError) as error:
        raise ValueError('Nonempty installation directory is not a Gate Desk installation') from error


def _version(version):
    if not isinstance(version, str) or not re.fullmatch(r'[a-zA-Z0-9][a-zA-Z0-9_.-]{0,79}', version) or version.endswith('.'):
        raise ValueError('Invalid version')
    return version


@contextmanager
def _lock(directory, name):
    path = member(directory, name)
    with path.open('a+b') as stream:
        stream.seek(0, 2)
        if stream.tell() == 0:
            stream.write(b'0'); stream.flush()
        stream.seek(0)
        try:
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as error:
            raise RuntimeError('Installation or runtime is in use; stop Gate Desk before changing versions') from error
        try:
            yield
        finally:
            stream.seek(0)
            if os.name == 'nt':
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(stream, fcntl.LOCK_UN)


@contextmanager
def _cold_installation(target):
    # Same nonblocking locks/order as the app and cold backup. Creating a lock
    # directory is bookkeeping only; no document, database or recording is edited.
    target.mkdir(parents=True, exist_ok=True)
    with ExitStack() as locks:
        locks.enter_context(_lock(target, '.installation.lock'))
        runtime = member(target, 'runtime-data')
        runtime.mkdir(exist_ok=True)
        locks.enter_context(_lock(runtime, '.gate-desk.lock'))
        for name in ('camera-supervisor', 'camera-ingest'):
            child = member(runtime, name)
            if child.exists():
                if not child.is_dir():
                    raise ValueError('Recorder runtime path is not a directory')
                locks.enter_context(_lock(child, '.gate-desk.lock'))
        yield


def _atomic_text(path, value):
    temporary = path.with_name(path.name + '-' + uuid.uuid4().hex + '.tmp')
    with temporary.open('w', encoding='utf-8', newline='') as stream:
        stream.write(value); stream.flush(); os.fsync(stream.fileno())
    os.replace(temporary, path)


def _write_marker(target, info):
    _atomic_text(target/'installation.json', json.dumps(info, indent=2)+'\n')


def _activate(target, version, previous, action):
    info = dict(schema_version=1, active_version=version, runtime='runtime-data',
                previous_version=previous['active_version'] if previous else None,
                activation_action=action, preserves_previous_versions=True,
                production_approved=False, installer='per_user_offline_script')
    _write_marker(target, info)  # One authoritative atomic activation pointer.
    return {**info, 'installed': str(target/'versions'/version),
            'launcher': str(target/'Gate Desk.cmd'), 'runtime': str(target/'runtime-data'),
            'runtime_modified': False, 'lock_bookkeeping_touched': True}


def install(payload, install_dir):
    payload, target = Path(payload).resolve(strict=True), _target(install_dir)
    manifest = verify(payload)  # Fail before mutation on corruption.
    if target == payload or target.is_relative_to(payload) or payload.is_relative_to(target):
        raise ValueError('Installation and payload must be separate directories')
    previous = _installation(target, allow_empty=True)
    destination = member(target, 'versions/'+manifest['version'])
    if destination.exists():
        raise ValueError('Version already installed; existing code and runtime were not overwritten')
    with _cold_installation(target):
        # Re-read after installer ownership in case another installer won a race.
        if previous is not None:
            previous = _installation(target)
        if destination.exists():
            raise ValueError('Version already installed; existing code and runtime were not overwritten')
        versions = target/'versions'; versions.mkdir(exist_ok=True)
        staging = versions/('.staging-'+uuid.uuid4().hex)
        shutil.copytree(payload, staging)
        verify(staging)
        staging.rename(destination)
        # New bootstrap can launch the old active marker if activation is
        # interrupted. It remains in a retained immutable version on rollback.
        v = manifest['version']
        _atomic_text(target/'launch-installed.py', Path(__file__).read_text(encoding='utf-8'))
        launch = ('@echo off\r\nsetlocal\r\n"%~dp0versions\\'+v+
                  '\\runtime\\python.exe" -I -B "%~dp0launch-installed.py" '
                  '--launch-installed --install-dir "%~dp0." %*\r\n')
        _atomic_text(target/'Gate Desk.cmd', launch)
        if (destination/'desktop.py').is_file():
            # Keep pre-window verification/refusal visible, including rollback
            # to an older version without a desktop entry point.
            desktop = launch.replace('--launch-installed', '--launch-desktop') + 'if errorlevel 1 pause\r\n'
            _atomic_text(target/'Gate Desk Desktop.cmd', desktop)
        stop = launch.replace('%*\r\n', '--request-stop %*\r\n')
        _atomic_text(target/'Stop-GateDesk.cmd', stop)
        return _activate(target, v, previous, 'install' if previous is None else 'upgrade')


def rollback(install_dir, version):
    target = _target(install_dir)
    version = _version(version)
    previous = _installation(target)
    destination = member(target, 'versions/'+version)
    if previous['active_version'] == version:
        raise ValueError('Requested version is already active')
    with _cold_installation(target):
        previous = _installation(target)
        # Verify once under every installation/runtime ownership lock. A full
        # scan before these locks adds work without authorizing activation;
        # verification must still be fresh inside the owned section.
        manifest = verify(destination)
        if manifest['version'] != version:
            raise ValueError('Installed version identity mismatch')
        if previous['active_version'] == version:
            raise ValueError('Requested version is already active')
        return _activate(target, version, previous, 'rollback')


def launch_command(install_dir, arguments=(), *, desktop=False):
    target = _target(install_dir)
    info = _installation(target)
    destination = member(target, 'versions/'+info['active_version'])
    manifest = verify(destination)
    if manifest['version'] != info['active_version']:
        raise ValueError('Installed version identity mismatch')
    if any(arg == '--runtime-dir' or arg.startswith('--runtime-dir=') for arg in arguments):
        raise ValueError('Installed runtime directory cannot be overridden')
    if desktop:
        if any(arg == '--bundle' or arg.startswith('--bundle=') for arg in arguments):
            raise ValueError('Installed desktop bundle cannot be overridden')
        if not (destination/'desktop.py').is_file() or not (destination/'runtime/pythonw.exe').is_file():
            raise ValueError('Selected version has no desktop entry point; use Gate Desk.cmd')
        options = argparse.ArgumentParser(add_help=False, allow_abbrev=False)
        options.add_argument('--port', type=int)
        selected, unknown = options.parse_known_args(arguments)
        if unknown:raise ValueError('Unsupported desktop arguments')
        if selected.port is not None and not 1024 <= selected.port <= 65535:
            raise ValueError('Invalid local port')
        arguments = ['--port', str(selected.port)] if selected.port is not None else []
        return [str(destination/'runtime/pythonw.exe'), '-I', '-B', str(destination/'desktop.py'),
                '--runtime-dir', str(target/'runtime-data'), *arguments]
    # Validate here as retained older bundles can still accept abbreviated options.
    # Only canonical options may follow the installation-owned runtime argument.
    options = argparse.ArgumentParser(add_help=False, allow_abbrev=False)
    options.add_argument('--port', type=int)
    options.add_argument('--document-dir')
    options.add_argument('--phone-config')
    options.add_argument('--restart-phone-handoff')
    options.add_argument('--wait-seconds', type=float)
    for flag in ('--verify-only', '--request-stop', '--help'):
        options.add_argument(flag, action='store_true')
    selected, unknown = options.parse_known_args(arguments)
    if unknown:
        raise ValueError('Unsupported console arguments')
    if selected.phone_config is not None and (selected.verify_only or selected.request_stop):
        raise ValueError('Phone activation cannot be combined with verification or stop')
    if selected.restart_phone_handoff is not None and (selected.phone_config is not None or selected.verify_only or selected.request_stop):
        raise ValueError('Phone restart handoff cannot be combined with activation, verification or stop')
    arguments = []
    for name in ('verify_only', 'request_stop', 'help'):
        if getattr(selected, name):
            arguments.append('--' + name.replace('_', '-'))
    for name in ('port', 'document_dir', 'phone_config', 'restart_phone_handoff', 'wait_seconds'):
        value = getattr(selected, name)
        if value is not None:
            arguments.append('--' + name.replace('_', '-') + '=' + str(value))
    return [str(destination/'runtime/python.exe'), '-I', '-B', str(destination/'launch.py'),
            '--runtime-dir', str(target/'runtime-data'), *arguments]


def exec_installed(command):
    # Both supported installed entries are customer profiles. A fresh factory
    # must reach first-owner setup without a shell setting or role-selector
    # authorization. Only this launched process and its children inherit it;
    # the separate source/developer demo entry is unchanged.
    os.environ['GATE_DESK_ACCOUNTS'] = '1'
    os.environ['GATE_DESK_OWNER_PC'] = '1'
    # Windows CRT execv joins argv without quoting. Encode each literal argument
    # using the same MS C-runtime rules as subprocess, without introducing a shell.
    arguments = ([subprocess.list2cmdline([value]) for value in command]
                 if os.name == 'nt' else command)
    os.execv(command[0], arguments)


def main():
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    parser.add_argument('--payload', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--install-dir', type=Path, default=Path(os.environ.get('LOCALAPPDATA', Path.home()))/'GateDesk')
    modes = parser.add_mutually_exclusive_group()
    parser.add_argument('--verify-only', action='store_true')
    modes.add_argument('--rollback-to', metavar='VERSION')
    modes.add_argument('--launch-installed', action='store_true')
    modes.add_argument('--launch-desktop', action='store_true')
    args, extra = parser.parse_known_args()
    if args.launch_desktop:
        if args.verify_only:parser.error('--verify-only cannot be combined with --launch-desktop')
        command = launch_command(args.install_dir, extra, desktop=True)
        exec_installed(command)
    if args.launch_installed:
        command = launch_command(args.install_dir, extra + (['--verify-only'] if args.verify_only else []))
        exec_installed(command)
    if args.rollback_to and args.verify_only:
        parser.error('--verify-only cannot be combined with --rollback-to')
    if extra:
        parser.error('Unrecognized arguments: ' + ' '.join(extra))
    result = (verify(args.payload) if args.verify_only else
              rollback(args.install_dir, args.rollback_to) if args.rollback_to else
              install(args.payload, args.install_dir))
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
