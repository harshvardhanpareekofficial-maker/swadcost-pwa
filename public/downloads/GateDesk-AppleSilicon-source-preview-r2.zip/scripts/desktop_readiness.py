"""Loopback readiness bound to one child, generation and per-launch secret.

Not application authorization or proof of model/camera health. The HTTP probe
uses a fresh challenge; an unrelated listener cannot echo a bearer token to
impersonate readiness. Local control records retain their existing validation.
"""
import hashlib
import hmac
import json
import re
import secrets
import socket
import time

from scripts.runtime_control import ControlTree, ControlError, ProcessWitness, _identity

PATH = '/_gate/desktop-ready'
ENV_KEY = 'GATE_DESK_DESKTOP_READY_KEY'
HEX = re.compile(r'[0-9a-f]{64}\Z')


def key_bytes(key):
    if not isinstance(key, str) or not HEX.fullmatch(key):
        raise ValueError('Invalid desktop readiness key')
    return bytes.fromhex(key)


def proof(key, challenge, identity):
    message = json.dumps({'challenge': challenge, 'identity': identity},
                         sort_keys=True, separators=(',', ':')).encode()
    return hmac.new(key_bytes(key), message, hashlib.sha256).hexdigest()


class ReadinessEndpoint:
    def __init__(self, key, identity, is_ready):
        key_bytes(key)
        self.key, self.identity, self.is_ready = key, dict(identity), is_ready

    async def handle(self, scope, send):
        if scope['type'] != 'http' or scope.get('path') != PATH:
            return False
        values = [v for k, v in scope.get('headers', []) if k == b'x-gate-challenge']
        challenge = values[0].decode('ascii', errors='replace') if len(values) == 1 else ''
        local = scope.get('client') and scope['client'][0] == '127.0.0.1'
        valid = local and scope.get('method') == 'GET' and HEX.fullmatch(challenge)
        status, body = 404, b'{}'
        if valid:
            status = 200 if self.is_ready() else 503
            if status == 200:
                body = json.dumps({'identity': self.identity,
                                   'proof': proof(self.key, challenge, self.identity)},
                                  separators=(',', ':')).encode()
        await send({'type': 'http.response.start', 'status': status, 'headers': [
            (b'content-type', b'application/json'), (b'cache-control', b'no-store'),
            (b'content-length', str(len(body)).encode())]})
        await send({'type': 'http.response.body', 'body': body})
        return True


def _get(port, challenge, seconds):
    """Fixed loopback address, no proxy/redirect, bounded bytes and total socket time."""
    deadline = time.monotonic() + seconds
    def remaining():
        left = deadline - time.monotonic()
        if left <= 0:
            raise TimeoutError('Readiness probe deadline')
        return left
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as connection:
        connection.settimeout(remaining())
        connection.connect(('127.0.0.1', port))
        request = (f'GET {PATH} HTTP/1.0\r\nHost: 127.0.0.1:{port}\r\n'
                   f'X-Gate-Challenge: {challenge}\r\nConnection: close\r\n\r\n').encode()
        connection.settimeout(remaining())
        connection.sendall(request)
        data = b''
        while len(data) <= 8192:
            connection.settimeout(remaining())
            part = connection.recv(min(1024, 8193-len(data)))
            if not part:
                break
            data += part
        remaining()
    if len(data) > 8192:
        raise ValueError('Oversized readiness response')
    head, body = data.split(b'\r\n\r\n', 1)
    lines = head.split(b'\r\n')
    if lines[0] not in (b'HTTP/1.0 200 OK', b'HTTP/1.1 200 OK'):
        return None
    lengths = [line.split(b':', 1)[1].strip() for line in lines[1:]
               if line.lower().startswith(b'content-length:')]
    if len(lengths) != 1 or int(lengths[0]) != len(body):
        raise ValueError('Invalid readiness response length')
    return json.loads(body)


class ChildReadinessProbe:
    def __init__(self, runtime, port, key, *, probe_seconds=.3):
        key_bytes(key)
        if type(port) is not int or not 1024 <= port <= 65535:
            raise ValueError('Invalid desktop port')
        if not 0 < probe_seconds <= 1:
            raise ValueError('Invalid probe bound')
        self.tree, self.port, self.key = ControlTree(runtime), port, key
        self.seconds = probe_seconds
        self.accepted_identity = None

    def __call__(self, process):
        self.accepted_identity = None
        try:
            if process.poll() is not None:
                return False
            record = self.tree.read('owner.json')
            identity = _identity(self.tree, record, owner=True)
            if record['state'] != 'running' or identity['pid'] != process.pid:
                return False
            if self.tree.read('identity.json', generation=identity['generation']) != identity:
                return False
            with ProcessWitness(process.pid, identity['created']) as witness:
                if witness.exited():
                    return False
                challenge = secrets.token_hex(32)
                response = _get(self.port, challenge, self.seconds)
                if (not isinstance(response, dict) or set(response) != {'identity', 'proof'}
                        or response['identity'] != identity or not isinstance(response['proof'], str)
                        or not hmac.compare_digest(response['proof'], proof(self.key, challenge, identity))):
                    return False
                if (witness.exited() or process.poll() is not None
                        or self.tree.read('owner.json') != record):
                    return False
                self.accepted_identity = identity
                return True
        except (ControlError, OSError, ValueError, TypeError, KeyError):
            return False
