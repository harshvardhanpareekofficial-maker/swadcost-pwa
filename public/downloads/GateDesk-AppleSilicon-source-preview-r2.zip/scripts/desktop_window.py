"""Native Win32 shell around the reviewed source desktop controller.

No third-party GUI runtime. This is source code, not an installed EXE/MSIX or
Windows service. Only this application's own window is operated here. Ordinary
close keeps the window and non-daemon owner worker until child settlement;
forced OS termination and destructive external window manipulation are outside
that contract. Bundle verification and app lifetime run off the UI thread.
"""
import argparse
import ctypes as c
from ctypes import wintypes as w
from pathlib import Path
import queue
import signal
import threading
import uuid

from scripts.desktop_host import DesktopHost, run_console

WM_CLOSE, WM_DESTROY, WM_COMMAND, WM_TIMER = 0x10, 2, 0x111, 0x113
OPEN, STOP = 101, 102
LRESULT = c.c_ssize_t
WNDPROC = c.WINFUNCTYPE(LRESULT, w.HWND, w.UINT, w.WPARAM, w.LPARAM)


class WNDCLASS(c.Structure):
    _fields_ = [('style', w.UINT), ('lpfnWndProc', WNDPROC),
                ('cbClsExtra', c.c_int), ('cbWndExtra', c.c_int),
                ('hInstance', w.HINSTANCE), ('hIcon', w.HICON),
                ('hCursor', w.HANDLE), ('hbrBackground', w.HBRUSH),
                ('lpszMenuName', w.LPCWSTR), ('lpszClassName', w.LPCWSTR)]


def api():
    user = c.WinDLL('user32', use_last_error=True)
    kernel = c.WinDLL('kernel32', use_last_error=True)
    shell = c.WinDLL('shell32', use_last_error=True)
    gdi = c.WinDLL('gdi32', use_last_error=True)
    signatures = {
        'RegisterClassW': ([c.POINTER(WNDCLASS)], w.ATOM),
        'UnregisterClassW': ([w.LPCWSTR, w.HINSTANCE], w.BOOL),
        'CreateWindowExW': ([w.DWORD, w.LPCWSTR, w.LPCWSTR, w.DWORD,
                            c.c_int, c.c_int, c.c_int, c.c_int,
                            w.HWND, w.HMENU, w.HINSTANCE, w.LPVOID], w.HWND),
        'DefWindowProcW': ([w.HWND, w.UINT, w.WPARAM, w.LPARAM], LRESULT),
        'DestroyWindow': ([w.HWND], w.BOOL),
        'IsWindow': ([w.HWND], w.BOOL),
        'ShowWindow': ([w.HWND, c.c_int], w.BOOL),
        'SetWindowTextW': ([w.HWND, w.LPCWSTR], w.BOOL),
        'EnableWindow': ([w.HWND, w.BOOL], w.BOOL),
        'SetTimer': ([w.HWND, c.c_size_t, w.UINT, w.LPVOID], c.c_size_t),
        'KillTimer': ([w.HWND, c.c_size_t], w.BOOL),
        'GetMessageW': ([c.POINTER(w.MSG), w.HWND, w.UINT, w.UINT], w.BOOL),
        'PeekMessageW': ([c.POINTER(w.MSG), w.HWND, w.UINT, w.UINT, w.UINT], w.BOOL),
        'TranslateMessage': ([c.POINTER(w.MSG)], w.BOOL),
        'DispatchMessageW': ([c.POINTER(w.MSG)], LRESULT),
        'SendMessageW': ([w.HWND, w.UINT, w.WPARAM, w.LPARAM], LRESULT),
        'PostQuitMessage': ([c.c_int], None),
    }
    for name, (args, result) in signatures.items():
        fn = getattr(user, name); fn.argtypes = args; fn.restype = result
    kernel.GetModuleHandleW.argtypes = [w.LPCWSTR]
    kernel.GetModuleHandleW.restype = w.HMODULE
    shell.ShellExecuteW.argtypes = [w.HWND,w.LPCWSTR,w.LPCWSTR,w.LPCWSTR,w.LPCWSTR,c.c_int]
    shell.ShellExecuteW.restype = w.HINSTANCE
    gdi.GetStockObject.argtypes = [c.c_int]; gdi.GetStockObject.restype = w.HANDLE
    return user, kernel, shell, gdi


class DesktopWindow:
    def __init__(self, host, *, show=True, tick_hook=None):
        self.host, self.show, self.tick_hook = host, show, tick_hook
        self.user, self.kernel, self.shell, self.gdi = api()
        self.instance = self.kernel.GetModuleHandleW(None)
        self.class_name = 'GateDeskHost_' + uuid.uuid4().hex
        self.callback = WNDPROC(self._dispatch)  # Retain for the full HWND lifetime.
        self.hwnd = self.status = self.open_button = self.stop_button = None
        self.worker = None
        self.messages = queue.SimpleQueue()
        self.result = None
        self.ui_failed = False
        self.close_pending = False
        self.last_status = None

    def _work(self):
        try:
            self.result = run_console(self.host, self.messages.put)
        except BaseException:
            self.result = 3
            self.host.request_close()
            # Last-resort retention, never a forced shutdown or auto-retry.
            while self.host.alive:
                threading.Event().wait(.1)

    def _settled(self):
        return (self.worker is not None and not self.worker.is_alive()
                and not self.host.alive)

    def request_close(self):
        self.close_pending = True
        self.host.request_close()

    def _tick(self):
        if self.host.signal_pending:self.request_close()
        while not self.messages.empty():
            self.messages.get()
        state = self.host.state
        labels = {
            'new': 'Preparing Gate Desk...', 'verifying': 'Checking application files...',
            'starting': 'Starting Gate Desk...', 'ready': 'Gate Desk is running on this PC.',
            'stopping': 'Stopping safely. Please keep this window open.',
            'stop_incomplete': 'Stop incomplete. Keeping the application owned until it exits.',
            'failed': 'Gate Desk could not start. Check the local application log.',
            'closed_clean': 'Gate Desk stopped safely.',
            'closed_unverified': 'Gate Desk exited. A clean stop was not confirmed.',
        }
        text = labels.get(state, 'Gate Desk is working...')
        if self.close_pending and not self._settled() and state != 'stop_incomplete':
            text = 'Close requested. Waiting for Gate Desk to stop safely...'
        if text != self.last_status:
            if not self.user.SetWindowTextW(self.status, text):raise c.WinError(c.get_last_error())
            self.last_status = text
        self.user.EnableWindow(self.open_button, state == 'ready' and not self.close_pending)
        self.user.SetWindowTextW(self.stop_button, 'Close' if self._settled() else 'Stop and close')
        if self.tick_hook is not None:
            self.tick_hook(self)  # Trusted test observer, never a CLI option.
        if self.close_pending and self._settled():
            self.worker.join()
            self.user.DestroyWindow(self.hwnd)

    def _dispatch(self, hwnd, message, wp, lp):
        try:
            if self.ui_failed and message in (WM_CLOSE, WM_TIMER):
                # Rendering may keep failing. Settlement must not depend on
                # another successful paint/status update or test callback.
                self.request_close()
                if self._settled():
                    self.worker.join()
                    self.user.DestroyWindow(hwnd)
                return 0
            if message == WM_CLOSE:
                self.request_close()
                return 0  # Never delegate WM_CLOSE to default destruction.
            if message == WM_COMMAND:
                if wp & 0xffff == STOP:
                    self.request_close()
                elif wp & 0xffff == OPEN and not self.close_pending:
                    try:url = self.host.url
                    except RuntimeError:return 0
                    result = self.shell.ShellExecuteW(hwnd, 'open', url, None, None, 1)
                    if not result or result <= 32:
                        self.user.SetWindowTextW(self.status, 'Could not open the browser. Try again.')
                return 0
            if message == WM_TIMER:
                self._tick(); return 0
            if message == 0x11:  # WM_QUERYENDSESSION: request graceful close first.
                self.request_close()
                return int(self._settled())
            if message == WM_DESTROY:
                self.host.request_close()
                self.user.PostQuitMessage(0)
                return 0
            return self.user.DefWindowProcW(hwnd, message, wp, lp)
        except BaseException:
            # ctypes callbacks must not leak exceptions into Win32.
            self.ui_failed = True
            self.request_close()
            return 0

    def _control(self, kind, text, x, y, width, height, identifier=0):
        handle = self.user.CreateWindowExW(0, kind, text, 0x50000000 | (0x10000 if kind=='BUTTON' else 0),
                                          x,y,width,height,self.hwnd,identifier,self.instance,None)
        if not handle:raise c.WinError(c.get_last_error())
        self.user.SendMessageW(handle,0x30,self.gdi.GetStockObject(17),1)  # WM_SETFONT.
        return handle

    def run(self):
        wc=WNDCLASS();wc.lpfnWndProc=self.callback;wc.hInstance=self.instance
        wc.lpszClassName=self.class_name;wc.hbrBackground=16  # COLOR_BTNFACE+1.
        if not self.user.RegisterClassW(c.byref(wc)):raise c.WinError(c.get_last_error())
        try:
            self.hwnd=self.user.CreateWindowExW(0,self.class_name,'Gate Desk',0x00CA0000,
                                               0x80000000,0x80000000,540,215,None,None,self.instance,None)
            if not self.hwnd:raise c.WinError(c.get_last_error())
            self.status=self._control('STATIC','Preparing Gate Desk...',20,22,490,55)
            self.open_button=self._control('BUTTON','Open Gate Desk',20,105,180,34,OPEN)
            self.stop_button=self._control('BUTTON','Stop and close',310,105,180,34,STOP)
            self.user.EnableWindow(self.open_button,False)
            if not self.user.SetTimer(self.hwnd,1,100,None):raise c.WinError(c.get_last_error())
            self.worker=threading.Thread(target=self._work,name='gate-desktop-owner',daemon=False)
            self.worker.start()
            if self.show:self.user.ShowWindow(self.hwnd,1)
            msg=w.MSG()
            while True:
                result=self.user.GetMessageW(c.byref(msg),None,0,0)
                if result == -1:
                    self.ui_failed=True;break
                if result == 0:break
                self.user.TranslateMessage(c.byref(msg))
                self.user.DispatchMessageW(c.byref(msg))
        finally:
            self.host.request_close()
            # Even message-loop failure cannot detach a live worker/child.
            if self.worker is not None:
                while self.worker.is_alive():
                    try:self.worker.join(.1)
                    except BaseException:self.ui_failed=True
            if self.hwnd and self.user.IsWindow(self.hwnd):
                self.user.KillTimer(self.hwnd,1)
                self.user.DestroyWindow(self.hwnd)
                # Consume our cleanup WM_QUIT so another test loop is independent.
                msg=w.MSG();self.user.PeekMessageW(c.byref(msg),None,0x12,0x12,1)
            self.user.UnregisterClassW(self.class_name,self.instance)
        return 3 if self.ui_failed or self.result != 0 else 0


def main():
    parser=argparse.ArgumentParser(description=__doc__,allow_abbrev=False)
    parser.add_argument('--bundle',required=True,type=Path)
    parser.add_argument('--runtime-dir',required=True,type=Path)
    parser.add_argument('--port',type=int,default=8765)
    args=parser.parse_args()
    host=DesktopHost(args.bundle,args.runtime_dir,port=args.port)
    window=DesktopWindow(host)
    previous={}
    try:
        for name in ('SIGINT','SIGBREAK','SIGTERM'):
            number=getattr(signal,name,None)
            if number is not None:previous[number]=signal.signal(number,host.signal_close)
        return window.run()
    finally:
        for number,handler in previous.items():signal.signal(number,handler)


if __name__=='__main__':
    raise SystemExit(main())
