"""Consume an owner-prepared local restart handoff using verified source bytes.

Run with the matching locked Python runtime. This helper requires a complete
source-manifest.json bundle; an arbitrary source checkout is not sufficient.
No passwords in arguments/environment, no force kill, no detached successor.
"""
import argparse
from pathlib import Path
import re
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    parser.add_argument('--runtime-dir', type=Path, required=True)
    parser.add_argument('--handoff-id', required=True, help='Fresh UUID displayed by owner phone setup')
    parser.add_argument('--document-dir', type=Path, help='Existing external document folder, only if this runtime uses one')
    parser.add_argument('--wait-seconds', type=float, default=110,
                        help='Bounded clean-stop wait (1..120); late settlement is contained but never starts a successor')
    args = parser.parse_args()
    if not re.fullmatch(r'[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}', args.handoff_id):
        parser.error('A canonical fresh restart UUID is required')
    root = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(root))
    from scripts import launch_offline_source as launcher
    # The regular launcher verifies source/dependencies before consuming anything.
    previous = sys.argv[:]
    sys.argv[:] = ['launch_offline_source', '--runtime-dir', str(args.runtime_dir),
                   '--restart-phone-handoff', args.handoff_id, '--wait-seconds', str(args.wait_seconds)]
    if args.document_dir is not None:
        sys.argv.extend(['--document-dir', str(args.document_dir)])
    try:
        return launcher.main()
    finally:
        sys.argv[:] = previous


if __name__ == '__main__':
    raise SystemExit(main())
