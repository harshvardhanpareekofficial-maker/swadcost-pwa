"""Source desktop-host controller; console entry point, not a native GUI/service.

Run from reviewed source with ``python -B -m scripts.desktop_host --bundle ...
--runtime-dir ...``. Bundle hashes detect corruption, not publisher identity.
The selected bundle must stay immutable; this is not an adversarial filesystem
sandbox. An incomplete cooperative stop retains the child and host indefinitely.
Abrupt host death containment and packaged/native launch remain separate gates.
"""
import argparse
from dataclasses import dataclass
import os
from pathlib import Path
import secrets
import signal
import threading
import time

from scripts.desktop_process_lease import DesktopProcessLease, IncompleteStop, bundle_command, local_path
from scripts.desktop_readiness import ChildReadinessProbe, ENV_KEY
from scripts.package_windows_install import verify


@dataclass(frozen=True)
class LaunchPlan:
    command: tuple
    cwd: Path
    version: str


def verified_bundle(bundle, runtime, port):
    # Validate local paths and tree separation before scanning or spawning.
    command = bundle_command(bundle, runtime, port)
    manifest = verify(bundle)
    return LaunchPlan(tuple(command), local_path(bundle), manifest['version'])


class StartupCancelled(RuntimeError):
    pass


class DesktopHost:
    """One owner thread; request_close is ordinary cross-thread input.

    Signal handlers use only signal_close, a scalar latch without Event locks.

    selector is a trusted internal integration seam, never CLI-supplied code.
    Public CLI always uses verified_bundle. The caller must retain this host
    after IncompleteStop, or use run_console which keeps it until child exit.
    """
    def __init__(self, bundle, runtime, *, port=8765, ready_seconds=45,
                 stop_seconds=20, selector=verified_bundle):
        self.bundle, self.runtime = local_path(bundle), local_path(runtime)
        if self.bundle.is_relative_to(self.runtime) or self.runtime.is_relative_to(self.bundle):
            raise ValueError('Runtime must be separate from application files')
        if type(port) is not int or not 1024 <= port <= 65535:
            raise ValueError('Invalid local port')
        if not 0 < ready_seconds <= 120:
            raise ValueError('Invalid readiness bound')
        self.port, self.ready_seconds = port, ready_seconds
        self.selector = selector
        self.lease = DesktopProcessLease(self.runtime, stop_seconds=stop_seconds)
        self.close_requested = threading.Event()
        self.signal_pending = False
        self.state = 'new'
        self.version = None
        self.probe = None
        self.log_path = None

    @property
    def alive(self):
        return self.lease.process is not None and self.lease.process.poll() is None

    @property
    def url(self):
        if self.state != 'ready' or not self.alive:
            raise RuntimeError('Application is not ready')
        return f'http://127.0.0.1:{self.port}/'

    def request_close(self, *_):
        self.close_requested.set()

    def signal_close(self, *_):
        # Python handlers can interrupt Event.wait/set while its non-reentrant
        # Condition is locked. The handler must not acquire that lock.
        self.signal_pending = True

    def closing(self):
        return self.signal_pending or self.close_requested.is_set()

    def start(self):
        if self.state != 'new':
            raise RuntimeError('Host session already used')
        self.state = 'verifying'
        try:
            if self.closing():
                raise StartupCancelled('Close requested before launch')
            plan = self.selector(self.bundle, self.runtime, self.port)
            if self.closing():
                raise StartupCancelled('Close requested during verification')
            self.version = plan.version
            key = secrets.token_hex(32)
            self.probe = ChildReadinessProbe(self.runtime, self.port, key)
            env = dict(os.environ)
            env[ENV_KEY] = key
            self.runtime.mkdir(parents=True, exist_ok=True)
            logs = local_path(self.runtime/'desktop-host')
            logs.mkdir(exist_ok=True)
            self.log_path = logs/('application-' + secrets.token_hex(12) + '.log')
            def ready(process):
                if self.closing():
                    raise StartupCancelled('Close requested during startup')
                return self.probe(process)
            self.state = 'starting'
            self.lease.start(plan.command, cwd=plan.cwd, log_path=self.log_path,
                             ready=ready, ready_seconds=self.ready_seconds, env=env)
            self.state = 'ready'
            return self
        except BaseException:
            self.state = 'stop_incomplete' if self.alive else 'failed'
            raise

    def close(self):
        self.close_requested.set()
        self.state = 'stopping'
        try:
            clean = self.lease.stop()
        except IncompleteStop:
            self.state = 'stop_incomplete'
            raise
        self.state = 'closed_clean' if clean else 'closed_unverified'
        return clean


def run_console(host, report=print):
    """Signal-driven host with a non-retrying keeper after incomplete stop.

    The keeper does not force-kill or declare a timeout clean. It only observes
    the retained process handle. Filesystem verification has no hard deadline.
    """
    def emit(message):
        try:
            report(message)
        except BaseException:
            # A closed stdout pipe/UI reporting failure cannot release a child.
            host.request_close()
    failed = False
    try:
        host.start()
        emit('Gate Desk ready: ' + host.url)
        emit('Press Ctrl+C to request a cooperative stop.')
        while host.alive and not host.closing():
            time.sleep(.1)
    except BaseException as error:
        failed = True
        # Never print arbitrary exception text or the launch environment.
        emit('Gate Desk launch failed: ' + type(error).__name__)
    finally:
        # start() already attempted a bounded stop if it raised with a live
        # child. Do not automatically repeat that failed stop attempt.
        try:
            if host.state != 'stop_incomplete':
                clean = host.close()
                failed = failed or not clean
            else:
                failed = True
        except BaseException:
            failed = True
        if host.alive:
            emit('Stop incomplete. Host remains open and retains the application. No forced stop.')
            while host.alive:
                try:
                    time.sleep(.1)
                except BaseException:
                    # Even an explicit Python interruption cannot discard a
                    # live child's lease. OS process termination is not caught.
                    failed = True
            host.close()  # Only releases after observed exit; no new stop request.
    return 3 if failed else 0


def main():
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    parser.add_argument('--bundle', required=True, type=Path)
    parser.add_argument('--runtime-dir', required=True, type=Path)
    parser.add_argument('--port', default=8765, type=int)
    args = parser.parse_args()
    host = DesktopHost(args.bundle, args.runtime_dir, port=args.port)
    previous = {}
    try:
        for name in ('SIGINT', 'SIGBREAK', 'SIGTERM'):
            number = getattr(signal, name, None)
            if number is not None:
                previous[number] = signal.signal(number, host.signal_close)
        return run_console(host)
    finally:
        for number, handler in previous.items():
            signal.signal(number, handler)


if __name__ == '__main__':
    raise SystemExit(main())
