"""Opt-in installed-runtime ownership adapter with explicit TLS admission.

The owner-only default does not activate this adapter. Deployment requires a
single-use prepared activation bound to exact settings and server SSLContext.
This module never loads keys or changes trust. A local diagnostic is a separate
mode whose trusted fixture caller remains responsible for certificate admission.

RFC1918 deployment settings remain unchanged and retain their canonical origin.
The explicitly separate diagnostic transport binds only 127.0.0.1, on the same
declared TLS port. A diagnostic client must deliberately connect locally while
verifying the declared DNS name/Host; this is NOT phone/LAN deployment. Numeric
private origins are rejected in diagnostic mode because they cannot describe it.
Admitted deployment binds only the configured RFC1918 TLS address, preserving
loopback-only PC HTTP and both exact retained reservations.
No second owner, loop, wrapper, provisioning or port fallback is introduced.
"""
import asyncio
from contextlib import ExitStack
import importlib
import signal
import ssl
import threading
from urllib.parse import urlsplit

from app import runtime_owner as ro
from app.camera_setup import install_local_camera_setup
from app.phone_setup_routes import install_local_phone_setup
from app.phone_loading_routes import install_local_phone_loading
from app.dual_transport import DualTransport
from app.mobile_config import parse_mobile_config
from app.pc_phone_host import compose_pc_phone_host
from app.runtime_server import reserve_loopback_listener, reserve_private_listener
from scripts.desktop_readiness import ReadinessEndpoint, key_bytes
from scripts.runtime_control import ControlTree, publish_owner, stop_requested
from scripts.runtime_dual_loop import make_loop
from scripts.runtime_lock import runtime_lock


def _admit(enabled, local_diagnostic, settings, tls_context, http_port, readiness_key,
           deployment_admission=None):
    if type(enabled) is not bool:
        raise ValueError('pc_phone_explicit_enabled_required')
    if not enabled:
        return None
    if type(local_diagnostic) is not bool or (not local_diagnostic and deployment_admission is None):
        raise ValueError('pc_phone_deployment_transport_not_admitted')
    if local_diagnostic and deployment_admission is not None:
        raise ValueError('pc_phone_mixed_activation_modes')
    config = parse_mobile_config(settings)
    if config is None:
        raise ValueError('pc_phone_enabled_settings_required')
    if local_diagnostic and urlsplit(config.canonical_origin).hostname.replace('.', '').isdigit():
        raise ValueError('pc_phone_diagnostic_dns_origin_required')
    if type(http_port) is not int or not 1024 <= http_port <= 65535 or http_port == config.port:
        raise ValueError('pc_phone_distinct_desktop_port_required')
    if not isinstance(tls_context, ssl.SSLContext) or tls_context.protocol != ssl.PROTOCOL_TLS_SERVER:
        raise ValueError('pc_phone_server_context_required')
    key_bytes(readiness_key)
    if threading.current_thread() is not threading.main_thread():
        raise ValueError('pc_phone_main_thread_required')
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        pass
    else:
        raise ValueError('pc_phone_existing_loop_not_supported')
    if ro.current_owner() is not None:
        raise ValueError('pc_phone_existing_owner_not_supported')
    if not local_diagnostic:
        from app.mobile_activation import validate_prepared_activation
        validate_prepared_activation(deployment_admission, config, tls_context)
    return config


def _listeners_ready(dual, owner):
    return (dual is not None and not owner.stop_requested.is_set() and owner.accepting
            and not owner.failures and len(dual.servers) == 2
            and all(obs.startup == 1 and not obs.failed for obs in dual.observations)
            and all(server.started and not server.should_exit and not server.force_exit
                    and len(server.listeners) == 1 and server.listeners[0].is_serving()
                    for server in dual.servers))


def _finish_handle(loop, handle, owner, dual):
    """Retain the same task/loop through interrupted observations; never cancel."""
    while not handle.done():
        try:
            loop.run_until_complete(asyncio.shield(handle))
        except BaseException:
            owner.fail('pc_phone_loop_observation_failed')
            if dual is not None:
                dual.request_stop()
            else:
                owner.request_stop()
    return handle.result()


def _hold_loop(loop, owner, dual):
    """Unknown work retains lock, sockets, owner and original loop for containment."""
    owner.fail('pc_phone_loop_ownership_unverified')
    if dual is not None:
        dual.request_stop()
    else:
        owner.request_stop()
    delay = threading.Event()
    while True:
        # Retain a single exact tick through interrupted observations. A closed
        # loop must not accumulate unstarted sleep coroutines or task wrappers.
        try:
            closed = loop.is_closed()
        except BaseException:
            _hold_owned(owner, 'pc_phone_keeper_loop_state_unknown')
        if closed:
            _hold_owned(owner, 'pc_phone_keeper_loop_closed')
        tick_coroutine = asyncio.sleep(.025)
        try:
            tick = loop.create_task(tick_coroutine)
        except BaseException:
            # Keep tick_coroutine and the original loop reachable. A task may
            # have been registered before create_task raised; do not discard it.
            _hold_owned(owner, 'pc_phone_keeper_tick_creation_unknown')
        while not tick.done():
            try:
                closed = loop.is_closed()
            except BaseException:
                _hold_owned(owner, 'pc_phone_keeper_loop_state_unknown')
            if closed:
                _hold_owned(owner, 'pc_phone_keeper_loop_closed')
            try:
                loop.run_until_complete(tick)
            except BaseException:
                owner.fail('pc_phone_keeper_interrupted')
                try:
                    delay.wait(.025)
                except BaseException:
                    pass
        try:
            tick.result()
        except BaseException:
            owner.fail('pc_phone_keeper_interrupted')
            try:
                delay.wait(.025)
            except BaseException:
                pass


def _hold_owned(owner, reason):
    """Retain closed-loop handles/lock; even close errors cannot unwind them."""
    owner.fail(reason)
    delay = threading.Event()
    while True:
        try:
            delay.wait(.025)
        except BaseException:
            owner.fail('pc_phone_keeper_interrupted')


def run_pc_phone(runtime, configure, *, enabled=False, local_diagnostic=False,
                 settings=None, sessions_path=None, tls_context=None,
                 http_port=8765, readiness_key=None, deployment_admission=None):
    """None when disabled; 0/3 only after physical settlement and lock release.

    Unknown ownership deliberately never returns: an external exact-child
    supervisor must contain it. configure() must establish owner-only app.main
    bindings to pre-existing stores, like the installed runtime configurator.
    """
    config = _admit(enabled, local_diagnostic, settings, tls_context, http_port, readiness_key,
                    deployment_admission)
    if config is None:
        return None
    tree = ControlTree(runtime)
    with tree.directories(create=True):
        pass
    lock = runtime_lock(tree.runtime)
    lock.__enter__()
    owner = ro.RuntimeOwner()
    previous = ro.install_owner(owner)
    handlers, sockets = {}, []
    identity = dual = loop = serving = None
    control_stop, published = threading.Event(), threading.Event()
    clean_transport = False
    try:
        for name in ('SIGINT', 'SIGBREAK', 'SIGTERM'):
            sig = getattr(signal, name, None)
            if sig is not None:
                handlers[sig] = signal.getsignal(sig)
                signal.signal(sig, owner.signal_stop)
        with ExitStack() as probes:
            for name in ('camera-supervisor', 'camera-ingest'):
                child = tree.runtime / name
                if child.exists():
                    probes.enter_context(runtime_lock(child))
        identity = publish_owner(tree)
        # Actual exclusive non-listening handles, not close/rebind probes.
        sockets.append(reserve_loopback_listener(http_port))
        tls_bind_address = '127.0.0.1' if local_diagnostic else config.bind_address
        sockets.append(reserve_loopback_listener(config.port) if local_diagnostic
                       else reserve_private_listener(tls_bind_address, config.port))
        loop = make_loop()
        endpoint = ReadinessEndpoint(readiness_key, identity,
                                     lambda: published.is_set() and _listeners_ready(dual, owner))
        with owner.importing():
            configure()
            main = importlib.import_module('app.main')
            install_local_phone_loading(main.app, tree.runtime, http_port, main_module=main)
            install_local_camera_setup(main.app, tree.runtime, http_port)
            install_local_phone_setup(main.app, tree.runtime, http_port,
                generation_provider=lambda: identity if owner.accepting and not owner.stop_requested.is_set() else None,
                running_provider=lambda: ({'state': 'running', 'verified': True,
                    'canonical_origin': config.canonical_origin, 'bind_address': tls_bind_address,
                    'port': config.port, 'factory_id': config.factory_id,
                    'local_diagnostic': local_diagnostic}
                    if published.is_set() and _listeners_ready(dual, owner)
                    else {'state': 'unknown', 'verified': False}))
            host = compose_pc_phone_host(settings, main_module=main, owner=owner,
                                         sessions_path=sessions_path)
        if host is None or host.owner is not owner or host.phone_service.owner is not owner:
            raise ValueError('pc_phone_host_owner_mismatch')
        # Preserve the factory's exact configuration: no loopback rewrite.
        if host.phone_service.config != config:
            raise ValueError('pc_phone_host_config_mismatch')

        async def pc(scope, receive, send):
            if not await endpoint.handle(scope, send):
                await host.pc_app(scope, receive, send)

        dual = DualTransport(owner, pc, host.phone_service.app, http_port=http_port,
                             tls_port=config.port, tls_context=tls_context,
                             generation=identity['generation'],
                             http_socket=sockets[0], tls_socket=sockets[1],
                             tls_bind_address=tls_bind_address)

        def control():
            while not control_stop.wait(.025):
                try:
                    if getattr(owner, 'signal_pending', False) or stop_requested(tree, identity):
                        dual.request_stop()
                    if owner.failures:
                        dual.request_stop()
                    if not published.is_set() and _listeners_ready(dual, owner):
                        tree.publish('owner.json', {**identity, 'state': 'running'}, replace=True)
                        published.set()
                    dual.poll_readiness()
                except BaseException:
                    owner.fail('pc_phone_control_failed')
                    dual.request_stop()

        worker = threading.Thread(target=control, name='gate-pc-phone-control', daemon=False)
        ro.start_thread(worker, control_stop.set, control=True)
        serving = loop.create_task(dual.serve(), name='gate-pc-phone-host')
        clean_transport = bool(_finish_handle(loop, serving, owner, dual))
        if (not dual.settled or not dual.physical_cleanup_verified
                or not dual.reserved_sockets_closed):
            _hold_loop(loop, owner, dual)
        if not clean_transport:
            owner.fail('pc_phone_transport_unclean')
    except BaseException:
        owner.fail('pc_phone_launcher_failed')
    finally:
        if loop is not None:
            # A failed create_task may have registered work before raising.
            # Never release original ownership on an unverified partial start.
            pending = [task for task in asyncio.all_tasks(loop) if not task.done()]
            if pending or (dual is not None and dual.task is not None and not dual.settled):
                _hold_loop(loop, owner, dual)
        owner.drain(include_control=False)
        control_stop.set()
        owner.drain(include_control=True)
        if loop is not None:
            for operation in (loop.shutdown_asyncgens, loop.shutdown_default_executor):
                try:
                    handle = loop.create_task(operation())
                    _finish_handle(loop, handle, owner, dual)
                except BaseException:
                    _hold_loop(loop, owner, dual)
            if [task for task in asyncio.all_tasks(loop) if not task.done()]:
                _hold_loop(loop, owner, dual)
            try:
                loop.close()
                if not loop.is_closed():
                    raise RuntimeError('loop_close_unverified')
            except BaseException:
                _hold_loop(loop, owner, dual)
        try:
            for sock in sockets:
                sock.close()
            if any(sock.fileno() != -1 for sock in sockets):
                raise RuntimeError('reservation_close_unverified')
        except BaseException:
            _hold_owned(owner, 'pc_phone_reservation_close_unverified')
        if not clean_transport:
            owner.fail('pc_phone_lifecycle_unverified')
        outcome = 'clean' if not owner.failures else 'stopped_unclean'
        try:
            if identity is not None:
                tree.publish('terminal.json', {'protocol': 2, 'generation': identity['generation'],
                             'runtime': tree.binding, 'outcome': outcome, 'summary': owner.summary()},
                             generation=identity['generation'])
        except BaseException:
            owner.fail('terminal_publication_failed')
            outcome = 'stopped_unclean'
        lock.__exit__(None, None, None)
        ro.install_owner(previous)
        for sig, handler in handlers.items():
            signal.signal(sig, handler)
    return 0 if outcome == 'clean' else 3
