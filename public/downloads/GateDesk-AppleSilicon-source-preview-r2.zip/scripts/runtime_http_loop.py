"""Explicit pinned Windows HTTP factory for reset-safe socket cleanup.

Private socket override is pinned and local to this loop. TLS is rejected, so
this factory cannot silently bypass the separate TLS transport contract.
"""
import asyncio
from app.proactor_socket_cleanup import ResetSafeSocketTransport, verify_runtime


class ResetSafeHTTPLoop(getattr(asyncio, 'ProactorEventLoop', asyncio.BaseEventLoop)):
    def __new__(cls):
        verify_runtime()  # Before allocating a proactor/self-pipe.
        return super().__new__(cls)

    def _make_socket_transport(self, sock, protocol, waiter=None, extra=None, server=None):
        return ResetSafeSocketTransport(self, sock, protocol, waiter, extra, server)

    def _make_ssl_transport(self, *args, **kwargs):
        raise RuntimeError('reset_http_loop_tls_forbidden')


def make_loop():
    return ResetSafeHTTPLoop()


def experimental_config(app, *, port):
    from app.server_transport import build_server_config
    verify_runtime()
    config = build_server_config(app, port=port)
    config.loop = 'scripts.runtime_http_loop:make_loop'
    return config
