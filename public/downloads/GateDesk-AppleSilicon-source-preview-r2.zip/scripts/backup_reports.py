"""Local reports-only SQLite snapshots; restore to a NEW runtime directory only.

Does not back up media, models, document photographs or annotation stores.
An incomplete directory without manifest.json is never a valid backup.
"""
import argparse
from contextlib import closing
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3
import time


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def readonly(path):
    path = Path(path).resolve(strict=True)
    return sqlite3.connect(path.as_uri() + '?mode=ro', uri=True, timeout=5)


def inspect_snapshot(path):
    with closing(readonly(path)) as db:
        if db.execute('PRAGMA integrity_check').fetchall() != [('ok',)]:
            raise ValueError('SQLite integrity check failed')
        if db.execute('PRAGMA foreign_key_check').fetchall():
            raise ValueError('SQLite foreign-key check failed')
        names = [row[0] for row in db.execute(
            "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")]
        return {name: db.execute('SELECT count(*) FROM "' + name.replace('"', '""') + '"').fetchone()[0]
                for name in names}


def backup(source, output, timeout_seconds=30):
    source, output = Path(source).resolve(strict=True), Path(output).absolute()
    if timeout_seconds <= 0:
        raise ValueError('Backup deadline must be positive')
    # Never copy a live main DB file directly: committed records may be in WAL.
    output.mkdir(parents=True, exist_ok=False)
    target = output/'reports.sqlite3'
    deadline = time.monotonic() + timeout_seconds

    def progress(status, remaining, total):
        if time.monotonic() > deadline:
            raise TimeoutError('Snapshot deadline exceeded; no valid backup was published')

    with closing(readonly(source)) as src, closing(sqlite3.connect(target)) as dst:
        src.backup(dst, pages=256, progress=progress, sleep=0.05)
        dst.execute('PRAGMA journal_mode=DELETE')
    manifest = {
        'schema_version': 1, 'kind': 'gate_desk_reports_only',
        'created_at': datetime.now(timezone.utc).isoformat(),
        'file': 'reports.sqlite3', 'sha256': digest(target),
        'bytes': target.stat().st_size, 'table_rows': inspect_snapshot(target),
        'scope': 'SQLite records only; media, models, photos and annotation files excluded',
    }
    # Manifest is the completion marker; partial/failed snapshots are not reusable.
    with (output/'manifest.json').open('x', encoding='utf-8') as stream:
        json.dump(manifest, stream, indent=2)
        stream.write('\n')
    return manifest


def verify_backup(directory):
    directory = Path(directory)
    manifest = json.loads((directory/'manifest.json').read_text(encoding='utf-8'))
    if (manifest.get('schema_version'), manifest.get('kind'), manifest.get('file')) != (
            1, 'gate_desk_reports_only', 'reports.sqlite3'):
        raise ValueError('Unsupported backup manifest')
    source = directory/'reports.sqlite3'
    if source.is_symlink() or source.stat().st_size != manifest['bytes'] or digest(source) != manifest['sha256']:
        raise ValueError('Backup checksum mismatch')
    if inspect_snapshot(source) != manifest['table_rows']:
        raise ValueError('Backup row inventory mismatch')
    return manifest


def restore(directory, runtime):
    directory, runtime = Path(directory), Path(runtime)
    manifest = verify_backup(directory)
    runtime.mkdir(parents=True, exist_ok=False)  # Never replace an existing runtime.
    target = runtime/'reports.sqlite3'
    with (directory/'reports.sqlite3').open('rb') as src, target.open('xb') as dst:
        shutil.copyfileobj(src, dst)
    if digest(target) != manifest['sha256'] or inspect_snapshot(target) != manifest['table_rows']:
        raise ValueError('Restored snapshot verification failed; do not launch this runtime')
    receipt = {'verified_at': datetime.now(timezone.utc).isoformat(),
               'backup_sha256': manifest['sha256'], 'table_rows': manifest['table_rows'],
               'scope': manifest['scope']}
    (runtime/'restore-receipt.json').write_text(json.dumps(receipt, indent=2)+'\n', encoding='utf-8')
    return receipt


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    take = sub.add_parser('backup')
    take.add_argument('--database', type=Path, required=True)
    take.add_argument('--output', type=Path, required=True)
    put = sub.add_parser('restore')
    put.add_argument('--backup', type=Path, required=True)
    put.add_argument('--new-runtime', type=Path, required=True)
    args = parser.parse_args()
    result = backup(args.database, args.output) if args.command == 'backup' else restore(args.backup, args.new_runtime)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
