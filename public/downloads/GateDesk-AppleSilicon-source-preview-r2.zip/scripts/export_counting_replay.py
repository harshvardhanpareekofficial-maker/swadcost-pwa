"""Bind saved prediction tracks to a local video for review; no decoding or training."""
import argparse
import hashlib
import json
import math
from pathlib import Path


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def export(video, tracks, summary, output):
    video, tracks, summary, output = map(Path, (video, tracks, summary, output))
    if output.exists():
        raise ValueError('Choose a fresh output path')
    if tracks.stat().st_size > 16 * 1024**2:
        raise ValueError('Tracks exceed the bounded review size')
    saved = json.loads(summary.read_text(encoding='utf-8-sig'))
    config = saved['configuration']
    if saved.get('status') != 'experimental_predictions_not_ground_truth':
        raise ValueError('Expected an experimental tracker summary')
    width, height, fps = config['width'], config['height'], config.get('fps')
    axis, line = config.get('axis', 'x'), config.get('line', .5)
    if (type(width) is not int or type(height) is not int or not 0 < width <= 16384
            or not 0 < height <= 16384 or type(fps) not in (int, float)
            or not math.isfinite(fps) or not 0 < fps <= 240 or axis not in ('x', 'y')
            or type(line) not in (int, float) or not math.isfinite(line) or not 0 < line < 1):
        raise ValueError('Explicit valid dimensions, fps and counting geometry required')
    frames = [json.loads(row) for row in tracks.read_text(encoding='utf-8-sig').splitlines() if row.strip()]
    if len(frames) > 50000:
        raise ValueError('Too many review frames')
    previous = -1
    for frame in frames:
        seconds = frame.get('timestamp_seconds')
        if type(seconds) not in (int, float) or not math.isfinite(seconds) or seconds < 0 or seconds <= previous:
            raise ValueError('Explicit increasing timestamps required')
        previous = seconds
        if type(frame.get('visibility_ok')) is not bool or not isinstance(frame.get('tracks'), list):
            raise ValueError('Visibility and track observations required')
    data = {'schema_version': 1, 'video_sha256': digest(video),
            'tracks_sha256': digest(tracks), 'summary_sha256': digest(summary),
            'width': width, 'height': height, 'fps': fps, 'axis': axis, 'line': line,
            'status': 'experimental_predictions_not_ground_truth',
            'binding_basis': 'operator_selected_files_hashed_together_not_independent_source_proof',
            'model_approved': False, 'frames': frames}
    encoded = (json.dumps(data, separators=(',', ':'), allow_nan=False) + '\n').encode()
    if len(encoded) > 16 * 1024**2:
        raise ValueError('Replay exceeds browser review size')
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('xb') as target:
        target.write(encoded)
    return {'output': str(output), 'sha256': digest(output), 'frames': len(frames), 'model_approved': False}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('video', 'tracks', 'summary', 'output'):
        parser.add_argument('--' + name, type=Path, required=True)
    print(json.dumps(export(**vars(parser.parse_args())), indent=2))
