"""Keep installed runtime ownership until real application work has finished."""
from contextlib import ExitStack
import importlib
import json
import signal
import threading

from app.runtime_owner import RuntimeOwner, install_owner, start_thread, wrap_application
from app.server_transport import build_server_config
from app.runtime_server import OwnedServer, LifespanObservation, PhysicalReadiness, reserve_loopback_listener
from app.camera_setup import install_local_camera_setup
from app.phone_setup_routes import install_local_phone_setup
from app.phone_loading_routes import install_local_phone_loading
from scripts.runtime_control import ControlTree, publish_owner, stop_requested
from scripts.runtime_lock import runtime_lock
from scripts.desktop_readiness import ReadinessEndpoint


def run_owned(runtime, configure, *, port=8765, app_factory=None, server_factory=None, readiness_key=None):
    tree=ControlTree(runtime)
    # Validate raw parents before any resolve-based runtime-lock helper.
    with tree.directories(create=True):pass
    lock=runtime_lock(tree.runtime)
    lock.__enter__()
    owner=RuntimeOwner()
    prior=install_owner(owner)
    handlers={}
    identity=None
    server=None
    listener=None
    control_stop=threading.Event()
    control=None
    lifecycle={'startup':False,'shutdown':False}
    observation=LifespanObservation(owner)
    try:
        for name in ('SIGINT','SIGBREAK','SIGTERM'):
            sig=getattr(signal,name,None)
            if sig is not None:
                handlers[sig]=signal.getsignal(sig)
                signal.signal(sig,owner.signal_stop)
        # Old orphan children must not overlap a new application owner.
        with ExitStack() as probes:
            for name in ('camera-supervisor','camera-ingest'):
                child=tree.runtime/name
                if child.exists():probes.enter_context(runtime_lock(child))
        identity=publish_owner(tree)
        # Reserve the actual socket before app configuration/lifespan. The same
        # bound handle is passed to Uvicorn; never probe-close-rebind a port.
        if server_factory is None:
            try:
                listener=reserve_loopback_listener(port)
            except OSError:
                owner.fail('listener_bind_failed')
                raise
        endpoint = ReadinessEndpoint(readiness_key, identity, lambda: (
            lifecycle['startup'] and server is not None and getattr(server, 'started', False)
            and not owner.stop_requested.is_set() and not server.should_exit
        )) if readiness_key is not None else None
        readiness=PhysicalReadiness(owner,identity['generation'])
        with owner.importing():
            configure()
            app=app_factory() if app_factory else importlib.import_module('app.main').app
            install_local_phone_loading(app, tree.runtime, port)
            install_local_camera_setup(app, tree.runtime, port)
            install_local_phone_setup(app, tree.runtime, port,
                generation_provider=lambda: identity if owner.accepting and not owner.stop_requested.is_set() else None,
                running_provider=lambda: {'state': 'not_started', 'verified': True})
            wrapped=wrap_application(app,owner)
        async def observed(scope,receive,send):
            if endpoint is not None and await endpoint.handle(scope,send):
                return
            if scope['type']!='lifespan':
                return await wrapped(scope,receive,send)
            observation.enter()
            async def report(message):
                kind=message['type']
                observation.message(kind)
                if kind=='lifespan.startup.complete':
                    lifecycle['startup']=True
                    tree.publish('owner.json',{**identity,'state':'running'},replace=True)
                elif kind=='lifespan.shutdown.complete':lifecycle['shutdown']=True
                elif kind.endswith('.failed'):owner.fail('lifespan_failed')
                await send(message)
            try:
                with owner.importing():
                    await wrapped(scope,receive,report)
            finally:
                observation.exit()
        config=build_server_config(observed,port=port)
        server=server_factory(config,owner) if server_factory else OwnedServer(config,owner,observation,readiness,bound_socket=listener)
        def observe():
            while not control_stop.wait(.025):
                if getattr(owner,'signal_pending',False):
                    owner.request_stop()
                try:
                    if stop_requested(tree,identity):
                        owner.request_stop()
                except BaseException:
                    # Malformed input cannot initiate stop or veto a stop
                    # independently latched by a signal or internal guard.
                    owner.fail('control_record_invalid')
                if owner.stop_requested.is_set():
                    server.should_exit=True
                    if readiness.armed.is_set():
                        readiness.poll()
                    else:
                        owner.stop_producers()
        control=threading.Thread(target=observe,name='gate-runtime-control',daemon=False)
        start_thread(control,control_stop.set,control=True)
        server.run()
        if not owner.stop_requested.is_set():owner.fail('server_return_without_stop')
        if getattr(server,'force_exit',False):owner.fail('server_force_exit')
    except BaseException:
        owner.fail('launcher_or_server_exception')
    finally:
        # No generic lock-context unwind here. Every failure passes the same
        # physical body/handle keeper before the original handle is released.
        owner.drain(include_control=False)
        control_stop.set()
        owner.drain(include_control=True)
        if listener is not None:
            listener.close()
        if not all(lifecycle.values()):owner.fail('lifespan_completion_unverified')
        outcome='clean' if not owner.failures else 'stopped_unclean'
        try:
            if identity is not None:
                tree.publish('terminal.json',{'protocol':2,'generation':identity['generation'],
                    'runtime':tree.binding,'outcome':outcome,'summary':owner.summary()},generation=identity['generation'])
        except BaseException:
            owner.fail('terminal_publication_failed')
            outcome='stopped_unclean'
        lock.__exit__(None,None,None)
        install_owner(prior)
        for sig,handler in handlers.items():signal.signal(sig,handler)
    return 0 if outcome=='clean' else 3
