"""Owned process lifetime for the future native desktop host.

Not yet wired to a native UI or MSIX. Readiness is supplied by the trusted
integration layer as a bounded, nonblocking callback; process existence alone
must never be treated as app ready. A blocked arbitrary callback cannot be
preempted by this class, so caller admission must bound every probe operation.
An incomplete stop keeps the lease and child handle: callers must keep this
object alive and visibly report failure, not discard it or report clean exit.
"""
from pathlib import Path
import os
import subprocess
import time

from scripts.runtime_lock import runtime_lock
from scripts.runtime_control import request_stop


def local_path(path):
    path=Path(path).absolute()
    if str(path).startswith(('\\\\','//')):
        raise ValueError('Local path required')
    for part in (path,*path.parents):
        if part.exists() or part.is_symlink():
            stat=part.lstat()
            if part.is_symlink() or getattr(stat,'st_file_attributes',0)&0x400:
                raise ValueError('Linked/reparse path is unsupported')
    return path.resolve()


def bundle_command(bundle,runtime,port=8765):
    bundle,runtime=local_path(bundle),local_path(runtime)
    if bundle.is_relative_to(runtime) or runtime.is_relative_to(bundle):
        raise ValueError('Runtime must be separate from immutable application files')
    if type(port) is not int or not 1024<=port<=65535:
        raise ValueError('Invalid local port')
    executable=bundle/'runtime/python.exe'
    launcher=bundle/'launch.py'
    if not executable.is_file() or not launcher.is_file():
        raise ValueError('Incomplete application bundle')
    return [str(executable),'-I','-B',str(launcher),'--runtime-dir',str(runtime),'--port',str(port)]


def stop_owned(runtime,process,wait_seconds):
    # request_stop calls captured before publishing the generation-bound stop.
    # A different runtime owner must never be stopped by this desktop session.
    def captured(identity):
        if identity['pid']!=process.pid or process.poll() is not None:
            raise RuntimeError('Desktop child no longer owns this runtime')
    return request_stop(runtime,wait_seconds,captured=captured)


class IncompleteStop(RuntimeError):
    pass


class DesktopProcessLease:
    def __init__(self,runtime,*,stopper=stop_owned,stop_seconds=20):
        if not 1<=stop_seconds<=120:raise ValueError('Invalid stop bound')
        self.runtime=local_path(runtime)
        self.stopper=stopper;self.stop_seconds=stop_seconds
        self.process=None;self._lock=None;self._log=None
        self.state='new';self.stop_result=None

    def start(self,command,*,cwd,log_path,ready,ready_seconds=45,env=None):
        if self.state!='new':raise RuntimeError('Session already used')
        if not 0<ready_seconds<=120:raise ValueError('Invalid readiness bound')
        self.runtime.mkdir(parents=True,exist_ok=True)
        lease_dir=local_path(self.runtime/'desktop-host')
        lease_dir.mkdir(exist_ok=True)
        local_path(lease_dir/'.gate-desk.lock')
        lock=runtime_lock(lease_dir)
        lock.__enter__()  # Before child launch; another desktop host fails here.
        self._lock=lock
        try:
            self._log=Path(log_path).open('xb')
            self.process=subprocess.Popen(command,cwd=cwd,env=env,shell=False,
                stdout=self._log,stderr=subprocess.STDOUT,
                creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
            self.state='starting';deadline=time.monotonic()+ready_seconds
            while True:
                if self.process.poll() is not None:
                    raise RuntimeError('Application exited before readiness')
                observed_ready=ready(self.process)
                if time.monotonic()>=deadline:raise TimeoutError('Application readiness timed out')
                if observed_ready:
                    if self.process.poll() is not None:
                        raise RuntimeError('Application exited during readiness')
                    self.state='ready';return self
                time.sleep(.025)
        except BaseException:
            if self.process is not None and self.process.poll() is None:
                self.stop()  # IncompleteStop retains ownership instead of hiding a child.
            else:
                self.state='failed';self._release()
            raise

    def stop(self):
        if self.process is None:
            self.state='closed';self._release();return False
        if self.process.poll() is None:
            self.state='stopping'
            try:self.stop_result=self.stopper(self.runtime,self.process,self.stop_seconds)
            except Exception as error:
                self.state='stop_incomplete'
                raise IncompleteStop('Stop failed; child ownership retained') from error
            # Stopper owns its bounded wait. Poll independently; a "clean" result
            # from a callback cannot substitute for actual process exit.
            if self.process.poll() is None:
                self.state='stop_incomplete'
                raise IncompleteStop('Child remains alive; ownership retained')
        clean=(self.process.returncode==0 and isinstance(self.stop_result,dict)
               and self.stop_result.get('status')=='clean')
        self.state='closed_clean' if clean else 'closed_unverified'
        self._release()
        return clean

    def _release(self):
        if self.process is not None and self.process.poll() is None:
            raise IncompleteStop('Cannot release a live child')
        if self._log is not None:self._log.close();self._log=None
        if self._lock is not None:
            self._lock.__exit__(None,None,None);self._lock=None
