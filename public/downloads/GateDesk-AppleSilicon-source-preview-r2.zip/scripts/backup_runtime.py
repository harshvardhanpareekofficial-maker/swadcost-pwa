"""Cold backup of portable runtime state; app must be stopped.

External source/media/model folders are not part of the runtime. External
document storage is rejected rather than silently omitted. Older/manual app
processes must also be stopped: only the packaged launcher shares the OS lock.
Private camera enrollment is deliberately excluded. Restore emits a durable
re-enrollment notice; protected credentials never silently become portable.
"""
import argparse
from contextlib import ExitStack
from datetime import datetime, timezone
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import sys
import tempfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from scripts.backup_reports import backup as backup_reports, digest, inspect_snapshot
from scripts.runtime_lock import runtime_lock

RECORDER_LOCK_DIRS = ('camera-supervisor', 'camera-ingest')
EXCLUDED = {'.gate-desk.lock', 'reports.sqlite3', 'reports.sqlite3-wal', 'reports.sqlite3-shm', 'reports.sqlite3-journal'}
EXCLUDED.update(name + '/.gate-desk.lock' for name in RECORDER_LOCK_DIRS)
PRIVATE_CAMERA_DIR = 'private-camera-enrollment'
CAMERA_NOTICE = 'camera-reenrollment-required.json'
NOTICE_CONTENT = {'schema_version': 1, 'reason': 'restored_without_private_camera_credentials'}


def private_camera_path(name):
    return PurePosixPath(name).parts[0].casefold() == PRIVATE_CAMERA_DIR


def camera_reenrollment_required(root):
    present = False
    for path in root.iterdir():
        if path.name.casefold() == PRIVATE_CAMERA_DIR:
            if path.is_symlink() or path.is_junction() or not path.is_dir():
                raise ValueError('Invalid private camera directory')
            present = True
    notice = root/CAMERA_NOTICE
    if notice.exists():
        if notice.is_symlink() or notice.is_junction() or json.loads(notice.read_text(encoding='utf-8')) != NOTICE_CONTENT:
            raise ValueError('Invalid camera re-enrollment notice')
        present = True
    return present


def inventory(root, *, omit_private_camera=False):
    if root.is_symlink() or (hasattr(root, 'is_junction') and root.is_junction()):
        raise ValueError('Linked runtime paths are not supported')
    result = {}
    for path in sorted(root.rglob('*')):
        name = path.relative_to(root).as_posix()
        if private_camera_path(name):
            if not omit_private_camera:
                raise ValueError('Private camera state is forbidden in portable backups')
            continue
        if path.is_symlink() or (hasattr(path, 'is_junction') and path.is_junction()):
            raise ValueError('Linked runtime paths are not supported')
        if path.is_file():
            if name not in EXCLUDED:
                result[name] = {'bytes':path.stat().st_size, 'sha256':digest(path)}
    return result


def staging(destination):
    destination = Path(destination).absolute()
    if destination.exists():
        raise FileExistsError('Refusing to replace an existing destination')
    destination.parent.mkdir(parents=True, exist_ok=True)
    stage = Path(tempfile.mkdtemp(prefix='.gate-incomplete-', dir=destination.parent))
    return destination, stage


def publish(stage, destination):
    if destination.exists():
        raise FileExistsError('Destination appeared during verification; refusing replacement')
    stage.rename(destination)  # Same-volume publish; Windows refuses existing targets.


def backup(runtime, output):
    runtime = Path(runtime).resolve(strict=True)
    output = Path(output).resolve()
    if output == runtime or output.is_relative_to(runtime):
        raise ValueError('Backup destination must be outside the source runtime')
    with ExitStack() as ownership:
        ownership.enter_context(runtime_lock(runtime))
        # A recorder can survive an abrupt app exit. Protect against that child
        # even after the parent runtime lock is released; never copy live media.
        for name in RECORDER_LOCK_DIRS:
            child = runtime / name
            if child.is_symlink() or (hasattr(child, 'is_junction') and child.is_junction()):
                raise ValueError('Linked runtime paths are not supported')
            if child.exists():
                if not child.is_dir():
                    raise ValueError('Recorder runtime path is not a directory')
                ownership.enter_context(runtime_lock(child))
        layout = json.loads((runtime/'runtime-layout.json').read_text(encoding='utf-8'))
        if layout != {'schema_version':1, 'documents_within_runtime':True}:
            raise ValueError('Runtime layout is unverified or documents are external; no complete backup possible')
        reenrollment = camera_reenrollment_required(runtime)
        before = inventory(runtime, omit_private_camera=True)
        destination, stage = staging(output)
        # A SQLite snapshot also absorbs committed WAL pages; raw sidecars are
        # never restored alongside it. This is still a cold, lock-held backup.
        db_manifest = backup_reports(runtime/'reports.sqlite3', stage/'database')
        files = stage/'files'
        files.mkdir()
        for name in before:
            target = files/name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(runtime/name, target)
        if (before != inventory(runtime, omit_private_camera=True) or before != inventory(files)
                or reenrollment != camera_reenrollment_required(runtime)):
            raise ValueError('Runtime files changed during backup; incomplete staging retained')
        manifest = {'schema_version':2, 'kind':'gate_desk_cold_runtime',
                    'created_at':datetime.now(timezone.utc).isoformat(), 'files':before,
                    'database_sha256':db_manifest['sha256'],
                    'excluded_private_directories':[PRIVATE_CAMERA_DIR],
                    'camera_reenrollment_required':reenrollment,
                    'scope':'Portable runtime state; private camera enrollment, locks and report SQLite sidecars excluded; source, external media and models excluded'}
        (stage/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
        verify(stage)
        publish(stage, destination)
        return manifest


def verify(directory):
    from scripts.backup_reports import verify_backup
    directory = Path(directory).resolve(strict=True)
    manifest = json.loads((directory/'manifest.json').read_text(encoding='utf-8'))
    version = manifest.get('schema_version')
    if type(version) is not int or version not in (1, 2) or manifest.get('kind') != 'gate_desk_cold_runtime':
        raise ValueError('Unsupported runtime backup')
    if version == 2 and (manifest.get('excluded_private_directories') != [PRIVATE_CAMERA_DIR]
                        or type(manifest.get('camera_reenrollment_required')) is not bool):
        raise ValueError('Invalid private camera backup policy')
    for name in manifest['files']:
        if (not name or '\\' in name or ':' in name or PurePosixPath(name).is_absolute()
                or '..' in PurePosixPath(name).parts
                or any(part.endswith(('.', ' ')) for part in PurePosixPath(name).parts)
                or name in EXCLUDED or private_camera_path(name)):
            raise ValueError('Unsafe backup path')
    if inventory(directory/'files') != manifest['files']:
        raise ValueError('Runtime backup checksum or file inventory mismatch')
    notice = directory/'files'/CAMERA_NOTICE
    if notice.exists() and (json.loads(notice.read_text(encoding='utf-8')) != NOTICE_CONTENT
                            or (version == 2 and not manifest['camera_reenrollment_required'])):
        raise ValueError('Invalid camera re-enrollment notice')
    database = verify_backup(directory/'database')
    if database['sha256'] != manifest['database_sha256']:
        raise ValueError('Database manifest mismatch')
    return manifest


def restore(directory, runtime):
    directory = Path(directory).resolve(strict=True)
    if Path(runtime).resolve().is_relative_to(directory):
        raise ValueError('Restore destination must be outside the backup')
    manifest = verify(directory)
    destination, stage = staging(runtime)
    for name in manifest['files']:
        target = stage/name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(directory/'files'/name, target)
    shutil.copyfile(directory/'database/reports.sqlite3', stage/'reports.sqlite3')
    if inventory(stage) != manifest['files'] or digest(stage/'reports.sqlite3') != manifest['database_sha256']:
        raise ValueError('Restore checksum mismatch; incomplete staging retained')
    rows = inspect_snapshot(stage/'reports.sqlite3')
    reenrollment = manifest.get('camera_reenrollment_required', False) or (stage/CAMERA_NOTICE).exists()
    if reenrollment:
        # Write only a fixed non-secret notice after exact restored-file checks.
        # Preserve it across subsequent backups, even before re-enrollment.
        (stage/CAMERA_NOTICE).write_text(json.dumps(NOTICE_CONTENT)+'\n', encoding='utf-8')
    publish(stage, destination)
    return {'verified_at':datetime.now(timezone.utc).isoformat(), 'table_rows':rows,
            'files_restored':len(manifest['files']), 'database_sha256':manifest['database_sha256'],
            'camera_reenrollment_required':reenrollment,
            'camera_notice':CAMERA_NOTICE if reenrollment else None}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest='command', required=True)
    take = sub.add_parser('backup')
    take.add_argument('--runtime', required=True, type=Path)
    take.add_argument('--output', required=True, type=Path)
    put = sub.add_parser('restore')
    put.add_argument('--backup', required=True, type=Path)
    put.add_argument('--new-runtime', required=True, type=Path)
    args = parser.parse_args()
    result = backup(args.runtime,args.output) if args.command == 'backup' else restore(args.backup,args.new_runtime)
    print(json.dumps(result,indent=2))
