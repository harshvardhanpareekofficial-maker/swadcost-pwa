"""Explicit loopback HTTP and exact prebound TLS loop; no implicit activation.

Inherit the TLS source pins, one-attempt reservation and 10-second handshake
contract. Prebound admission is a separate exact-handle path using those same
pins, one-attempt and ten-second bounds. No global policy or SSL patch.
"""
from app.proactor_socket_cleanup import ResetSafeSocketTransport, verify_runtime
import asyncio
import socket
import ssl
import sys
from scripts.runtime_tls_loop import RuntimeTLSLoop, TransportContractError
from app.runtime_server import validate_tls_bind_address


def validate_reserved_socket(value, port, address='127.0.0.1'):
    """Validate retained reservation without binding, listening or adopting it."""
    try:
        validate_tls_bind_address(address)
        valid = (isinstance(value, socket.socket) and value.fileno() >= 0
                 and value.family == socket.AF_INET and value.type == socket.SOCK_STREAM
                 and type(port) is int and 1 <= port <= 65535
                 and value.getsockname() == (address, port) and not value.getblocking()
                 and value.getsockopt(socket.SOL_SOCKET, socket.SO_ACCEPTCONN) == 0)
        if valid and sys.platform == 'win32':
            valid = value.getsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE) == 1
    except (OSError, ValueError):
        valid = False
    if not valid:
        raise TransportContractError('invalid_prebound_reservation')


def validate_reserved_pair(http_socket, tls_socket, http_port, tls_port, *, tls_bind_address='127.0.0.1'):
    validate_reserved_socket(http_socket, http_port)
    validate_reserved_socket(tls_socket, tls_port, tls_bind_address)
    if http_socket is tls_socket or http_socket.fileno() == tls_socket.fileno() or http_port == tls_port:
        raise TransportContractError('distinct_prebound_reservations_required')


class RuntimeDualLoop(RuntimeTLSLoop):
    def __new__(cls):
        verify_runtime()
        return super().__new__(cls)

    def __init__(self):
        super().__init__()
        self._http_reserved = False
        self._bound_pair = None
        self._bound_context = None
        self._bound_handles = None

    def bind_reserved_sockets(self, http_socket, tls_socket, tls_context, *, tls_bind_address='127.0.0.1'):
        if asyncio.get_running_loop() is not self:
            raise TransportContractError('prebound_loop_mismatch')
        if self._bound_pair is not None or self._http_reserved or self._tls_reserved:
            raise TransportContractError('prebound_registration_single_use')
        if not isinstance(tls_context, ssl.SSLContext) or tls_context.protocol != ssl.PROTOCOL_TLS_SERVER:
            raise TransportContractError('prebound_server_context_required')
        try:
            http_port, tls_port = http_socket.getsockname()[1], tls_socket.getsockname()[1]
        except (AttributeError, OSError, IndexError, TypeError):
            raise TransportContractError('invalid_prebound_reservation') from None
        validate_reserved_pair(http_socket, tls_socket, http_port, tls_port, tls_bind_address=tls_bind_address)
        # Registration itself opens no listener and transfers no ownership.
        self._bound_pair = (http_socket, tls_socket)
        self._bound_context = tls_context
        self._bound_handles = (http_socket.fileno(), tls_socket.fileno())
        self._bound_ports = (http_port, tls_port)
        self._bound_addresses = ('127.0.0.1', tls_bind_address)

    @property
    def http_reservations(self):
        return int(self._http_reserved)

    async def create_server(self, protocol_factory, host=None, port=None, **kwargs):
        bound = getattr(self, '_bound_pair', None)
        candidate = kwargs.get('sock')
        if bound is not None:
            if asyncio.get_running_loop() is not self or host is not None or port is not None:
                raise TransportContractError('prebound_listener_shape_required')
            if candidate is bound[0]:
                side, context = 0, None
            elif candidate is bound[1]:
                side, context = 1, self._bound_context
            else:
                raise TransportContractError('unregistered_prebound_socket')
            if kwargs.get('ssl') is not context:
                raise TransportContractError('prebound_context_mismatch')
            validate_reserved_socket(candidate, self._bound_ports[side], self._bound_addresses[side])
            if candidate.fileno() != self._bound_handles[side]:
                raise TransportContractError('prebound_handle_changed')
            flag = '_http_reserved' if side == 0 else '_tls_reserved'
            if getattr(self, flag):
                raise TransportContractError('prebound_listener_already_reserved')
            if side == 1:
                timeout = kwargs.get('ssl_handshake_timeout')
                if timeout is not None and (type(timeout) not in (int, float) or timeout != 10.0):
                    raise TransportContractError('conflicting_tls_timeout')
                kwargs['ssl_handshake_timeout'] = 10.0
            # Commit before the only await. Failed/cancelled attempts never
            # reset registration or permit a port-only fallback/rebind.
            setattr(self, flag, True)
            return await self._delegate_create_server(protocol_factory, None, None, **kwargs)
        if candidate is not None:
            raise TransportContractError('unregistered_prebound_socket')
        if kwargs.get('ssl') is None:
            if asyncio.get_running_loop() is not self:
                raise TransportContractError('http_loop_mismatch')
            if (type(host) is not str or host != '127.0.0.1'
                    or type(port) is not int or not 1 <= port <= 65535
                    or kwargs.get('sock') is not None):
                raise TransportContractError('unsupported_http_listener_shape')
            if self._http_reserved:
                raise TransportContractError('http_listener_already_reserved')
            self._http_reserved = True
        # TLS validation/reservation/timeout remain wholly in the original hook.
        return await super().create_server(protocol_factory, host, port, **kwargs)

    def _make_socket_transport(self, sock, protocol, waiter=None, extra=None, server=None):
        return ResetSafeSocketTransport(self, sock, protocol, waiter, extra, server)


def make_loop():
    return RuntimeDualLoop()
