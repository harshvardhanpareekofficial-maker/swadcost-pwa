"""Launch a verified source bundle using an already provisioned locked Python runtime."""
import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import secrets
import sys


def verify(root):
    root = Path(root).resolve()
    manifest = json.loads((root/'source-manifest.json').read_text())
    for item in manifest['files']:
        path = root/item['path']
        if not path.resolve().is_relative_to(root) or path.is_symlink():
            raise ValueError('Invalid package member')
        if hashlib.sha256(path.read_bytes()).hexdigest() != item['sha256']:
            raise ValueError(f"Source integrity mismatch: {item['path']}")
    versions = {}
    for line in (root/'requirements-lock.txt').read_text().splitlines():
        if not line.strip() or line.startswith('#'):
            continue
        name, expected = line.split('==', 1)
        actual = importlib.metadata.version(name)
        if actual != expected:
            raise ValueError(f'Locked dependency mismatch: {name}: {actual} != {expected}')
        versions[name] = actual
    return versions


def configure_runtime(root, runtime, document_dir=None):
    """Keep mutable files outside replaceable code; never silently migrate data."""
    root, runtime = Path(root).resolve(), Path(runtime).resolve()
    marker = runtime/'runtime-layout.json'
    if marker.exists():
        try:
            layout = json.loads(marker.read_text(encoding='utf-8'))
        except (ValueError, OSError) as error:
            raise ValueError('Cannot read the existing runtime layout; document storage '
                             'was not changed. Restore a verified layout before launching.') from error
        if (not isinstance(layout, dict)
                or set(layout) != {'schema_version', 'documents_within_runtime'}
                or type(layout['schema_version']) is not int
                or layout['schema_version'] != 1
                or type(layout['documents_within_runtime']) is not bool):
            raise ValueError('Unsupported existing runtime layout; document storage was not changed.')
        if not layout['documents_within_runtime'] and document_dir is None:
            raise ValueError('This runtime uses an external document folder. Select the existing '
                             'folder explicitly with --document-dir; document storage was not changed.')
    if document_dir is None and (root/'data/gatepasses.json').exists():
        raise ValueError('Legacy documents found in the source folder. Select their data folder '
                         'explicitly with --document-dir; no documents were moved or overwritten.')
    documents = Path(document_dir).resolve() if document_dir is not None else runtime/'documents'
    runtime.mkdir(parents=True, exist_ok=True)
    documents.mkdir(parents=True, exist_ok=True)
    os.environ['GATE_DESK_DB'] = str(runtime/'reports.sqlite3')
    os.environ['ANNOTATOR_STORE'] = str(runtime/'annotator')
    os.environ['GATE_DESK_DOCUMENT_DIR'] = str(documents)
    return documents


def main(*, phone_startup_guard=None):
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    parser.add_argument('--runtime-dir', required=True, type=Path)
    parser.add_argument('--port', default=8765, type=int)
    parser.add_argument('--document-dir', type=Path,
                        help='Existing document data folder; default: RUNTIME/documents. No automatic migration.')
    parser.add_argument('--verify-only', action='store_true')
    parser.add_argument('--request-stop', action='store_true')
    parser.add_argument('--phone-config', type=Path,
                        help='Explicit owner-authorized phone receiver settings; interactive console only.')
    parser.add_argument('--restart-phone-handoff',
                        help='Consume a fresh owner-prepared restart UUID; interactive console only.')
    parser.add_argument('--wait-seconds', type=float, default=110)
    args = parser.parse_args()
    if args.phone_config is not None and (args.verify_only or args.request_stop):
        parser.error('--phone-config cannot be combined with verification or stop')
    if args.restart_phone_handoff is not None:
        import re
        if (args.phone_config is not None or args.verify_only or args.request_stop
                or not re.fullmatch(r'[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}', args.restart_phone_handoff)):
            parser.error('A canonical restart UUID is required without phone-config, stop or verification')
    root = Path(__file__).resolve().parents[1]
    if args.request_stop:
        if args.verify_only:
            parser.error('--request-stop and --verify-only are mutually exclusive')
        sys.path.insert(0, str(root))
        from scripts.runtime_control import request_stop, ControlError
        try:
            result = request_stop(args.runtime_dir, args.wait_seconds)
        except (ControlError, OSError):
            result = {'code': 4, 'status': 'control_invalid_or_unavailable'}
        print(json.dumps(result))
        return result['code']
    versions = verify(root)
    if args.verify_only:
        print(json.dumps({'verified': True, 'locked_dependencies': len(versions)}))
        return
    sys.path.insert(0, str(root))
    if args.restart_phone_handoff is not None:
        from app.phone_restart import consume_handoff
        explicit_port = any(value == '--port' or value.startswith('--port=') for value in sys.argv[1:])
        return consume_handoff(args.runtime_dir, args.restart_phone_handoff, document_dir=args.document_dir,
                               requested_port=args.port if explicit_port else None, wait_seconds=args.wait_seconds)
    from scripts.runtime_runner import run_owned
    def configure():
        documents = configure_runtime(root, args.runtime_dir, args.document_dir)
        layout = {'schema_version':1, 'documents_within_runtime':
                  documents == args.runtime_dir.resolve()/'documents'}
        (args.runtime_dir/'runtime-layout.json').write_text(json.dumps(layout)+'\n', encoding='utf-8')
    from scripts.desktop_readiness import ENV_KEY
    if args.phone_config is not None:
        from app.mobile_startup import (read_phone_settings, existing_runtime,
                                        authorize_owner, recheck_owner)
        from app.mobile_activation import prepare_activation
        from scripts.pc_phone_runner import run_pc_phone
        settings = read_phone_settings(args.phone_config)
        runtime, documents = existing_runtime(args.runtime_dir, args.document_dir)
        authorization = authorize_owner(runtime, settings['factory_id'])
        prepared = prepare_activation(settings)
        def configure_phone():
            # Called under the same runtime lock/owner as the listeners. Never
            # bootstrap, migrate or rewrite the existing layout for activation.
            checked_runtime, checked_documents = existing_runtime(runtime, documents)
            if checked_runtime != runtime or checked_documents != documents:
                raise ValueError('phone_startup_storage_changed')
            recheck_owner(authorization)
            if phone_startup_guard is not None:
                phone_startup_guard()
            os.environ['GATE_DESK_ACCOUNTS'] = '1'
            os.environ['GATE_DESK_OWNER_PC'] = '1'
            configure_runtime(root, runtime, documents)
        return run_pc_phone(runtime, configure_phone, enabled=True, local_diagnostic=False,
                            settings=settings, sessions_path=runtime/'remote-sessions.sqlite3',
                            tls_context=prepared.tls_context, deployment_admission=prepared,
                            http_port=args.port,
                            readiness_key=os.environ.pop(ENV_KEY, None) or secrets.token_hex(32))
    return run_owned(args.runtime_dir, configure, port=args.port,
                     readiness_key=os.environ.pop(ENV_KEY, None))


if __name__ == '__main__':
    raise SystemExit(main())
