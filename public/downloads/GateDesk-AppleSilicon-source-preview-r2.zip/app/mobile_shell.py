"""Opt-in shell composition, not a listener or production registration.

Public login assets contain no factory data. API authorization stays in the
injected MobileBoundary. Requires direct TLS with proxy headers disabled.
"""
from pathlib import Path
import hashlib
import json


ASSETS = ('styles.css', 'tracker_reports.js', 'mobile_client.js',
          'mobile_bridge.js', 'app.js', 'notifications.js', 'counting.css',
          'counting.js', 'customer.css', 'worker_invites.js', 'qr_decoder.js', 'qr_worker.js',
          'vendor/jsqr/jsQR-1.4.0.js', 'mobile_enrollment.js', 'phone_outbox.js', 'phone_passes.js', 'customer.js', 'fonts/archivo.woff2',
          'phone_install.js', 'phone-icons/gate-192.png', 'phone-icons/gate-512.png')


class MobileShell:
    def __init__(self, api, config):
        self.api, self.config = api, config
        root = Path(__file__).parent / 'static'
        html = (root / 'index.html').read_bytes()
        marker = b'<html lang="en">'
        if html.count(marker) != 1:
            raise ValueError('mobile_shell_marker_missing')
        # Owner-PC setup is neither served nor executed on the phone transport.
        html = html.replace(b'<script src="/static/phone_setup.js" defer></script>', b'')
        html = html.replace(b'<script src="/static/phone_loading_review.js" defer></script>', b'')
        customer = b'<script src="/static/customer.js" defer></script>'
        if html.count(customer) != 1:
            raise ValueError('mobile_entry_script_marker_missing')
        html = html.replace(customer, b'<script src="/static/qr_decoder.js" defer></script><script src="/static/mobile_enrollment.js" defer></script><script src="/static/phone_outbox.js" defer></script><script src="/static/phone_passes.js" defer></script>' + customer)
        html = html.replace(b'</head>', b'<link rel="manifest" href="/phone.webmanifest"><meta name="theme-color" content="#132e2b"><link rel="apple-touch-icon" href="/static/phone-icons/gate-192.png"><script src="/static/phone_install.js" defer></script></head>')
        self.assets = {'/': (html.replace(marker, b'<html lang="en" data-transport="remote">'),
                              b'text/html; charset=utf-8')}
        for name in ASSETS:
            data = (root / name).read_bytes()
            if len(data) > 2 * 1024 * 1024:
                raise ValueError('mobile_asset_too_large')
            mime = (b'image/png' if name.endswith('.png') else b'font/woff2' if name.endswith('.woff2') else
                    b'text/css; charset=utf-8' if name.endswith('.css') else b'text/javascript; charset=utf-8')
            self.assets['/static/' + name] = (data, mime)
        manifest = {'id': '/', 'name': 'Gate Desk', 'short_name': 'Gate Desk',
                    'start_url': '/', 'scope': '/', 'display': 'standalone',
                    'background_color': '#132e2b', 'theme_color': '#132e2b',
                    'prefer_related_applications': False,
                    'icons': [{'src': f'/static/phone-icons/gate-{size}.png',
                               'sizes': f'{size}x{size}', 'type': 'image/png', 'purpose': 'any'}
                              for size in (192, 512)]}
        self.assets['/phone.webmanifest'] = (json.dumps(manifest).encode(), b'application/manifest+json')
        hashes = {path: hashlib.sha256(value[0]).hexdigest() for path, value in self.assets.items()}
        worker = ''''use strict';
const FILES=__FILES__, CACHE='gate-desk-public-shell-'+__VERSION__;
const digest=async response=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',await response.arrayBuffer())),v=>v.toString(16).padStart(2,'0')).join('');
self.addEventListener('install',event=>event.waitUntil((async()=>{
 const cache=await caches.open(CACHE);
 try{for(const [path,expected] of Object.entries(FILES)){
  const response=await fetch(path,{cache:'no-store',credentials:'omit',redirect:'error'});
  if(response.status!==200||await digest(response.clone())!==expected)throw Error('Shell integrity failure');
  await cache.put(path,response);
 }}catch(error){await caches.delete(CACHE);throw error;}
})()));
// Wait for old windows to close before switching; never cache API or private originals.
self.addEventListener('activate',event=>event.waitUntil((async()=>{
 for(const name of await caches.keys())if(name.startsWith('gate-desk-public-shell-')&&name!==CACHE)await caches.delete(name);
 await self.clients.claim();
})()));
self.addEventListener('fetch',event=>{
 const url=new URL(event.request.url);
 if(event.request.method!=='GET'||url.origin!==self.location.origin||url.search||!Object.hasOwn(FILES,url.pathname))return;
 event.respondWith((async()=>{
  const cache=await caches.open(CACHE),saved=await cache.match(url.pathname);
  if(saved)return saved;
  const response=await fetch(event.request);
  if(response.status!==200||await digest(response.clone())!==FILES[url.pathname])return new Response('Reconnect to update Gate Desk.',{status:503});
  return response;
 })());
});
'''
        version = hashlib.sha256(json.dumps(hashes, sort_keys=True).encode() + worker.encode()).hexdigest()
        worker = worker.replace('__FILES__', json.dumps(hashes)).replace('__VERSION__', json.dumps(version))
        self.assets['/phone-worker.js'] = (worker.encode(), b'text/javascript; charset=utf-8')

    async def __call__(self, scope, receive, send):
        if scope['type'] != 'http':
            return await self.api(scope, receive, send)
        hosts = [v for k, v in scope.get('headers', []) if k.lower() == b'host']
        valid = (self.config is not None and scope.get('scheme') == 'https'
                 and scope.get('root_path', '') == ''
                 and hosts == [self.config.canonical_origin[8:].encode('ascii')])
        path = scope.get('path', '')
        if valid and path.startswith('/api/'):
            return await self.api(scope, receive, send)
        asset = self.assets.get(path)
        allowed = (valid and asset is not None and scope.get('method') in ('GET', 'HEAD')
                   and scope.get('raw_path') == path.encode('ascii')
                   and not scope.get('query_string', b''))
        data, mime = asset if allowed else (b'Access denied.', b'text/plain; charset=utf-8')
        await send({'type': 'http.response.start', 'status': 200 if allowed else 403,
                    'headers': [(b'content-type', mime), (b'content-length', str(len(data)).encode()),
                                (b'cache-control', b'no-store'), (b'x-content-type-options', b'nosniff'),
                                (b'x-frame-options', b'DENY'), (b'referrer-policy', b'no-referrer')]})
        await send({'type': 'http.response.body',
                    'body': b'' if scope.get('method') == 'HEAD' else data})
