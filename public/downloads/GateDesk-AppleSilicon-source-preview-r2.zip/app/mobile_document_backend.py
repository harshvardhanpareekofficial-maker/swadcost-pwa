"""Host-created single-factory document capability, no global path replacement."""
from app.document_store import DocumentStore, DocumentReview
from app.mobile_documents import DocumentBackend
from app.mobile_document_reads import DocumentReadStore
from app.phone_submissions import PhoneSubmissions


def document_backend(factory_id, store):
    if not isinstance(factory_id, str) or not factory_id.strip() or type(store) is not DocumentStore:
        raise ValueError('explicit_factory_document_store_required')
    # The host must reuse this store/lock for every writer to the same root.
    return DocumentBackend(factory_id, store.import_image, DocumentReview.model_validate,
                           store.review, DocumentReadStore(store.index),
                           PhoneSubmissions(store, factory_id).import_image)
