"""Retained same-loop local HTTP plus explicitly bound TLS coordinator.

Host installs ONE owner, runs on RuntimeDualLoop and retains its off-loop control
poller calling poll_readiness() until BOTH fences settle. This module neither
starts that poller nor releases installation locks nor cancels serving tasks.
Unknown ownership holds the loop for the host's explicit child containment.
Apps must already use the supplied owner's admission/lifecycle wrappers.
"""
import asyncio
import inspect
import threading

from app import runtime_owner as ro
from app.runtime_server import OwnedServer, LifespanObservation, PhysicalReadiness, validate_tls_bind_address
from app.server_transport import build_server_config


class DualTransport:
    def __init__(self, owner, http_app, tls_app, *, http_port, tls_port, tls_context, generation,
                 http_socket=None, tls_socket=None, tls_bind_address='127.0.0.1'):
        if type(owner) is not ro.RuntimeOwner or not isinstance(generation, str) or not generation:
            raise ValueError('dual_owner_generation_required')
        if http_port == tls_port or tls_context is None:
            raise ValueError('dual_distinct_ports_and_tls_required')
        self.owner = owner
        self.tls_bind_address = validate_tls_bind_address(tls_bind_address)
        if tls_bind_address != '127.0.0.1' and (http_socket is None or tls_socket is None):
            raise ValueError('dual_private_prebound_pair_required')
        if (http_socket is None) != (tls_socket is None):
            raise ValueError('dual_both_reserved_sockets_required')
        self.reserved_sockets = ()
        if http_socket is not None:
            from scripts.runtime_dual_loop import validate_reserved_pair
            validate_reserved_pair(http_socket, tls_socket, http_port, tls_port,
                                   tls_bind_address=tls_bind_address)
            self.reserved_sockets = (http_socket, tls_socket)
        self.reserved_sockets_closed = False
        self._socket_by_port = dict(zip((http_port, tls_port), self.reserved_sockets))
        self._tls_context = tls_context
        self.observations = tuple(LifespanObservation(owner) for _ in range(2))
        self.readiness = tuple(PhysicalReadiness(owner, generation + '-' + name) for name in ('http', 'tls'))
        self.servers = tuple(self._server(app, port, context, observation, readiness)
                             for app, port, context, observation, readiness in zip(
                                 (http_app, tls_app), (http_port, tls_port), (None, tls_context),
                                 self.observations, self.readiness))
        self.task = None
        self.serving_tasks = []
        self.loop = None
        self.loop_thread = None
        self.settled = False
        self.physical_cleanup_verified = False
        self.held_reason = None
        self.scheduling_tasks = []
        self.pending_coroutines = []

    def _schedule(self, operation, name):
        coroutine = operation()
        try:
            return self.loop.create_task(coroutine, name=name)
        except BaseException:
            # No custom task factory is admitted. If a task was registered
            # before failure, retain it rather than closing its coroutine.
            scheduled = [task for task in asyncio.all_tasks(self.loop)
                         if task.get_coro() is coroutine]
            self.scheduling_tasks.extend(scheduled)
            if not scheduled and inspect.getcoroutinestate(coroutine) == inspect.CORO_CREATED:
                coroutine.close()
            elif not scheduled:
                self.pending_coroutines.append(coroutine)
            raise

    def _server(self, app, port, context, observation, readiness):
        async def observed(scope, receive, send):
            if scope['type'] != 'lifespan':
                return await app(scope, receive, send)
            observation.enter()
            async def reported(message):
                observation.message(message['type'])
                await send(message)
            try:
                return await app(scope, receive, reported)
            finally:
                observation.exit()
        config = build_server_config(observed, port=port, tls_context=context)
        config.loop = 'scripts.runtime_dual_loop:make_loop'
        config.access_log = False
        address = self.tls_bind_address if context is not None else '127.0.0.1'
        if address != '127.0.0.1':
            config.host = address
            return OwnedServer(config, self.owner, observation, readiness,
                               bound_socket=self._socket_by_port.get(port), bound_address=address)
        return OwnedServer(config, self.owner, observation, readiness,
                           bound_socket=self._socket_by_port.get(port))

    def _close_reserved_sockets(self):
        # Caller may invoke only after both real serve handles/fences settle.
        if not self._settled_servers():
            raise RuntimeError('dual_prebound_close_before_fences')
        for reserved in self.reserved_sockets:
            reserved.close()
        if any(reserved.fileno() != -1 for reserved in self.reserved_sockets):
            raise RuntimeError('dual_prebound_socket_close_unverified')
        self.reserved_sockets_closed = True

    def _check_loop(self):
        from scripts.runtime_dual_loop import RuntimeDualLoop
        if type(asyncio.get_running_loop()) is not RuntimeDualLoop:
            raise RuntimeError('dual_explicit_loop_required')
        if ro.current_owner() is not self.owner:
            raise RuntimeError('dual_owner_mismatch')
        if asyncio.get_running_loop().get_task_factory() is not None:
            raise RuntimeError('dual_task_factory_not_supported')

    def request_stop(self):
        self.owner.request_stop()
        for server, readiness in zip(self.servers, self.readiness):
            server.should_exit = True
            readiness.arm()

    def poll_readiness(self):
        """Host's retained off-loop control poller only; may join physical work."""
        if self.loop_thread == threading.get_ident():
            raise RuntimeError('dual_readiness_requires_off_loop_poller')
        for readiness in self.readiness:
            readiness.poll()

    def _settled_servers(self):
        for server, task in zip(self.servers, self.serving_tasks):
            if not task.done() or task.cancelled():
                return False
            if task.exception() is not None:
                return False
            if not server.fence_complete or server.unknown_listener or server.held_reason is not None:
                return False
            if any(not retained.done() for retained in server.tasks + server.listener_waits):
                return False
            for retained in server.tasks + server.listener_waits:
                if retained.cancelled():
                    return False
                try:
                    if not retained.result().ok:
                        self.owner.fail('dual_retained_operation_failed')
                except BaseException:
                    return False
            if server.server_state.tasks or server.server_state.connections:
                return False
            if any(listener.is_serving() or listener.sockets for listener in server.listeners):
                return False
            observation = server.observation
            if observation.task is not None and not observation.task.done():
                return False
            if (observation.startup != 1 or observation.shutdown != 1
                    or not observation.exited or observation.failed):
                self.owner.fail('dual_lifespan_completion_unverified')
        return len(self.serving_tasks) == 2

    async def _tick(self):
        try:
            await asyncio.sleep(.025)
        except BaseException:
            self.owner.fail('dual_coordinator_interrupted')
            self.request_stop()

    async def _hold(self, reason):
        self.held_reason = reason
        self.owner.fail(reason)
        self.request_stop()
        while True:
            await self._tick()

    async def _run(self):
        try:
            for server in self.servers:
                self.serving_tasks.append(self._schedule(server.serve, 'gate-dual-server'))
            while not all(task.done() for task in self.serving_tasks):
                if (self.owner.stop_requested.is_set() or self.owner.failures
                        or any(server.should_exit or server.force_exit for server in self.servers)
                        or any(task.done() for task in self.serving_tasks)):
                    self.request_stop()
                await self._tick()
            self.request_stop()
            if not self._settled_servers():
                await self._hold('dual_server_settlement_unverified')
            # Both server fences have already observed the common owner's
            # resource drain and off-loop physical-readiness proof.
            if any(not ready.ready.is_set() for ready in self.readiness):
                await self._hold('dual_physical_readiness_unverified')
            summary = self.owner.summary()
            # The host control poller is intentionally still alive here; its
            # exact join belongs to the host after both fences. Readiness has
            # proved non-control workers, so total "unjoined" cannot gate this.
            if any(summary[key] for key in ('calls', 'resources', 'bootstrap')):
                await self._hold('dual_owner_settlement_unverified')
            self._close_reserved_sockets()
            self.settled = True
            # Injected test servers can exercise propagation but cannot prove
            # transport cleanup with invented flags.
            self.physical_cleanup_verified = all(type(server) is OwnedServer for server in self.servers)
        except BaseException:
            await self._hold('dual_coordinator_ownership_unverified')

    async def serve(self):
        if self.task is not None:
            raise RuntimeError('dual_single_use')
        self._check_loop()
        self.loop = asyncio.get_running_loop()
        self.loop_thread = threading.get_ident()
        if self.reserved_sockets:
            # Bind exact host-owned identities before either app starts. A
            # rejected binding schedules nothing; host still retains handles.
            self.loop.bind_reserved_sockets(*self.reserved_sockets, self._tls_context,
                                           tls_bind_address=self.tls_bind_address)
        try:
            self.task = self._schedule(self._run, 'gate-dual-coordinator')
        except BaseException:
            # Even construction failure cannot release possible scheduled work.
            return await self._hold('dual_coordinator_creation_unverified')
        while not self.task.done():
            try:
                await asyncio.shield(self.task)
            except BaseException:
                self.owner.fail('dual_observer_interrupted')
                self.request_stop()
        # Retain and consume the actual coordinator result. No cancellation or
        # timeout grants permission to close its original loop.
        self.task.result()
        return self.settled and self.physical_cleanup_verified and not self.owner.failures
