"""Local notification policy, durable outbox, and explicitly enabled delivery.

Never call providers in a counting transaction. A separate dispatcher reads
durable, operator-confirmed events and calls enqueue_event; failures leave the
source event available for replay. SMTP is at-least-once, NOT exactly-once.
"""
from __future__ import annotations
from app.runtime_owner import start_thread, start_process, process_finished, forced_process_stop, register_queue

import hashlib
import json
import multiprocessing
import os
import re
import smtplib
import sqlite3
import ssl
import threading
import time
import uuid
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
from email.message import EmailMessage
from pathlib import Path
from typing import Any, Mapping, Protocol


class NotificationPolicyError(ValueError):
    """Input does not represent an eligible, trusted event."""


class NotificationConflict(ValueError):
    """Stable event ID was reused for different content."""


def _text(event, key, maximum=200):
    value = event.get(key)
    if not isinstance(value, str) or not value.strip() or len(value) > maximum:
        raise NotificationPolicyError(f"Invalid {key}")
    if any(ord(c) < 32 for c in value):
        raise NotificationPolicyError(f"Invalid control character in {key}")
    return value.strip()


def _integer(event, key):
    value = event.get(key)
    if type(value) is not int or not 0 <= value <= 1_000_000_000:
        raise NotificationPolicyError(f"Invalid {key}")
    return value


def prepare_event(event: Mapping[str, Any]) -> dict:
    """Allowlist text-only fields; never accept raw detections as crossings.

    `confirmed` is a trust assertion, not authentication. The bridge must only
    supply persisted operator approvals or an authorized serious-health source.
    Extra media, secrets, provider addresses and inference fields are not copied.
    """
    kind = event.get("kind")
    if kind not in {"confirmed_crossing", "finalized_pass", "serious_health"}:
        raise NotificationPolicyError("Raw detections and unconfirmed events are not eligible")
    method = event.get("confirmation_method")
    allowed_methods = {"operator", "health_monitor"} if kind == "serious_health" else {"operator"}
    if event.get("confirmed") is not True or method not in allowed_methods:
        raise NotificationPolicyError("A trusted confirmation is required")
    stamp = _text(event, "occurred_at", 80)
    try:
        date = datetime.fromisoformat(stamp.replace("Z", "+00:00"))
        if date.utcoffset() is None:
            raise ValueError("naive timestamp")
    except ValueError as exc:
        raise NotificationPolicyError("occurred_at requires an aware ISO timestamp") from exc
    result = {"event_id": _text(event, "event_id"), "kind": kind,
              "occurred_at": date.astimezone(timezone.utc).isoformat(),
              "confirmed": True, "confirmation_method": method}
    if kind in {"confirmed_crossing", "finalized_pass"}:
        result["operation_id"] = _text(event, "operation_id")
    if kind == "confirmed_crossing":
        if event.get("material_class") != "bag":
            raise NotificationPolicyError("Crossing notifications currently support confirmed bags only")
        if event.get("direction") not in {"Incoming", "Outgoing"}:
            raise NotificationPolicyError("A crossing direction is required")
        result.update(material_class="bag", direction=event["direction"])
        if "counted" in event:
            result["counted"] = _integer(event, "counted")
    elif kind == "finalized_pass":
        if event.get("finalized") is not True:
            raise NotificationPolicyError("Pass must be finalized")
        counted, expected = _integer(event, "counted"), _integer(event, "expected")
        difference = counted - expected
        result.update(finalized=True, counted=counted, expected=expected,
                      difference=difference, unit=_text(event, "unit", 40),
                      reconciliation="matched" if difference == 0 else "shortage" if difference < 0 else "excess")
    else:
        if event.get("severity") not in {"serious", "critical"} or event.get("active") is not True:
            raise NotificationPolicyError("Only active serious health events are eligible")
        result.update(health_key=_text(event, "health_key"), severity=event["severity"],
                      message=_text(event, "message", 1000), active=True)
    return result


class NotificationOutbox:
    """SQLite outbox, separate from count storage; one connection per operation."""

    def __init__(self, db_path, *, clock=time.time, health_cooldown_seconds=900):
        self.db_path = Path(db_path)
        self.clock = clock
        if not 0 <= health_cooldown_seconds <= 86400:
            raise ValueError("health cooldown must be 0..86400 seconds")
        self.health_cooldown_seconds = health_cooldown_seconds
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with self._db() as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.executescript("""
                CREATE TABLE IF NOT EXISTS notification_outbox (
                    id TEXT PRIMARY KEY, event_id TEXT NOT NULL,
                    channel TEXT NOT NULL, recipient_ref TEXT NOT NULL,
                    payload TEXT NOT NULL, payload_sha256 TEXT NOT NULL,
                    status TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0,
                    created_at REAL NOT NULL, updated_at REAL NOT NULL,
                    next_attempt_at REAL NOT NULL, lease_until REAL,
                    lease_token TEXT, delivered_at REAL, last_error_code TEXT,
                    UNIQUE(event_id, channel, recipient_ref)
                );
                CREATE INDEX IF NOT EXISTS notification_ready
                    ON notification_outbox(status,next_attempt_at,lease_until);
                CREATE TABLE IF NOT EXISTS notification_cooldowns (
                    health_key TEXT NOT NULL, channel TEXT NOT NULL,
                    recipient_ref TEXT NOT NULL, last_enqueued_at REAL NOT NULL,
                    PRIMARY KEY(health_key,channel,recipient_ref)
                );
            """)

    @contextmanager
    def _db(self):
        db = sqlite3.connect(self.db_path, timeout=0.25)
        db.row_factory = sqlite3.Row
        try:
            db.execute("PRAGMA synchronous=FULL")
            with db:
                yield db
        finally:
            db.close()

    def enqueue_event(self, event: dict, *, channel="email", recipient_ref="GATE_DESK_NOTIFY_TO") -> dict:
        payload = prepare_event(event)
        if not re.fullmatch(r"[a-z][a-z0-9_-]{0,39}", channel):
            raise NotificationPolicyError("Invalid channel")
        if not re.fullmatch(r"[A-Z][A-Z0-9_]{0,119}", recipient_ref):
            raise NotificationPolicyError("recipient_ref must be an environment/config reference")
        encoded = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
        digest = hashlib.sha256(encoded.encode()).hexdigest()
        identity = json.dumps([payload["event_id"], channel, recipient_ref], separators=(",", ":"))
        notification_id = hashlib.sha256(identity.encode()).hexdigest()
        now = self.clock()
        with self._db() as db:
            db.execute("BEGIN IMMEDIATE")
            old = db.execute("SELECT payload_sha256,status FROM notification_outbox WHERE id=?", (notification_id,)).fetchone()
            if old:
                if old["payload_sha256"] != digest:
                    raise NotificationConflict("Event ID already exists with different content")
                return {"id": notification_id, "status": "duplicate", "delivery_status": old["status"]}
            status, reason = "pending", None
            if payload["kind"] == "serious_health":
                # Escalation to critical gets its own cooldown; repeated severity is coalesced.
                key = payload["health_key"] + ":" + payload["severity"]
                previous = db.execute("SELECT last_enqueued_at FROM notification_cooldowns WHERE health_key=? AND channel=? AND recipient_ref=?", (key, channel, recipient_ref)).fetchone()
                if previous and now - previous[0] < self.health_cooldown_seconds:
                    status, reason = "suppressed", "health_cooldown"
                else:
                    db.execute("INSERT INTO notification_cooldowns VALUES (?,?,?,?) ON CONFLICT(health_key,channel,recipient_ref) DO UPDATE SET last_enqueued_at=excluded.last_enqueued_at", (key, channel, recipient_ref, now))
            db.execute("""INSERT INTO notification_outbox
                (id,event_id,channel,recipient_ref,payload,payload_sha256,status,created_at,updated_at,next_attempt_at,last_error_code)
                VALUES (?,?,?,?,?,?,?,?,?,?,?)""", (notification_id, payload["event_id"], channel, recipient_ref, encoded, digest, status, now, now, now, reason))
        result = {"id": notification_id, "status": "suppressed" if reason else "queued"}
        if reason:
            result["reason"] = reason
        return result

    def list_events(self, limit=100) -> list[dict]:
        if type(limit) is not int or not 1 <= limit <= 1000:
            raise ValueError("limit must be 1..1000")
        with self._db() as db:
            rows = db.execute("SELECT * FROM notification_outbox ORDER BY created_at DESC,id LIMIT ?", (limit,)).fetchall()
        return [self._record(row) for row in rows]

    @staticmethod
    def _record(row):
        result = dict(row)
        result["payload"] = json.loads(result["payload"])
        result.pop("lease_token", None)
        return result

    def stats(self) -> dict:
        with self._db() as db:
            return {row[0]: row[1] for row in db.execute("SELECT status,COUNT(*) FROM notification_outbox GROUP BY status")}

    def claim(self, *, lease_seconds, max_attempts):
        now, token = self.clock(), uuid.uuid4().hex
        with self._db() as db:
            db.execute("BEGIN IMMEDIATE")
            db.execute("""UPDATE notification_outbox SET status='dead',lease_token=NULL,lease_until=NULL,
                last_error_code='attempts_exhausted',updated_at=? WHERE attempts>=? AND
                (status='pending' OR (status='delivering' AND lease_until<=?))""", (now, max_attempts, now))
            row = db.execute("""SELECT * FROM notification_outbox WHERE attempts<? AND
                ((status='pending' AND next_attempt_at<=?) OR (status='delivering' AND lease_until<=?))
                ORDER BY next_attempt_at,created_at,id LIMIT 1""", (max_attempts, now, now)).fetchone()
            if row is None:
                return None
            db.execute("UPDATE notification_outbox SET status='delivering',attempts=attempts+1,lease_token=?,lease_until=?,updated_at=? WHERE id=?", (token, now + lease_seconds, now, row["id"]))
            result = self._record(row)
            result.update(lease_token=token, attempts=row["attempts"] + 1, status="delivering")
            return result

    def finish(self, item, *, success, error_code=None, max_attempts=5, retry_delay=5):
        now = self.clock()
        status = "delivered" if success else "dead" if item["attempts"] >= max_attempts else "pending"
        with self._db() as db:
            changed = db.execute("""UPDATE notification_outbox SET status=?,updated_at=?,next_attempt_at=?,
                delivered_at=?,last_error_code=?,lease_token=NULL,lease_until=NULL
                WHERE id=? AND status='delivering' AND lease_token=? AND lease_until>?""",
                (status, now, now + retry_delay, now if success else None, error_code,
                 item["id"], item["lease_token"], now)).rowcount
        return status if changed else "lease_lost"

    def suppress_delivery(self, item):
        """Retain an ineligible queued record without calling its provider."""
        now = self.clock()
        with self._db() as db:
            changed = db.execute("""UPDATE notification_outbox SET status='suppressed',
                updated_at=?,last_error_code='delivery_policy_suppressed',
                lease_token=NULL,lease_until=NULL
                WHERE id=? AND status='delivering' AND lease_token=? AND lease_until>?""",
                (now, item['id'], item['lease_token'], now)).rowcount
        return 'suppressed' if changed else 'lease_lost'


class DeliveryAdapter(Protocol):
    """Adapters must be spawn-picklable and honor the idempotency key if supported."""
    def send(self, notification: dict, *, recipient_ref: str, idempotency_key: str, timeout_seconds: float) -> None: ...


def _delivery_child(adapter, payload, recipient_ref, key, timeout_seconds, pipe):
    try:
        adapter.send(payload, recipient_ref=recipient_ref, idempotency_key=key, timeout_seconds=timeout_seconds)
        pipe.send((True, None))
    except Exception as exc:
        # Exception messages can contain hostnames, addresses, responses or passwords.
        pipe.send((False, "adapter_" + type(exc).__name__))
    finally:
        pipe.close()


def bounded_delivery(adapter, payload, recipient_ref, key, timeout_seconds):
    """A killed subprocess bounds even an adapter that ignores its timeout.

    No uncancelled delivery thread may run past its outbox lease. Process startup
    is included in the timeout. As with every remote protocol, timeout after
    acceptance can still mean delivery occurred; retries reuse the stable key.
    """
    context = multiprocessing.get_context("spawn")
    receive, send = context.Pipe(duplex=False)
    process = context.Process(target=_delivery_child, args=(adapter, payload, recipient_ref, key, timeout_seconds, send), daemon=True)
    start = time.monotonic()
    try:
        start_process(process)
        send.close()
        remaining = max(0, timeout_seconds - (time.monotonic() - start))
        if receive.poll(remaining):
            try:
                return receive.recv()
            except EOFError:
                return False, "adapter_process_exit"
        return False, "delivery_timeout"
    except Exception as exc:
        return False, "worker_" + type(exc).__name__
    finally:
        send.close()
        receive.close()
        if process.pid is not None:
            if process.is_alive():
                forced_process_stop()
                process.terminate()
            process.join(timeout=1)
            if process.is_alive():
                forced_process_stop()
                process.kill()
                process.join(timeout=1)
            process_finished(process)
            process.close()


class NotificationWorker:
    def __init__(self, outbox, adapters, *, allow_external_send=False, timeout_seconds=10,
                 max_attempts=5, base_backoff_seconds=5, max_backoff_seconds=300,
                 delivery_runner=bounded_delivery, delivery_policy=None):
        if not 0 < timeout_seconds <= 30:
            raise ValueError("delivery timeout must be >0 and <=30 seconds")
        if type(max_attempts) is not int or not 1 <= max_attempts <= 20:
            raise ValueError("max_attempts must be 1..20")
        if not 0 < base_backoff_seconds <= max_backoff_seconds <= 86400:
            raise ValueError("invalid retry bounds")
        self.outbox, self.adapters = outbox, dict(adapters)
        self.allow_external_send = allow_external_send is True
        self.timeout_seconds, self.max_attempts = timeout_seconds, max_attempts
        self.base_backoff_seconds, self.max_backoff_seconds = base_backoff_seconds, max_backoff_seconds
        self.delivery_runner = delivery_runner
        self.delivery_policy = delivery_policy
        self._stop = threading.Event()
        self._lock = threading.Lock()
        self._thread = None
        self.last_worker_error_code = None

    def run_once(self):
        if not self.allow_external_send:
            return {"status": "disabled", "reason": "external_delivery_not_enabled"}
        if not self._lock.acquire(blocking=False):
            return {"status": "busy"}
        try:
            item = self.outbox.claim(lease_seconds=self.timeout_seconds + 30, max_attempts=self.max_attempts)
            if item is None:
                return {"status": "idle"}
            if self.delivery_policy is not None:
                try:
                    eligible = self.delivery_policy(item['payload']) is True
                except Exception:
                    eligible = False
                if not eligible:
                    return {'id': item['id'], 'status': self.outbox.suppress_delivery(item),
                            'attempts': item['attempts'], 'error_code': 'delivery_policy_suppressed'}
            adapter = self.adapters.get(item["channel"])
            if adapter is None:
                success, code = False, "adapter_unavailable"
            else:
                try:
                    success, code = self.delivery_runner(adapter, item["payload"], item["recipient_ref"], item["id"], self.timeout_seconds)
                except Exception as exc:
                    success, code = False, "runner_" + type(exc).__name__
            delay = min(self.max_backoff_seconds, self.base_backoff_seconds * 2 ** (item["attempts"] - 1))
            status = self.outbox.finish(item, success=success, error_code=code,
                                        max_attempts=self.max_attempts, retry_delay=delay)
            return {"id": item["id"], "status": status, "attempts": item["attempts"], "error_code": code}
        finally:
            self._lock.release()

    def start(self, poll_seconds=1):
        if not 0.05 <= poll_seconds <= 60:
            raise ValueError("poll interval must be .05..60 seconds")
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        def loop():
            while not self._stop.is_set():
                try:
                    result = self.run_once()
                    self.last_worker_error_code = None
                except Exception as exc:
                    self.last_worker_error_code = type(exc).__name__
                    result = {"status": "error"}
                # Always yield; delivery errors cannot hot-loop or stall counting.
                self._stop.wait(0.05 if result["status"] == "delivered" else poll_seconds)
        self._thread = threading.Thread(target=loop, name="gate-notification-worker", daemon=True)
        start_thread(self._thread, self._stop.set)

    def stop(self, timeout=1):
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=max(0, min(timeout, 35)))
        return not (self._thread and self._thread.is_alive())


def render_email(notification):
    kind = notification["kind"]
    if kind == "confirmed_crossing":
        title = "Gate Desk: operator-confirmed bag crossing"
        body = f"Operation: {notification['operation_id']}\nDirection: {notification['direction']}\nMaterial: bag"
        if "counted" in notification:
            body += f"\nCounted so far: {notification['counted']}"
    elif kind == "finalized_pass":
        title = f"Gate Desk: finalized pass - {notification['reconciliation']}"
        body = (f"Operation: {notification['operation_id']}\nCounted: {notification['counted']} {notification['unit']}"
                f"\nExpected: {notification['expected']} {notification['unit']}"
                f"\nDifference (counted - expected): {notification['difference']:+d}"
                f"\nResult: {notification['reconciliation']}")
    else:
        title = f"Gate Desk: {notification['severity']} health alert"
        body = f"Health condition: {notification['health_key']}\n{notification['message']}"
    body += f"\nEvent: {notification['event_id']}\nOccurred: {notification['occurred_at']}\nConfirmation: {notification['confirmation_method']}"
    return title, body


def email_setup_status(env=None, *, prefix="GATE_DESK_NOTIFY_", recipient_ref="GATE_DESK_NOTIFY_TO"):
    """Read-only syntax preflight, never transport/authorization verification.

    Only fixed codes and booleans leave this function. Credentials, hostnames and
    addresses remain local configuration and are never echoed to the caller.
    """
    env = os.environ if env is None else env
    address = re.compile(r"[^\x00-\x20\x7f\s@<>,;]+@[^\x00-\x20\x7f\s@<>,;]+\.[^\x00-\x20\x7f\s@<>,;]+")
    host = env.get(prefix + "SMTP_HOST", "")
    sender = env.get(prefix + "FROM", "")
    recipient = env.get(recipient_ref, "")
    security = env.get(prefix + "SMTP_SECURITY", "ssl").lower()
    user = env.get(prefix + "SMTP_USERNAME", "")
    password = env.get(prefix + "SMTP_PASSWORD", "")
    recipient_valid = bool(address.fullmatch(recipient))
    blockers = []
    if not re.fullmatch(r"[A-Za-z0-9_.:-]{1,253}", host):
        blockers.append("smtp_host_missing_or_invalid")
    if not address.fullmatch(sender):
        blockers.append("sender_missing_or_invalid")
    if not recipient_valid:
        blockers.append("recipient_missing_or_invalid")
    if security not in {"ssl", "starttls"}:
        blockers.append("secure_transport_required")
    try:
        port = int(env.get(prefix + "SMTP_PORT", "465" if security == "ssl" else "587"))
        if not 1 <= port <= 65535:
            raise ValueError
    except (TypeError, ValueError):
        blockers.append("smtp_port_invalid")
    if bool(user) != bool(password):
        blockers.append("smtp_authentication_incomplete")
    return {"configuration_valid": not blockers, "blockers": blockers,
            "recipient_valid": recipient_valid,
            "email_adapter_enabled": env.get(prefix + "EMAIL_ENABLED", "").lower() == "true",
            "transport_verified": False,
            "scope": "Local configuration checks only; no connection or message sent."}


@dataclass(frozen=True)
class EmailAdapter:
    """SMTP fallback using environment references only; no import-time network.

    Configure GATE_DESK_NOTIFY_EMAIL_ENABLED=true separately from the worker's
    allow_external_send switch. TLS verification is mandatory, including STARTTLS.
    """
    env_prefix: str = "GATE_DESK_NOTIFY_"

    @classmethod
    def from_env(cls, prefix="GATE_DESK_NOTIFY_"):
        return cls(env_prefix=prefix)

    def send(self, notification, *, recipient_ref, idempotency_key, timeout_seconds):
        env = os.environ
        if env.get(self.env_prefix + "EMAIL_ENABLED", "").lower() != "true":
            raise RuntimeError("Email delivery is not explicitly enabled")
        host = env.get(self.env_prefix + "SMTP_HOST", "")
        sender = env.get(self.env_prefix + "FROM", "")
        recipient = env.get(recipient_ref, "")
        user = env.get(self.env_prefix + "SMTP_USERNAME", "")
        password = env.get(self.env_prefix + "SMTP_PASSWORD", "")
        security = env.get(self.env_prefix + "SMTP_SECURITY", "ssl").lower()
        if not host or not sender or not recipient or security not in {"ssl", "starttls"}:
            raise ValueError("Incomplete secure email configuration")
        if any(c in sender + recipient + host for c in "\r\n"):
            raise ValueError("Invalid email configuration")
        # A single explicit recipient avoids accidental lists/partial SMTP success.
        address = re.compile(r"[^\s@<>,;]+@[^\s@<>,;]+\.[^\s@<>,;]+")
        if not address.fullmatch(sender) or not address.fullmatch(recipient):
            raise ValueError("FROM and recipient require one mailbox each")
        if bool(user) != bool(password):
            raise ValueError("SMTP authentication requires both username and password")
        port = int(env.get(self.env_prefix + "SMTP_PORT", "465" if security == "ssl" else "587"))
        if not 1 <= port <= 65535:
            raise ValueError("Invalid SMTP port")
        title, body = render_email(notification)
        msg = EmailMessage()
        msg["From"], msg["To"], msg["Subject"] = sender, recipient, title
        msg["Message-ID"] = f"<{idempotency_key}@gate-desk.local>"
        msg.set_content(body)
        tls = ssl.create_default_context()
        client = smtplib.SMTP_SSL(host, port, timeout=timeout_seconds, context=tls) if security == "ssl" else smtplib.SMTP(host, port, timeout=timeout_seconds)
        try:
            if security == "starttls":
                client.ehlo()
                client.starttls(context=tls)
                client.ehlo()
            if user:
                client.login(user, password)
            if client.send_message(msg, from_addr=sender, to_addrs=[recipient]):
                raise RuntimeError("Recipient refused")
        finally:
            # No QUIT roundtrip after acceptance: a failed QUIT must not cause retry.
            try:
                client.close()
            except Exception:
                pass  # Closing a socket cannot retract SMTP acceptance.
