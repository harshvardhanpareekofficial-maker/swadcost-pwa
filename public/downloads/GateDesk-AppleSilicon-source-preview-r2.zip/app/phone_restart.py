"""One-use local owner restart handoffs; no credential persistence or forced stop.

The original process witness is retained after any possible stop publication
until that exact process exits, even when the bounded acceptance wait failed.
Such late/interrupted containment never starts a successor.
"""
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import time
import uuid

from app.phone_setup import PhoneSetupStore, SetupError, safe, strict_object, live_generation
from app.mobile_startup import authorize_owner, recheck_owner, existing_runtime, read_phone_settings
from app.mobile_activation import prepare_activation, validate_prepared_activation
from scripts.runtime_control import ControlTree, ProcessWitness, _identity, request_stop, settled_summary, stop_record

TTL_SECONDS = 600
_ID = re.compile(r'[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}\Z')
_RECORD_FIELDS = {'schema_version', 'handoff_id', 'owner_id', 'factory_id', 'created_at', 'expires_at',
                  'runtime_binding', 'process_identity', 'config_revision', 'config_sha256', 'config_path', 'http_port'}


class RestartError(SetupError):
    pass


def _write(path, value):
    safe(path, missing=True)
    with path.open('xb') as stream:
        stream.write((json.dumps(value, sort_keys=True, allow_nan=False)+'\n').encode())
        stream.flush(); os.fsync(stream.fileno())


def _directory(runtime, handoff_id, *, create=False):
    if not isinstance(handoff_id, str) or not _ID.fullmatch(handoff_id):
        raise RestartError('invalid_restart_handoff')
    root = safe(Path(runtime)/'phone-restarts', missing=True)
    if not root.exists() and create:
        root.mkdir()
    safe(root)
    if not root.is_dir() or (create and sum(1 for _ in root.iterdir()) >= 1024):
        raise RestartError('restart_handoff_capacity')
    child = safe(root/handoff_id, missing=create)
    if create:
        child.mkdir()
    if not child.is_dir():
        raise RestartError('invalid_restart_handoff')
    return child


def prepare_handoff(runtime, saved, identity, owner_id, factory_id, http_port, authorize):
    store = PhoneSetupStore(runtime)
    if type(http_port) is not int or not 1024 <= http_port <= 65535:
        raise RestartError('invalid_restart_handoff')
    with store.locked():
        authorize()
        current = store._read(factory_id)
        if current is None or current != saved:
            raise RestartError('revision_conflict')
        actual = live_generation(store.runtime, identity)
        if current['settings']['port'] == http_port:
            raise RestartError('invalid_phone_settings')
        handoff_id = str(uuid.uuid4())
        directory = _directory(store.runtime, handoff_id, create=True)
        now = time.time()
        record = dict(schema_version=1, handoff_id=handoff_id, owner_id=owner_id, factory_id=factory_id,
                      created_at=now, expires_at=now+TTL_SECONDS, runtime_binding=actual['runtime'],
                      process_identity=actual, config_revision=current['revision'], config_sha256=current['config_sha256'],
                      config_path=current['config_path'], http_port=http_port)
        authorize()
        _write(directory/'handoff.json', record)
    return {'kind': 'manual_owner_console_restart', 'state': 'prepared_manual',
            'generation': actual['generation'], 'runtime_binding': actual['runtime'], 'process_identity': actual,
            'config_revision': current['revision'], 'config_sha256': current['config_sha256'], 'config_path': current['config_path'],
            'requires_owner_password': True, 'automatic_restart': False, 'consumer_available': True,
            'consumer_scope': 'source_only_unaccepted', 'handoff_id': handoff_id,
            'handoff_path': str(directory/'handoff.json'), 'runtime_dir': str(store.runtime),
            'expires_at': now+TTL_SECONDS, 'helper_relative_path': 'scripts/restart_phone_service.py',
            'consumer_args': ['--runtime-dir', str(store.runtime), '--handoff-id', handoff_id]}


def load_handoff(runtime, handoff_id):
    store = PhoneSetupStore(runtime)
    path = safe(_directory(store.runtime, handoff_id)/'handoff.json')
    if path.stat().st_size > 8192:
        raise RestartError('invalid_restart_handoff')
    raw = path.read_bytes()
    record = json.loads(raw, object_pairs_hook=strict_object,
                        parse_constant=lambda _: (_ for _ in ()).throw(ValueError()))
    tree = ControlTree(store.runtime)
    if (type(record) is not dict or set(record) != _RECORD_FIELDS or type(record['schema_version']) is not int
            or record['schema_version'] != 1 or record['handoff_id'] != handoff_id
            or record['runtime_binding'] != tree.binding or type(record['config_revision']) is not int
            or not 1 <= record['config_revision'] <= 10000 or type(record['http_port']) is not int
            or not 1024 <= record['http_port'] <= 65535
            or not isinstance(record['config_sha256'], str) or not re.fullmatch(r'[0-9a-f]{64}', record['config_sha256'])
            or not isinstance(record['owner_id'], str) or not 1 <= len(record['owner_id']) <= 128
            or not isinstance(record['factory_id'], str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,128}', record['factory_id'])
            or any(type(record[key]) not in (int, float) for key in ('created_at', 'expires_at'))
            or not record['created_at'] <= time.time() < record['expires_at']
            or record['expires_at']-record['created_at'] != TTL_SECONDS):
        raise RestartError('invalid_or_expired_restart_handoff')
    _identity(tree, record['process_identity'])
    return record, hashlib.sha256(raw).hexdigest()


def _config_current(store, record):
    current = store._read(record['factory_id'])
    if (current is None or current['revision'] != record['config_revision']
            or current['config_sha256'] != record['config_sha256'] or current['config_path'] != record['config_path']):
        raise RestartError('restart_configuration_changed')
    settings = read_phone_settings(current['config_path'])
    if settings['factory_id'] != record['factory_id'] or settings['port'] == record['http_port']:
        raise RestartError('restart_configuration_changed')
    return settings


def _same_original(tree, record, *, allow_exited=False):
    original = record['process_identity']
    current = tree.read('owner.json')
    if (_identity(tree, current, owner=True) != original or current['state'] != 'running'
            or tree.read('identity.json', generation=original['generation']) != original):
        raise RestartError('restart_generation_changed')
    if not allow_exited and (tree.read('stop.json', generation=original['generation']) is not None
                           or tree.read('terminal.json', generation=original['generation']) is not None):
        raise RestartError('restart_original_already_stopping')


def _clean_terminal(tree, record):
    identity = record['process_identity']
    terminal = tree.read('terminal.json', generation=identity['generation'])
    if (type(terminal) is not dict or set(terminal) != {'protocol', 'generation', 'runtime', 'outcome', 'summary'}
            or type(terminal['protocol']) is not int or terminal['protocol'] != 2
            or terminal['generation'] != identity['generation'] or terminal['runtime'] != tree.binding
            or terminal['outcome'] != 'clean' or not settled_summary(terminal['summary']) or terminal['summary']['failures']):
        raise RestartError('restart_original_not_clean')


def consume_handoff(runtime, handoff_id, *, document_dir=None, requested_port=None, wait_seconds=110):
    """Called only after the source launcher verified its package/dependencies.

    One-use claim is never reset. Failures after claim require a new owner-prepared
    handoff. If the old process stops but successor authorization fails, start the
    normal owner console explicitly; no background or automatic retry is made.
    """
    if not isinstance(handoff_id, str) or not _ID.fullmatch(handoff_id):
        raise RestartError('invalid_restart_handoff')
    if type(wait_seconds) not in (int, float) or not 1 <= wait_seconds <= 120:
        raise RestartError('invalid_restart_wait')
    runtime, documents = existing_runtime(runtime, document_dir)
    record, digest = load_handoff(runtime, handoff_id)
    if requested_port is not None and requested_port != record['http_port']:
        raise RestartError('restart_port_override_forbidden')
    if record['process_identity']['pid'] == os.getpid():
        raise RestartError('restart_requires_separate_owner_console')
    store, tree = PhoneSetupStore(runtime), ControlTree(runtime)
    directory = _directory(runtime, handoff_id)
    claim_path = safe(directory/'claim.json', missing=True)
    if claim_path.exists():
        raise RestartError('restart_handoff_already_claimed')
    authorization = authorize_owner(runtime, record['factory_id'])
    if authorization.user_snapshot[0] != record['owner_id']:
        raise RestartError('restart_handoff_owner_mismatch')
    with store.locked():
        settings = _config_current(store, record)
    # Real certificate identity admission is completed before any stop request.
    prepared = prepare_activation(settings)
    validate_prepared_activation(prepared, prepared.config, prepared.tls_context)
    recheck_owner(authorization)
    with store.locked():
        fresh, fresh_digest = load_handoff(runtime, handoff_id)
        if fresh != record or fresh_digest != digest:
            raise RestartError('restart_handoff_changed')
        _config_current(store, record)
        _same_original(tree, record)
        _write(claim_path, {'schema_version': 1, 'handoff_sha256': digest, 'consumer_pid': os.getpid(),
                            'claimed_at': time.time(), 'one_use': True})
    claimed = json.loads(claim_path.read_text())

    def stage(name, **details):
        _write(directory/(name+'.json'), {'stage': name, 'at': time.time(), **details})

    def revalidate(*, startup=False):
        fresh, fresh_digest = load_handoff(runtime, handoff_id)
        if fresh != record or fresh_digest != digest or json.loads(safe(claim_path).read_text()) != claimed:
            raise RestartError('restart_handoff_changed')
        with store.locked():
            _config_current(store, record)
        recheck_owner(authorization)
        if startup:
            _clean_terminal(tree, record)

    original = record['process_identity']
    try:
        process = ProcessWitness(original['pid'], original['created'])
    except BaseException as exc:
        try: stage('failure', reason=type(exc).__name__, stop_possible=False)
        except BaseException: pass
        raise RestartError('restart_original_witness_unavailable') from None
    stop_possible = False
    late = interrupted = False
    started = time.monotonic()
    try:
        if process.exited():
            raise RestartError('restart_original_already_exited')
        revalidate()
        stage('01-authorized-and-claimed')
        def captured(identity):
            nonlocal stop_possible
            if identity != original:
                raise RestartError('restart_generation_changed')
            revalidate()
            _same_original(tree, record)
            # From here publication may occur even if an observation raises.
            stop_possible = True
        try:
            answer = request_stop(runtime, wait_seconds, captured=captured)
            if not stop_possible or answer.get('code') != 0 or answer.get('status') != 'clean' or answer.get('newer_owner_observed'):
                raise RestartError('restart_stop_not_clean_within_bound')
        except BaseException as exc:
            interrupted = isinstance(exc, (KeyboardInterrupt, SystemExit))
            raise
        finally:
            if stop_possible:
                try:
                    recorded_stop = tree.read('stop.json', generation=original['generation'])
                    if recorded_stop is None:
                        # Verified failed-before-publication: do not hold a
                        # healthy predecessor forever when no stop was issued.
                        stop_possible = False
                    elif recorded_stop != stop_record(original):
                        interrupted = True
                except BaseException:
                    # Publication is uncertain. Keep the exact witness rather
                    # than dropping a process which may already be stopping.
                    interrupted = True
            if stop_possible:
                # No force kill or detached process. Retain this exact native
                # process witness until settlement, including late/error paths.
                while True:
                    try:
                        if process.exited(): break
                        if time.monotonic()-started >= wait_seconds: late = True
                        time.sleep(.05)
                    except BaseException:
                        interrupted = True
                        try: time.sleep(.05)
                        except BaseException: pass
                late = late or time.monotonic()-started >= wait_seconds
        if late or interrupted:
            raise RestartError('restart_late_or_interrupted_no_successor')
        _same_original(tree, record, allow_exited=True)
        _clean_terminal(tree, record)
        revalidate(startup=True)
        stage('02-original-clean-exit', elapsed_seconds=time.monotonic()-started)
    except BaseException as exc:
        try: stage('failure', reason=type(exc).__name__, stop_possible=stop_possible, late=late, interrupted=interrupted)
        except BaseException: pass
        raise RestartError('restart_refused_no_successor') from None
    finally:
        process.close()

    def startup_guard():
        from app.runtime_owner import current_owner
        owner = current_owner()
        if owner is None or not owner.accepting or owner.stop_requested.is_set():
            raise RestartError('restart_successor_ownership_required')
        revalidate(startup=True)
        successor = _identity(tree, tree.read('owner.json'), owner=True)
        if successor['pid'] != os.getpid() or successor['generation'] == original['generation']:
            raise RestartError('restart_successor_generation_invalid')
        stage('04-successor-owned-configuration', generation=successor['generation'])

    # Still no successor: recheck original pointer before entering the normal
    # launcher. Its runtime lock rejects an intervening competing process.
    try:
        _same_original(tree, record, allow_exited=True)
        revalidate(startup=True)
        stage('03-entering-interactive-startup')
    except BaseException as exc:
        try: stage('successor-failure', reason=type(exc).__name__)
        except BaseException: pass
        raise RestartError('restart_successor_failed_manual_recovery_required') from None
    from scripts import launch_offline_source as launcher
    previous = sys.argv[:]
    sys.argv[:] = ['launch_offline_source', '--runtime-dir', str(runtime), '--document-dir', str(documents),
                   '--port', str(record['http_port']), '--phone-config', record['config_path']]
    try:
        result = launcher.main(phone_startup_guard=startup_guard)
        stage('05-successor-returned', return_code=result)
        return result
    except BaseException as exc:
        try: stage('successor-failure', reason=type(exc).__name__)
        except BaseException: pass
        raise RestartError('restart_successor_failed_manual_recovery_required') from None
    finally:
        sys.argv[:] = previous
