"""Explicit document storage capabilities. One shared instance/lock per root.

Trusted host selects the root; this does not provide multi-process locking or
protection against concurrent local filesystem attackers.
"""
import hashlib
import io
import json
import os
import threading
from pathlib import Path
from datetime import datetime, timezone
from typing import Literal
from fastapi import HTTPException
from pydantic import BaseModel, Field
from PIL import Image, ImageOps, UnidentifiedImageError

class DocumentLine(BaseModel):
    id:str=Field(min_length=1,max_length=50)
    material:str=Field(min_length=1,max_length=150)
    quantity:int=Field(ge=1,le=10000)
    unit:Literal['unit','bag','cone','beam','roll','bundle','carton']
    weight_kg:str=Field(default='',max_length=30)
class DocumentReview(BaseModel):
    number:str=Field(min_length=1,max_length=60)
    date_raw:str=Field(min_length=1,max_length=60)
    carrier:str=Field(default='',max_length=60)
    direction:Literal['Incoming','Outgoing']
    lines:list[DocumentLine]=Field(min_length=1,max_length=30)

class DocumentStore:
    @classmethod
    def create_new(cls, directory):
        """Explicit provisioning only: refuse even an empty existing directory.

        A missing index in an existing factory may mean lost evidence. Never
        interpret that as permission to initialize. Partial failures remain for
        inspection; no automatic deletion or retry repairs the directory.
        """
        root=Path(directory)
        root.mkdir(parents=False, exist_ok=False)
        index=root/'gatepasses.json'
        with index.open('xb') as stream:
            stream.write(b'[]\n');stream.flush();os.fsync(stream.fileno())
        return cls(index)

    def __init__(self, index, lock=None):
        self.index=Path(index)
        self.lock=lock if lock is not None else threading.Lock()

    def documents(self):
        return json.loads(self.index.read_text(encoding='utf-8')) if self.index.exists() else []

    def import_image(self, file):
        """Local image intake only. No OCR, inferred quantities or review approval."""
        data=file.file.read(10*1024*1024+1)
        if len(data)>10*1024*1024:raise HTTPException(413,'Choose an image smaller than 10 MB.')
        try:
            with Image.open(io.BytesIO(data)) as image:
                if image.format not in ('JPEG','PNG','WEBP') or getattr(image,'n_frames',1)!=1:
                    raise HTTPException(422,'Choose a single-page JPG, PNG or WebP image.')
                if image.width*image.height>20_000_000:
                    raise HTTPException(413,'Choose an image below 20 megapixels.')
                extension={'JPEG':'jpg','PNG':'png','WEBP':'webp'}[image.format]
                image=ImageOps.exif_transpose(image).convert('RGB')
                image.load()
                normalized=io.BytesIO();image.save(normalized,format='PNG')
                pixels=hashlib.sha256(image.tobytes()).hexdigest()
                width,height=image.size
        except (UnidentifiedImageError,OSError,Image.DecompressionBombError):
            raise HTTPException(422,'Choose a readable JPG, PNG or WebP image.')
        source_sha=hashlib.sha256(data).hexdigest();doc_id='scan-'+source_sha
        preview=normalized.getvalue();preview_sha=hashlib.sha256(preview).hexdigest()
        with self.lock:
            items=self.documents()
            existing=next((d for d in items if d['id']==doc_id),None)
            root=self.index.parent
            assets=[(root/'gatepass-originals'/(doc_id+'.'+extension),data),
                    (root/'gatepasses'/(doc_id+'.png'),preview)]
            if existing:
                # Retry never replaces operator-reviewed fields or damaged evidence.
                source=existing.get('source',{})
                expected=[source.get('sha256'),source.get('preview_sha256')]
                for (path,_),sha in zip(assets,expected):
                    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=sha:
                        raise HTTPException(409,'Saved document evidence is missing or changed; restore it before retrying.')
                return {'document':existing,'idempotent_retry':True}
            for path,content in assets:
                path.parent.mkdir(parents=True,exist_ok=True)
                if path.exists():
                    if path.read_bytes()!=content:
                        raise HTTPException(409,'An incomplete import has conflicting evidence; no file was replaced.')
                else:
                    with path.open('xb') as stream:
                        stream.write(content);stream.flush();os.fsync(stream.fileno())
            document={'id':doc_id,'status':'unreviewed','issuer':'Imported document','recipient':'',
                      'number':'','direction':'','date_raw':'','carrier':'','lines':[],
                      'notes':'Image imported locally. Enter and review the document fields; no OCR was run.',
                      'imported_at':datetime.now(timezone.utc).isoformat(),
                      'source':{'sha256':source_sha,'bytes':len(data),'extension':extension,
                                'preview_sha256':preview_sha,'rgb_sha256':pixels,'width':width,'height':height,
                                'processing':'EXIF orientation applied; RGB PNG preview; original bytes preserved'}}
            items.append(document)
            # Index is the commit marker. A failed write may leave unlisted assets;
            # an explicit retry reuses matching assets without replacing evidence.
            temp=self.index.with_suffix('.tmp')
            with temp.open('w',encoding='utf-8') as stream:
                json.dump(items,stream,indent=2);stream.flush();os.fsync(stream.fileno())
            temp.replace(self.index)
            return {'document':document,'idempotent_retry':False}

    def review(self, doc_id, body):
        if not body.number.strip() or any(not line.material.strip() for line in body.lines):raise HTTPException(422,'Enter the document number and material descriptions.')
        if len({line.id for line in body.lines})!=len(body.lines):raise HTTPException(422,'Line identifiers must be unique.')
        with self.lock:
            items=self.documents();document=next((d for d in items if d['id']==doc_id),None)
            if not document:raise HTTPException(404,'Document not found.')
            if document.get('source'):
                source=document['source'];extension=source.get('extension')
                if extension not in ('jpg','png','webp'):raise HTTPException(409,'Imported document evidence is invalid.')
                for folder,suffix,key in [('gatepass-originals',extension,'sha256'),('gatepasses','png','preview_sha256')]:
                    root=(self.index.parent/folder).resolve();path=(root/(doc_id+'.'+suffix)).resolve()
                    if not path.is_relative_to(root) or not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=source.get(key):
                        raise HTTPException(409,'Imported document evidence is missing or changed; review was not saved.')
            document.update(body.model_dump());document['status']='reviewed';document['reviewed_at']=datetime.now(timezone.utc).isoformat()
            temp=self.index.with_suffix('.tmp');temp.write_text(json.dumps(items,indent=2),encoding='utf-8');temp.replace(self.index)
            return document
