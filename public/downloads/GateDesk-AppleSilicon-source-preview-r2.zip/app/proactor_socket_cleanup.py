"""Windows socket-only correction for the observed 10054 cleanup gap.

No global monkeypatch; selected only by the explicit Windows HTTP loop.
Private asyncio API: constructor refuses anything but the inspected runtime.
"""
import hashlib
from pathlib import Path
import socket
import sys
from asyncio import proactor_events


SOURCE_SHA256 = '62d15e99315cae52e8548f487391ae6c46827bf8e5b4bcf3382c777a494a759b'


def verify_runtime():
    if (sys.platform != 'win32' or tuple(sys.version_info[:3]) != (3, 12, 14)
            or hashlib.sha256(Path(proactor_events.__file__).read_bytes()).hexdigest() != SOURCE_SHA256):
        raise RuntimeError('unsupported_socket_cleanup_runtime')


def finish_socket(transport, exc):
    if transport._called_connection_lost:
        return
    try:
        transport._protocol.connection_lost(exc)
    finally:
        sock = transport._sock
        if hasattr(sock, 'shutdown') and sock.fileno() != -1:
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except ConnectionResetError as error:
                # Only the exact observed Windows reset is recoverable here.
                # Other shutdown failures retain the original ownership hold.
                if getattr(error, 'winerror', None) != 10054 and error.errno != 10054:
                    raise
        sock.close()
        # Do not detach, clear references, or claim completion if close raises.
        transport._sock = None
        server = transport._server
        if server is not None:
            server._detach()
            transport._server = None
        transport._called_connection_lost = True


class ResetSafeSocketTransport(proactor_events._ProactorSocketTransport):
    def __init__(self, *args, **kwargs):
        verify_runtime()
        super().__init__(*args, **kwargs)

    def _call_connection_lost(self, exc):
        return finish_socket(self, exc)
