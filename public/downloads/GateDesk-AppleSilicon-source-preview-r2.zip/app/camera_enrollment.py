"""Unwired production camera drafts; no capture, HTTP routes or network calls.

Trusted host supplies an authorizer that revalidates an opaque session against
enabled accounts/current factory membership on every call. This is a service
boundary, not endpoint security. Never expose authorizer injection to clients.
Encrypted credentials and public config commit in one SQLite transaction; no
cross-store orphan cleanup. Database is private and must not enter portable
backups/packages. Existing research recorder configuration is never touched.
"""
import ctypes
from ctypes import wintypes
from dataclasses import dataclass
import ipaddress
import json
from pathlib import Path
import re
import sqlite3
import sys
from contextlib import contextmanager


class EnrollmentError(RuntimeError):
    """Only fixed, non-secret codes leave this module."""


@dataclass(frozen=True)
class OwnerIdentity:
    account_id: str
    factory_id: str
    role: str
    active: bool
    accounts_enabled: bool


def _identifier(value):
    return isinstance(value, str) and re.fullmatch(r'[A-Za-z0-9_-]{1,80}', value)


class WindowsUserProtection:
    """DPAPI current-user scope, no UI, no plaintext fallback.

    No LOCAL_MACHINE flag. Python cannot promise erasure of immutable copies.
    Windows roaming profiles can affect portability; no cross-user claim here.
    """
    class Blob(ctypes.Structure):
        _fields_ = [('cbData', wintypes.DWORD), ('pbData', ctypes.POINTER(ctypes.c_ubyte))]

    def _transform(self, value, *, decrypt):
        if sys.platform != 'win32':
            raise EnrollmentError('windows_secret_protection_unavailable')
        if not isinstance(value, bytes) or not 1 <= len(value) <= 32768:
            raise EnrollmentError('invalid_secret_blob')
        source = ctypes.create_string_buffer(value)
        incoming = self.Blob(len(value), ctypes.cast(source, ctypes.POINTER(ctypes.c_ubyte)))
        outgoing = self.Blob()
        kernel = None
        try:
            crypt = ctypes.WinDLL('crypt32', use_last_error=True)
            kernel = ctypes.WinDLL('kernel32', use_last_error=True)
            kernel.LocalFree.argtypes = [ctypes.c_void_p]
            kernel.LocalFree.restype = ctypes.c_void_p
            operation = crypt.CryptUnprotectData if decrypt else crypt.CryptProtectData
            operation.argtypes = [ctypes.POINTER(self.Blob), ctypes.c_void_p,
                                  ctypes.POINTER(self.Blob), ctypes.c_void_p,
                                  ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(self.Blob)]
            operation.restype = wintypes.BOOL
            if not operation(ctypes.byref(incoming), None, None, None, None, 1,
                             ctypes.byref(outgoing)):
                raise EnrollmentError('secret_protection_failed')
            if not 0 < outgoing.cbData <= 32768:
                raise EnrollmentError('invalid_secret_blob')
            return ctypes.string_at(outgoing.pbData, outgoing.cbData)
        except Exception:
            raise EnrollmentError('secret_protection_failed') from None
        finally:
            ctypes.memset(source, 0, len(source))
            if outgoing.pbData and kernel is not None:
                ctypes.memset(outgoing.pbData, 0, outgoing.cbData)
                kernel.LocalFree(ctypes.cast(outgoing.pbData, ctypes.c_void_p))

    def protect(self, value):
        return self._transform(value, decrypt=False)

    def unprotect(self, value):
        return self._transform(value, decrypt=True)


def validate_draft(draft):
    if not isinstance(draft, dict) or set(draft) != {'camera_id', 'name', 'host', 'port', 'stream_path'}:
        raise EnrollmentError('invalid_camera_draft')
    if not _identifier(draft['camera_id']):
        raise EnrollmentError('invalid_camera_draft')
    name = draft['name']
    if not isinstance(name, str) or not 1 <= len(name.strip()) <= 80 or any(ord(c) < 32 for c in name):
        raise EnrollmentError('invalid_camera_draft')
    try:
        address = ipaddress.IPv4Address(draft['host'])
        if not any(address in ipaddress.ip_network(n) for n in
                   ('10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16')):
            raise ValueError()
    except (ValueError, TypeError, ipaddress.AddressValueError):
        raise EnrollmentError('invalid_camera_address') from None
    if not isinstance(draft['host'], str) or str(address) != draft['host']:
        raise EnrollmentError('invalid_camera_address')
    if type(draft['port']) is not int or not 1 <= draft['port'] <= 65535:
        raise EnrollmentError('invalid_camera_port')
    path = draft['stream_path']
    if (not isinstance(path, str) or not re.fullmatch(r'/[A-Za-z0-9_/-]{1,200}', path)
            or '//' in path):
        raise EnrollmentError('invalid_stream_path')
    return dict(draft)


class CameraEnrollment:
    """Single camera draft per explicit factory DB. Authorizer is host capability.

    authorize(session) must return a freshly checked OwnerIdentity or reject.
    No capture exists in this slice, so all revisions remain unverified drafts.
    Existing files are never automatically initialized/repaired.
    """
    def __init__(self, database, *, factory_id, authorize, protection=None):
        if not _identifier(factory_id) or not callable(authorize):
            raise EnrollmentError('invalid_enrollment_binding')
        self.database = Path(database).resolve()
        self.factory_id = factory_id
        self._authorize = authorize
        if protection is not None:
            self._protection = protection
        elif sys.platform == "darwin":
            from native.macos.keychain import MacUserProtection
            self._protection = MacUserProtection(self.database)
        else:
            self._protection = WindowsUserProtection()

    def _owner(self, session):
        try:
            owner = self._authorize(session)
            allowed = (isinstance(owner, OwnerIdentity) and _identifier(owner.account_id)
                       and owner.factory_id == self.factory_id and owner.role == 'owner'
                       and owner.active is True and owner.accounts_enabled is True)
        except Exception:
            allowed = False
        if not allowed:
            raise EnrollmentError('owner_required') from None
        return owner.account_id

    @classmethod
    def create_new(cls, directory, *, factory_id, authorize, session, protection=None):
        root = Path(directory)
        service = cls(root / 'camera-enrollment.sqlite3', factory_id=factory_id,
                      authorize=authorize, protection=protection)
        service._owner(session)
        try:
            root.mkdir(parents=False, exist_ok=False)
            with sqlite3.connect(service.database, timeout=0.2) as db:
                db.execute('PRAGMA synchronous=FULL')
                db.execute('CREATE TABLE binding (singleton INTEGER PRIMARY KEY CHECK(singleton=1), version INTEGER NOT NULL, factory_id TEXT NOT NULL)')
                db.execute('INSERT INTO binding VALUES (1,1,?)', (factory_id,))
                db.execute('CREATE TABLE draft (singleton INTEGER PRIMARY KEY CHECK(singleton=1), revision INTEGER NOT NULL, public TEXT NOT NULL, secret BLOB NOT NULL)')
        except Exception:
            # Leave partial provisioning for inspection; never erase/reinitialize.
            raise EnrollmentError('enrollment_provision_failed') from None
        return service

    @contextmanager
    def _db(self):
        db = None
        try:
            db = sqlite3.connect(self.database.as_uri() + '?mode=rw', uri=True, timeout=0.2)
            db.execute('PRAGMA synchronous=FULL')
            binding = db.execute('SELECT version,factory_id FROM binding WHERE singleton=1').fetchone()
            if binding != (1, self.factory_id):
                raise EnrollmentError('invalid_enrollment_binding')
            yield db
        except EnrollmentError:
            raise
        except Exception:
            raise EnrollmentError('enrollment_storage_failed') from None
        finally:
            if db is not None:
                db.close()

    def _read(self, db):
        row = db.execute('SELECT revision,public,length(secret) FROM draft WHERE singleton=1').fetchone()
        if row is None:
            return None
        try:
            revision, raw, size = row
            value = json.loads(raw)
            if (type(revision) is not int or revision < 1 or not 0 < size <= 32768
                    or set(value) != {'camera', 'revision', 'factory_id', 'saved_by', 'state'}
                    or value['revision'] != revision or value['factory_id'] != self.factory_id
                    or value['state'] != 'configured_unverified' or not _identifier(value['saved_by'])):
                raise ValueError()
            validate_draft(value['camera'])
            return value
        except Exception:
            raise EnrollmentError('enrollment_corrupt') from None

    def read(self, session):
        self._owner(session)
        with self._db() as db:
            return self._read(db)

    def save(self, session, *, draft, username, password, expected_revision):
        owner = self._owner(session)
        camera = validate_draft(draft)
        if type(expected_revision) is not int or not 0 <= expected_revision < 2**31:
            raise EnrollmentError('invalid_revision')
        if (not isinstance(username, str) or not 1 <= len(username) <= 128
                or not isinstance(password, str) or not 1 <= len(password) <= 1024
                or any(ord(c) < 32 for c in username + password)):
            raise EnrollmentError('invalid_credentials')
        with self._db() as db:
            db.execute('BEGIN IMMEDIATE')
            current = self._read(db)
            if (current['revision'] if current else 0) != expected_revision:
                raise EnrollmentError('revision_conflict')
            revision = expected_revision + 1
            value = dict(camera=camera, revision=revision, factory_id=self.factory_id,
                         saved_by=owner, state='configured_unverified')
            payload = json.dumps(dict(factory_id=self.factory_id, camera_id=camera['camera_id'],
                                      revision=revision, username=username, password=password)).encode()
            try:
                encrypted = self._protection.protect(payload)
                if not isinstance(encrypted, bytes) or not 0 < len(encrypted) <= 32768:
                    raise ValueError()
            except Exception:
                raise EnrollmentError('secret_protection_failed') from None
            db.execute('INSERT OR REPLACE INTO draft VALUES (1,?,?,?)',
                       (revision, json.dumps(value, sort_keys=True), encrypted))
            db.commit()
            return value
