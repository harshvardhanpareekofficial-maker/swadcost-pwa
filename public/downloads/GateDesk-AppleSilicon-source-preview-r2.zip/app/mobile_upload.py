"""Owned remote upload adapter; caller supplies trusted factory import function.

No route registration. Authorization must precede this call. Admission remains
held through actual receive settlement, parser/import worker exit and cleanup.
"""
import asyncio
from app.runtime_owner import current_owner
from app.runtime_resources import ResourceUnavailable
from app.upload_intake import validate_headers, IntakeError, MAX_BYTES, CHUNK_BYTES
from app.memory_multipart import parse_memory_file


async def import_owned_upload(scope, receive, pool, importer):
    owner = current_owner()
    if owner is None:
        raise ResourceUnavailable('mobile_owner_required')
    length, boundary = validate_headers(scope.get('headers'))
    token = pool.try_acquire()
    buffer, outcome = bytearray(), []
    async def cleanup():
        buffer[:] = b'\0' * len(buffer)
        buffer.clear()
        pool.release(token)
    try:
        lease = owner.acquire_request_resource('upload', cleanup)
    except BaseException:
        pool.release(token)
        raise
    try:
        loop = asyncio.get_running_loop()
        deadline = loop.time() + 30
        while True:
            pending = lease.start_receive(receive)
            done, _ = await asyncio.wait({pending}, timeout=max(0, min(10, deadline-loop.time())))
            if not done or loop.time() >= deadline:
                raise IntakeError(408, 'body_timeout')
            message = pending.result()
            if not isinstance(message, dict) or message.get('type') != 'http.request':
                raise IntakeError(400, 'invalid_body')
            chunk = message.get('body', b'')
            more = message.get('more_body', False)
            if type(chunk) is not bytes or type(more) is not bool:
                raise IntakeError(400, 'invalid_body')
            if len(buffer)+len(chunk) > MAX_BYTES:
                raise IntakeError(413, 'body_too_large')
            buffer.extend(chunk)
            if length is not None and len(buffer) > length:
                raise IntakeError(400, 'length_mismatch')
            if not more:
                break
        if length is not None and length != len(buffer):
            raise IntakeError(400, 'length_mismatch')
        def work(cancel):
            file = None
            try:
                chunks = (bytes(buffer[i:i+CHUNK_BYTES]) for i in range(0, len(buffer), CHUNK_BYTES))
                file = parse_memory_file(chunks, boundary, len(buffer), cancelled=cancel.is_set)
                if cancel.is_set():
                    raise ResourceUnavailable('upload_cancelled')
                outcome.append((True, importer(file)))
            except Exception as exc:
                outcome.append((False, exc))
            finally:
                if file is not None:
                    file.close()
                lease.request_close()
        lease.start_worker(work)
        await lease.wait_closed()
        if not outcome:
            raise ResourceUnavailable('upload_not_started')
        success, result = outcome[0]
        if not success:
            raise result
        return result
    finally:
        lease.request_close()
        await lease.wait_closed()
