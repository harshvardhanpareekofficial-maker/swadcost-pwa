"""Inert account adapter. Does not install routes or enable remote accounts.

The caller must supply an owned async offloader that retains physical DB work
through cancellation/shutdown. There is deliberately no unowned default executor.
"""
from pathlib import Path
import re
import sqlite3

COOKIE = '__Host-gate_desk_remote'


def membership_reader(path):
    uri = Path(path).resolve().as_uri() + '?mode=ro'
    def membership(uid, factory_id):
        c = sqlite3.connect(uri, uri=True, timeout=0.2)
        try:
            row = c.execute('''SELECT u.role FROM users u CROSS JOIN factory f
                WHERE u.id=? AND u.active=1 AND f.singleton=1 AND f.id=?''',
                            (uid, factory_id)).fetchone()
        finally:
            c.close()
        return row[0] if row and row[0] in ('owner', 'worker') else None
    return membership


def remote_cookie(scope):
    headers = [v for k, v in scope.get('headers', []) if k.lower() == b'cookie']
    if len(headers) != 1 or len(headers[0]) > 4096:
        return None
    try:
        text = headers[0].decode('ascii')
    except UnicodeDecodeError:
        return None
    if any(ord(c) < 32 or ord(c) == 127 for c in text):
        return None
    found = []
    for part in text.split(';'):
        name, sep, value = part.strip().partition('=')
        if not sep or not name:
            return None
        if name == COOKIE:
            found.append(value)
    if len(found) != 1 or not re.fullmatch(r'[A-Za-z0-9_-]{43}', found[0]):
        return None
    return found[0]


def session_resolver(store, owned_offload):
    if not callable(owned_offload):
        raise ValueError('owned_offloader_required')
    async def resolve(scope):
        token = remote_cookie(scope)
        if token is None:
            return None
        try:
            return await owned_offload(lambda: store.resolve(token))
        except sqlite3.Error:
            # No storage paths, SQL or credentials in a client response.
            return None
    return resolve
