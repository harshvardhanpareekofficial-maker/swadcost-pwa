"""Local quarantine ingest; never labels, counts, training admission or uploads.

The supervisor owns scheduling. Each explicit attempt runs at most once, with a
single OS-locked writer. RTSP capture remuxes native video packets in-process;
credentials come from the environment and never enter command arguments/receipts.
"""
from __future__ import annotations

import argparse
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import re
import shutil
import time
import threading
from urllib.parse import urlsplit

import av

from ml.video_triage import sha256
from scripts.runtime_lock import runtime_lock


class IngestError(RuntimeError):
    """Safe, fixed error code; never includes backend text or a camera URL."""


def _now():
    return datetime.now(timezone.utc).isoformat()


def _identifier(value):
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9_-]{1,80}", value):
        raise IngestError("invalid_identifier")
    return value


def _atomic_json(path, value):
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8") as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.write("\n")
        f.flush()
        os.fsync(f.fileno())
    os.replace(temporary, path)


@dataclass(frozen=True)
class RTSPConfig:
    camera_id: str
    endpoint_env: str = "GATE_CAMERA_RTSP_URL"
    segment_seconds: int = 180
    connect_timeout_seconds: int = 10
    read_timeout_seconds: int = 10

    def validate(self):
        _identifier(self.camera_id)
        _identifier(self.endpoint_env)
        for field, low, high in (("segment_seconds", 1, 900),
                                 ("connect_timeout_seconds", 1, 60),
                                 ("read_timeout_seconds", 1, 60)):
            value = getattr(self, field)
            if type(value) is not int or not low <= value <= high:
                raise IngestError("invalid_capture_bound")

    def resolve_endpoint(self):
        self.validate()
        value = os.environ.get(self.endpoint_env, "")
        try:
            parsed = urlsplit(value)
            address = ipaddress.ip_address(parsed.hostname or "")
            allowed = any(address in network for network in (
                ipaddress.ip_network("10.0.0.0/8"),
                ipaddress.ip_network("172.16.0.0/12"),
                ipaddress.ip_network("192.168.0.0/16"),
                ipaddress.ip_network("fc00::/7")))
            valid = parsed.scheme == "rtsp" and allowed and parsed.path and not parsed.fragment
            valid = valid and (parsed.port is None or 1 <= parsed.port <= 65535)
        except (ValueError, TypeError):
            valid = False
        if not valid:
            raise IngestError("missing_or_invalid_local_rtsp_endpoint")
        return value


class IngestStore:
    """One private runtime directory, outside published/static assets.

    Callers must supply protected exact source hashes from their policy registry.
    An unrecognized source still stays quarantined; lack of a hash match is not
    proof of a new operation or permission to train.
    """
    def __init__(self, root, *, protected_hashes=(), max_bytes=512 * 1024**2,
                 min_free_bytes=512 * 1024**2):
        self.root = Path(root).resolve()
        if max_bytes <= 0 or min_free_bytes < 0:
            raise IngestError("invalid_storage_bound")
        self.max_bytes, self.min_free_bytes = max_bytes, min_free_bytes
        self.protected_hashes = frozenset(protected_hashes)
        if any(not re.fullmatch(r"[0-9a-f]{64}", x) for x in self.protected_hashes):
            raise IngestError("invalid_protected_hash")
        for name in ("attempts", "staging", "originals"):
            (self.root / name).mkdir(parents=True, exist_ok=True)

    def pause(self):
        # Independent of the long-running writer lock so capture can be stopped.
        (self.root / "PAUSED").touch(exist_ok=True)

    def resume(self):
        """Only a direct user resume should call this; never invoked by recovery."""
        (self.root / "PAUSED").unlink(missing_ok=True)

    def is_paused(self):
        return (self.root / "PAUSED").exists()

    def _path(self, attempt_id):
        return self.root / "attempts" / (_identifier(attempt_id) + ".json")

    def _save(self, record):
        _atomic_json(self._path(record["attempt_id"]), record)

    def _space(self, upcoming=0):
        if shutil.disk_usage(self.root).free - upcoming < self.min_free_bytes:
            raise IngestError("disk_reserve_reached")

    def _check_stop(self, stop):
        if self.is_paused() or (stop and stop()):
            raise IngestError("interrupted")

    @contextmanager
    def segment_session(self):
        """Connection-wide writer ownership for public locked transactions."""
        with runtime_lock(self.root):
            self._segment_owner = threading.get_ident()
            try:
                yield self
            finally:
                self._segment_owner = None

    def _require_segment_owner(self):
        if getattr(self, "_segment_owner", None) != threading.get_ident():
            raise IngestError("segment_writer_lock_required")

    def begin_segment_locked(self, *, attempt_id, camera_id, request_identity):
        """Register once before opening a stream segment; caller owns session lock."""
        self._require_segment_owner()
        _identifier(camera_id)
        if (not isinstance(request_identity, dict) or
                set(request_identity) != {"session_id", "authorization_id", "clock_evidence_sha256", "ordinal"}):
            raise IngestError("invalid_segment_identity")
        _identifier(request_identity["session_id"])
        _identifier(request_identity["authorization_id"])
        if (not isinstance(request_identity["clock_evidence_sha256"], str) or
                not re.fullmatch(r"[0-9a-f]{64}", request_identity["clock_evidence_sha256"]) or
                type(request_identity["ordinal"]) is not int or not 1 <= request_identity["ordinal"] <= 10):
            raise IngestError("invalid_segment_identity")
        path = self._path(attempt_id)
        if path.exists():
            raise IngestError("segment_attempt_already_registered")
        self._check_stop(None)
        self._space()
        part = self.root / "staging" / (attempt_id + ".part")
        if part.exists():
            raise IngestError("unregistered_staging_file")
        record = dict(version=1, attempt_id=attempt_id, camera_id=camera_id,
                      kind="rtsp_stream_segment", request_identity=request_identity,
                      state="running", started_at=_now(),
                      staging_file=part.relative_to(self.root).as_posix(),
                      split="quarantine_unassigned", operation_id=None, truth=None,
                      model_exposure=False, training_admitted=False,
                      source_clock_verified=False, complete_operation=None,
                      continuity_verified=False, automatic_retry=False)
        self._save(record)
        return record

    def seal_segment_locked(self, attempt_id, metadata):
        """Seal a closed complete segment. Prepared bytes remain recoverable."""
        self._require_segment_owner()
        record = json.loads(self._path(attempt_id).read_text(encoding="utf-8"))
        if record["state"] != "running" or record["kind"] != "rtsp_stream_segment":
            raise IngestError("segment_not_running")
        self._check_stop(None)
        part = self.root / record["staging_file"]
        if not part.is_file() or not 0 < part.stat().st_size <= self.max_bytes:
            raise IngestError("empty_or_oversize_source")
        self._space()
        with part.open("r+b") as file:
            os.fsync(file.fileno())
        source_hash = sha256(part)
        if source_hash in self.protected_hashes:
            raise IngestError("protected_source")
        record.update(state="prepared", capture_finished_at=_now(),
                      source_sha256=source_hash, bytes=part.stat().st_size,
                      original_file=f"originals/{source_hash[:2]}/{source_hash}.mkv",
                      media=metadata)
        self._save(record)
        return self._commit(record)

    def interrupt_segment_locked(self, attempt_id, reason):
        """Retain partial bytes; never downgrade a committed/prepared receipt."""
        self._require_segment_owner()
        if not re.fullmatch(r"[a-z0-9_]{1,80}", reason):
            raise IngestError("invalid_segment_reason")
        record = json.loads(self._path(attempt_id).read_text(encoding="utf-8"))
        if record["state"] in {"quarantined", "prepared"}:
            return record
        part = self.root / record["staging_file"]
        record.update(state="interrupted", ended_at=_now(), error_code=reason,
                      partial_bytes=part.stat().st_size if part.exists() else 0,
                      partial_sha256=sha256(part) if part.exists() else None)
        self._save(record)
        return record

    def _commit(self, record):
        source_hash = record["source_sha256"]
        if source_hash in self.protected_hashes:
            raise IngestError("protected_source")
        part = self.root / record["staging_file"]
        target = self.root / record["original_file"]
        if target.exists():
            if target.stat().st_size != record["bytes"] or sha256(target) != source_hash:
                raise IngestError("existing_original_integrity_failure")
            if part.exists() and sha256(part) != source_hash:
                raise IngestError("prepared_source_integrity_failure")
            duplicate = True
        else:
            if not part.exists() or sha256(part) != source_hash:
                raise IngestError("prepared_source_integrity_failure")
            target.parent.mkdir(parents=True, exist_ok=True)
            os.replace(part, target)
            duplicate = False
        record.update(state="quarantined", committed_at=_now(), exact_duplicate=duplicate,
                      original_integrity_verified=True)
        self._save(record)
        # Only our verified duplicate temporary copy is removable. Source files,
        # incomplete capture bytes and canonical originals are never deleted.
        if duplicate and part.exists():
            part.unlink()
        return record

    def _execute(self, attempt_id, camera_id, kind, writer, *, stop=None,
                 request_identity=None):
        _identifier(camera_id)
        with runtime_lock(self.root):
            path = self._path(attempt_id)
            if path.exists():
                record = json.loads(path.read_text(encoding="utf-8"))
                if (record["camera_id"], record["kind"], record.get("request_identity")) != (
                        camera_id, kind, request_identity):
                    raise IngestError("attempt_identity_conflict")
                return record  # Never repeats a failed/interrupted/finished job.
            self._check_stop(stop)
            self._space()
            part = self.root / "staging" / (attempt_id + ".part")
            if part.exists():
                raise IngestError("unregistered_staging_file")
            record = dict(version=1, attempt_id=attempt_id, camera_id=camera_id,
                          kind=kind, request_identity=request_identity,
                          state="running", started_at=_now(),
                          staging_file=part.relative_to(self.root).as_posix(),
                          split="quarantine_unassigned", operation_id=None,
                          truth=None, model_exposure=False, training_admitted=False,
                          source_clock_verified=False, complete_operation=None,
                          continuity_verified=False, automatic_retry=False)
            self._save(record)
            try:
                metadata = writer(part)
                self._check_stop(stop)
                if not part.is_file() or not 0 < part.stat().st_size <= self.max_bytes:
                    raise IngestError("empty_or_oversize_source")
                self._space()
                source_hash = sha256(part)
                if source_hash in self.protected_hashes:
                    raise IngestError("protected_source")
                record.update(state="prepared", capture_finished_at=_now(),
                              source_sha256=source_hash, bytes=part.stat().st_size,
                              original_file=f"originals/{source_hash[:2]}/{source_hash}.mkv"
                              if kind == "rtsp_remux" else
                              f"originals/{source_hash[:2]}/{source_hash}.media",
                              media=metadata)
                self._save(record)
                return self._commit(record)
            except BaseException as exc:
                # Backend exceptions can contain usernames, passwords and URLs.
                # Persist only safe fixed codes; suppress chained backend errors.
                code = str(exc) if isinstance(exc, IngestError) else (
                    "interrupted" if isinstance(exc, (KeyboardInterrupt, SystemExit)) else "ingest_failed")
                record.update(state="interrupted" if code == "interrupted" else "failed",
                              ended_at=_now(), error_code=code,
                              partial_bytes=part.stat().st_size if part.exists() else None)
                self._save(record)
                if isinstance(exc, (KeyboardInterrupt, SystemExit)):
                    raise
                raise IngestError(code) from None

    def ingest_file(self, source, *, attempt_id, camera_id, stop=None):
        """Copy a caller-finalized local original byte-for-byte; never alter it.

        Caller must signal that the recorder has closed the file. Before/after
        hashes and stat checks reject files that change while being copied.
        """
        source = Path(source).resolve(strict=True)
        if not source.is_file() or source.is_relative_to(self.root):
            raise IngestError("invalid_local_source")
        initial = source.stat()
        if not 0 < initial.st_size <= self.max_bytes:
            raise IngestError("empty_or_oversize_source")
        initial_hash = sha256(source)
        if initial_hash in self.protected_hashes:
            raise IngestError("protected_source")

        def copy(part):
            with source.open("rb") as reader, part.open("xb") as output:
                while block := reader.read(1024 * 1024):
                    self._check_stop(stop)
                    self._space(len(block))
                    output.write(block)
                    if output.tell() > self.max_bytes:
                        raise IngestError("empty_or_oversize_source")
                output.flush()
                os.fsync(output.fileno())
            after = source.stat()
            if ((initial.st_size, initial.st_mtime_ns) != (after.st_size, after.st_mtime_ns)
                    or sha256(part) != initial_hash or sha256(source) != initial_hash):
                raise IngestError("source_changed_during_copy")
            return probe_video(part)

        return self._execute(attempt_id, camera_id, "local_export", copy, stop=stop,
                             request_identity=initial_hash)

    def capture_once(self, config: RTSPConfig, *, attempt_id, stop=None):
        """One bounded explicit acquisition. Does not discover devices or retry."""
        config.validate()
        def capture(part):
            endpoint = config.resolve_endpoint()
            # Captured libav messages are discarded, not forwarded to logs.
            with av.logging.Capture(local=True):
                with av.open(endpoint, mode="r", options={"rtsp_transport": "tcp"},
                             timeout=(config.connect_timeout_seconds,
                                      config.read_timeout_seconds)) as incoming:
                    return _remux(incoming, part, config.segment_seconds, self, stop)
        return self._execute(attempt_id, config.camera_id, "rtsp_remux", capture,
                             stop=stop, request_identity={
                                 "endpoint_reference": config.endpoint_env,
                                 "segment_seconds": config.segment_seconds,
                                 "connect_timeout_seconds": config.connect_timeout_seconds,
                                 "read_timeout_seconds": config.read_timeout_seconds})

    def reconcile(self):
        """Recover committed bytes, never restart capture or resume partial media."""
        results = []
        with runtime_lock(self.root):
            for path in sorted((self.root / "attempts").glob("*.json")):
                record = json.loads(path.read_text(encoding="utf-8"))
                if record["state"] == "prepared":
                    try:
                        self._commit(record)
                    except IngestError as exc:
                        record.update(state="failed", error_code=str(exc), ended_at=_now())
                        self._save(record)
                    results.append(record)
                elif record["state"] == "running":
                    part = self.root / record["staging_file"]
                    record.update(state="interrupted", error_code="process_interrupted",
                                  ended_at=_now(), partial_bytes=part.stat().st_size if part.exists() else 0)
                    self._save(record)
                    results.append(record)
        return results

    def records(self):
        return [json.loads(p.read_text(encoding="utf-8"))
                for p in sorted((self.root / "attempts").glob("*.json"))]


def probe_video(source):
    """Container headers only. This does NOT prove every packet decodes."""
    with av.logging.Capture(local=True):
        with av.open(str(source), "r") as container:
            if not container.streams.video:
                raise IngestError("no_video_stream")
            stream = container.streams.video[0]
            if stream.width <= 0 or stream.height <= 0:
                raise IngestError("invalid_video_dimensions")
            return dict(width=stream.width, height=stream.height,
                        codec=stream.codec_context.name,
                        nominal_fps=float(stream.average_rate) if stream.average_rate else None,
                        container_duration_seconds=container.duration / av.time_base
                        if container.duration is not None else None,
                        validation="container_headers_only", decoded_frames=0)


def _remux(incoming, destination, seconds, store, stop=None):
    """Keep full native video context without frame decode/resize/re-encoding."""
    if not incoming.streams.video:
        raise IngestError("no_video_stream")
    video = incoming.streams.video[0]
    started = time.monotonic()
    first_dts = last_dts = None
    packets = 0
    reached_bound = False
    with av.open(str(destination), "w", format="matroska") as output:
        target = output.add_stream_from_template(video)
        for packet in incoming.demux(video):
            store._check_stop(stop)
            if time.monotonic() - started >= seconds:
                reached_bound = True
                break
            if packet.dts is None:
                continue
            if not packets and not packet.is_keyframe:
                continue
            # Preserve source time bases; never synthesize missing timestamps.
            dts = float(packet.dts * packet.time_base)
            if last_dts is not None and dts < last_dts:
                raise IngestError("nonmonotonic_stream_timestamp")
            if first_dts is None:
                first_dts = dts
            if dts - first_dts >= seconds:
                reached_bound = True
                break
            last_dts = dts
            packet.stream = target
            output.mux(packet)
            packets += 1
            store._space()
            if destination.exists() and destination.stat().st_size > store.max_bytes:
                raise IngestError("empty_or_oversize_source")
    if not packets:
        raise IngestError("no_decodable_start_packet")
    if not reached_bound:
        raise IngestError("stream_ended_before_bound")
    with destination.open("r+b") as file:
        os.fsync(file.fileno())
    return {**probe_video(destination), "packet_count": packets,
            "first_source_dts_seconds": first_dts, "last_source_dts_seconds": last_dts,
            "requested_seconds": seconds, "audio_retained": False,
            "native_video_packets_remuxed": True, "source_clock": None,
            "limitations": ["Packet timestamps are not verified camera wall-clock time.",
                            "Starting at a keyframe can omit initial context.",
                            "Reconnect/segment boundaries may have gaps; not continuous coverage."]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", required=True, help="Private local runtime ingest directory")
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("status", "reconcile", "pause", "resume"):
        sub.add_parser(name)
    capture = sub.add_parser("capture-once")
    capture.add_argument("--camera-id", required=True)
    capture.add_argument("--attempt-id", required=True)
    capture.add_argument("--endpoint-env", default="GATE_CAMERA_RTSP_URL")
    capture.add_argument("--seconds", type=int, default=180)
    args = parser.parse_args()
    store = IngestStore(args.root)
    try:
        if args.command == "status":
            result = {"paused": store.is_paused(), "attempts": store.records()}
        elif args.command == "reconcile":
            result = store.reconcile()
        elif args.command in ("pause", "resume"):
            getattr(store, args.command)()
            result = {"paused": store.is_paused()}
        else:
            result = store.capture_once(RTSPConfig(args.camera_id, args.endpoint_env, args.seconds),
                                        attempt_id=args.attempt_id)
        print(json.dumps(result, indent=2))
    except IngestError as exc:
        print(json.dumps({"error_code": str(exc)}))
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
