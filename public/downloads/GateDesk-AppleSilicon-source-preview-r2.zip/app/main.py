from pathlib import Path
from typing import Literal
from datetime import datetime, timezone
import sqlite3, json, uuid, math, os, csv, io, threading, time, hashlib
from fastapi import FastAPI, HTTPException, Request, UploadFile, Query
from fastapi.responses import FileResponse, Response, JSONResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.trustedhost import TrustedHostMiddleware
from pydantic import BaseModel, Field
from PIL import Image, ImageOps, UnidentifiedImageError
from contextlib import asynccontextmanager

@asynccontextmanager
async def lifespan(application):
    from app.runtime_lifespan import service_lifespan
    from app.notification_bridge import NotificationService
    from app.camera_routes import RecorderService
    async with service_lifespan(application, [
        ('notification_service', NotificationService),
        ('recorder_service', lambda: RecorderService(Path(DB).parent)),
    ]):
        yield

ROOT=Path(__file__).resolve().parents[1]
DB=Path(os.environ.get('GATE_DESK_DB',str(ROOT/'data/reports.sqlite3')))
DB.parent.mkdir(parents=True,exist_ok=True)
app=FastAPI(title='Gate Desk local prototype',docs_url=None,redoc_url=None,openapi_url=None,lifespan=lifespan)
app.add_middleware(TrustedHostMiddleware,allowed_hosts=['127.0.0.1','localhost','testserver'])

def conn():
    c=sqlite3.connect(DB,timeout=20);c.row_factory=sqlite3.Row;return c
with conn() as c:
    c.execute('''CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY, gatepass TEXT NOT NULL, material TEXT NOT NULL, expected INTEGER NOT NULL,
    direction TEXT NOT NULL, carrier TEXT NOT NULL, scenario TEXT NOT NULL, observed INTEGER NOT NULL DEFAULT 0,
    step INTEGER NOT NULL DEFAULT 0, uncertain INTEGER NOT NULL DEFAULT 0, phase TEXT NOT NULL DEFAULT 'in_progress',
    status TEXT NOT NULL DEFAULT 'In progress', started_at TEXT NOT NULL, ended_at TEXT,
    mode TEXT NOT NULL DEFAULT 'demonstration')''')
    columns={r[1] for r in c.execute('PRAGMA table_info(sessions)')}
    for name,definition in [('unit',"TEXT NOT NULL DEFAULT 'unit'"),('document_id','TEXT'),('document_line_id','TEXT'),('document_snapshot','TEXT')]:
        if name not in columns:c.execute(f'ALTER TABLE sessions ADD COLUMN {name} {definition}')

@app.middleware('http')
async def local_boundary(request:Request,call_next):
    if request.method not in ['GET','HEAD','OPTIONS']:
        if request.headers.get('x-gate-desk')!='local':return JSONResponse({'detail':'Local application header required.'},403)
        origin=request.headers.get('origin')
        if origin and origin != str(request.base_url).rstrip('/'):return JSONResponse({'detail':'Origin not allowed.'},403)
    response=await call_next(request)
    response.headers['X-Content-Type-Options']='nosniff'
    response.headers['Referrer-Policy']='no-referrer'
    response.headers['Content-Security-Policy']="default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' blob: data:; media-src 'self' blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
    if request.url.path.startswith('/api/'):response.headers['Cache-Control']='no-store'
    return response

class Start(BaseModel):
    gatepass:str=Field(min_length=1,max_length=60)
    material:str=Field(min_length=1,max_length=80)
    carrier:str=Field(default='MH 04 AB 1234',max_length=60)
    direction:Literal['Incoming','Outgoing']='Incoming'
    expected:int=Field(ge=1,le=10000)
    scenario:Literal['matched','missing','excess','blocked','dust']='missing'
    unit:Literal['unit','bag','cone','beam','roll','bundle','carton']='unit'
    document_id:str|None=None
    document_line_id:str|None=None
class Advance(BaseModel):
    step:int=Field(ge=1,le=10002)

def serialize(row):
    d=dict(row);d['uncertain']=bool(d['uncertain']);d['difference']=None if d['uncertain'] else d['observed']-d['expected']
    d['document_snapshot']=json.loads(d['document_snapshot']) if d.get('document_snapshot') else None
    return d

def get_session(c,sid):
    row=c.execute('SELECT * FROM sessions WHERE id=?',(sid,)).fetchone()
    if not row:raise HTTPException(404,'Session not found.')
    return serialize(row)

@app.get('/api/state')
def state():
    with conn() as c:
        active=c.execute("SELECT * FROM sessions WHERE phase='in_progress' ORDER BY started_at DESC LIMIT 1").fetchone()
        reports=c.execute("SELECT * FROM sessions WHERE phase!='in_progress' ORDER BY ended_at DESC LIMIT 200").fetchall()
    return {'active':serialize(active) if active else None,'reports':[serialize(r) for r in reports],'storage':'Local SQLite','camera_connected':False}

@app.post('/api/sessions')
def start(body:Start):
    if not body.gatepass.strip() or not body.material.strip():raise HTTPException(422,'Gate pass and material cannot be blank.')
    if bool(body.document_id)!=bool(body.document_line_id):raise HTTPException(422,'Provide both document and line identifiers, or neither.')
    snapshot=None
    if body.document_id:
        with document_lock:
            document=find_document(body.document_id)
            if document['status']!='reviewed':raise HTTPException(409,'Review the document before using its quantities.')
            line=next((line for line in document['lines'] if line['id']==body.document_line_id),None)
            if not line or (body.expected,body.unit,body.direction,body.gatepass,body.material.strip())!=(line['quantity'],line['unit'],document['direction'],document['number'],line['material'].strip()):raise HTTPException(409,'The session must match the reviewed document line, including its material.')
            snapshot=document_line_snapshot(document,line)
    with conn() as c:
        c.execute('BEGIN IMMEDIATE')
        if c.execute("SELECT 1 FROM sessions WHERE phase='in_progress'").fetchone():raise HTTPException(409,'Finish or pause the current demonstration before starting another.')
        sid=str(uuid.uuid4());c.execute('INSERT INTO sessions (id,gatepass,material,expected,direction,carrier,scenario,started_at) VALUES (?,?,?,?,?,?,?,?)',(sid,body.gatepass.strip(),body.material.strip(),body.expected,body.direction,body.carrier.strip(),body.scenario,datetime.now(timezone.utc).isoformat()))
        c.execute('UPDATE sessions SET unit=?,document_id=?,document_line_id=?,document_snapshot=? WHERE id=?',(body.unit,body.document_id,body.document_line_id,json.dumps(snapshot,ensure_ascii=False) if snapshot else None,sid))
        return get_session(c,sid)

@app.post('/api/demo/{sid}/advance')
def advance(sid:str,body:Advance):
    with conn() as c:
        c.execute('BEGIN IMMEDIATE');s=get_session(c,sid)
        if s['phase']!='in_progress' or body.step<=s['step']:return s
        if body.step!=s['step']+1:raise HTTPException(409,'Refresh the session before continuing.')
        target=s['expected'] if s['scenario'] in ['matched','dust'] else s['expected']+2 if s['scenario']=='excess' else max(0,s['expected']-5)
        batch=max(1,math.ceil(target/10));movement_steps=math.ceil(target/batch)
        observed=min(target,body.step*batch)
        uncertain=s['uncertain'] or (s['scenario'] in ['blocked','dust'] and body.step>=min(3,max(1,movement_steps)))
        phase='completed' if body.step>=movement_steps+2 else 'in_progress'
        status='In progress'
        if phase=='completed':
            difference=observed-s['expected']
            status='Needs review' if uncertain else 'Matched' if difference==0 else f'Missing {-difference}' if difference<0 else f'Excess {difference}'
        ended=datetime.now(timezone.utc).isoformat() if phase=='completed' else None
        c.execute('UPDATE sessions SET step=?,observed=?,uncertain=?,phase=?,status=?,ended_at=? WHERE id=?',(body.step,observed,int(uncertain),phase,status,ended,sid))
        return get_session(c,sid)

@app.post('/api/demo/{sid}/end')
def end_early(sid:str):
    with conn() as c:
        c.execute('BEGIN IMMEDIATE');s=get_session(c,sid)
        if s['phase']=='in_progress':c.execute("UPDATE sessions SET phase='completed', uncertain=1,status='Needs review',ended_at=? WHERE id=?",(datetime.now(timezone.utc).isoformat(),sid))
        return get_session(c,sid)

@app.get('/api/reports.csv')
def export():
    fields=['gatepass','started_at','ended_at','direction','material','unit','expected','observed','difference','status','uncertain','mode','document_id','document_line_id','document_snapshot']
    with conn() as c:rows=c.execute("SELECT * FROM sessions WHERE phase!='in_progress' ORDER BY ended_at DESC").fetchall()
    stream=io.StringIO(newline='');writer=csv.DictWriter(stream,fieldnames=fields);writer.writeheader()
    for row in rows:
        s=serialize(row);out={k:s[k] for k in fields}
        out['document_snapshot']=json.dumps(s['document_snapshot'],sort_keys=True,ensure_ascii=False) if s['document_snapshot'] else ''
        for k,v in out.items():
            if isinstance(v,str) and v.lstrip().startswith(('=','+','-','@')):out[k]="'"+v
        writer.writerow(out)
    return Response('\ufeff'+stream.getvalue(),media_type='text/csv',headers={'Content-Disposition':'attachment; filename="gate-desk-reports.csv"'})

MODEL_DIR=ROOT/'models/reviewed-bags-20260920-run02'
_model=None
_model_lock=threading.Lock()

@app.get('/api/model')
def model_status():
    path=MODEL_DIR/'status.json'
    data=json.loads(path.read_text()) if path.exists() else {'phase':'not_available','classes':['bag']}
    return {**data,'model':MODEL_DIR.name,'beam_model_ready':False,'factory_validated':False,
            'counting_validated':False,'production_approved':False}

def predict(image):
    global _model
    if not (MODEL_DIR/'last.pt').exists():raise HTTPException(409,'The experimental bag checkpoint is unavailable.')
    with _model_lock:
        import torch
        from torchvision.transforms.functional import pil_to_tensor
        from ml.test_bag_model import load_model
        if _model is None:
            try:_model=load_model(MODEL_DIR)
            except (ValueError,KeyError,OSError,RuntimeError):raise HTTPException(409,'Model verification failed. Restore the verified checkpoint before testing.')
        image.thumbnail((1600,1600));started=time.perf_counter()
        with torch.inference_mode():out=_model([pil_to_tensor(image).float()/255])[0]
        detections=[]
        for box,score,label in zip(out['boxes'].tolist(),out['scores'].tolist(),out['labels'].tolist()):
            if score>=0.5 and label==1:detections.append({'box':box,'score':round(score,3),'label':'bag'})
        return {'width':image.width,'height':image.height,'detections':detections,
                'inference_ms':round((time.perf_counter()-started)*1000),'threshold':0.5,
                'model':MODEL_DIR.name,'note':'Experimental bag detections only; not movement counts. Other material classes are unsupported.'}

def sample_path(index):
    manifest=MODEL_DIR/'dataset.json'
    if not manifest.exists():raise HTTPException(409,'Reviewed sample manifest is unavailable.')
    rows=[r for r in json.loads(manifest.read_text())['records'] if r['split']=='validation']
    if index>=len(rows):raise HTTPException(404,'Sample not found.')
    path=(ROOT/rows[index]['source']).resolve()
    if not path.is_relative_to((ROOT/'data/public-bags').resolve()):raise HTTPException(409,'Invalid sample source.')
    if not path.is_file():raise HTTPException(404,'Sample image unavailable.')
    return path

@app.get('/api/sample')
def sample(index:int=Query(0,ge=0,le=7)):
    return FileResponse(sample_path(index))

@app.post('/api/model/sample')
def infer_sample(index:int=Query(0,ge=0,le=7)):
    with Image.open(sample_path(index)) as im:return predict(im.convert('RGB'))

@app.post('/api/model/image')
def infer_image(file:UploadFile):
    data=file.file.read(10*1024*1024+1)
    if len(data)>10*1024*1024:raise HTTPException(413,'Choose an image smaller than 10 MB.')
    try:
        with Image.open(io.BytesIO(data)) as im:
            if im.width*im.height>20_000_000:raise HTTPException(413,'Choose an image below 20 megapixels.')
            return predict(ImageOps.exif_transpose(im).convert('RGB'))
    except (UnidentifiedImageError,OSError,Image.DecompressionBombError):raise HTTPException(422,'Choose a readable JPG, PNG or WebP image.')

DOCUMENT_FILE=Path(os.environ.get('GATE_DESK_DOCUMENT_DIR',str(ROOT/'data')))/'gatepasses.json'
document_lock=threading.Lock()
def documents():
    return json.loads(DOCUMENT_FILE.read_text(encoding='utf-8')) if DOCUMENT_FILE.exists() else []
def find_document(doc_id):
    document=next((d for d in documents() if d['id']==doc_id),None)
    if not document:raise HTTPException(404,'Document not found.')
    return document
def document_record_sha256(document):
    return hashlib.sha256(json.dumps(document,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode('utf-8')).hexdigest()
def document_line_snapshot(document,line):
    return {'schema_version':2,'document_id':document['id'],'document_sha256':document_record_sha256(document),
            'reviewed_at':document.get('reviewed_at'),'number':document['number'],'direction':document['direction'],
            'line':line,'document_lines':document['lines']}
from app.document_store import DocumentStore, DocumentLine, DocumentReview
@app.get('/api/documents')
def list_documents():return [{**d,'revision_sha256':document_record_sha256(d) if d.get('status')=='reviewed' else None} for d in documents()]

@app.post('/api/documents/import-image')
def import_document_image(file:UploadFile):
    return DocumentStore(DOCUMENT_FILE,document_lock).import_image(file)

@app.get('/api/documents/{doc_id}/original')
def document_original(doc_id:str):
    document=find_document(doc_id);source=document.get('source',{})
    extension=source.get('extension')
    if extension not in ('jpg','png','webp'):raise HTTPException(404,'Original imported file unavailable.')
    root=(DOCUMENT_FILE.parent/'gatepass-originals').resolve()
    path=(root/(doc_id+'.'+extension)).resolve()
    if not path.is_relative_to(root):raise HTTPException(409,'Invalid document image path.')
    if not path.is_file():raise HTTPException(404,'Original imported file unavailable.')
    if hashlib.sha256(path.read_bytes()).hexdigest()!=source.get('sha256'):
        raise HTTPException(409,'Original document checksum mismatch.')
    return FileResponse(path)

@app.get('/api/documents/{doc_id}/image')
def document_image(doc_id:str):
    find_document(doc_id)
    image_root=(DOCUMENT_FILE.parent/'gatepasses').resolve()
    path=(image_root/(doc_id+'.png')).resolve()
    if not path.is_relative_to(image_root):raise HTTPException(409,'Invalid document image path.')
    if not path.is_file():raise HTTPException(404,'Document image not available.')
    return FileResponse(path)
@app.post('/api/documents/{doc_id}/review')
def review_document(doc_id:str,body:DocumentReview):
    return DocumentStore(DOCUMENT_FILE,document_lock).review(doc_id,body)

@app.post('/api/camera-health/compare')
def compare_health(reference:UploadFile,current:UploadFile):
    from ml.camera_health import compare_images
    images=[]
    for file in [reference,current]:
        data=file.file.read(10*1024*1024+1)
        if len(data)>10*1024*1024:raise HTTPException(413,'Each image must be smaller than 10 MB.')
        try:
            with Image.open(io.BytesIO(data)) as im:
                if im.width*im.height>20_000_000:raise HTTPException(413,'Choose images below 20 megapixels.')
                images.append(ImageOps.exif_transpose(im).convert('RGB'))
        except (UnidentifiedImageError,OSError,Image.DecompressionBombError):raise HTTPException(422,'Choose readable reference and current images.')
    return compare_images(*images)

@app.get('/')
def index():return FileResponse(ROOT/'app/static/index.html')
from app.annotation import router as annotation_router
app.include_router(annotation_router)
from app.movements import router as movement_router
app.include_router(movement_router)
from app.notification_bridge import router as notification_router
app.include_router(notification_router)
@app.get('/annotator')
def annotator():return FileResponse(ROOT/'app/static/annotator.html')
app.mount('/static',StaticFiles(directory=ROOT/'app/static'),name='static')

from app.camera_routes import router as recorder_router
app.include_router(recorder_router)
from app.mobile_report_routes import router as mobile_report_router
app.include_router(mobile_report_router)

from app.accounts import install_accounts
install_accounts(app, lambda: Path(DB).with_name('accounts.sqlite3'),
                 opted_in=os.environ.get('GATE_DESK_ACCOUNTS') == '1',
                 owner_only=os.environ.get('GATE_DESK_OWNER_PC') == '1')
