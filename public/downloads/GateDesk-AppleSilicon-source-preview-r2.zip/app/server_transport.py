"""Loopback server configuration; optional TLS is not a launcher activation API.

The shipped runtime calls only the portable HTTP branch. A caller supplying an
already-owned server SSLContext must separately satisfy certificate, shutdown,
authorization and transport acceptance; configuration alone establishes none.
"""
import ssl
import sys


def build_server_config(asgi_app, *, port, tls_context=None):
    if type(port) is not int or not 1 <= port <= 65535:
        raise ValueError('invalid_server_port')
    import uvicorn

    options = dict(host='127.0.0.1', port=port, log_level='warning',
                   lifespan='on', workers=1, reload=False,
                   proxy_headers=False, forwarded_allow_ips='')
    if tls_context is not None:
        if (not isinstance(tls_context, ssl.SSLContext)
                or tls_context.protocol != ssl.PROTOCOL_TLS_SERVER):
            raise ValueError('server_tls_context_required')
        # Do not import Windows subclasses or apply runtime pins to plain HTTP.
        from scripts.runtime_tls_loop import verify_tls_runtime
        verify_tls_runtime()

        def owned_context(config, default_factory):
            # No key/certificate paths, default loading, logging or serialization.
            return tls_context

        options.update(loop='scripts.runtime_tls_loop:make_loop',
                       ssl_context_factory=owned_context)
    elif sys.platform == 'win32':
        # The bundled Windows runtime has an evidenced socket-shutdown reset
        # defect. Select the tested, pinned socket transport for HTTP only.
        # Drift fails closed before listener creation; TLS retains its own loop.
        from app.proactor_socket_cleanup import verify_runtime
        verify_runtime()
        options.update(loop='scripts.runtime_http_loop:make_loop')
    return uvicorn.Config(asgi_app, **options)
