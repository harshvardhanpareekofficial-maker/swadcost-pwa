"""Isolated pre-dispatch intake; no parser, worker, runtime or route integration.

The trusted caller supplies authorization and retains AdmittedBody until actual
downstream cleanup. Closing it is NOT proof that downstream work has stopped.
The pool is confined to one event loop; its synchronous transitions never wait.
"""
import asyncio
from dataclasses import dataclass
import re

MAX_BYTES = 11 * 1024 * 1024
CHUNK_BYTES = 64 * 1024
IDLE_SECONDS = 10
TOTAL_SECONDS = 30


class IntakeError(Exception):
    def __init__(self, status, code):
        self.status = status
        self.code = code
        super().__init__(code)  # Fixed codes only; never include request data.


@dataclass(frozen=True, slots=True)
class UploadGrant:
    subject: str
    purpose: str = 'document_upload'


@dataclass(frozen=True, slots=True)
class _Token:
    generation: int


class UploadPool:
    """One loop, one holder, zero queued waiters; token identity prevents ABA."""
    def __init__(self):
        self._loop = None
        self._token = None
        self._generation = 0

    def _check_loop(self):
        loop = asyncio.get_running_loop()
        if self._loop is None:
            self._loop = loop
        elif self._loop is not loop:
            raise IntakeError(503, 'ownership_unavailable')

    def try_acquire(self):
        self._check_loop()
        if self._token is not None:
            raise IntakeError(429, 'upload_busy')
        self._generation += 1
        self._token = _Token(self._generation)
        return self._token

    def release(self, token):
        self._check_loop()
        if token is not self._token or token is None:
            return False
        self._token = None
        return True


class AdmittedBody:
    """Explicitly owned, single-pass replay. No destructor releases the lease."""
    def __init__(self, pool, token, buffer, length, boundary):
        self._pool, self._token, self._buffer = pool, token, buffer
        self.length, self.boundary = length, boundary
        self._replayed = False
        self.closed = False

    def chunks(self):
        if self.closed or self._replayed:
            raise IntakeError(409, 'body_unavailable')
        self._replayed = True
        return self._chunks()

    def _chunks(self):
        offset = 0
        while offset < self.length:
            if self.closed:
                raise IntakeError(409, 'body_unavailable')
            end = min(offset + CHUNK_BYTES, self.length)
            yield bytes(memoryview(self._buffer)[offset:end])
            offset = end

    def close(self):
        if self.closed:
            return
        self._pool._check_loop()
        # Best-effort overwrite of our buffer, not secure erasure of copies,
        # allocator memory, pagefiles or the caller's received message bytes.
        zeros = b'\0' * CHUNK_BYTES
        for offset in range(0, MAX_BYTES, CHUNK_BYTES):
            self._buffer[offset:offset + CHUNK_BYTES] = zeros
        self._buffer = None
        self.closed = True
        self._pool.release(self._token)


class LoopTiming:
    def now(self):
        return asyncio.get_running_loop().time()

    async def wait(self, task, deadline):
        done, _ = await asyncio.wait({task}, timeout=max(0, deadline - self.now()))
        return task in done


_TOKEN = rb"[!#$%&'*+.^_`|~0-9A-Za-z-]+"
_BCHARS = set(b"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'()+_,-./:=? ")


def validate_headers(headers):
    """Bound raw metadata before interpreting a single framing header."""
    if type(headers) not in (list, tuple) or len(headers) > 32:
        raise IntakeError(400, 'invalid_headers')
    total = 0
    values = {}
    critical = {b'content-length', b'content-type', b'transfer-encoding', b'content-encoding', b'expect', b'trailer'}
    for entry in headers:
        if type(entry) not in (tuple, list) or len(entry) != 2:
            raise IntakeError(400, 'invalid_headers')
        name, value = entry
        if type(name) is not bytes or type(value) is not bytes:
            raise IntakeError(400, 'invalid_headers')
        total += len(name) + len(value)
        if len(value) > 8192 or total > 16384 or not re.fullmatch(_TOKEN, name):
            raise IntakeError(400, 'invalid_headers')
        if any(byte < 32 and byte != 9 or byte == 127 for byte in value):
            raise IntakeError(400, 'invalid_headers')
        name = name.lower()
        if name in critical:
            if name in values:
                raise IntakeError(400, 'duplicate_header')
            values[name] = value
    content_type = values.get(b'content-type', b'')
    match = re.fullmatch(rb'multipart/form-data[ \t]*;[ \t]*boundary[ \t]*=[ \t]*("[^"\\]*"|'+_TOKEN+rb')[ \t]*',
                         content_type, flags=re.IGNORECASE)
    if not match:
        raise IntakeError(400, 'invalid_content_type')
    boundary = match[1]
    if boundary.startswith(b'"'):
        boundary = boundary[1:-1]
    if not 1 <= len(boundary) <= 70 or boundary.endswith(b' ') or any(b not in _BCHARS for b in boundary):
        raise IntakeError(400, 'invalid_boundary')
    length = values.get(b'content-length')
    if length is not None:
        if not re.fullmatch(rb'0|[1-9][0-9]{0,7}', length):
            raise IntakeError(400, 'invalid_length')
        length = int(length)
        if length > MAX_BYTES:
            raise IntakeError(413, 'body_too_large')
    transfer = values.get(b'transfer-encoding')
    if transfer is not None and (length is not None or transfer.lower() != b'chunked'):
        raise IntakeError(400, 'invalid_framing')
    if values.get(b'content-encoding', b'identity').lower() != b'identity':
        raise IntakeError(415, 'unsupported_encoding')
    if values.get(b'expect', b'100-continue').lower() != b'100-continue':
        raise IntakeError(417, 'unsupported_expectation')
    if b'trailer' in values:
        raise IntakeError(400, 'unsupported_trailer')
    return length, boundary


async def _settle(task):
    """Cancel once, then retain a suppressing coroutine through repeated cancels."""
    if not task.done():
        task.cancel()
    while not task.done():
        try:
            await asyncio.shield(task)
        except asyncio.CancelledError:
            continue
        except BaseException:
            break
    try:
        task.result()
    except BaseException:
        pass


async def _receive_one(receive, timing, deadline):
    if timing.now() >= deadline:
        raise IntakeError(408, 'body_timeout')
    task = asyncio.create_task(receive())
    try:
        ready = await timing.wait(task, deadline)
        if not ready or timing.now() >= deadline:
            raise IntakeError(408, 'body_timeout')
        return task.result()
    except BaseException:
        await _settle(task)
        raise


async def admit_body(scope, receive, *, authorize=None, pool=None, timing=None):
    """Return owned bytes/lease; no parser or downstream callable is invoked.

authorize is a trusted, fast server callback, after real security checks. It
must not hold a transaction/lock on return. Neither scope nor body grants access.
"""
    if authorize is None:
        raise IntakeError(403, 'upload_denied')
    try:
        grant = authorize()
    except Exception:
        raise IntakeError(503, 'authorization_unavailable') from None
    if (type(grant) is not UploadGrant or type(grant.subject) is not str
            or not 1 <= len(grant.subject) <= 80 or not grant.subject.strip()
            or grant.purpose != 'document_upload'):
        raise IntakeError(403, 'upload_denied')
    if type(pool) is not UploadPool:
        raise IntakeError(503, 'ownership_unavailable')
    if type(scope) is not dict or scope.get('type') != 'http':
        raise IntakeError(400, 'invalid_scope')
    length, boundary = validate_headers(scope.get('headers'))
    token = pool.try_acquire()
    body = None
    try:
        timing = timing if timing is not None else LoopTiming()
        start = timing.now()
        total_deadline, last_progress = start + TOTAL_SECONDS, start
        body = AdmittedBody(pool, token, bytearray(MAX_BYTES), 0, boundary)
        while True:
            message = await _receive_one(receive, timing, min(total_deadline, last_progress + IDLE_SECONDS))
            if type(message) is not dict:
                raise IntakeError(400, 'invalid_message')
            if message.get('type') == 'http.disconnect':
                raise IntakeError(499, 'client_disconnected')
            chunk, more = message.get('body', b''), message.get('more_body', False)
            if message.get('type') != 'http.request' or type(chunk) is not bytes or type(more) is not bool:
                raise IntakeError(400, 'invalid_message')
            if len(chunk) > MAX_BYTES - body.length:
                raise IntakeError(413, 'body_too_large')
            end = body.length + len(chunk)
            body._buffer[body.length:end] = chunk
            body.length = end
            if chunk:
                last_progress = timing.now()
            # Do not keep a giant received message beyond this iteration.
            del chunk, message
            if not more:
                if length is not None and body.length != length:
                    raise IntakeError(400, 'length_mismatch')
                return body
            await asyncio.sleep(0)  # Fairness for immediate or empty messages.
    except BaseException as error:
        if body is not None:
            body.close()
        else:
            pool.release(token)
        if isinstance(error, Exception) and not isinstance(error, IntakeError):
            raise IntakeError(503, 'intake_failed') from None
        raise
