"""Opt-in isolated document routes; backend capabilities are supplied by host.

Factory ID binds the deployment, not a client-selected storage path. The host
must supply callbacks scoped to that factory; this module never switches globals.
"""
from dataclasses import dataclass
import json
import re
import sqlite3
from typing import Callable
from fastapi import Request
from fastapi.responses import JSONResponse, Response
from pydantic import ValidationError
from app.mobile_body import read_auth_body
from app.mobile_upload import import_owned_upload
from app.mobile_offload import owned_database_call
from app.upload_intake import UploadPool, IntakeError
from app.memory_multipart import MultipartAdmissionError
from app.phone_submissions import submission_metadata


@dataclass(frozen=True)
class DocumentBackend:
    factory_id: str
    import_image: Callable
    validate_review: Callable
    review: Callable
    reads: object = None
    submit_image: object = None


def install_document_routes(app, config, backend):
    if (type(backend) is not DocumentBackend or backend.factory_id != config.factory_id
            or not all(callable(fn) for fn in (backend.import_image, backend.validate_review, backend.review))):
        raise ValueError('factory_document_backend_required')
    upload_pool, review_pool = UploadPool(), UploadPool()
    if backend.reads is not None:
        @app.api_route('/api/documents', methods=['GET','HEAD'])
        async def listing(request: Request):
            pairs=request.query_params.multi_items()
            if (len(pairs)>1 or any(not ((k=='offset' and re.fullmatch(r'0|[1-9][0-9]{0,4}',v))
                                        or (k=='selected' and re.fullmatch(r'[A-Za-z0-9_-]{1,128}',v))) for k,v in pairs)):
                return response({'detail':'Invalid document page.'},422)
            selected=request.query_params.get('selected')
            offset=int(request.query_params.get('offset','0'))
            if offset>10000: return response({'detail':'Invalid document page.'},422)
            try: return response(await owned_database_call(lambda:backend.reads.page(offset,selected)))
            except FileNotFoundError: return response({'detail':'Document not found.'},404)
            except (OSError,ValueError,TypeError,KeyError): return response({'detail':'Document storage unavailable.'},503)

        @app.api_route('/api/documents/{doc_id}/{kind}', methods=['GET','HEAD'])
        async def image(doc_id: str, kind: str, request: Request):
            if kind not in ('image','original') or request.query_params:
                return response({'detail':'Invalid document request.'},422)
            try:
                data,mime=await owned_database_call(lambda:backend.reads.image(doc_id,kind=='original'))
                return Response(data,media_type=mime,headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'})
            except FileNotFoundError: return response({'detail':'Document not found.'},404)
            except (OSError,ValueError,TypeError,KeyError): return response({'detail':'Document storage unavailable.'},503)
    def response(value, status=200):
        return JSONResponse(value, status, headers={'Cache-Control': 'no-store'})
    def permitted(request):
        s = getattr(request.state, 'mobile_session', None)
        return bool(s and s.role == 'worker' and s.factory_id == backend.factory_id
                    and s.audience == config.canonical_origin)

    @app.post('/api/documents/submit')
    async def submit(request: Request):
        session = getattr(request.state, 'mobile_session', None)
        if not (session and session.role in ('owner', 'worker') and session.user_id
                and session.factory_id == backend.factory_id and session.audience == config.canonical_origin):
            return response({'detail': 'Factory sign-in required.'}, 403)
        if backend.submit_image is None:
            return response({'detail': 'Phone synchronization is unavailable.'}, 503)
        try:
            if request.query_params:
                raise ValueError('query_not_allowed')
            values = []
            for name in (b'x-gate-submission-id', b'x-gate-original-sha256', b'x-gate-saved-at'):
                found = [v for k, v in request.scope['headers'] if k.lower() == name]
                if len(found) != 1:
                    raise ValueError('single_submission_header_required')
                values.append(found[0].decode('ascii'))
            submission_metadata(*values)
        except (ValueError, UnicodeError):
            return response({'detail': 'Invalid phone submission metadata.'}, 422)
        try:
            value = await import_owned_upload(request.scope, request.receive, upload_pool,
                lambda file: backend.submit_image(file, session.user_id, *values))
            return response(value)
        except (IntakeError, MultipartAdmissionError) as exc:
            return response({'detail': 'Document upload rejected.'}, exc.status)
        except (OSError, sqlite3.Error):
            return response({'detail': 'Receipt storage unavailable; keep the original and retry.'}, 503)

    @app.post('/api/documents/import-image')
    async def upload(request: Request):
        if not permitted(request): return response({'detail': 'Worker access required.'}, 403)
        try:
            value = await import_owned_upload(request.scope, request.receive, upload_pool, backend.import_image)
            return response(value)
        except (IntakeError, MultipartAdmissionError) as exc:
            return response({'detail': 'Document upload rejected.'}, exc.status)
        except OSError:
            return response({'detail': 'Document storage unavailable.'}, 503)

    @app.post('/api/documents/{doc_id}/review')
    async def review(doc_id: str, request: Request):
        if not permitted(request): return response({'detail': 'Worker access required.'}, 403)
        try:
            raw = await read_auth_body(request.receive, review_pool)
            body = backend.validate_review(json.loads(raw))
            value = await owned_database_call(lambda: backend.review(doc_id, body))
            return response(value)
        except IntakeError as exc:
            return response({'detail': 'Document review rejected.'}, exc.status)
        except (ValueError, ValidationError):
            return response({'detail': 'Invalid document fields.'}, 422)
        except OSError:
            return response({'detail': 'Document storage unavailable.'}, 503)
