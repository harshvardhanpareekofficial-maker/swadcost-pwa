"""Pre-admitted, physical service cleanup for application lifespan.

Blocking stop/join callbacks run on one owned worker, never the asyncio loop.
The callback list is sealed before that worker can consume it, including when
construction or startup fails. Completion and actual thread exit are distinct.
"""
import asyncio
from contextlib import asynccontextmanager
import threading

from app.runtime_owner import current_owner, start_thread


class ServiceCleanup:
    def __init__(self):
        self.owner = current_owner()
        self.requested = threading.Event()
        self.sealed = threading.Event()
        self.completed = threading.Event()
        self.callbacks = []
        self.failures = []
        self.thread = threading.Thread(target=self._run, name='gate-service-cleanup', daemon=False)

    def start(self):
        # Registration precedes any construction/start of application services.
        start_thread(self.thread, self.request)

    def add(self, callback):
        if self.sealed.is_set() or not callable(callback):
            raise RuntimeError('invalid_service_cleanup_registration')
        self.callbacks.append(callback)

    def seal(self):
        self.sealed.set()

    def request(self):
        self.requested.set()

    def _run(self):
        self.requested.wait()
        self.sealed.wait()
        for callback in reversed(self.callbacks):
            try:
                callback()
            except BaseException:
                self.failures.append('service_stop_failed')
                if self.owner is not None:
                    self.owner.fail('service_stop_failed')
        self.completed.set()

    async def wait(self):
        while True:
            try:
                if self.completed.is_set() and not self.thread.is_alive():
                    self.thread.join(0)
                    break
                await asyncio.sleep(.025)
            except BaseException:
                if self.owner is not None:
                    self.owner.fail('service_cleanup_observation_interrupted')
                self.request()
        if self.failures:
            raise RuntimeError('service_cleanup_failed')


@asynccontextmanager
async def service_lifespan(application, factories):
    """Factories are ordered (state attribute, synchronous constructor) pairs."""
    cleanup = ServiceCleanup()
    try:
        cleanup.start()
    except BaseException:
        # A refused registration never invoked Thread.start. Once admitted,
        # absent ident/_started is not positive proof of no native thread.
        # Keep the ASGI invocation alive until this exact worker acknowledges
        # cleanup AND physically exits, even if an older owner row says NEVER_STARTED.
        if cleanup.owner is not None:
            with cleanup.owner.guard:
                admitted = cleanup.thread in cleanup.owner.workers
            if not admitted:
                raise
            cleanup.owner.fail('service_cleanup_start_failed')
        cleanup.seal()
        cleanup.request()
        await cleanup.wait()
        raise
    try:
        for name, factory in factories:
            if cleanup.owner is not None and cleanup.owner.stop_requested.is_set():
                raise RuntimeError('service_start_admission_closed')
            service = factory()
            cleanup.add(service.stop)  # Own partial start before invoking it.
            setattr(application.state, name, service)
            service.start()
        cleanup.seal()
        yield
    finally:
        cleanup.seal()
        cleanup.request()
        await cleanup.wait()
