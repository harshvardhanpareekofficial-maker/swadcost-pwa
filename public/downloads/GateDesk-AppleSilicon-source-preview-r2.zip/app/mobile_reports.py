"""Pure, allowlisted projections of trusted local stored reports.

No router, database, authentication or physical verification is performed here.
Callers must obtain records from the authorized local store, never a request body.
Hash/identity checks detect inconsistent records; they are not signatures or proof
that an operator's physical observation was correct.
"""
import hashlib
import json
import re
from datetime import datetime, timezone


class ProjectionError(ValueError):
    """Generic failure, deliberately without record contents or private paths."""


def _reject():
    raise ProjectionError('Stored report evidence is invalid.')


def _mapping(value):
    if type(value) is not dict:
        _reject()
    return value


def _text(value, maximum):
    if type(value) is not str or not value.strip() or len(value) > maximum:
        _reject()
    return value


def _integer(value, minimum, maximum):
    if type(value) is not int or not minimum <= value <= maximum:
        _reject()
    return value


def _choice(value, choices):
    if type(value) is not str or value not in choices:
        _reject()
    return value


def _timestamp(value, optional=False):
    if value is None and optional:
        return None
    value = _text(value, 64)
    try:
        parsed = datetime.fromisoformat(value)
        if parsed.tzinfo is None or parsed.utcoffset() is None:
            _reject()
        return parsed.astimezone(timezone.utc).isoformat()
    except (ValueError, OverflowError):
        _reject()


def _hash(value):
    if type(value) is not str or not re.fullmatch('[0-9a-f]{64}', value):
        _reject()
    return value


def _canonical(value):
    try:
        return json.dumps(value, sort_keys=True, separators=(',', ':'),
                          ensure_ascii=False, allow_nan=False)
    except (TypeError, ValueError, RecursionError):
        _reject()


UNITS = ('bag', 'beam', 'cone', 'roll', 'bundle', 'carton', 'unit')
DIRECTIONS = ('Incoming', 'Outgoing')
REASONS = ('visibility_lost', 'stream_gap', 'review_hold',
           'reverse_movement_exceeds_forward_count', 'interrupted')


def _line(value):
    row = _mapping(value)
    return {'id': _text(row.get('id'), 50),
            'material': _text(row.get('material'), 150),
            'quantity': _integer(row.get('quantity'), 1, 10000),
            'unit': _choice(row.get('unit'), UNITS)}


def _document(value, report):
    doc = _mapping(value)
    if type(doc.get('schema_version')) is not int or doc['schema_version'] != 2:
        _reject()
    line = _line(doc.get('line'))
    lines = doc.get('document_lines')
    if type(lines) is not list or not 1 <= len(lines) <= 30:
        _reject()
    projected = [_line(row) for row in lines]
    if len({row['id'] for row in projected}) != len(projected):
        _reject()
    if sum(_canonical(row) == _canonical(doc['line']) for row in lines) != 1:
        _reject()
    if (line['quantity'], line['unit'], doc.get('direction'), doc.get('number'),
        doc.get('confirmed_material_class')) != (
            report['expected'], report['unit'], report['direction'],
            report['gatepass'], report['material']):
        _reject()
    if doc.get('mapping_basis') != 'explicit_operator_selection_not_automatic_semantic_match':
        _reject()
    _timestamp(doc.get('bound_at'))
    return {'document_id': _text(doc.get('document_id'), 100),
            'document_sha256': _hash(doc.get('document_sha256')),
            'reviewed_at': _timestamp(doc.get('reviewed_at')),
            'number': _text(doc.get('number'), 80),
            'direction': _choice(doc.get('direction'), DIRECTIONS), 'line': line}


def project_replay(report):
    """Project unconfirmed predictions; even raw 'Matched' is never final."""
    report = _mapping(report)
    if report.get('mode') != 'replay' or report.get('camera_verified') is not False:
        _reject()
    if type(report.get('uncertain')) is not bool:
        _reject()
    phase = _choice(report.get('phase'), ('in_progress', 'completed'))
    ended = _timestamp(report.get('ended_at'), optional=phase == 'in_progress')
    if phase == 'in_progress' and (ended is not None or report.get('completion_reason') is not None):
        _reject()
    if phase == 'completed':
        _choice(report.get('completion_reason'), ('carrier_departed', 'operator_ended', 'interrupted'))
    reasons = report.get('uncertainty_reasons')
    if type(reasons) is not list or len(reasons) > len(REASONS):
        _reject()
    reasons = [_choice(reason, REASONS) for reason in reasons]
    if len(set(reasons)) != len(reasons) or bool(reasons) != report['uncertain']:
        _reject()
    result = {'id': _text(report.get('id'), 80),
              'gatepass': _text(report.get('gatepass'), 80),
              'material': _text(report.get('material'), 80),
              'unit': _choice(report.get('unit'), UNITS),
              'direction': _choice(report.get('direction'), DIRECTIONS),
              'expected': _integer(report.get('expected'), 1, 10000),
              'phase': phase, 'started_at': _timestamp(report.get('started_at'), optional=True),
              'ended_at': ended, 'prediction_uncertain': report['uncertain'],
              'prediction_uncertainty_reasons': reasons,
              'predicted_incoming': _integer(report.get('incoming'), 0, 100000),
              'predicted_outgoing': _integer(report.get('outgoing'), 0, 100000),
              'predicted_count': _integer(report.get('observed'), -100000, 100000),
              'confirmed_count': None, 'difference': None, 'finality': 'unconfirmed',
              'status': 'In progress' if phase == 'in_progress' else 'Needs review',
              'basis': 'replay_prediction', 'camera_verified': False, 'model_approved': False}
    net = result['predicted_incoming'] - result['predicted_outgoing']
    if result['direction'] == 'Outgoing':
        net = -net
    if net != result['predicted_count']:
        _reject()
    doc = report.get('document_evidence')
    expected_basis = 'reviewed_document_line' if doc is not None else 'caller_supplied_unverified'
    if report.get('expected_provenance') != expected_basis:
        _reject()
    result['expected_provenance'] = expected_basis
    result['document'] = _document(doc, result) if doc is not None else None
    # A replay estimate is never an operator confirmation. Review hold for an
    # unvalidated model permits a labelled estimate, but gaps/interruption or a
    # negative directional net cannot establish even an estimated total.
    estimable = (result['document'] is not None and net >= 0
                 and all(reason == 'review_hold' for reason in reasons)
                 and report.get('completion_reason') != 'interrupted')
    result['estimated_count'] = net if estimable else None
    result['estimated_difference'] = net - result['expected'] if estimable else None
    result['estimate_basis'] = 'replay_prediction' if estimable else None
    return result


def project_reconciliation(report, stored_confirmation):
    """Project a matching immutable local operator attestation, not model truth."""
    result = project_replay(report)
    row = _mapping(stored_confirmation)
    evidence = _mapping(row.get('evidence'))
    snapshot = _mapping(evidence.get('report_snapshot'))
    if (evidence.get('basis') != 'operator_attestation'
            or evidence.get('kind') != 'reconciliation'
            or evidence.get('event') is not None
            or evidence.get('session_id') != result['id']
            or evidence.get('model_approved') is not False
            or result['phase'] != 'completed' or result['document'] is None
            or _canonical(snapshot) != _canonical(report)):
        _reject()
    source = _mapping(snapshot.get('prediction_source'))
    _text(source.get('operation_id'), 200)
    _hash(source.get('source_sha256'))
    _hash(source.get('plan_sha256'))
    if source.get('review_hold_reason') != 'model_unvalidated':
        _reject()
    _text(evidence.get('reviewer'), 80)
    _text(evidence.get('note'), 1000)
    identity = hashlib.sha256(_canonical([result['id'], 'reconciliation', None]).encode()).hexdigest()
    if row.get('id') != identity:
        _reject()
    counted = _integer(evidence.get('counted'), 0, 100000)
    difference = _integer(evidence.get('difference'), -10000, 99999)
    if difference != counted - result['expected']:
        _reject()
    result.update(confirmed_count=counted, difference=difference,
                  basis='operator_attestation', finality='operator_attested',
                  confirmation_id=identity, confirmed_at=_timestamp(row.get('created_at')),
                  status='Matched' if difference == 0 else (
                      f'Missing {-difference}' if difference < 0 else f'Excess {difference}'))
    return result
