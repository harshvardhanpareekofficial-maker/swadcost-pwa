"""Host-only receipt-to-candidate adapter; no HTTP route or camera access.

The composition root must construct HostPhoneLoadingCapability from its own
PhoneSubmissions store and authenticated identity, never from request JSON or a
caller-selected path. The association loader is a trusted host capability: it
must read an explicit operator-reviewed camera/direction association. Checking
its fields cannot prove that a human performed that review. No association
store/route is supplied here; integration must provide that capability.

This is not a security boundary against code executing inside the Python host
or local filesystem attackers. It refuses receipt dictionaries as provenance.
"""
from dataclasses import dataclass
from contextlib import closing
from datetime import datetime
import hashlib
import json
import re
import sqlite3
from types import MappingProxyType
from typing import Callable, Mapping

from app.phone_submissions import PhoneSubmissions, submission_metadata
from ml.loading_window import plan_phone_submission_window


def _identity(value):
    if not isinstance(value, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,128}', value):
        raise ValueError('trusted_identity_required')
    return value


def _aware(value):
    if not isinstance(value, str) or len(value) > 64:
        raise ValueError('review_timestamp_required')
    try:
        parsed = datetime.fromisoformat(value.replace('Z', '+00:00'))
        if parsed.utcoffset() is None:
            raise ValueError()
    except ValueError as exc:
        raise ValueError('review_timestamp_required') from exc
    return parsed


@dataclass(frozen=True)
class HostPhoneLoadingCapability:
    """Host-created authority, not a deserializable user request schema."""
    submissions: PhoneSubmissions
    authenticated_factory_id: str
    authenticated_user_id: str
    load_reviewed_association: Callable[[Mapping], Mapping]

    def __post_init__(self):
        if type(self.submissions) is not PhoneSubmissions:
            raise ValueError('host_receipt_store_required')
        _identity(self.authenticated_factory_id)
        _identity(self.authenticated_user_id)
        if self.submissions.factory_id != self.authenticated_factory_id:
            raise ValueError('factory_scope_mismatch')
        if not callable(self.load_reviewed_association):
            raise ValueError('trusted_review_loader_required')


def plan_phone_loading_candidate(capability, submission_id):
    """Load the immutable host receipt, scope its review, plan savedAt +600s.

    No caller timing, arbitrary receipt, window padding, clock proof or fetch
    permission is accepted. Camera-clock review remains a separate next gate.
    """
    if type(capability) is not HostPhoneLoadingCapability:
        raise ValueError('host_loading_capability_required')
    # Validate the selector before touching the store. Placeholder values here
    # validate UUID syntax only; all actual metadata is loaded below.
    submission_metadata(submission_id, '0'*64, '2000-01-01T00:00:00Z')
    receiver = capability.submissions
    if receiver.factory_id != capability.authenticated_factory_id:
        raise ValueError('factory_scope_mismatch')
    if not receiver.store.index.is_file() or not receiver.path.is_file():
        raise ValueError('durable_phone_receipt_unavailable')
    try:
        with closing(sqlite3.connect(receiver.path.resolve().as_uri()+'?mode=ro', uri=True, timeout=0.2)) as db:
            row = db.execute('''SELECT factory,submission,uid,digest,saved_at,document,received_at
                FROM phone_submissions_v1 WHERE factory=? AND submission=? AND uid=?''',
                (capability.authenticated_factory_id, submission_id, capability.authenticated_user_id)).fetchone()
    except sqlite3.Error as exc:
        raise ValueError('durable_phone_receipt_unavailable') from exc
    if row is None:
        raise ValueError('durable_phone_receipt_unavailable')
    receipt = dict(zip(('factoryId','id','userId','digest','savedAt','documentId','receivedAt'),row))
    submission_metadata(receipt['id'], receipt['digest'], receipt['savedAt'])
    received = _aware(receipt['receivedAt'])
    if receipt['documentId'] != 'scan-'+receipt['digest']:
        raise ValueError('receipt_document_identity_mismatch')
    # The read-only loader receives immutable scalar receipt fields; it cannot
    # rewrite the event anchor or trusted identity used by the planner.
    association = capability.load_reviewed_association(MappingProxyType(receipt))
    if not isinstance(association, Mapping):
        raise ValueError('reviewed_camera_direction_required')
    for key, expected in [('factoryId',receipt['factoryId']),('userId',receipt['userId']),
                          ('submissionId',receipt['id']),('documentId',receipt['documentId']),
                          ('originalDigest',receipt['digest'])]:
        if association.get(key) != expected:
            raise ValueError('association_identity_mismatch')
    reviewer = association.get('reviewedBy')
    if (association.get('reviewBasis') != 'explicit_operator_camera_direction_review'
            or not isinstance(reviewer,str) or not reviewer.strip() or len(reviewer)>128
            or any(ord(c)<32 for c in reviewer)):
        raise ValueError('reviewed_camera_direction_required')
    if _aware(association.get('reviewedAt')) < received:
        raise ValueError('association_review_precedes_receipt')
    result = plan_phone_submission_window({'camera_id':association.get('cameraId'),
        'direction':association.get('direction'), 'uploaded_at':receipt['savedAt'],
        'received_at':receipt['receivedAt']})
    encoded=json.dumps(receipt,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode('utf-8')
    result['phone_receipt'] = {**receipt, 'receipt_sha256':hashlib.sha256(encoded).hexdigest(),
                              'source':'host_phone_submissions_v1'}
    result['association_review'] = {'reviewed_by':reviewer,'reviewed_at':association['reviewedAt'],
                                   'basis':association['reviewBasis']}
    result['limitations'].append('Phone savedAt remains a device-reported save time, not verified loading time.')
    return result
