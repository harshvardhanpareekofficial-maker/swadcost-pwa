/* Active-session local capture and explicit authenticated durable synchronization. */
(() => {
 'use strict';
 let binding=null,epoch=0,busy=false,syncing=false,attempt=null,listEpoch=0;
 const get=id=>document.getElementById(id);
 const key=b=>b?JSON.stringify([b.factoryId,b.userId]):null;
 function controls(){const button=get('customer-upload')?.querySelector('button[type=submit]');if(button)button.disabled=busy||!binding;const sync=get('phone-sync');if(sync)sync.disabled=syncing||!binding;}
 function panel(){
  let section=get('phone-pending');
  if(!section){section=document.createElement('section');section.id='phone-pending';section.className='customer-panel';section.setAttribute('aria-label','Passes saved on this phone');get('customer-upload').after(section);}
  return section;
 }
 async function refresh(){
  if(!window.GateDeskMobile)return;
  const target=panel(),ticket=epoch,listTicket=++listEpoch,bound=binding;target.replaceChildren();target.hidden=!bound;
  if(!bound)return;
  try{
   const rows=await window.GateDeskPhoneOutbox.list(bound);if(ticket!==epoch||listTicket!==listEpoch)return;
   const heading=document.createElement('h3');heading.textContent='Saved on this phone';target.append(heading);
   const note=document.createElement('p');note.textContent='These originals stay on this device. Awaiting sync does not mean the factory PC has received them. Keep this app data until receipt is confirmed.';target.append(note);
   if(rows.some(row=>row.status==='awaiting_sync')&&window.GateDeskMobile?.client?.submit){const button=document.createElement('button');button.id='phone-sync';button.type='button';button.className='button primary';button.textContent=syncing?'Syncing pending passes…':'Sync pending passes';button.disabled=syncing;button.onclick=()=>sync().catch(error=>{if(ticket===epoch&&key(bound)===key(binding))get('upload-feedback').textContent=error.message;});target.append(button);}
   if(!rows.length){const empty=document.createElement('p');empty.textContent='No passes saved for this account on this phone.';target.append(empty);}
   for(const row of rows){const line=document.createElement('p');line.textContent=(row.status==='received_by_pc'?'Received by factory PC — awaiting processing':'Saved on this phone — awaiting sync')+' · '+row.id.slice(0,8);target.append(line);}
  }catch{if(ticket===epoch&&listTicket===listEpoch)target.textContent='The saved-pass list is unavailable. Existing originals have not been deleted. Try again before leaving this device.';}
 }
 function setAccount(account){
  if(!window.GateDeskMobile)return;
  const candidate=account?.enabled===true&&(account.authenticated===true||account.offline_capture===true)&&['owner','worker'].includes(account.user?.role)?{factoryId:account.factory?.id,userId:account.user?.id}:null;
  const next=candidate&&Object.values(candidate).every(v=>typeof v==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(v))?candidate:null;
  if(key(next)!==key(binding)){epoch++;attempt=null;get('customer-upload').reset();get('upload-feedback').textContent='';}
  binding=next;controls();refresh();
 }
 async function save(file){
  if(!binding||!window.GateDeskPhoneOutbox)throw Error('Sign in to the factory before saving on this phone.');
  if(busy)throw Error('A photograph is already being saved.');
  const bound={...binding},ticket=epoch;
  if(!attempt||attempt.file!==file||attempt.binding!==key(bound))attempt={file,binding:key(bound),id:window.GateDeskPhoneOutbox.newSubmissionId()};
  const submissionId=attempt.id;busy=true;controls();
  try{
   const row=await window.GateDeskPhoneOutbox.save(bound,file,{operationTime:null,cameraId:null},submissionId);
   if(ticket!==epoch)return {saved:true,accountChanged:true};
   attempt=null;refresh();return {saved:true,accountChanged:false,id:row.id,status:row.status};
  }catch(error){if(ticket!==epoch)return {saved:false,accountChanged:true};throw error;}
  finally{busy=false;controls();}
 }
 function validReceipt(ack,row,bound){
  if(!ack||ack.id!==row.id||ack.factoryId!==bound.factoryId||ack.userId!==bound.userId||ack.digest!==row.digest||ack.savedAt!==row.createdAt
     ||typeof ack.documentId!=='string'||!/^[A-Za-z0-9_-]{1,128}$/.test(ack.documentId)
     ||typeof ack.receivedAt!=='string'||!/^\d{4}-\d{2}-\d{2}T.+(?:Z|[+-]\d{2}:\d{2})$/.test(ack.receivedAt)||!Number.isFinite(Date.parse(ack.receivedAt)))throw Error('Factory receipt does not match this saved pass. Original remains pending.');
 }
 async function sync(){
  if(!binding||!window.GateDeskMobile?.client?.submit)throw Error('Sign in to the factory before syncing.');
  if(syncing)throw Error('Pending passes are already syncing.');
  const bound={...binding},ticket=epoch,current=()=>ticket===epoch&&key(bound)===key(binding);
  let received=0;syncing=true;controls();
  try{
   const live=await window.GateDeskMobile.client.account();
   if(!current())return {received,accountChanged:true};
   if(live?.authenticated!==true)throw Error('Current factory sign-in is required to sync. Originals remain on this phone.');
   if(live.factory?.id!==bound.factoryId||live.user?.id!==bound.userId){setAccount(null);throw Error('Factory account changed. Sign in to the original account before syncing its saved passes.');}
   const rows=await window.GateDeskPhoneOutbox.list(bound);
   for(const summary of rows){
    if(!current())return {received,accountChanged:true};
    if(summary.status!=='awaiting_sync')continue;
    const row=await window.GateDeskPhoneOutbox.read(bound,summary.id);
    if(!current())return {received,accountChanged:true};
    if(row.factoryId!==bound.factoryId||row.userId!==bound.userId||row.id!==summary.id||row.status!=='awaiting_sync')throw Error('Saved pass account or status changed. Sync stopped.');
    const ack=await window.GateDeskMobile.client.submit(row);
    if(!current())return {received,accountChanged:true};
    validReceipt(ack,row,bound);
    await window.GateDeskPhoneOutbox.acknowledge(bound,ack);
    if(!current())return {received,accountChanged:true};
    received++;
   }
   if(current())get('upload-feedback').textContent=received+' pass'+(received===1?'':'es')+' received by factory PC. Originals retained on this phone; processing is separate.';
   return {received,accountChanged:false};
  }catch(error){if(!current())return {received,accountChanged:true};throw error;}
  finally{syncing=false;controls();refresh();}
 }
 document.addEventListener('gate-remote-unavailable',event=>{if(event.detail?.authenticationLost)setAccount(null);});
 window.GateDeskPhonePasses=Object.freeze({setAccount,save,refresh,sync});
})();
