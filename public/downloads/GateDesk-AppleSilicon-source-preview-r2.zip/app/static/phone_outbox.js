/* Local encrypted pending originals. Not enrollment, backup, or a sync service. */
(() => {
 'use strict';
 const DB='gate-desk-phone-outbox-v1',MAX_FILE=10*1024*1024,MAX_TOTAL=50*1024*1024,MAX_ROWS=100;
 const encoder=new TextEncoder(),decoder=new TextDecoder();
 let opening;
 function open(){
  if(!opening)opening=new Promise((resolve,reject)=>{
   const request=indexedDB.open(DB,1);
   request.onupgradeneeded=()=>{request.result.createObjectStore('keys');request.result.createObjectStore('items',{keyPath:['factoryId','userId','id']});};
   request.onerror=()=>{opening=null;reject(Error('Phone storage is unavailable. Nothing was confirmed saved.'));};
   request.onblocked=()=>{ /* Do not acknowledge before the browser opens storage. */ };
   request.onsuccess=()=>{const db=request.result;db.onversionchange=()=>{db.close();opening=null;};resolve(db);};
  });
  return opening;
 }
 async function transaction(store,mode,work){
  const db=await open();return new Promise((resolve,reject)=>{
   let result,error;
   const tx=db.transaction(store,mode,mode==='readwrite'?{durability:'strict'}:undefined);
   tx.oncomplete=()=>resolve(result);tx.onabort=()=>reject(error||Error('Phone save failed. Original has not been acknowledged.'));
   tx.onerror=()=>{};
   const fail=reason=>{error=reason;tx.abort();};
   try{work(tx.objectStore(store),value=>{result=value;},fail);}catch(e){fail(e);}
  });
 }
 function binding(value){
  if(!value||!['factoryId','userId'].every(k=>typeof value[k]==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(value[k])))throw Error('An enrolled factory account is required.');
  return {factoryId:value.factoryId,userId:value.userId};
 }
 function keyId(b){return JSON.stringify([b.factoryId,b.userId]);}
 async function key(b){
  const existing=await transaction('keys','readonly',(s,done)=>{s.get(keyId(b)).onsuccess=e=>done(e.target.result);});
  if(existing)return existing;
  const generated=await crypto.subtle.generateKey({name:'AES-GCM',length:256},false,['encrypt','decrypt']);
  return transaction('keys','readwrite',(s,done)=>{s.get(keyId(b)).onsuccess=e=>{if(e.target.result)done(e.target.result);else{s.add(generated,keyId(b));done(generated);}};});
 }
 const hex=bytes=>Array.from(new Uint8Array(bytes),x=>x.toString(16).padStart(2,'0')).join('');
 const hash=async bytes=>hex(await crypto.subtle.digest('SHA-256',bytes));
 function id(value){if(typeof value!=='string'||!/^[a-f0-9-]{36}$/.test(value))throw Error('Invalid submission identity.');return value;}
 const aad=row=>encoder.encode(JSON.stringify([row.factoryId,row.userId,row.id,row.digest]));
 const summary=row=>({id:row.id,factoryId:row.factoryId,userId:row.userId,digest:row.digest,createdAt:row.createdAt,bytes:row.bytes,status:row.status,documentId:row.documentId||null});
 async function save(account,file,details={},submissionId=crypto.randomUUID()){
  const b=binding(account);id(submissionId);
  if(!(file instanceof Blob)||!['image/png','image/jpeg','image/webp'].includes(file.type)||file.size===0||file.size>MAX_FILE)throw Error('Choose a PNG, JPEG or WebP original no larger than 10 MB.');
  const metadata={name:typeof file.name==='string'?file.name.slice(0,160):'gate-pass',type:file.type,operationTime:details.operationTime??null,cameraId:details.cameraId??null};
  if(![metadata.operationTime,metadata.cameraId].every(v=>v===null||(typeof v==='string'&&v.length<=128)))throw Error('Invalid operation details.');
  // Phone capture time is not treated as the actual loading time.
  const original=await file.arrayBuffer(),digest=await hash(original),meta=encoder.encode(JSON.stringify(metadata));
  const payload=new Uint8Array(4+meta.length+original.byteLength);new DataView(payload.buffer).setUint32(0,meta.length);payload.set(meta,4);payload.set(new Uint8Array(original),4+meta.length);
  const row={...b,id:submissionId,digest,payloadDigest:await hash(payload),createdAt:new Date().toISOString(),bytes:file.size,status:'awaiting_sync',iv:crypto.getRandomValues(new Uint8Array(12))};
  row.ciphertext=await crypto.subtle.encrypt({name:'AES-GCM',iv:row.iv,additionalData:aad(row)},await key(b),payload);
  return transaction('items','readwrite',(store,done,fail)=>{
   const request=store.get([b.factoryId,b.userId,row.id]);
   request.onsuccess=()=>{
    const previous=request.result;
    if(previous){if(previous.payloadDigest!==row.payloadDigest){fail(Error('Submission ID already belongs to different content.'));return;}done(summary(previous));return;}
    store.getAll().onsuccess=e=>{const rows=e.target.result;if(rows.length>=MAX_ROWS||rows.reduce((n,r)=>n+r.bytes,0)+row.bytes>MAX_TOTAL){fail(Error('Phone queue is full. Existing originals were kept.'));return;}store.add(row);done(summary(row));};
   };
  });
 }
 async function list(account){const b=binding(account);return transaction('items','readonly',(s,done)=>{s.getAll().onsuccess=e=>done(e.target.result.filter(r=>r.factoryId===b.factoryId&&r.userId===b.userId).map(summary));});}
 async function read(account,submissionId){
  const b=binding(account);id(submissionId);
  const row=await transaction('items','readonly',(s,done)=>{s.get([b.factoryId,b.userId,submissionId]).onsuccess=e=>done(e.target.result);});
  if(!row)throw Error('Pending pass not found for this account.');
  const payload=await crypto.subtle.decrypt({name:'AES-GCM',iv:row.iv,additionalData:aad(row)},await key(b),row.ciphertext);
  if(await hash(payload)!==row.payloadDigest)throw Error('Saved pass integrity check failed.');
  const size=new DataView(payload).getUint32(0);if(size>4096||size+4>payload.byteLength)throw Error('Saved metadata is invalid.');
  const metadata=JSON.parse(decoder.decode(payload.slice(4,4+size))),original=payload.slice(4+size);
  if(await hash(original)!==row.digest)throw Error('Saved original integrity check failed.');
  return {...summary(row),metadata,original:new Blob([original],{type:metadata.type})};
 }
 // Only the authenticated sync adapter may call this after a committed PC ack.
 // A matching local value alone does not prove delivery; no adapter is wired yet.
 async function acknowledge(account,ack){
  const b=binding(account);id(ack?.id);
  if(ack.factoryId!==b.factoryId||ack.userId!==b.userId||typeof ack.documentId!=='string'||!/^[A-Za-z0-9_-]{1,128}$/.test(ack.documentId))throw Error('Invalid factory acknowledgement.');
  return transaction('items','readwrite',(s,done,fail)=>{s.get([b.factoryId,b.userId,ack.id]).onsuccess=e=>{
   const row=e.target.result;if(!row||row.digest!==ack.digest){fail(Error('Acknowledgement does not match the saved original.'));return;}
   if(row.documentId&&row.documentId!==ack.documentId){fail(Error('Conflicting acknowledgement.'));return;}
   row.status='received_by_pc';row.documentId=ack.documentId;s.put(row);done(summary(row));
  };});
 }
 window.GateDeskPhoneOutbox=Object.freeze({save,list,read,acknowledge,newSubmissionId:()=>crypto.randomUUID(),requestPersistence:async()=>Boolean(await navigator.storage?.persist?.())});
})();
