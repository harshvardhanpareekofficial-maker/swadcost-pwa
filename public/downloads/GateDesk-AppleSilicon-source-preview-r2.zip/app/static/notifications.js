(() => {
  const find = id => document.getElementById(id);
  let sessions = [], loading = false;
  async function request(path, body) {
    const response = await fetch('/api/notifications/' + path, body ? {
      method: 'POST', headers: {'X-Gate-Desk': 'local', 'Content-Type': 'application/json'}, body: JSON.stringify(body)
    } : {});
    const data = await response.json();
    if (!response.ok) throw new Error(typeof data.detail === 'string' ? data.detail : 'Check the confirmation fields.');
    return data;
  }
  function option(value, text) { const item = document.createElement('option'); item.value=value; item.textContent=text; return item; }
  function selection() {
    const session = sessions.find(s => s.id === find('alerts-session').value);
    const crossing = find('alerts-kind').value === 'crossing';
    find('alerts-event-label').hidden = !crossing;
    find('alerts-count-label').hidden = crossing;
    find('alerts-count').required = !crossing;
    find('alerts-event').required = crossing;
    find('alerts-event').replaceChildren(...(session?.crossings || []).map(e => option(e.id, `${e.direction} · ${e.occurred_at} · ${e.id}`)));
    find('alerts-save').disabled = !session || (crossing ? !session.crossings.length : session.phase !== 'completed' || !session.document_bound);
  }
  function rows(id, values, text) {
    const target=find(id); target.replaceChildren();
    if (!values.length) { target.textContent='None yet.'; return; }
    const list=document.createElement('ul');
    for (const value of values) { const li=document.createElement('li'); li.textContent=text(value); list.append(li); }
    target.append(list);
  }
  async function refresh() {
    if (loading) return;
    loading=true;
    try {
      const [status, options, queue, confirmed] = await Promise.all(['status','review-options','queue','confirmations'].map(p=>request(p)));
      const setup=status.setup, labels={smtp_host_missing_or_invalid:'Set a valid SMTP host',sender_missing_or_invalid:'Set one sender email address',recipient_missing_or_invalid:'Set one authorized recipient email address',secure_transport_required:'Use verified TLS (SSL or STARTTLS)',smtp_port_invalid:'Set a valid SMTP port',smtp_authentication_incomplete:'Provide both SMTP username and password, or neither',email_adapter_disabled:'Email adapter is off',external_delivery_disabled:'External delivery is off',worker_not_running:'Notification worker is not running'};
      const guidance=setup?`${setup.state==='configured_unverified'?'Configuration checks passed; delivery is still unverified.':'Setup needed: '+setup.blockers.map(code=>labels[code]||'Check local notification configuration').join('; ')+'.'} No connection test or message was sent by this check. Configure credentials locally; enable sending only for an authorized recipient.`:'Setup validation unavailable; delivery is unverified.';
      find('alerts-status').textContent=`Delivery: ${status.state.replaceAll('_',' ')}. Recipient ${status.recipient_configured?'configured':'not configured'}. External sending ${status.external_send_enabled?'enabled':'off'}. ${guidance} Alerts cover finalized discrepancies and serious health only; crossing confirmations and matched passes stay local.`;
      const previous=find('alerts-session').value;
      sessions=options.sessions;
      find('alerts-session').replaceChildren(...sessions.map(s=>option(s.id, `${s.gatepass} · ${s.unit} · ${s.phase}`)));
      if(sessions.some(s=>s.id===previous))find('alerts-session').value=previous;
      selection();
      rows('alerts-queue',queue.rows,r=>`${r.status} · ${r.kind || r.event?.kind || r.id}`);
      rows('alerts-confirmations',confirmed.rows,r=>`${r.evidence.report_snapshot.gatepass} · ${r.evidence.kind} · ${r.evidence.reviewer}${r.evidence.difference===null?'':` · discrepancy ${r.evidence.difference>0?'+':''}${r.evidence.difference}`}`);
    } catch(error) { find('alerts-status').textContent=error.message || 'Local alert status unavailable.'; }
    finally { loading=false; }
  }
  find('alerts-session').addEventListener('change',selection);
  find('alerts-kind').addEventListener('change',selection);
  find('alerts-refresh').addEventListener('click',refresh);
  window.addEventListener('gate-desk-alerts',refresh);
  find('alerts-confirm-form').addEventListener('submit',async e=>{
    e.preventDefault(); find('alerts-save').disabled=true;
    const kind=find('alerts-kind').value;
    const body={session_id:find('alerts-session').value, kind, reviewer:find('alerts-reviewer').value,
      evidence_note:find('alerts-note').value, physically_verified:find('alerts-attest').checked,
      event_id:kind==='crossing'?find('alerts-event').value:null,
      counted:kind==='reconciliation'?Number(find('alerts-count').value):null};
    try { await request('confirmations',body); find('alerts-feedback').textContent='Confirmation saved locally. Delivery is handled independently.'; find('alerts-attest').checked=false; await refresh(); }
    catch(error) { find('alerts-feedback').textContent=error.message; }
    finally { selection(); }
  });
  
})();
