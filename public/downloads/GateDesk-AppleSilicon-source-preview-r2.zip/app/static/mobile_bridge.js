/* Mode comes only from server-rendered HTML, never a URL or role preference. */
(() => {
 'use strict';
 if (document.documentElement.dataset.transport !== 'remote') return;
 const client = GateDeskRemoteClient.createRemoteClient(window.fetch.bind(window), detail => document.dispatchEvent(new CustomEvent('gate-remote-unavailable',{detail})),undefined,{getItem:key=>window.localStorage.getItem(key),setItem:(key,value)=>window.localStorage.setItem(key,value),removeItem:key=>window.localStorage.removeItem(key)});
 window.GateDeskMobile = {
  client,
  async request(path, options={}) {
   const body=typeof options.body==='string' ? JSON.parse(options.body) : options.body;
   if(path==='/api/account') return client.account();
   if(path==='/api/account/login') return client.login(body);
   if(path==='/api/account/logout') return client.logout();
   if(path==='/api/documents/import-image') return client.upload(options.form || options.body);
   if(path==='/api/documents') return (await client.documents(0,typeof selectedDocumentId==='string'?selectedDocumentId:null)).documents;
   const match=/^\/api\/documents\/([A-Za-z0-9_-]+)\/review$/.exec(path);
   if(match) return client.review(match[1],body);
   throw Error('This action is available on the factory PC only.');
  }
 };
})();
