/* Pinned local decoder, one bounded image per worker; never any remote URL. */
importScripts('/static/vendor/jsqr/jsQR-1.4.0.js');
self.onmessage=event=>{
 try{
  const {buffer,width,height}=event.data;
  if(!Number.isInteger(width)||!Number.isInteger(height)||width<1||height<1||width>1024||height>1024||!(buffer instanceof ArrayBuffer)||buffer.byteLength!==width*height*4)throw Error('invalid_pixels');
  const pixels=new Uint8ClampedArray(buffer),first=jsQR(pixels,width,height,{inversionAttempts:'attemptBoth'});
  if(!first){self.postMessage({values:[]});return;}
  // Mask the first code, then look for another. Never silently choose between
  // two readable invitations in the same image.
  const corners=['topLeftCorner','topRightCorner','bottomLeftCorner','bottomRightCorner'].map(k=>first.location[k]);
  const left=Math.max(0,Math.floor(Math.min(...corners.map(p=>p.x)))-2),right=Math.min(width,Math.ceil(Math.max(...corners.map(p=>p.x)))+2);
  const top=Math.max(0,Math.floor(Math.min(...corners.map(p=>p.y)))-2),bottom=Math.min(height,Math.ceil(Math.max(...corners.map(p=>p.y)))+2);
  for(let y=top;y<bottom;y++)for(let x=left;x<right;x++){const i=(y*width+x)*4;pixels[i]=pixels[i+1]=pixels[i+2]=pixels[i+3]=255;}
  const second=jsQR(pixels,width,height,{inversionAttempts:'attemptBoth'});
  self.postMessage({values:second?[first.data,second.data]:[first.data]});
 }catch{self.postMessage({error:'Code image could not be read.'});}
};
