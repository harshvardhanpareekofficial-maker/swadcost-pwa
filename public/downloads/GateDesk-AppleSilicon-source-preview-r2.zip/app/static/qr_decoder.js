/* Canvas sampling on-device; decoding in a terminable local worker. */
(() => {
 'use strict';
 function create(){
  let running=null,closed=false;
  return {
   close(){closed=true;running?.finish(Error('Code reading stopped.'));},
   async detect(source){
    if(closed||running)throw Error('Code reader is unavailable.');
    const width=source.videoWidth||source.width,height=source.videoHeight||source.height;
    if(!width||!height)return [];
    const scale=Math.min(1,1024/Math.max(width,height)),w=Math.max(1,Math.round(width*scale)),h=Math.max(1,Math.round(height*scale));
    const canvas=document.createElement('canvas');canvas.width=w;canvas.height=h;
    let pixels;
    try{const context=canvas.getContext('2d',{willReadFrequently:true});context.drawImage(source,0,0,w,h);pixels=context.getImageData(0,0,w,h).data;}
    finally{canvas.width=canvas.height=0;}
    return new Promise((resolve,reject)=>{
     let worker,timer,done=false;
     const finish=(error,values)=>{if(done)return;done=true;clearTimeout(timer);worker?.terminate();running=null;error?reject(error):resolve(values.map(rawValue=>({rawValue})));};
     running={finish};
     try{
      worker=new Worker('/static/qr_worker.js');
      timer=setTimeout(()=>finish(Error('Code reading timed out. Use a clearer, tightly cropped image.')),2000);
      worker.onerror=()=>finish(Error('Local code reader could not start. Enter the invitation code.'));
      worker.onmessage=event=>{const values=event.data?.values;if(!Array.isArray(values)||values.length>2||values.some(v=>typeof v!=='string'||v.length>2048)){finish(Error('Code image could not be read.'));return;}finish(null,values);};
      worker.postMessage({buffer:pixels.buffer,width:w,height:h},[pixels.buffer]);
     }catch{finish(Error('Local code reader could not start. Enter the invitation code.'));}
    });
   }
  };
 }
 window.GateDeskQRDecoder={create};
})();
