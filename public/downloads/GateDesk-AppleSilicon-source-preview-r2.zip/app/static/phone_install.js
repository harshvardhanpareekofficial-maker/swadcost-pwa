/* Cache only the public application shell. API authority always stays online. */
(() => {
 'use strict';
 if(document.documentElement.dataset.transport!=='remote'||!('serviceWorker' in navigator))return;
 window.addEventListener('load',()=>{
  navigator.serviceWorker.register('/phone-worker.js',{scope:'/',updateViaCache:'none'}).catch(()=>{
   // Installation failure must not claim that offline launch is available.
   document.documentElement.dataset.offlineShell='unavailable';
  });
 });
})();
