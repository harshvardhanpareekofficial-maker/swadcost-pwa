/* Invitation secret stays in memory; QR fragments are removed before navigation. */
(() => {
 'use strict';
 let token = /^#join=([A-Za-z0-9_-]{43})$/.exec(location.hash)?.[1] || '';
 if(token){history.replaceState(null,'','#account');window.gateDeskPendingPage='account';}
 const escape=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 let epoch=0;
 async function local(path, body){
  const response=await fetch('/api/account/worker-invitations'+path,{method:body===undefined?'GET':'POST',credentials:'same-origin',cache:'no-store',headers:{'X-Gate-Desk':'local','Content-Type':'application/json'},...(body===undefined?{}:{body:JSON.stringify(body)})});
  const data=await response.json();if(!response.ok)throw Error(typeof data.detail==='string'?data.detail:'Invitation request failed.');return data;
 }
 function render(account){
  const generation=++epoch,target=document.getElementById('account-auth');
  if(!target||!account?.enabled)return;
  const remote=window.GateDeskMobile?.client;
  if(account.authenticated&&account.user?.role==='owner'){
   const box=document.createElement('section');box.className='customer-panel';box.id='worker-invitations';
   box.innerHTML=`<h3>Invite a worker</h3><p>Owner ID: <strong>${escape(account.user.id||'Assigned by factory')}</strong></p><p>Each invitation gives one person worker access. It expires after 15 minutes.</p><button class="button primary" id="create-worker-invite">${remote?'Generate worker QR':'Create worker invitation'}</button><div id="worker-invite-result" role="status"></div><div id="worker-invite-list"></div>`;target.append(box);
   const output=box.querySelector('#worker-invite-result'),list=box.querySelector('#worker-invite-list');
   async function refresh(){
    try{const data=await(remote?remote.invitations():local(''));if(generation!==epoch)return;
     list.innerHTML=data.invitations.map(i=>`<p>${escape(i.status)} · expires ${escape(new Date(i.expires_at*1000).toLocaleTimeString())} ${i.status==='pending'?`<button class="button secondary" data-cancel-invite="${escape(i.id)}">Cancel invitation</button>`:''}</p>`).join('');
    }catch(error){if(generation===epoch)list.textContent=error.message;}
   }
   box.querySelector('#create-worker-invite').onclick=async e=>{
    e.target.disabled=true;output.replaceChildren();
    try{const data=await(remote?remote.invite():local('',{}));if(generation!==epoch)return;
     if(data.qr_data_url?.startsWith('data:image/png;base64,')&&data.join_url){
      const image=document.createElement('img');image.src=data.qr_data_url;image.alt='One-use worker enrollment QR';image.width=256;image.height=256;output.append(image);
      const message=document.createElement('p');message.textContent='Worker: scan, choose your own sign-in details, then sign in. The code works once.';output.append(message);
     }else{output.textContent=account.owner_only?'Phone enrollment needs the configured secure factory address. Keep this one-use code for the phone app; worker enrollment is disabled on this PC: ':'Phone QR requires the configured secure factory address. This local invitation code can be entered on this PC: ';const code=document.createElement('code');code.textContent=data.token;output.append(code);}
     await refresh();
    }catch(error){if(generation===epoch)output.textContent=error.message;}finally{if(generation===epoch)e.target.disabled=false;}
   };
   list.onclick=async e=>{const b=e.target.closest('[data-cancel-invite]');if(!b)return;b.disabled=true;try{await(remote?remote.revokeInvitation(b.dataset.cancelInvite):local('/'+b.dataset.cancelInvite+'/revoke',{}));output.replaceChildren();await refresh();}catch(error){output.textContent=error.message;b.disabled=false;}};
   refresh();
  }else if(!account.authenticated&&!account.bootstrap_required&&!account.owner_only){
   const box=document.createElement('details');box.className='customer-panel';box.open=!!token;
   box.innerHTML=`<summary>Join as a worker</summary><form id="worker-invite-join"><label>Invitation code<input name="token" required autocomplete="off" pattern="[A-Za-z0-9_-]{43}"></label><label>Your name<input name="display_name" required maxlength="80"></label><label>Username<input name="username" required autocomplete="username" pattern="[A-Za-z0-9_.-]{3,64}"></label><label>Create password<input name="password" type="password" required minlength="12" maxlength="128" autocomplete="new-password"></label><button class="button primary">Accept worker invitation</button><p role="status"></p></form>`;target.append(box);
   const form=box.querySelector('form');form.elements.token.value=token;
   form.onsubmit=async e=>{e.preventDefault();const button=form.querySelector('button'),status=form.querySelector('[role=status]');button.disabled=true;
    try{await(remote?remote.redeemInvitation(Object.fromEntries(new FormData(form))):local('/redeem',Object.fromEntries(new FormData(form))));token='';form.reset();status.textContent='Worker account created. Sign in above using your new details.';}
    catch(error){status.textContent=error.message;}finally{button.disabled=false;}
   };
  }
 }
 window.GateDeskInvitations={render};
 document.addEventListener('gate-remote-unavailable',e=>{if(e.detail?.authenticationLost){epoch++;document.getElementById('worker-invitations')?.remove();}});
})();
