/* Customer workspace. Browser view preferences never grant server permissions. */
(() => {
'use strict';
const el=id=>document.getElementById(id), esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let account=null,role='worker',offset=0,total=0,sessions=[],finals=[],docs=[],loading=false,ready=false,dataGeneration=0;
const mobile=window.GateDeskMobile;
let cameraState=null,cameraBusy=false,cameraGeneration=0;
const cameraAllowed=()=>!mobile&&account?.enabled===true&&account.authenticated===true&&account.user?.role==='owner'&&account.camera_setup_enabled===true;
function clearCameraCredentials(){for(const id of ['camera-username','camera-password'])if(el(id))el(id).value='';}
function cameraUnavailable(){cameraGeneration++;cameraState=null;clearCameraCredentials();el('camera-setup').hidden=true;}
function cameraControls(){const enabled=cameraAllowed()&&!cameraBusy;el('camera-refresh').disabled=!enabled;el('camera-provision').disabled=!enabled||cameraState?.provision_required!==true;el('camera-save').disabled=!enabled||!cameraState||cameraState.provision_required;}
function cameraRender(state,saved=false){
 if(!state||typeof state.provision_required!=='boolean'||typeof state.reenrollment_required!=='boolean'||(state.draft!==null&&(!state.draft?.camera||!Number.isSafeInteger(state.draft.revision)||state.draft.revision<1)))throw Error('camera_state_invalid');
 cameraState=state;const camera=state.draft?.camera;
 for(const key of ['camera_id','name','host','port','stream_path'])el('camera-'+key).value=camera?.[key]??(key==='port'?'554':'');
 clearCameraCredentials();el('camera-provision').hidden=!state.provision_required;el('camera-fields').disabled=state.provision_required;
 el('camera-feedback').textContent=state.reenrollment_required?(saved?'Saved, connection not tested. The restore notice still requires attention. Refresh the saved setup before any further change.':'Re-enter camera credentials after restore. Connection not tested.'):(state.draft?'Saved, connection not tested.':state.provision_required?'Create local camera storage before saving a camera.':'Ready to save a camera. Connection not tested.');
 cameraControls();
}
async function cameraRequest(path,body){
 const response=await fetch('/api/camera-enrollment/'+path,{method:body===undefined?'GET':'POST',credentials:'same-origin',cache:'no-store',headers:{'X-Gate-Desk':'local','Content-Type':'application/json'},...(body===undefined?{}:{body:JSON.stringify(body)})});
 if(!response.ok){const error=Error('camera_request_failed');error.status=response.status;throw error;}return response.json();
}
async function cameraAction(action){
 if(!cameraAllowed()||cameraBusy)return;
 if(action==='provision'&&cameraState?.provision_required!==true)return;
 if(action==='save'&&(!cameraState||cameraState.provision_required))return;
 const generation=++cameraGeneration;cameraBusy=true;cameraControls();
 try{
  let state;
  if(action==='save'){
   const form=el('camera-form');if(!form.reportValidity())return;
   const draft=Object.fromEntries(['camera_id','name','host','stream_path'].map(key=>[key,el('camera-'+key).value.trim()]));draft.port=Number(el('camera-port').value);
   const body={draft,username:el('camera-username').value,password:el('camera-password').value,expected_revision:cameraState.draft?.revision??0};
   clearCameraCredentials();state=await cameraRequest('draft',body);
  }else state=await cameraRequest(action==='provision'?'provision':'draft',action==='provision'?{}:undefined);
  if(generation===cameraGeneration&&cameraAllowed())cameraRender(state,action==='save');
 }catch(error){
  if(generation!==cameraGeneration)return;
  if([401,403].includes(error.status)){cameraUnavailable();account.camera_setup_enabled=false;}
  else{cameraState=null;el('camera-feedback').textContent=error.status===409?'Camera setup changed. Refresh saved setup, then re-enter credentials before saving.':'Camera setup could not be confirmed. Refresh saved setup before trying again. No connection test was started.';}
 }finally{clearCameraCredentials();cameraBusy=false;cameraControls();}
}
const pages=['current','history','account'], tools=['documents','counting','notifications','reports','health','workspace','model'];
const canOperate=()=>account?.enabled===false||account?.authenticated===true||(!!mobile&&account?.offline_capture===true);
const isWorker=()=>account?.enabled===true&&account.user?.role==='worker';
async function request(url,options={}){if(mobile)return mobile.request(url,options);const r=await fetch(url,{...options,headers:{'X-Gate-Desk':'local',...(options.body instanceof FormData?{}:{'Content-Type':'application/json'}),...options.headers}});const d=await r.json();if(!r.ok&&[401,403].includes(r.status)){cameraUnavailable();if(account)account.camera_setup_enabled=false;}if(!r.ok)throw Error(typeof d.detail==='string'?d.detail:'The request could not be completed.');return d;}
const post=(url,body)=>request(url,{method:'POST',body:JSON.stringify(body)});
function navigate(name){
 if(!ready){window.gateDeskPendingPage=name;return;}
 if(tools.includes(name)){openTool(name);return;}
 if(!pages.includes(name))name='current';
 if(name!=='account')clearCameraCredentials();
 if(!canOperate())name='account';
 document.querySelectorAll('.page').forEach(p=>p.hidden=p.id!==name+'-page');
 document.querySelectorAll('.nav').forEach(b=>{const active=b.dataset.page===name;b.classList.toggle('active',active);if(active)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');});
 el('crumb').textContent={current:'Current Passes',history:'History',account:'Account & Plans'}[name];
 if(location.hash!=='#'+name)history.replaceState(null,'','#'+name);
 if(name!=='account')refreshData();
}
function openTool(name){
 if(mobile&&name!=='documents'){navigate('account');return;}
 if(account?.offline_capture===true||!canOperate()||(isWorker()&&name!=='documents')){navigate('account');return;}
 const parent=['documents','counting'].includes(name)?'current':'account';navigate(parent);
 if(parent==='account')el('advanced-tools').open=true;
 const detail=el(name+'-tool');detail.open=true;el(name+'-page').hidden=false;
 if(name==='documents')loadDocuments();
 if(name==='workspace')refresh().catch(e=>toast(e.message));
 if(name==='reports'){refresh().catch(e=>toast(e.message));loadPredictionReports();}
 if(name==='model')loadModel();
 if(name==='counting')window.dispatchEvent(new Event('gate-desk-counting'));
 if(name==='notifications')window.dispatchEvent(new Event('gate-desk-alerts'));
 detail.scrollIntoView?.({block:'start',behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});
}
function empty(text,help){return `<div class="empty-state"><strong>${esc(text)}</strong><p>${esc(help)}</p></div>`;}
function reconciliationView(attested,expected,counted,difference,phase,estimate=null){
 const known=attested&&Number.isSafeInteger(expected)&&expected>=0&&Number.isSafeInteger(counted)&&counted>=0&&Number.isSafeInteger(difference)&&difference===counted-expected;
 if(!known&&!attested&&estimate){
  const delta=estimate.difference,label=delta===0?'No difference':delta<0?'Short by '+Math.abs(delta):'Extra '+delta;
  return {tone:delta===0?'review':'mismatch',status:(phase==='in_progress'?'Estimate so far · ':'Estimated · ')+label,difference:delta>0?'+'+delta:String(delta),estimated:true};
 }
 if(!known)return {tone:'review',status:phase==='in_progress'?'In progress · count unconfirmed':'Needs count review',difference:'Unknown'};
 return {tone:difference===0?'matched':'mismatch',status:difference===0?'Matched':'Discrepancy · '+(difference<0?'Short by '+Math.abs(difference):'Extra '+difference),difference:difference>0?'+'+difference:String(difference)};
}
function replayEstimate(s,projected=false){
 const units=['bag','beam','cone','roll','bundle','carton','unit'],integer=(n,max)=>Number.isSafeInteger(n)&&n>=0&&n<=max;
 const timestamp=t=>typeof t==='string'&&/[T ].*(?:Z|[+-]\d\d:\d\d)$/.test(t)&&Number.isFinite(Date.parse(t));
 const reasons=projected?s.prediction_uncertainty_reasons:s.uncertainty_reasons,uncertain=projected?s.prediction_uncertain:s.uncertain;
 if((projected?s.basis!=='replay_prediction':s.mode!=='replay')||s.camera_verified!==false||!['Incoming','Outgoing'].includes(s.direction)||!units.includes(s.unit)||!integer(s.expected,10000)||s.expected<1||!['in_progress','completed'].includes(s.phase))return null;
 if(typeof uncertain!=='boolean'||!Array.isArray(reasons)||new Set(reasons).size!==reasons.length||Boolean(reasons.length)!==uncertain||reasons.some(r=>r!=='review_hold'))return null;
 if(s.phase==='completed'&&!timestamp(s.ended_at))return null;
 if(!projected&&((s.phase==='in_progress'&&(s.ended_at!=null||s.completion_reason!=null))||s.completion_reason==='interrupted'||(s.phase==='completed'&&!['carrier_departed','operator_ended'].includes(s.completion_reason))))return null;
 const incoming=projected?s.predicted_incoming:s.incoming,outgoing=projected?s.predicted_outgoing:s.outgoing,observed=projected?s.predicted_count:s.observed;
 if(!integer(incoming,100000)||!integer(outgoing,100000)||!integer(observed,100000))return null;
 const count=s.direction==='Incoming'?incoming-outgoing:outgoing-incoming;
 if(count<0||count!==observed)return null;
 const d=projected?s.document:s.document_evidence,l=d?.line;
 if(s.expected_provenance!=='reviewed_document_line'||!d||!l||!timestamp(d.reviewed_at)||!/^[0-9a-f]{64}$/.test(d.document_sha256)||!d.document_id||d.number!==s.gatepass||d.direction!==s.direction||l.quantity!==s.expected||l.unit!==s.unit||typeof l.id!=='string'||!l.id||typeof l.material!=='string'||!l.material.trim())return null;
 if(!projected){
  if(d.schema_version!==2||!timestamp(d.bound_at)||d.confirmed_material_class!==s.material||d.mapping_basis!=='explicit_operator_selection_not_automatic_semantic_match'||!Array.isArray(d.document_lines)||!d.document_lines.length||d.document_lines.length>30)return null;
  if(d.document_lines.some(line=>!line||typeof line.id!=='string'||!line.id||typeof line.material!=='string'||!line.material.trim()||!integer(line.quantity,10000)||line.quantity<1||!units.includes(line.unit))||new Set(d.document_lines.map(line=>line.id)).size!==d.document_lines.length)return null;
  if(d.document_lines.filter(line=>['id','material','quantity','unit'].every(key=>line[key]===l[key])).length!==1)return null;
 }
 const difference=count-s.expected;
 if(projected&&(s.estimate_basis!=='replay_prediction'||s.estimated_count!==count||s.estimated_difference!==difference))return null;
 return {count,difference};
}
function reportCard(row,confirmation){
 if(mobile){
 const attested=row.basis==='operator_attestation'&&row.finality==='operator_attested',estimate=attested?null:replayEstimate(row,true),view=reconciliationView(attested,row.expected,row.confirmed_count,row.difference,row.phase,estimate);
 return `<article class="pass-card"><p class="eyebrow">${esc(row.direction)} · ${esc(row.unit==='carton'?'box/carton':row.unit)}</p><h3>${esc(row.gatepass)}</h3><p>${esc(row.material)}</p><span class="pill ${view.tone}">${esc(view.status)}</span><dl><div><dt>Expected</dt><dd>${esc(Number.isSafeInteger(row.expected)?row.expected:'Unknown')}</dd></div><div><dt>${estimate?'Estimated count':'Confirmed'}</dt><dd>${esc(estimate?estimate.count:attested&&Number.isSafeInteger(row.confirmed_count)&&row.confirmed_count>=0?row.confirmed_count:'Not confirmed')}</dd></div><div><dt>${view.estimated?'Estimated difference':'Difference'}</dt><dd class="difference-${view.tone}">${esc(view.difference)}</dd></div></dl><p>${attested?'Operator attestation; not model accuracy certification.':estimate?'Replay estimate against the reviewed pass; not confirmed inventory. Model not approved.':'Prediction record; count remains unconfirmed. Missing or incomplete evidence stays Unknown.'}</p></article>`;
 }
 const e=confirmation?.evidence,s=e?.report_snapshot||row,confirmed=!!e;
 const stamp=confirmation?.created_at||s.ended_at||s.started_at;
 const date=stamp&&Number.isFinite(Date.parse(stamp))?new Date(stamp).toLocaleString('en-IN'):'Time not recorded';
 const expected=Number.isSafeInteger(s.expected)?s.expected:'Unknown',observed=confirmed?e.counted:null;
 const estimate=confirmed?null:replayEstimate(s),view=reconciliationView(confirmed,s.expected,observed,e?.difference,s.phase,estimate);
 return `<article class="pass-card"><div class="pass-card-head"><p class="eyebrow">${esc(s.direction||'Direction unassigned')} · ${esc(s.unit==='carton'?'box/carton':s.unit||'unit unassigned')}</p><span class="pill ${view.tone}">${esc(view.status)}</span></div>${confirmed?'<small class=confirmation-basis>Operator-confirmed</small>':`<small class=confirmation-basis>${estimate?'Replay estimate · model not approved':s.prediction_source?'Tracker prediction replay':'Replay record · unverified'}</small>`}<h3>${esc(s.gatepass||'Pass not assigned')}</h3><p>${esc(s.material||'Material not recorded')}</p><dl><div><dt>Expected</dt><dd>${esc(expected)}</dd></div><div><dt>${confirmed?'Final count':estimate?'Estimated count':'Verified count'}</dt><dd>${confirmed?esc(observed):estimate?esc(estimate.count):'Not confirmed'}</dd></div><div><dt>${view.estimated?'Estimated difference':'Difference'}</dt><dd class="difference-${view.tone}">${esc(view.difference)}</dd></div></dl><p>${estimate?'Replay estimate against the reviewed pass; not confirmed inventory. Each unit is one physical item.':!confirmed?'Missing or incomplete evidence stays Unknown.':''}</p><details><summary>View details</summary><p>${esc(date)}</p><p>Carrier: ${esc(s.carrier||'Not recorded')}</p>${confirmed?`<p>Confirmed by ${esc(e.reviewer)}. ${esc(e.note)}</p><p>Operator attestation; not model accuracy certification.</p>`:`<p>${s.prediction_source?'Predicted':'Recorded replay'} incoming: ${esc(s.incoming??'Unknown')} · outgoing: ${esc(s.outgoing??'Unknown')}. Predictions are not verified inventory.</p>`}<button class="text-button" data-open-tool="${confirmed?'notifications':'reports'}">Open evidence tools →</button></details></article>`;
}
function documentCard(d){return `<article class="pass-card"><p class="eyebrow">Saved document</p><h3>${esc(d.number||'Needs pass number')}</h3><p>${esc(d.direction||'Direction not reviewed')} · ${esc(d.date_raw||'Date not reviewed')}</p><p>${esc((d.lines||[]).map(l=>`${l.quantity} ${l.unit} · ${l.material}`).join(' / ')||'No quantity reviewed')}</p><span class="pill ${d.status==='reviewed'?'matched':'review'}">${d.status==='reviewed'?'Document reviewed':'Fields need review'}</span><button class="text-button" data-document-open="${esc(d.id)}">Review photograph →</button></article>`;}
function renderCards(){
 const current=sessions.filter(s=>s.phase==='in_progress');
 el('current-cards').innerHTML=current.map(s=>reportCard(s)).join('')||empty('No active counting passes in the loaded records.','Upload and review a gate pass below. A document upload does not start or verify a camera count.');
 if(role==='worker')el('current-cards').innerHTML=[...docs].reverse().slice(0,6).map(documentCard).join('')||empty('Your gate-pass desk is ready.','Save a photograph below, then check the written fields.');
 const q=el('customer-search').value.trim().toLowerCase(),filter=el('customer-history-filter').value;
 const confirmedIds=new Set(finals.map(f=>f.evidence.session_id));
 let items=[...finals.map(f=>({row:f.evidence.report_snapshot,confirmation:f})),...sessions.filter(s=>s.phase==='completed'&&!confirmedIds.has(s.id)).map(row=>({row}))];
 items=items.filter(x=>(filter==='all'||(filter==='confirmed')===(mobile?x.row.basis==='operator_attestation':!!x.confirmation))&&[x.row.gatepass,x.row.material,x.row.carrier].join(' ').toLowerCase().includes(q));
 el('history-cards').innerHTML=role==='worker'?([...docs].reverse().filter(d=>[d.number,d.carrier,d.direction,...(d.lines||[]).map(l=>l.material)].join(' ').toLowerCase().includes(q)).map(documentCard).join('')||empty('No saved gate passes in this view.','Upload a photograph from Current Passes, or change your search.')):items.map(x=>reportCard(x.row,x.confirmation)).join('')||empty('No reports in this view.','Final confirmations appear after an operator reviews and confirms a closed movement.');
 el('history-prev').disabled=loading||offset===0||(role==='worker'&&!mobile);el('history-next').disabled=loading||offset+(mobile?100:200)>=total||(role==='worker'&&!mobile);
}
document.addEventListener('gate-remote-unavailable',event=>{if(!mobile)return;dataGeneration++;loading=false;sessions=[];finals=[];docs=[];total=0;renderCards();if(event.detail?.authenticationLost){account={enabled:true,authenticated:false,remote:true};applyRole();authForm();navigate('account');}});
async function refreshHealth(){
 if(mobile){el('customer-health').textContent='Camera monitoring status unavailable on this connection.';return;}
 try{const h=await request('/api/notifications/health-summary');el('customer-health').textContent=h.monitor_state!=='available'?'Camera monitoring status unavailable.':h.incidents?.length?h.incidents.map(i=>i.message).join(' · '):'No active camera alerts reported. This does not verify a live feed or counting accuracy.';el('customer-health').parentElement.classList.toggle('has-alert',h.monitor_state==='available'&&!!h.incidents?.length);}
 catch{el('customer-health').textContent='Camera monitoring status unavailable.';}
}
async function refreshData(){
 if(loading||!canOperate()||account?.offline_capture===true)return;const generation=++dataGeneration;loading=true;el('current-status').textContent='Loading local records…';el('history-status').textContent='Loading local records…';
 try{
  if(mobile&&role==='owner'){const r=await mobile.client.reports(offset);if(generation!==dataGeneration)return;sessions=r.reports;total=r.total;finals=[];}
  else if(mobile){const r=await mobile.client.documents(offset);if(generation!==dataGeneration)return;docs=r.documents;sessions=[];finals=[];total=r.total;}
  else if(role==='worker'){const received=await request('/api/documents');if(generation!==dataGeneration)return;docs=received;sessions=[];finals=[];total=0;}
  else{const [r,c]=await Promise.all([request(`/api/replay-sessions?limit=200&offset=${offset}`),request('/api/notifications/confirmations')]);if(generation!==dataGeneration)return;GateDeskTrackerReports.page(r,offset,200);sessions=r.sessions.filter(s=>s&&s.mode!=='demonstration');total=r.total;finals=c.rows.filter(f=>f.evidence?.kind==='reconciliation'&&f.evidence.basis==='operator_attestation');}
  el('current-status').textContent=role==='worker'?`${Math.min(docs.length,6)} saved gate passes from the loaded page. Browse History for more.`:`${sessions.filter(s=>s.phase==='in_progress').length} in-progress reports on loaded page · ${total} saved records overall.`;
  el('history-status').textContent=role==='worker'?`${docs.length} saved gate passes${mobile?' on this page of '+total+' records':''}. Document review does not confirm camera counts.`:`Saved report page ${Math.floor(offset/(mobile?100:200))+1} · ${mobile?'projected evidence records.':'latest 100 confirmation records checked.'}`;
 el('connection-state').textContent=mobile?'Connected to factory account':'Connected to this PC';document.body.classList.toggle('has-active-passes',sessions.some(s=>s.phase==='in_progress'));
 }catch(e){if(generation!==dataGeneration)return;if(mobile){sessions=[];finals=[];docs=[];total=0;clearDocumentEditor();}el('connection-state').textContent='Local status unavailable';el('current-status').textContent=e.message+' Previously loaded records may be stale.';el('history-status').textContent=el('current-status').textContent;}
 finally{if(generation===dataGeneration){loading=false;renderCards();}}if(generation===dataGeneration)refreshHealth();
}
function applyRole(){
 el('camera-setup').hidden=!cameraAllowed();if(!cameraAllowed())cameraUnavailable();cameraControls();
 if(mobile){document.querySelector('.top-status').textContent='Factory connection';document.querySelector('#customer-upload>p').textContent='Save the original on this phone first, then use Sync pending passes when the factory PC is reachable. A pass stays pending until the PC confirms receipt.';el('customer-upload').querySelector('button[type=submit]').textContent='Save photograph on this phone';window.GateDeskPhonePasses?.setAccount(account);}
 role=account?.enabled?account.user?.role||'worker':role;
 document.body.dataset.role=role;el('history-page').querySelector('h1').textContent=role==='worker'?'Your saved gate passes':'History';el('history-page').querySelector('.subtitle').textContent=role==='worker'?'Find a photograph and check its saved fields.':'Final confirmations and closed reports, with their evidence status intact.';el('customer-history-filter').closest('label').hidden=role==='worker';document.querySelector('.history-pagination').hidden=role==='worker'&&!mobile;el('history-scope-note').textContent=role==='worker'?(mobile?'Search covers the loaded document page. Use Previous and Next for more records.':'All saved document records on this PC. Reviewing a document does not approve a movement count.'):(mobile?'Search covers the loaded projected report page. Different material units remain separate.':'Search covers the loaded report page and latest 100 confirmations. Different material units remain separate.');el('desk-role').textContent=account?.enabled?(account.authenticated?'Signed in · '+role:'Sign in required'):'Preview · '+role;
 el('customer-account').querySelector('h2').textContent=account?.enabled?(account.authenticated?'Your factory account':'Sign in to your factory'):'Your working view';
 el('account-page').querySelector('.subtitle').textContent=account?.enabled?'Manage your local factory account and check what is available.':'Choose your working view and check what is available.';
 if(account?.enabled&&!account.authenticated)el('connection-state').textContent='Sign in required';
 el('role-intro').textContent=role==='owner'?'Keep final reports close. Follow the evidence behind every count.':'Keep the gate moving. Save the pass, then check the written quantities.';
 el('advanced-tools').hidden=!!mobile||role==='worker';el('counting-tool').hidden=!!mobile||role==='worker';document.querySelector('.stage-actions [data-page=history]').hidden=role==='worker';document.querySelector('.inline-health [data-open-tool=counting]').hidden=role==='worker';
 el('account-mode').textContent=account?.enabled?(account.authenticated?`${account.user.display_name||'Factory account'} · ${account.user.role} · ${account.factory.name||account.factory.id}`:'Sign in to your factory workspace.'):'Local preview preference only. This is not authentication and does not restrict access.';
 document.querySelector('#customer-account>.role-buttons').hidden=account?.enabled!==false;
 if(account?.offline_capture===true){el('desk-role').textContent='Offline - local capture only';el('connection-state').textContent='Offline - saved on this phone';el('account-mode').textContent='Previously enrolled account. Server access is not verified. Sync requires current factory sign-in.';}
 document.querySelectorAll('[data-role]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.role===role)));
}
function chooseRole(value){if(account?.enabled!==false)return;role=value;dataGeneration++;loading=false;sessions=[];finals=[];docs=[];renderCards();try{localStorage.setItem('gate-desk-view',role);}catch{}el('role-dialog').close();applyRole();navigate(role==='owner'?'history':'current');}
function authForm(){
 const target=el('account-auth');target.replaceChildren();if(!account?.enabled)return;
 if(account.authenticated){target.innerHTML='<button class="button secondary" id="account-logout">Sign out</button><p class="small-note">'+(mobile?'Connected factory account. Owners can invite workers here; existing worker access is managed on the factory PC.':'Local factory account. Check Phone connection setup for the phone-service status of this runtime.')+'</p>';
 el('account-logout').onclick=async()=>{cameraUnavailable();try{await post('/api/account/logout',{});location.reload();}catch(e){toast(e.message);}};
 if(!mobile&&account.user.role==='owner'){target.insertAdjacentHTML('beforeend','<details class="customer-panel"><summary>Worker accounts</summary><form id="worker-create" class="panel-body"><label>Username<input name="username" required autocomplete="off"></label><label>Display name<input name="display_name" required></label><label>Initial password<input type="password" name="password" required minlength="12" autocomplete="new-password"></label><button class="button primary">Create worker</button><p id="worker-feedback" role="status"></p></form><div id="worker-list"></div></details>');el('worker-create').onsubmit=async e=>{e.preventDefault();try{await post('/api/account/workers',Object.fromEntries(new FormData(e.target)));e.target.reset();el('worker-feedback').textContent='Worker account created.';loadWorkers();}catch(err){el('worker-feedback').textContent=err.message;}};loadWorkers();}
 }else{const bootstrap=account.bootstrap_required;target.innerHTML=`<form id="account-login"><h2>${bootstrap?'Set up this factory':account.owner_only?'Owner sign in':'Sign in'}</h2>${bootstrap?'<label>Factory name<input name="factory_name" required></label><label>Your name<input name="display_name" required></label>':''}<label>Sign-in ID<input name="username" autocomplete="username" required></label><label>Password<input type="password" name="password" autocomplete="${bootstrap?'new-password':'current-password'}" required ${bootstrap?'minlength="12"':''}></label><button class="button primary">${bootstrap?'Create owner account':'Sign in'}</button><p id="login-feedback" role="status"></p></form>`;
 el('account-login').onsubmit=async e=>{e.preventDefault();const button=e.target.querySelector('button');button.disabled=true;try{account=await post('/api/account/'+(bootstrap?'bootstrap':'login'),Object.fromEntries(new FormData(e.target)));applyRole();authForm();navigate(account.user.role==='owner'?'history':'current');}catch(err){el('login-feedback').textContent=err.message;}finally{button.disabled=false;}};}
 if(mobile&&account.offline_capture===true){const button=document.createElement('button');button.type='button';button.className='button secondary';button.textContent='Lock local capture on this phone';button.onclick=()=>{try{mobile.client.lockLocal();}catch(error){toast(error.message);}};target.prepend(button);}
 window.GateDeskInvitations?.render(account);
 window.GateDeskPhoneEntry?.render(account);
 window.GateDeskPhoneSetup?.render(account);
 window.GateDeskPhoneLoadingReview?.render(account);
}
async function loadWorkers(){try{const d=await request('/api/account/workers');el('worker-list').innerHTML=d.users.map(u=>`<div class="worker-row"><span>${esc(u.display_name)} · ${esc(u.username)}</span><button class="button secondary" data-revoke-worker="${esc(u.id)}">Revoke access</button></div>`).join('')||'<p>No worker accounts yet.</p>';}catch(e){el('worker-list').textContent=e.message;}}
document.addEventListener('click',async e=>{const tool=e.target.closest('[data-open-tool]'),r=e.target.closest('button[data-role]'),d=e.target.closest('[data-document-open]'),revoke=e.target.closest('[data-revoke-worker]');if(tool)openTool(tool.dataset.openTool);if(r)chooseRole(r.dataset.role);if(d){selectedDocumentId=d.dataset.documentOpen;openTool('documents');}if(revoke){try{await post('/api/account/workers/'+encodeURIComponent(revoke.dataset.revokeWorker)+'/revoke',{});loadWorkers();}catch(err){toast(err.message);}}});
for(const name of tools)el(name+'-tool').addEventListener('toggle',()=>{if(el(name+'-tool').open&&el(name+'-page').hidden&&!el(name+'-tool').closest('.page').hidden)openTool(name);else if(!el(name+'-tool').open)el(name+'-page').hidden=true;});
el('customer-refresh').onclick=refreshData;el('history-refresh').onclick=refreshData;el('customer-search').oninput=renderCards;el('customer-history-filter').onchange=renderCards;el('history-prev').onclick=()=>{offset=Math.max(0,offset-(mobile?100:200));refreshData();};el('history-next').onclick=()=>{offset+=(mobile?100:200);refreshData();};
el('customer-upload').onsubmit=async e=>{e.preventDefault();const file=el('pass-image').files[0],button=e.target.querySelector('button');if(!file)return;if(mobile){if(!window.GateDeskPhonePasses){el('upload-feedback').textContent='Phone saving is unavailable. Reload before proceeding.';return;}el('upload-feedback').textContent='Saving on this phone…';try{const result=await window.GateDeskPhonePasses.save(file);if(!result.accountChanged){el('upload-feedback').textContent='Saved on this phone — awaiting sync. The factory PC has not received this pass.';e.target.reset();}}catch(error){el('upload-feedback').textContent=error.message;}return;}if(file.size>10*1024*1024){el('upload-feedback').textContent='Choose an image smaller than 10 MB.';return;}button.disabled=true;el('upload-feedback').textContent='Saving on this PC…';try{const form=new FormData();form.append('file',file);const data=await request('/api/documents/import-image',{method:'POST',body:form});selectedDocumentId=data.document.id;el('upload-feedback').textContent=data.idempotent_retry?'This photograph was already saved. Existing review is preserved.':'Photograph saved locally. Enter its fields and at least one physical count line, then review.';e.target.reset();await loadDocuments();await refreshData();}catch(err){el('upload-feedback').textContent=err.message;}finally{button.disabled=false;}};
window.addEventListener('keydown',e=>{if(e.key==='Escape'&&canOperate()&&!isWorker()&&el('counting-tool').open&&!el('current-page').hidden){el('count-pause').click();el('count-video').pause();}});
window.GateDeskCustomerUI={navigate,openTool,refreshData,reportCard};
el('camera-refresh').onclick=()=>cameraAction('load');
el('camera-provision').onclick=()=>cameraAction('provision');
el('camera-form').onsubmit=event=>{event.preventDefault();cameraAction('save');};
el('camera-setup').addEventListener('toggle',()=>{if(el('camera-setup').open&&!cameraState)cameraAction('load');if(!el('camera-setup').open)clearCameraCredentials();});
window.addEventListener('pagehide',cameraUnavailable);
(async()=>{try{account=await request('/api/account');}catch{account=null;el('account-mode').textContent='Account status unavailable. Reload the app before proceeding.';el('connection-state').textContent='Account status unavailable';}
 if(account?.enabled===false){try{const saved=localStorage.getItem('gate-desk-view');if(['owner','worker'].includes(saved))role=saved;else el('role-dialog').showModal();}catch{el('role-dialog').showModal();}}
 ready=true;if(account){applyRole();authForm();}navigate(window.gateDeskPendingPage||location.hash.slice(1)||(role==='owner'?'history':'current'));})();
})();
