/* Explicit remote API adapter. Not loaded by the shipped local page yet. */
(function (root) {
'use strict';
function createRemoteClient(fetcher, onUnavailable = () => {}, timers = {setTimeout:(fn,ms)=>setTimeout(fn,ms),clearTimeout:id=>clearTimeout(id)}, enrollment = null) {
 let csrf = null,authGeneration=0,authIdentity=null;
 const enrollmentKey='gate-desk-offline-capture-v1';
 const validScope=b=>b&&b.version===1&&['factoryId','userId'].every(k=>typeof b[k]==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(b[k]));
 let offlineBlocked=false;
 function storageFailure(){csrf=null;authIdentity=null;authGeneration++;onUnavailable({authenticationLost:true});return Error('Local account lock could not be persisted. Do not share this device. Preserve or sync pending originals before resetting site data; resetting removes saved originals.');}
 function forget(){offlineBlocked=true;try{enrollment?.removeItem(enrollmentKey);if(enrollment?.getItem(enrollmentKey))throw Error('Scope remains');}catch{throw storageFailure();}}
 function remember(data){
  const b={version:1,factoryId:data.factory_id,userId:data.user_id};
  if(!validScope(b)){forget();return;}
  try{const encoded=JSON.stringify(b);enrollment?.setItem(enrollmentKey,encoded);if(enrollment&&enrollment.getItem(enrollmentKey)!==encoded)throw Error('Scope not saved');offlineBlocked=false;}catch{offlineBlocked=true;try{forget();}catch(error){throw error;}csrf=null;authIdentity=null;authGeneration++;onUnavailable({authenticationLost:true});throw Error('Offline capture enrollment could not be saved. Sign in again when phone storage is available.');}
 }
 function restore(){
  if(offlineBlocked)return null;
  try{const b=JSON.parse(enrollment?.getItem(enrollmentKey)||'null');if(validScope(b))return {enabled:true,authenticated:false,remote:true,offline_capture:true,user:{id:b.userId,role:'worker'},factory:{id:b.factoryId},can_manage_workers:false};}catch{}
  return null;
 }
 const stale=()=>Object.assign(Error('Account changed while this request was pending.'),{staleAuthentication:true});
 function updateAuth(next,identity,context){
  if(next!==csrf||identity!==authIdentity){csrf=next;authIdentity=identity;authGeneration++;}
  context.generation=authGeneration;
 }
 async function requestUnchecked(path, options = {}, context) {
  if (typeof path !== 'string' || !/^\/api\/(?:account(?:\/login|\/logout|\/worker-invitations(?:\/redeem|\/[A-Za-z0-9-]{1,80}\/revoke)?)?|mobile\/reports(?:\/[A-Za-z0-9_.:-]+)?(?:\?limit=100&offset=\d+)?|documents(?:\/import-image|\/submit|\/[A-Za-z0-9_-]+\/review|\?offset=\d+|\?selected=[A-Za-z0-9_-]+)?)$/.test(path)) throw Error('Unsupported remote request.');
  const method = options.method || 'GET';
  if (!['GET', 'POST'].includes(method)) throw Error('Unsupported remote method.');
  const headers = {};
  if (method === 'POST') {
   if (!csrf) throw Error('Sign in again before continuing.');
   headers['X-Gate-Desk-CSRF'] = csrf;
  }
  if (options.json !== undefined) headers['Content-Type'] = 'application/json';
  if (options.submission) {
   headers['X-Gate-Submission-Id']=options.submission.id;
   headers['X-Gate-Original-SHA256']=options.submission.digest;
   headers['X-Gate-Saved-At']=options.submission.createdAt;
  }
  // No caller headers, role, Origin spoofing, foreign URL, token persistence or automatic POST retry.
  let response;try {response = await fetcher(path, {method, credentials: 'same-origin', cache: 'no-store',
   headers, signal:options.signal, body: options.json !== undefined ? JSON.stringify(options.json) : options.form});}catch(error){if(context.generation!==authGeneration)throw stale();throw Object.assign(Error(error.message||'Factory connection unavailable.'),{transportUnavailable:true,cause:error});}
  const data = await response.json();
  if(context.generation!==authGeneration||options.signal?.aborted)throw stale();
  if (!response.ok) {
   if ([401,403].includes(response.status)) {forget();updateAuth(null,null,context);}
   const error = Error(typeof data.detail === 'string' ? data.detail : 'Request failed.'); error.status=response.status; throw error;
  }
  if (['/api/account','/api/account/login','/api/account/logout'].includes(path)) {
   const next=typeof data.csrf==='string'&&/^[A-Za-z0-9_-]{43}$/.test(data.csrf)?data.csrf:null;
   updateAuth(next,JSON.stringify([data.authenticated===true,data.factory_id??null,data.user_id??null,data.role??null]),context);
  }
  return data;
 }
 async function request(path, options, context={generation:authGeneration}) {
  try { return await requestUnchecked(path, options, context); }
  catch (error) { if(context.generation===authGeneration&&!error.staleAuthentication)onUnavailable({authenticationLost:[401,403].includes(error.status)}); throw error; }
 }
 async function account() {
  const context={generation:authGeneration};let data;try{data=await request('/api/account',undefined,context);}catch(error){if(error.transportUnavailable&&context.generation===authGeneration){const cached=restore();if(cached)return cached;}throw error;}
  if(context.generation!==authGeneration)throw stale();
  if (data.authenticated !== true) { forget();onUnavailable({authenticationLost:true}); return {enabled: true, authenticated: false, bootstrap_required: false, remote: true}; }
  if (!['worker','owner'].includes(data.role) || typeof data.factory_id !== 'string') throw Error('Invalid account response.');
  remember(data);
  return {enabled: true, authenticated: true, remote: true,
   user: {id: data.user_id, role: data.role}, factory: {id: data.factory_id}, can_manage_workers: false};
 }
 return Object.freeze({account,
  lockLocal(){const context={generation:++authGeneration};updateAuth(null,null,context);forget();onUnavailable({authenticationLost:true});return {localLocked:true,serverLogoutConfirmed:false};},
  invitations: () => request('/api/account/worker-invitations'),
  invite: () => request('/api/account/worker-invitations',{method:'POST',json:{}}),
  redeemInvitation: values => request('/api/account/worker-invitations/redeem',{method:'POST',json:values}),
  revokeInvitation: id => {if(!/^[A-Za-z0-9-]{1,80}$/.test(id))throw Error('Invalid invitation.');return request('/api/account/worker-invitations/'+id+'/revoke',{method:'POST',json:{}});},
  async login(values) {
   forget();const context={generation:++authGeneration};
   await request('/api/account/login', {method:'POST', json:values},context);
   if(context.generation!==authGeneration)throw stale();
   return account();
  },
  async logout() {
   forget();const context={generation:++authGeneration};
   try { return await request('/api/account/logout', {method:'POST',json:{}},context); }
   finally { if(context.generation===authGeneration){updateAuth(null,null,context);onUnavailable({authenticationLost:true});} }
  },
  async reports(offset=0) {
   if (!Number.isInteger(offset) || offset<0 || offset>10000) throw Error('Invalid page.');
   const page = await request('/api/mobile/reports?limit=100&offset='+offset);
   if (!Array.isArray(page.reports) || !Number.isSafeInteger(page.total) || page.total<0) throw Error('Invalid report response.');
   // Keep projected evidence fields; never fabricate legacy confirmation rows.
   return page;
  },
  documents: (offset=0,selected=null) => {
   if(selected!==null){if(!/^[A-Za-z0-9_-]{1,128}$/.test(selected))throw Error('Invalid document.');return request('/api/documents?selected='+selected);}
   if(!Number.isInteger(offset)||offset<0||offset>10000)throw Error('Invalid page.');
   return request('/api/documents?offset='+offset);
  },
  upload: form => request('/api/documents/import-image', {method:'POST',form}),
  submit: row => {
   if (!row || typeof row.id!=='string' || !/^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/.test(row.id)
       || typeof row.digest!=='string' || !/^[a-f0-9]{64}$/.test(row.digest)
       || typeof row.createdAt!=='string' || !Number.isFinite(Date.parse(row.createdAt))
       || new Date(row.createdAt).toISOString()!==row.createdAt
       || !(row.original instanceof Blob) || !['image/png','image/jpeg','image/webp'].includes(row.original.type)
       || row.original.size===0 || row.original.size>10*1024*1024
       || !['factoryId','userId'].every(k=>typeof row[k]==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(row[k]))) throw Error('Invalid saved submission.');
   const identity=authIdentity?JSON.parse(authIdentity):null;
   if(!identity||identity[0]!==true||identity[1]!==row.factoryId||identity[2]!==row.userId)throw Error('Current factory sign-in does not match this saved pass.');
   const form=new FormData();
   form.append('file',row.original,'gate-pass.'+({ 'image/png':'png','image/jpeg':'jpg','image/webp':'webp' }[row.original.type]));
   const controller=new AbortController();let timer;
   const deadline=new Promise((resolve,reject)=>{timer=timers.setTimeout(()=>{controller.abort();reject(Error('Sync timed out. Original remains on this phone; retry explicitly.'));},30000);});
   // Covers response-body parsing as well as fetch. A late result cannot become
   // a receipt after the caller has observed timeout. No automatic POST retry.
   return Promise.race([request('/api/documents/submit',{method:'POST',form,signal:controller.signal,submission:{id:row.id,digest:row.digest,createdAt:row.createdAt}}),deadline]).finally(()=>timers.clearTimeout(timer));
  },
  review: (id, values) => {
   if (!/^[A-Za-z0-9_-]{1,128}$/.test(id)) throw Error('Invalid document.');
   return request('/api/documents/'+id+'/review',{method:'POST',json:values});
  }
 });
}
if (typeof module !== 'undefined' && module.exports) module.exports = {createRemoteClient};
else root.GateDeskRemoteClient = {createRemoteClient};
})(typeof window === 'undefined' ? globalThis : window);
