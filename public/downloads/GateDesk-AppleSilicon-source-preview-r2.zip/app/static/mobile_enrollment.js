/* Phone entry and local QR reading. No images/tokens are uploaded or persisted. */
(() => {
 'use strict';
 let dispose = () => {}, pending=false, updateControls=()=>{};
 function invitation(value) {
  if(typeof value!=='string'||value.length>2048)throw Error('Use an invitation from this factory.');
  if(/^[A-Za-z0-9_-]{43}$/.test(value))return value;
  let url;try{url=new URL(value);}catch{throw Error('Use an invitation from this factory.');}
  const match=/^#join=([A-Za-z0-9_-]{43})$/.exec(url.hash);
  if(url.protocol!=='https:'||url.origin!==location.origin||url.pathname!=='/'||url.search||url.username||url.password||!match)throw Error('Use an invitation from this factory.');
  return match[1];
 }
 function render(account) {
  dispose();dispose=()=>{};updateControls=()=>{};
  if(!window.GateDeskMobile||account?.authenticated||!account?.enabled)return;
  const target=document.getElementById('account-auth'),login=document.getElementById('account-login'),form=document.getElementById('worker-invite-join');
  if(!target||!login||!form)return;
  const worker=form.closest('details');
  const choices=document.createElement('div');choices.id='phone-entry';
  choices.innerHTML='<button type="button" class="button primary" data-entry="owner">Owner: log in with ID and password</button> <button type="button" class="button secondary" data-entry="worker">Worker: scan or upload a code</button>';
  target.prepend(choices);
  const reader=document.createElement('div');
  reader.innerHTML='<button type="button" class="button secondary" data-scan>Scan QR code</button> <label>Upload code image<input type="file" accept="image/png,image/jpeg,image/webp" data-code-image></label><button type="button" class="button secondary" data-cancel hidden>Stop scanning</button><video playsinline muted hidden style="max-width:100%;width:320px"></video><p role="status" data-reader-status></p><button type="button" class="button secondary" data-existing>Already enrolled? Sign in</button>';
  worker.insertBefore(reader,form);
  const video=reader.querySelector('video'),status=reader.querySelector('[data-reader-status]'),scan=reader.querySelector('[data-scan]'),upload=reader.querySelector('[data-code-image]'),cancel=reader.querySelector('[data-cancel]');
  let generation=0,stream=null,expiry=null,alive=true,activeBitmap=null,activeDetector=null;
  const closedBitmaps=new WeakSet();
  function closeBitmap(bitmap){if(bitmap&&!closedBitmaps.has(bitmap)){closedBitmaps.add(bitmap);bitmap.close();}}
  function controls(){scan.disabled=pending;upload.disabled=pending;}
  updateControls=controls;
  const release=s=>s?.getTracks().forEach(t=>t.stop());
  function stop(){generation++;clearTimeout(expiry);activeDetector?.close?.();activeDetector=null;release(stream);stream=null;closeBitmap(activeBitmap);activeBitmap=null;video.srcObject=null;video.hidden=true;cancel.hidden=true;controls();}
  function select(mode){stop();login.hidden=mode==='worker';worker.hidden=mode!=='worker';worker.open=mode==='worker';login.querySelector('h2').textContent=mode==='owner'?'Owner sign in':'Sign in';}
  choices.querySelector('[data-entry=owner]').onclick=()=>select('owner');
  choices.querySelector('[data-entry=worker]').onclick=()=>select('worker');
  reader.querySelector('[data-existing]').onclick=()=>{select('login');worker.hidden=true;};
  cancel.onclick=()=>{stop();status.textContent='Scanning stopped.';};
  async function detector(){
   if(window.isSecureContext){
    try{if(window.BarcodeDetector&&(await window.BarcodeDetector.getSupportedFormats()).includes('qr_code'))return new window.BarcodeDetector({formats:['qr_code']});}catch{}
    if(window.GateDeskQRDecoder&&window.Worker)return window.GateDeskQRDecoder.create();
   }
   throw Error('QR reading is unavailable here. Enter the invitation code below or open its trusted factory link.');
  }
  function accept(results){
   if(results.length!==1)throw Error('Show exactly one factory invitation QR code.');
   const value=invitation(results[0].rawValue);form.elements.token.value=value;stop();status.textContent='Code read. Complete your details below. Access is checked by the factory when you submit.';
  }
  scan.onclick=async()=>{
   if(pending)return;stop();pending=true;controls();form.elements.token.value='';const ticket=generation;cancel.hidden=false;status.textContent='Allow camera access to scan. Scanning stops after 30 seconds.';
   expiry=setTimeout(()=>{stop();status.textContent='Scan stopped after 30 seconds. Wait for the reader to finish before retrying.';},30000);
   try{
    const readerDetector=await detector();if(ticket!==generation){readerDetector.close?.();return;}activeDetector=readerDetector;
    if(!navigator.mediaDevices?.getUserMedia)throw Error('Camera scanning is unavailable. Upload a code image or enter the code.');
    const acquired=await navigator.mediaDevices.getUserMedia({video:{facingMode:'environment',width:{ideal:640},height:{ideal:480}},audio:false});
    if(ticket!==generation){release(acquired);return;}stream=acquired;video.srcObject=stream;video.hidden=false;await video.play();
    while(ticket===generation){
     const values=await readerDetector.detect(video);if(ticket!==generation)return;
     if(values.length){accept(values);return;}
     await new Promise(resolve=>setTimeout(resolve,250));
    }
   }catch(error){if(ticket===generation){stop();status.textContent=error.message==='Permission denied'?'Camera permission was denied. Upload an image or enter the code.':error.name==='NotAllowedError'?'Camera permission was denied. Upload an image or enter the code.':error.message;}}
   finally{pending=false;updateControls();}
  };
  upload.onchange=async()=>{
   if(pending)return;const file=upload.files?.[0];stop();upload.value='';if(!file)return;pending=true;controls();form.elements.token.value='';
   const ticket=generation;let bitmap;cancel.hidden=false;
   expiry=setTimeout(()=>{stop();status.textContent='Image reading stopped. Wait for the reader to finish before retrying.';},15000);
   try{
    if(!['image/png','image/jpeg','image/webp'].includes(file.type)||file.size>10*1024*1024)throw Error('Choose a PNG, JPEG or WebP image smaller than 10 MB.');
    const readerDetector=await detector();if(ticket!==generation){readerDetector.close?.();return;}activeDetector=readerDetector;
    bitmap=await createImageBitmap(file);if(ticket!==generation)return;activeBitmap=bitmap;
    if(bitmap.width>8192||bitmap.height>8192||bitmap.width*bitmap.height>20000000)throw Error('Choose a smaller code image.');
    const results=await readerDetector.detect(bitmap);if(ticket!==generation)return;accept(results);
   }catch(error){if(ticket===generation){stop();status.textContent=error.message;}}
   finally{closeBitmap(bitmap);if(activeBitmap===bitmap)activeBitmap=null;pending=false;updateControls();}
  };
  const leave=()=>{stop();form.elements.token.value='';};
  const hidden=()=>{if(document.hidden)leave();};
  const lost=e=>{if(e.detail?.authenticationLost)leave();};
  form.addEventListener('submit',stop,true);
  window.addEventListener('pagehide',leave);window.addEventListener('hashchange',leave);document.addEventListener('visibilitychange',hidden);document.addEventListener('gate-remote-unavailable',lost);
  dispose=()=>{if(!alive)return;alive=false;leave();choices.remove();reader.remove();form.removeEventListener('submit',stop,true);window.removeEventListener('pagehide',leave);window.removeEventListener('hashchange',leave);document.removeEventListener('visibilitychange',hidden);document.removeEventListener('gate-remote-unavailable',lost);};
  if(form.elements.token.value)select('worker');else{login.hidden=true;worker.hidden=true;}controls();
 }
 window.GateDeskPhoneEntry={render,invitation};
})();
