/* Prediction report rendering and explicit document-selection rules. No inventory approval. */
(function(root){
 'use strict';
 const escape=(value)=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const quantity=value=>Number.isSafeInteger(value)&&value>=0?String(value):'Unknown';
 const isPrediction=row=>!!row&&typeof row.prediction_source==='object'&&row.prediction_source!==null;
 const canAttach=row=>isPrediction(row)&&row.phase==='in_progress'&&!row.document_evidence;
 function candidates(row,documents){
  if(!canAttach(row)||!Array.isArray(documents))return [];
  return documents.flatMap(doc=>doc.status==='reviewed'&&/^[0-9a-f]{64}$/.test(doc.revision_sha256||'')&&doc.number===row.gatepass&&doc.direction===row.direction&&Array.isArray(doc.lines)?doc.lines.filter(line=>line.quantity===row.expected&&line.unit===row.unit).map(line=>({document:doc,line})):[]);
 }
 function page(data,requestedOffset,limit){
  if(!data||!Array.isArray(data.sessions)||!Number.isSafeInteger(data.total)||data.total<0||data.sessions.length>limit||data.offset!==requestedOffset||data.limit!==limit)throw new Error('Prediction report page could not be verified. Refresh to try again.');
  return {rows:data.sessions.filter(isPrediction),total:data.total,offset:requestedOffset,
   previous:requestedOffset>0,next:requestedOffset+limit<data.total,
   first:data.sessions.length?requestedOffset+1:0,last:data.sessions.length?requestedOffset+data.sessions.length:0};
 }
 function table(rows,emptyText='No tracker predictions on this page'){
  if(!rows.length)return `<div class="empty-state"><strong>${escape(emptyText)}</strong><p>Imported prediction reports appear here for review. They do not update verified inventory.</p></div>`;
  return `<div class="table-wrap tracker-report-table"><table><caption class="sr-only">Unvalidated tracker predictions, separated by material class</caption><thead><tr><th>Gate pass</th><th>Material class / unit</th><th>Expected direction</th><th class="number">Expected quantity</th><th class="number">Predicted incoming</th><th class="number">Predicted outgoing</th><th>Review status</th></tr></thead><tbody>${rows.map(row=>`<tr><td class="pass-cell">${escape(row.gatepass)}<small>Tracker prediction</small>${row.prediction_source?.operation_id?`<button type="button" class="button secondary" data-operation-id="${escape(row.prediction_source.operation_id)}">View document coverage</button>`:''}${canAttach(row)?`<button type="button" class="button secondary attach-document" data-session-id="${escape(row.id)}">Attach document line</button>`:''}</td><td>${escape(row.material)}<small class="unit-note">${escape(row.unit||'unit')}</small></td><td>${escape(row.direction)}</td><td class="number">${quantity(row.expected)}<small class="unit-note">${row.expected_provenance==='reviewed_document_line'&&row.document_evidence?'Reviewed document line':'Unverified entry'}</small></td><td class="number">${quantity(row.incoming)}</td><td class="number">${quantity(row.outgoing)}</td><td><span class="pill review">Needs review</span><small class="unit-note">${row.phase==='completed'?'Closed, still unverified':'In progress, still unverified'}</small></td></tr>`).join('')}</tbody></table></div>`;
 }
 function filter(rows,query){
  const search=String(query||'').trim().toLowerCase();
  return rows.filter(row=>[row.gatepass,row.material,row.unit,row.direction].join(' ').toLowerCase().includes(search));
 }
 function reconciliation(data){
  const issues={historical_line_roster_unknown:'The original full line list was not saved. Document coverage is unknown.',inconsistent_frozen_line_rosters:'Saved line lists conflict. Document coverage is unknown.',multiple_document_revisions_in_operation:'Different revisions of this document are attached to this operation. Review them separately.',unbound_document_lines:'Some document lines have no counting evidence.'};
  const documents=data.documents.map(doc=>`<section><h3>${escape(doc.number)} · ${escape(doc.direction)}</h3><p class="small-note">Saved revision ${escape(doc.document_sha256.slice(0,12))} · ${doc.line_roster_known?'Full line list saved':'Full line list unknown'}</p>${doc.issues.map(issue=>`<p class="reconciliation-warning">${escape(issues[issue]||issue)}</p>`).join('')}<div class="table-wrap"><table><thead><tr><th>Document line / unit</th><th>Mapped class</th><th>Expected</th><th>Predicted in</th><th>Predicted out</th><th>Evidence</th></tr></thead><tbody>${doc.lines.map(item=>`<tr><td>${escape(item.line.material)}<small class="unit-note">Line ${escape(item.line.id)} · ${escape(item.line.unit)}</small></td><td>${escape(item.material_class||'Unassigned')}</td><td>${quantity(item.line.quantity)}</td><td>${quantity(item.predicted_incoming)}</td><td>${quantity(item.predicted_outgoing)}</td><td>${item.binding_status==='attached'?'Attached · counts need review':'No counting evidence'}</td></tr>`).join('')}</tbody></table></div></section>`).join('');
  const unbound=data.unbound_class_reports;
  return `<p class="small-note">Only attached documents are listed. Missing evidence stays unknown. These predictions do not establish a verified quantity or a shortage.</p>${documents||'<p>No reviewed document is attached to this operation.</p>'}${unbound.length?`<h3>Class reports without a document line</h3><ul>${unbound.map(row=>`<li>${escape(row.material)} · ${escape(row.unit)} · ${escape(row.direction)} — expected quantity is an unverified entry</li>`).join('')}</ul>`:''}<p><strong>Needs review</strong> · No combined class count or pass approval.</p>`;
 }
 const api={page,table,filter,isPrediction,canAttach,candidates,reconciliation};
 if(typeof module!=='undefined'&&module.exports)module.exports=api;
 else root.GateDeskTrackerReports=api;
})(typeof window!=='undefined'?window:globalThis);
