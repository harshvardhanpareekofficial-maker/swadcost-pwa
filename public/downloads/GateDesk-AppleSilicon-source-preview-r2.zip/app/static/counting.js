/* Local replay presentation. Predictions never mutate confirmed records. */
(function(root){
'use strict';
function validateReplay(data){
 if(data?.schema_version!==1||!/^[a-f0-9]{64}$/.test(data.video_sha256||'')||!Number.isInteger(data.width)||!Number.isInteger(data.height)||data.width<1||data.height<1||data.width>16384||data.height>16384||!['x','y'].includes(data.axis)||!Number.isFinite(data.line)||data.line<=0||data.line>=1||!Number.isFinite(data.fps)||data.fps<=0||data.fps>240||!Array.isArray(data.frames)||data.frames.length>50000)throw Error('Unsupported or incomplete replay evidence.');
 let previous=-1;
 for(const frame of data.frames){
  if(!Number.isFinite(frame.timestamp_seconds)||frame.timestamp_seconds<0||frame.timestamp_seconds<=previous||typeof frame.visibility_ok!=='boolean'||!Array.isArray(frame.tracks)||frame.tracks.length>200)throw Error('Invalid replay timing or visibility.');
  previous=frame.timestamp_seconds;
  const ids=new Set();
  for(const track of frame.tracks){
   const box=track.xyxy;
   if(typeof track.track_id!=='string'||track.track_id.length>80||ids.has(track.track_id)||typeof track.label!=='string'||track.label.length>80||!Array.isArray(box)||box.length!==4||!box.every(Number.isFinite)||box[0]<0||box[1]<0||box[2]>data.width||box[3]>data.height||box[0]>=box[2]||box[1]>=box[3])throw Error('Invalid track geometry.');
   ids.add(track.track_id);
  }
 }
 return data;
}
function frameAt(data,seconds){
 let lo=0,hi=data.frames.length;
 while(lo<hi){const mid=(lo+hi)>>1;if(data.frames[mid].timestamp_seconds<=seconds)lo=mid+1;else hi=mid;}
 const frame=data.frames[lo-1];
 return frame&&seconds-frame.timestamp_seconds<=1.5/data.fps&&frame.visibility_ok?{frame,index:lo-1}:null;
}
function confirmedSummary(rows,sessionId){
 const selected=rows.filter(r=>r.evidence?.session_id===sessionId),ids=new Set();
 let incoming=0,outgoing=0,final=null;
 for(const row of selected){const e=row.evidence;if(e.basis!=='operator_attestation'||ids.has(row.id))continue;ids.add(row.id);
  if(e.kind==='crossing'){if(e.event?.direction==='Incoming')incoming++;if(e.event?.direction==='Outgoing')outgoing++;}
  if(e.kind==='reconciliation'&&Number.isSafeInteger(e.counted)&&e.counted>=0)final=e;
 }
 return {incoming,outgoing,final};
}
const api={validateReplay,frameAt,confirmedSummary};
if(typeof module!=='undefined'&&module.exports){module.exports=api;return;}
root.GateDeskCounting=api;
const $=id=>document.getElementById(id),video=$('count-video'),canvas=$('count-overlay'),ctx=canvas.getContext('2d');
let videoFile=null,url=null,replay=null,videoHash=null,generation=0,sessions=[],confirmations=[],refreshing=false;
const say=text=>{$('count-feedback').textContent=text;};
async function get(path,body){const r=await fetch(path,body?{method:'POST',headers:{'Content-Type':'application/json','X-Gate-Desk':'local'},body:JSON.stringify(body)}:{});const d=await r.json();if(!r.ok)throw Error(typeof d.detail==='string'?d.detail:'Local service unavailable.');return d;}
function resetReplay(){replay=null;ctx.clearRect(0,0,canvas.width,canvas.height);$('count-overlay-status').textContent='No linked tracking evidence';}
$('count-video-file').addEventListener('change',()=>{
 generation++;resetReplay();videoHash=null;videoFile=$('count-video-file').files[0]||null;
 video.pause();video.removeAttribute('src');if(url)URL.revokeObjectURL(url);url=null;
 if(!videoFile){video.load();video.hidden=true;$('count-empty').hidden=false;video.parentElement.classList.remove('has-video');return;}
 url=URL.createObjectURL(videoFile);video.src=url;video.parentElement.classList.add('has-video');$('count-empty').hidden=true;video.hidden=false;
 $('count-source-name').textContent=videoFile.name;say('Local playback only. This file is not linked to the selected report or used for training.');
});
video.addEventListener('error',()=>say('This video cannot play in the browser. The original file is unchanged.'));
$('count-replay-file').addEventListener('change',async()=>{
 const file=$('count-replay-file').files[0],token=++generation;resetReplay();
 try{
  if(!videoFile||!video.videoWidth)throw Error('Open a playable local video first.');
  if(!file||file.size>16*1024**2)throw Error('Replay evidence must be at most 16 MiB.');
  if(videoFile.size>256*1024**2)throw Error('Overlay verification currently supports video files up to 256 MiB. Playback still works.');
  const data=validateReplay(JSON.parse(await file.text()));
  say('Checking that the replay belongs to this exact video…');
  const hash=videoHash||Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',await videoFile.arrayBuffer())),b=>b.toString(16).padStart(2,'0')).join('');
  if(token!==generation)return;
  if(hash!==data.video_sha256||video.videoWidth!==data.width||video.videoHeight!==data.height)throw Error('Video hash or dimensions do not match. Overlays remain off.');
  videoHash=hash;replay=data;canvas.width=data.width;canvas.height=data.height;
  $('count-overlay-status').textContent='Linked replay · predictions need review';say('Video bytes match the replay manifest. Tracking and the counting line remain unvalidated predictions.');draw();
 }catch(e){if(token===generation)say(e.message);}
});
function draw(){
 ctx.clearRect(0,0,canvas.width,canvas.height);if(!replay)return;
 const w=canvas.width,h=canvas.height;ctx.lineWidth=Math.max(2,w/500);ctx.strokeStyle='#67ddd3';ctx.setLineDash([w/80,w/110]);ctx.beginPath();
 if(replay.axis==='x'){ctx.moveTo(w*replay.line,0);ctx.lineTo(w*replay.line,h);}else{ctx.moveTo(0,h*replay.line);ctx.lineTo(w,h*replay.line);}ctx.stroke();ctx.setLineDash([]);
 const item=frameAt(replay,video.currentTime);if(!item)return;
 ctx.font=`${Math.max(13,w/65)}px monospace`;
 for(const track of item.frame.tracks){const [x,y,x2,y2]=track.xyxy;ctx.strokeStyle='#f1bc62';ctx.strokeRect(x,y,x2-x,y2-y);ctx.fillStyle='#172c3e';const label=`${track.label} #${track.track_id}`;const size=ctx.measureText(label).width;ctx.fillRect(x,Math.max(0,y-w/40),size+10,w/40);ctx.fillStyle='#fff';ctx.fillText(label,x+4,Math.max(w/55,y-4));
  ctx.beginPath();let began=false,lastTime=item.frame.timestamp_seconds;
  for(let i=item.index;i>=Math.max(0,item.index-15);i--){const f=replay.frames[i];if(!f.visibility_ok||lastTime-f.timestamp_seconds>1.5/replay.fps)break;const t=f.tracks.find(t=>t.track_id===track.track_id);if(!t)break;const a=(t.xyxy[0]+t.xyxy[2])/2,b=(t.xyxy[1]+t.xyxy[3])/2;if(!began){ctx.moveTo(a,b);began=true;}else ctx.lineTo(a,b);lastTime=f.timestamp_seconds;}ctx.stroke();
 }
}
function animate(){if(!video.paused)draw();requestAnimationFrame(animate);}requestAnimationFrame(animate);
video.addEventListener('seeked',draw);video.addEventListener('timeupdate',draw);
function renderReport(){
 const session=sessions.find(s=>s.id===$('count-session').value),summary=confirmedSummary(confirmations,session?.id);
 $('count-in').textContent=session?summary.incoming:'—';$('count-out').textContent=session?summary.outgoing:'—';
 $('count-expected').textContent=session?.document_bound?session.expected:'Not reviewed';
 $('count-final').textContent=summary.final?summary.final.counted:'Awaiting review';
 const difference=summary.final?.difference;$('count-difference').textContent=Number.isSafeInteger(difference)?`${difference>0?'+':''}${difference}`:'—';
 $('count-difference').dataset.kind=difference===0?'matched':Number.isSafeInteger(difference)?'mismatch':'unknown';
 $('count-unit').textContent=session?`${session.gatepass} · ${session.unit}`:'Choose an evidence-bound report';
 const list=$('count-events');list.replaceChildren();
 for(const row of confirmations.filter(r=>r.evidence?.session_id===session?.id).slice(0,8)){const li=document.createElement('li'),e=row.evidence;li.textContent=e.kind==='crossing'?`${e.event.direction} crossing · reviewed by ${e.reviewer}`:`Final count ${e.counted} · discrepancy ${e.difference>0?'+':''}${e.difference}`;list.append(li);}
 if(!list.children.length){const li=document.createElement('li');li.textContent='No operator confirmations in the loaded records.';list.append(li);}
}
async function refresh(){if(refreshing)return;refreshing=true;
 try{const [rec,options,records]=await Promise.all([get('/api/recorder/status'),get('/api/notifications/review-options'),get('/api/notifications/confirmations')]);
  $('count-recorder').textContent=`Recorder: ${String(rec.state||'unknown').replaceAll('_',' ')} · ${rec.camera_connected?'connection reported':'no verified live feed'}`;
  $('count-resume').disabled=!rec.paused;$('count-pause').disabled=!!rec.paused;
  sessions=options.sessions;confirmations=records.rows;const prior=$('count-session').value;$('count-session').replaceChildren();
  const empty=document.createElement('option');empty.value='';empty.textContent='Select a report';$('count-session').append(empty);
  for(const s of sessions){const o=document.createElement('option');o.value=s.id;o.textContent=`${s.gatepass} · ${s.unit} · ${s.phase}`;$('count-session').append(o);}if(sessions.some(s=>s.id===prior))$('count-session').value=prior;renderReport();
 }catch(e){$('count-recorder').textContent='Local recorder status unavailable';say(e.message);}finally{refreshing=false;}}
$('count-session').addEventListener('change',renderReport);$('count-refresh').addEventListener('click',refresh);
for(const action of ['pause','resume'])$('count-'+action).addEventListener('click',async()=>{try{await get('/api/recorder/'+action,action==='resume'?{direct_user_confirmation:true}:{});say(action==='pause'?'Capture paused. Playback and reports remain available.':'Resume requested. Camera configuration and evidence gates still apply.');await refresh();}catch(e){say(e.message);}});
window.addEventListener('keydown',e=>{if(e.key==='Escape'&&location.hash==='#counting'){$('count-pause').click();video.pause();}});
window.addEventListener('gate-desk-counting',refresh);
window.addEventListener('pagehide',()=>{if(url)URL.revokeObjectURL(url);});
})(typeof window!=='undefined'?window:globalThis);
