/* Owner-PC review associates an existing phone receipt with a camera, never footage truth. */
(() => {
 'use strict';
 const anchor=document.getElementById('documents-tool');if(!anchor)return;
 const section=document.createElement('section');section.id='phone-loading-review';section.className='customer-panel';section.hidden=true;
 section.innerHTML='<h3>Find footage for phone passes</h3><p>Choose the camera and movement direction for a received pass. The first search window uses the phone save time and the following ten minutes. Camera clock, recording coverage and the complete movement still need verification.</p><button type="button" class="button secondary" id="phone-loading-refresh">Refresh received passes</button><p role="status" id="phone-loading-feedback"></p><div id="phone-loading-rows"></div><button type="button" class="button secondary" id="phone-loading-next" hidden>Next received passes</button>';
 anchor.before(section);
 const el=id=>document.getElementById(id), feedback=el('phone-loading-feedback'), rows=el('phone-loading-rows');
 let account=null,epoch=0,busy=false,offset=0,next=null;
 const jobs=new Map();
 const allowed=()=>document.documentElement.dataset.transport!=='remote'&&!window.GateDeskMobile&&account?.enabled===true&&account.authenticated===true&&account.owner_only===true&&account.user?.role==='owner';
 const identifier=value=>typeof value==='string'&&/^[A-Za-z0-9_-]{1,128}$/.test(value);
 const uuid=value=>typeof value==='string'&&/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/.test(value);
 const date=value=>typeof value==='string'&&/\dT.*(?:Z|[+-]\d{2}:\d{2})$/.test(value)&&Number.isFinite(Date.parse(value));
 function controls(){section.querySelectorAll('button,input,select').forEach(node=>node.disabled=!allowed()||busy);el('phone-loading-next').hidden=next===null;}
 function paragraph(parent,text){const item=document.createElement('p');item.textContent=text;parent.append(item);return item;}
 function checkedReview(review){
  const candidate=review?.candidate;
  if(!Number.isSafeInteger(review?.revision)||review.revision<1||!identifier(review.reviewed_by)||!date(review.reviewed_at)
    ||typeof review.camera_id!=='string'||!/^[A-Za-z0-9_.:-]{1,128}$/.test(review.camera_id)||!['incoming','outgoing'].includes(review.direction)
    ||!candidate||candidate.camera_id!==review.camera_id||candidate.direction!==review.direction
    ||candidate.count!==null||candidate.loading_confirmed!==false||candidate.fetch_authorized!==false
    ||candidate.complete_operation!==null||candidate.footage_coverage!=='unknown'||candidate.recorder_window!==null
    ||candidate.status!=='needs_clock_review'||!date(candidate.reference_window?.start)||!date(candidate.reference_window?.end)
    ||Date.parse(candidate.reference_window.end)-Date.parse(candidate.reference_window.start)!==600000)throw Error('invalid_response');
  return review;
 }
 function checkedRow(row){
  if(!uuid(row?.id)||!identifier(row.userId)||!identifier(row.documentId)||!/^[a-f0-9]{64}$/.test(row.digest)
    ||!date(row.savedAt)||!date(row.receivedAt)||!Object.hasOwn(row,'review'))throw Error('invalid_response');
  if(row.review!==null){
   checkedReview(row.review);
   const receipt=row.review.candidate.phone_receipt;
   if(!receipt||receipt.id!==row.id||receipt.userId!==row.userId||receipt.factoryId!==account.factory?.id||receipt.digest!==row.digest
    ||receipt.documentId!==row.documentId||receipt.savedAt!==row.savedAt||receipt.receivedAt!==row.receivedAt
    ||Date.parse(row.review.candidate.reference_window.start)!==Date.parse(row.savedAt))throw Error('invalid_response');
  }
  return row;
 }
 function checkedJob(value,row){
  const job=value?.job, receipt=job?.snapshot?.receipt;
  if(value?.factory_id!==account.factory?.id||value.id!==row.id||!uuid(job?.id)
    ||job.factory_id!==account.factory?.id||job.submission_id!==row.id||job.review_revision!==row.review?.revision
    ||job.state!=='pending'||job.count!==null||job.complete_operation!==null||job.completed_at!==null
    ||job.fetch_authorized!==false||job.footage_coverage!=='unknown'||job.superseded_by!==null
    ||JSON.stringify(job.blocked_reasons)!==JSON.stringify(['source_clock_review_required','recorder_retention_unverified','footage_coverage_unknown','whole_operation_boundaries_unverified','recorder_adapter_not_admitted'])
    ||!receipt||receipt.id!==row.id||receipt.factoryId!==account.factory?.id||receipt.userId!==row.userId
    ||receipt.digest!==row.digest||receipt.documentId!==row.documentId||receipt.savedAt!==row.savedAt||receipt.receivedAt!==row.receivedAt)throw Error('invalid_response');
  checkedRow({...row,review:job.snapshot.review});
  if(job.snapshot.review.revision!==row.review.revision||job.snapshot.review.camera_id!==row.review.camera_id
    ||job.snapshot.review.direction!==row.review.direction)throw Error('invalid_response');
  return job;
 }
 async function request(path,body){
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),15000);
  try{
   const response=await fetch('/api/phone-loading'+path,{method:body===undefined?'GET':'POST',credentials:'same-origin',cache:'no-store',redirect:'error',signal:controller.signal,
    headers:{'X-Gate-Desk':'local','Content-Type':'application/json'},...(body===undefined?{}:{body:JSON.stringify(body)})});
   if(!response.ok){const error=Error('request_failed');error.status=response.status;throw error;}
   return await response.json();
  }finally{clearTimeout(timer);}
 }
 function showRow(row){
  const box=document.createElement('article');box.className='customer-panel';box.dataset.submissionId=row.id;
  paragraph(box,'Received pass '+row.id+' · '+row.documentId);
  paragraph(box,'Saved on phone: '+row.savedAt+' · Received by PC: '+row.receivedAt);
  if(row.review){const c=row.review.candidate;paragraph(box,'Reviewed camera: '+row.review.camera_id+' · '+row.review.direction+' · revision '+row.review.revision);paragraph(box,'Candidate window: '+c.reference_window.start+' to '+c.reference_window.end+'. Count: Unknown. Footage has not been fetched or verified.');}
  else paragraph(box,'No camera association reviewed. Count: Unknown.');
  const form=document.createElement('form');
  const label=document.createElement('label');label.textContent='Camera identifier';
  const camera=document.createElement('input');camera.name='camera_id';camera.required=true;camera.maxLength=128;camera.value=row.review?.camera_id||'';label.append(camera);form.append(label);
  const directionLabel=document.createElement('label');directionLabel.textContent='Movement direction';
  const direction=document.createElement('select');direction.name='direction';direction.required=true;
  for(const [value,text] of [['','Choose direction'],['incoming','Incoming'],['outgoing','Outgoing']]){const option=document.createElement('option');option.value=value;option.textContent=text;direction.append(option);}
  direction.value=row.review?.direction||'';directionLabel.append(direction);form.append(directionLabel);
  const confirmLabel=document.createElement('label');const confirm=document.createElement('input');confirm.type='checkbox';confirm.name='confirmed';confirm.required=true;confirmLabel.append(confirm,document.createTextNode(' I reviewed this pass and selected its camera and direction. This does not confirm the count.'));form.append(confirmLabel);
  const save=document.createElement('button');save.type='submit';save.className='button primary';save.textContent='Save reviewed association';form.append(save);
  form.addEventListener('submit',event=>{event.preventDefault();if(allowed()&&!busy&&form.reportValidity())action('save',row,{expected_revision:row.review?.revision||0,camera_id:camera.value.trim(),direction:direction.value,confirmed:confirm.checked});});
  box.append(form);rows.append(box);
  if(row.review){
   const pending=jobs.get(row.id), current=pending?.review_revision===row.review.revision?pending:null;
   if(current)paragraph(box,'Catch-up job '+current.id+' is pending. Count: Unknown. Waiting for verified camera time, recording retention, footage coverage, whole-operation boundaries and an admitted recorder adapter. No footage has been fetched.');
   else paragraph(box,'Catch-up status has not been loaded here. Queueing this reviewed revision again returns its existing pending job.');
   const queue=document.createElement('button');queue.type='button';queue.className='button secondary';queue.textContent=current?'Check pending catch-up':'Queue pending catch-up';
   queue.addEventListener('click',()=>action('queue',row,{review_revision:row.review.revision}));box.append(queue);
  }
 }
 function showPage(value){
  if(value?.factory_id!==account.factory?.id||!Array.isArray(value.receipts)||value.receipts.length>25
    ||!(value.next_offset===null||(Number.isSafeInteger(value.next_offset)&&value.next_offset===offset+25&&value.next_offset<=10000)))throw Error('invalid_response');
  const checked=value.receipts.map(checkedRow);next=value.next_offset;rows.replaceChildren();checked.forEach(showRow);
  feedback.textContent=checked.length?'Reviewing an association does not start camera access or confirm loading.':'No phone passes received in this page.';
 }
 async function action(kind,row,body){
  if(!allowed()||busy)return;
  const ticket=epoch;busy=true;controls();feedback.textContent=kind==='save'?'Saving reviewed association…':kind==='queue'?'Saving pending catch-up work…':'Loading received passes…';
  try{
   if(kind==='save'){
    const value=await request('/'+row.id+'/review',body);if(ticket!==epoch||!allowed())return;
    if(value?.factory_id!==account.factory?.id||value.id!==row.id)throw Error('invalid_response');
    checkedRow({...row,review:value.review});
   }else if(kind==='queue'){
    const value=await request('/'+row.id+'/catchup',body);if(ticket!==epoch||!allowed())return;
    jobs.set(row.id,checkedJob(value,row));
   }
   const value=await request('?offset='+offset);if(ticket!==epoch||!allowed())return;showPage(value);
  }catch(error){
   if(ticket!==epoch)return;
   rows.replaceChildren();next=null;
   if([401,403].includes(error.status)){account=null;section.hidden=true;}
   else feedback.textContent=error.status===409?'This association changed. Refresh and review it again before saving or queueing.':'Could not confirm the current review or pending work. Refresh before retrying; the save may already have reached the PC. Queueing the same reviewed revision is safe to retry.';
  }finally{busy=false;controls();}
 }
 function render(value){epoch++;account=value;offset=0;next=null;jobs.clear();rows.replaceChildren();feedback.textContent='';section.hidden=!allowed();controls();if(allowed()&&!busy)action('refresh');}
 el('phone-loading-refresh').onclick=()=>{offset=0;action('refresh');};
 el('phone-loading-next').onclick=()=>{if(next!==null&&!busy){offset=next;action('refresh');}};
 window.GateDeskPhoneLoadingReview=Object.freeze({render});
})();
