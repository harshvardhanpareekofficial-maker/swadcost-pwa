/* Owner-PC settings only. Saving/preparing never starts, stops or exposes a listener. */
(() => {
 'use strict';
 const el=id=>document.getElementById(id), box=el('phone-setup');
 if(!box)return;
 const fields=['canonical_origin','bind_address','port','certificate_path','private_key_path'];
 let account=null,state=null,busy=false,epoch=0;
 const allowed=()=>document.documentElement.dataset.transport!=='remote'&&!window.GateDeskMobile
   &&account?.enabled===true&&account.authenticated===true&&account.owner_only===true&&account.user?.role==='owner';
 function controls(){
  const enabled=allowed()&&!busy;
  el('phone-refresh').disabled=!enabled;
  el('phone-fields').disabled=!enabled||!state;
  el('phone-save').disabled=!enabled||!state;
  el('phone-handoff').disabled=!enabled||!state?.saved||state?.restart?.available!==true;
 }
 function clear(){
  state=null;el('phone-form').reset();el('phone-factory').textContent='';
  el('phone-saved-status').textContent='Saved setup has not been checked.';
  el('phone-running-status').textContent='Running phone service has not been verified.';
  el('phone-handoff-result').replaceChildren();
 }
 function render(value){
  epoch++;account=value;busy=false;clear();box.hidden=!allowed();controls();
  if(allowed())action('refresh');
 }
 function checked(value){
  if(!value||!Object.hasOwn(value,'saved')||!value.running||typeof value.running.verified!=='boolean'
     ||typeof value.running.state!=='string'||!value.restart||typeof value.restart.available!=='boolean')throw Error('invalid_response');
  if(value.saved!==null){
   const saved=value.saved;
   if(!Number.isSafeInteger(saved.revision)||saved.revision<1||typeof saved.factory_id!=='string'
      ||saved.factory_id!==account.factory?.id||!saved.settings
      ||fields.some(key=>key==='port'?!Number.isSafeInteger(saved.settings[key]):typeof saved.settings[key]!=='string'))throw Error('invalid_response');
  }
  return value;
 }
 function runningText(running,saved){
  if(running.verified===true&&running.state==='not_started')return 'Phone service has not been started by this app runtime. Saving settings alone does not start it.';
  if(running.verified===true&&running.state==='running'&&typeof running.local_diagnostic==='boolean'
    &&running.factory_id===account.factory?.id&&typeof running.canonical_origin==='string'
    &&typeof running.bind_address==='string'&&Number.isSafeInteger(running.port)&&running.port>=1&&running.port<=65535){
   const mode=running.local_diagnostic?'Local diagnostic listener is running on this PC only. This is not a phone-access deployment.':'Phone listener is running in this app runtime. This does not verify a phone connection or off-site access.';
   const address=' Current address: '+running.canonical_origin+' · bind '+running.bind_address+':'+running.port+'.';
   const matching=saved&&['canonical_origin','bind_address','port'].every(key=>saved.settings[key]===running[key]);
   const comparison=!saved?' No saved setup is available to compare.':matching?' Visible address settings match the saved revision; certificate files have not been compared.':' Saved address settings differ from the running listener. Saving has not reconfigured this runtime.';
   return mode+address+comparison;
  }
  return 'Running phone service: not verified by this setup screen. Saved settings are not evidence of a working phone connection.';
 }
 function show(value){
  state=checked(value);const saved=state.saved;
  for(const key of fields)el('phone-'+key).value=saved?.settings[key]??(key==='port'?'8443':'');
  el('phone-factory').textContent='Factory: '+(account.factory?.name||account.factory?.id||'Assigned by server');
  el('phone-saved-status').textContent=saved?'Saved on this PC · revision '+saved.revision+'. Saving does not activate phone access.':'No phone settings saved. Saving will not start phone access.';
  // Runtime readiness is narrower than phone/off-site acceptance; the provider
  // does not expose certificate paths, so only visible address fields compare.
  el('phone-running-status').textContent=runningText(state.running,saved);
  el('phone-feedback').textContent=state.restart.available?'Settings can be prepared for a separate owner-console restart.':'Restart preparation is unavailable for this runtime. Save and refresh are separate from activation.';
  el('phone-handoff-result').replaceChildren();controls();
 }
 async function request(path,body){
  const response=await fetch('/api/phone-setup'+path,{method:body===undefined?'GET':'POST',
   credentials:'same-origin',cache:'no-store',redirect:'error',headers:{'X-Gate-Desk':'local','Content-Type':'application/json'},
   ...(body===undefined?{}:{body:JSON.stringify(body)})});
  if(!response.ok){const error=Error('phone_setup_failed');error.status=response.status;throw error;}
  return response.json();
 }
 function handoff(value){
  const item=value.handoff;
  if(!item||item.kind!=='manual_owner_console_restart'||item.automatic_restart!==false
    ||item.requires_owner_password!==true||item.config_revision!==state.saved?.revision
    ||typeof item.generation!=='string'||!item.generation||typeof item.config_path!=='string'
    ||typeof item.runtime_binding!=='string'||!/^[a-f0-9]{64}$/.test(item.config_sha256)
    ||typeof item.consumer_available!=='boolean')throw Error('invalid_handoff');
  const consumer=item.consumer_available;
  if(consumer&&(item.consumer_scope!=='source_only_unaccepted'||item.state!=='prepared_manual'
    ||item.helper_relative_path!=='scripts/restart_phone_service.py'
    ||typeof item.handoff_id!=='string'||!/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/.test(item.handoff_id)
    ||typeof item.handoff_path!=='string'||!/^[A-Za-z]:[\\/]/.test(item.handoff_path)
    ||typeof item.runtime_dir!=='string'||!/^[A-Za-z]:[\\/]/.test(item.runtime_dir)
    ||!Array.isArray(item.consumer_args)||item.consumer_args.length!==4
    ||item.consumer_args[0]!=='--runtime-dir'||item.consumer_args[1]!==item.runtime_dir
    ||item.consumer_args[2]!=='--handoff-id'||item.consumer_args[3]!==item.handoff_id))throw Error('invalid_handoff_consumer');
  const target=el('phone-handoff-result');
  const message=document.createElement('p');
  message.textContent='Restart handoff prepared for this running generation. Nothing has been stopped or started. Do not enter your owner password into this page.';
  const details=document.createElement('p');details.className='small-note';
  details.textContent='Saved revision '+item.config_revision+' · generation '+item.generation;
  const path=document.createElement('p');path.className='small-note';
  path.textContent='Saved configuration: '+item.config_path;
  target.replaceChildren(message,details,path);
  const availability=document.createElement('p');
  availability.textContent=consumer?'Source restart helper is available for separately supervised acceptance. Its restart flow and installed-package integration are not accepted by this screen.':'No executable restart consumer is available for this handoff. Keep the running app open and arrange a supported restart procedure.';
  target.append(availability);
  if(consumer){
   const recipe=document.createElement('p');recipe.className='small-note';recipe.textContent='Prepared local handoff file: '+item.handoff_path;target.append(recipe);
   const steps=document.createElement('ol');
   for(const text of [
    'Finish active counting, uploads and reviews before starting a separately supervised restart.',
    'In an owner console, use the locked Python runtime with '+item.helper_relative_path+' from the matching reviewed source directory. This is not a Candidate18 or desktop-button instruction.',
    'Pass the arguments shown below. If this runtime uses an external document folder, also supply its existing path with --document-dir; do not choose a new data folder.',
    'Enter your owner sign-in ID and password only in that console when prompted. The helper must authorize before stopping this exact generation; normal phone startup asks for authorization again after clean shutdown.',
    'Keep that console open while it owns the runtime. A stale, changed, used or failed handoff requires a newly prepared handoff; do not edit the JSON or retry it as if unused.'
   ]){const line=document.createElement('li');line.textContent=text;steps.append(line);}
   target.append(steps);
   const argumentsBox=document.createElement('pre');argumentsBox.textContent=item.consumer_args.map((value,index)=>(index%2===0?'Option: ':'Value: ')+value).join('\n');target.append(argumentsBox);
  }
 }
 async function action(kind){
  if(!allowed()||busy)return;
  if(kind!=='refresh'&&!state)return;
  if(kind==='handoff'&&(!state.saved||!state.restart.available))return;
  if(kind==='save'&&!el('phone-form').reportValidity())return;
  const generation=++epoch;busy=true;controls();el('phone-handoff-result').replaceChildren();
  el('phone-feedback').textContent=kind==='save'?'Saving settings only…':kind==='handoff'?'Preparing restart handoff only…':'Checking saved settings…';
  try{
   let response;
   if(kind==='save'){
    const settings=Object.fromEntries(fields.map(key=>[key,key==='port'?Number(el('phone-'+key).value):el('phone-'+key).value.trim()]));
    response=await request('',{expected_revision:state.saved?.revision??0,settings});
   }else if(kind==='handoff')response=await request('/restart-handoff',{expected_revision:state.saved.revision});
   else response=await request('');
   if(generation!==epoch||!allowed())return;
   show(response);if(kind==='handoff')handoff(response);
  }catch(error){
   if(generation!==epoch)return;
   if([401,403,404].includes(error.status)){
    render(null);el('phone-feedback').textContent='Owner phone setup is unavailable. Sign in on the factory PC before continuing.';
   }else{
    state=null;el('phone-handoff-result').replaceChildren();
    el('phone-feedback').textContent=error.status===409?'Saved setup changed elsewhere. Refresh before editing or preparing a restart.':error.status===422?'Settings were rejected. Refresh the saved setup, then check the HTTPS address, private interface, port and local certificate paths.':'Saved setup or restart preparation could not be confirmed. Refresh before continuing; no activation is assumed.';
   }
  }finally{if(generation===epoch){busy=false;controls();}}
 }
 el('phone-refresh').onclick=()=>action('refresh');
 el('phone-form').onsubmit=event=>{event.preventDefault();action('save');};
 el('phone-handoff').onclick=()=>action('handoff');
 document.addEventListener('click',event=>{if(event.target.closest?.('#account-logout'))render(null);},true);
 window.addEventListener('pagehide',()=>render(null));
 window.GateDeskPhoneSetup={render};
 controls();
})();
