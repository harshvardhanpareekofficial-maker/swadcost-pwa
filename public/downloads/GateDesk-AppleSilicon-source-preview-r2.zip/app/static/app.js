const $ = (selector) => document.querySelector(selector);
let draft={gatepass:'GP-030',material:'Beams',expected:50,direction:'Incoming',carrier:'MH 04 AB 1234',unit:'beam'};
let active=null,last=null,reports=[],timer=null,busy=false,inferenceBusy=false,toastTimer;
let imageSource='sample',uploadedFile=null,objectUrl=null,sampleIndex=0;
let predictionPage=null,predictionOffset=0,predictionLoading=false,predictionError='';
const predictionPageSize=200;
const escapeHtml=(s)=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function toast(message){$('#toast').textContent=message;$('#toast').hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').hidden=true,5000);}
async function api(url,{method='GET',body,form}={}){
 if(window.GateDeskMobile)return window.GateDeskMobile.request(url,{method,body:body?JSON.stringify(body):undefined,form});
 const options={method,headers:{'X-Gate-Desk':'local'}};
 if(form)options.body=form;else if(body){options.headers['Content-Type']='application/json';options.body=JSON.stringify(body);}
 let response;try{response=await fetch(url,options);}catch{throw new Error('The local app is unavailable. Restart Gate Desk and try again.');}
 if(!response.ok){let d=await response.json().catch(()=>({}));throw new Error(typeof d.detail==='string'?d.detail:'Check the entered values and try again.');}
 return response.json();
}
function showPage(name){
 if(window.GateDeskCustomerUI)window.GateDeskCustomerUI.navigate(name);
 else window.gateDeskPendingPage=name;
}
document.querySelectorAll('[data-page]').forEach(b=>b.addEventListener('click',()=>showPage(b.dataset.page)));
window.addEventListener('hashchange',()=>showPage(location.hash.slice(1)));
function pillClass(s){return s==='Matched'?'matched':s==='Needs review'?'review':'warning';}
function reportTable(rows,emptyText='No completed sessions yet'){
 if(!rows.length)return `<div class="empty-state"><strong>${escapeHtml(emptyText)}</strong><p>Completed demonstrations appear here after the carrier leaves.</p></div>`;
 return `<div class="table-wrap"><table><thead><tr><th>Gate pass / time</th><th>Direction</th><th>Material</th><th class="number">Expected</th><th class="number">Observed</th><th class="number">Difference</th><th>Outcome</th></tr></thead><tbody>${rows.map(r=>`<tr><td class="pass-cell">${escapeHtml(r.gatepass)}<small>${escapeHtml(new Date(r.ended_at).toLocaleString('en-IN',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'}))} · DEMO</small></td><td>${r.direction==='Incoming'?'↓':'↑'} ${escapeHtml(r.direction)}</td><td>${escapeHtml(r.material)}<small class="unit-note">${escapeHtml(r.unit||'unit')}</small></td><td class="number">${r.expected}</td><td class="number">${r.uncertain?'≥ ':''}${r.observed}</td><td class="number">${r.uncertain?'Uncertain':r.difference>0?'+'+r.difference:r.difference}</td><td><span class="pill ${pillClass(r.status)}">${escapeHtml(r.status)}</span></td></tr>`).join('')}</tbody></table></div><p class="table-disclaimer">Demonstration records · An uncertain observed quantity is a confirmed minimum, not a complete count.</p>`;
}
function renderReports(){
 $('#recent-reports').innerHTML=reportTable(reports.slice(0,3));
 const search=$('#report-search').value.trim().toLowerCase(),filter=$('#report-filter').value;
 const filtered=reports.filter(r=>(filter==='all'||r.status.startsWith(filter))&&[r.gatepass,r.material,r.carrier].join(' ').toLowerCase().includes(search));
 $('#all-reports').innerHTML=reportTable(filtered,reports.length?'No reports match your filters':'No completed sessions yet');
}
$('#report-search').addEventListener('input',renderReports);$('#report-filter').addEventListener('change',renderReports);
function renderPredictionReports(){
 const rows=predictionPage?.rows||[],filtered=GateDeskTrackerReports.filter(rows,$('#prediction-search').value);
 const emptyText=predictionError&&!predictionPage?'Prediction reports unavailable':predictionLoading&&!predictionPage?'Loading prediction reports':rows.length?'No predictions match this page filter':'No tracker predictions on this page';
 $('#prediction-reports').innerHTML=GateDeskTrackerReports.table(filtered,emptyText);
 $('#prediction-prev').disabled=predictionLoading||!predictionPage?.previous;
 $('#prediction-next').disabled=predictionLoading||!predictionPage?.next;
 $('#prediction-refresh').disabled=predictionLoading;
 const summary=predictionPage?`${filtered.length} prediction report${filtered.length===1?'':'s'} shown${filtered.length!==rows.length?' after filtering':''}. Saved records ${predictionPage.first}–${predictionPage.last} of ${predictionPage.total}; other replay records are hidden.`:'Prediction reports have not been loaded.';
 $('#prediction-page-status').textContent=predictionError?`${predictionError}${predictionPage?' Previously loaded reports remain below.':''}`:predictionLoading?'Loading prediction reports…':summary;
 $('#prediction-page-status').classList.toggle('report-load-error',!!predictionError);
 $('#prediction-reports').setAttribute('aria-busy',String(predictionLoading));
}
async function loadPredictionReports(offset=0){
 if(predictionLoading)return;
 predictionLoading=true;predictionError='';renderPredictionReports();
 try{
  let data=await api(`/api/replay-sessions?limit=${predictionPageSize}&offset=${offset}`);
  if(data.total>0&&offset>=data.total){offset=Math.floor((data.total-1)/predictionPageSize)*predictionPageSize;data=await api(`/api/replay-sessions?limit=${predictionPageSize}&offset=${offset}`);}
  predictionPage=GateDeskTrackerReports.page(data,offset,predictionPageSize);predictionOffset=offset;
 }catch(error){predictionError=error.message||'Prediction reports are unavailable.';}
 finally{predictionLoading=false;renderPredictionReports();}
}
$('#prediction-search').addEventListener('input',renderPredictionReports);
$('#prediction-refresh').addEventListener('click',()=>loadPredictionReports(predictionOffset));
$('#prediction-prev').addEventListener('click',()=>loadPredictionReports(Math.max(0,predictionOffset-predictionPageSize)));
$('#prediction-next').addEventListener('click',()=>loadPredictionReports(predictionOffset+predictionPageSize));
function render(){
 const s=active||last||draft,observed=s.observed||0,expected=s.expected,complete=s.phase==='completed',running=!!timer;
 $('#unit-label').textContent=(s.unit||'unit')+(expected===1?'':'s');$('#scope-note').hidden=!s.document_id;$('#scope-note').textContent='Selected count target only. Other material lines are not reconciled by this session.';
 $('#pass-label').textContent=s.gatepass;$('#material-label').textContent=s.material;$('#expected-label').textContent=expected;$('#denominator').textContent=expected;
 $('#observed-label').textContent=observed;$('#direction-label').textContent=(s.direction==='Incoming'?'↓ ':'↑ ')+s.direction;
 $('#movement-label').textContent=s.direction==='Incoming'?'Outside → Factory':'Factory → Outside';
 $('#count-caption').textContent=s.uncertain?'Confirmed minimum · uncertain footage':'Observed in this demo';
 const pct=Math.round(observed/expected*100);$('#progress-fill').style.width=Math.min(100,pct)+'%';$('#progress-pct').textContent=pct+'%';
 $('#count-note').textContent=complete?'Carrier left · report saved':active?(running?'Unloading is in progress':'Demonstration paused'):'Start the demonstration below';
 $('#stage-status').textContent=complete?'Carrier departed':active?(running?'Movement in progress':'Demo paused'):'Ready to explore';
 $('#stage-status').className='pill '+(active?'blue':'neutral');
 $('#carrier-label').textContent=(active||last)?s.carrier+' · '+(complete?'departed':'at receiving bay'):'Carrier awaiting arrival';
 $('#camera-stage').classList.toggle('running',running);$('#camera-stage').classList.toggle('departed',complete);
 $('#workspace-page').classList.toggle('outgoing',s.direction==='Outgoing');
 $('#journey-arrival').classList.toggle('done',!!(active||last));$('#journey-unloading').classList.toggle('done',observed>0);$('#journey-departure').classList.toggle('done',complete);
 $('#obstruction').hidden=!(active?.uncertain&&(active.scenario==='dust'||(active.step>=3&&active.step<=5)));
 $('#obstruction strong').textContent=active?.scenario==='dust'?'Possible lens dirt or blur':'Visibility interrupted';
 $('#obstruction span').textContent=active?.scenario==='dust'?'Inspect and clean the camera if needed. This demonstration count is uncertain.':'This demonstration includes missing footage. The final count will need review.';
 let title='Ready when you are',description='The comparison stays open until the carrier leaves.',kind='',mark='○';
 if(active){title=`In progress · ${observed}/${expected}`;description=active.uncertain?'Footage was interrupted. This session will need review.':'Counting continues. A shortage is only reported after departure.';mark='↻';if(active.uncertain)kind='alert';}
 if(complete){title=s.status;mark=s.status==='Matched'?'✓':'!';kind=s.status==='Matched'?'success':'alert';description=s.uncertain?'Footage was missing or the demonstration ended early. The final quantity is uncertain.':s.status==='Matched'?'Observed quantity matches the gate pass. Report saved.':`${observed} observed against ${expected} expected. Report saved after departure.`;}
 $('#outcome').className='outcome '+kind;$('#outcome-title').textContent=title;$('#outcome-description').textContent=description;$('.outcome-mark').textContent=mark;
 $('#run-demo').textContent=running?'Ⅱ Pause demonstration':active?'▶ Resume demonstration':complete?'↻ Run another demonstration':'▶ Run demonstration';
 $('#run-demo').disabled=busy;$('#end-demo').hidden=!active;$('#end-demo').disabled=busy;
 $('#scenario').disabled=!!active||busy;$('#new-pass').disabled=!!active||busy;
 const scenarios={missing:`${Math.max(0,expected-5)} of ${expected} · Short delivery`,matched:`${expected} of ${expected} · Exact delivery`,excess:`${expected+2} of ${expected} · Extra material`,blocked:'Visibility lost · Needs review',dust:'Possible lens dirt · Needs review'};
 for(const option of $('#scenario').options)option.textContent=scenarios[option.value];
}
function pause(){clearInterval(timer);timer=null;render();}
async function refresh(){const state=await api('/api/state');active=state.active;reports=state.reports;if(active){for(const k of ['gatepass','material','expected','direction','carrier','unit','document_id','document_line_id'])draft[k]=active[k];$('#scenario').value=active.scenario;}render();renderReports();$('#connection-state').textContent='Connected to this PC';}
async function tick(){
 if(!active||busy)return;busy=true;
 try{const updated=await api(`/api/demo/${active.id}/advance`,{method:'POST',body:{step:active.step+1}});active=updated;
 if(updated.phase==='completed'){last=updated;active=null;pause();await refresh();toast(updated.status==='Needs review'?'Report saved · quantity needs review':`Report saved · ${updated.status}`);}}
 catch(e){pause();toast(e.message);}finally{busy=false;render();}
}
$('#run-demo').addEventListener('click',async()=>{
 if(timer){pause();return;}if(busy)return;busy=true;render();
 try{if(!active){last=null;active=await api('/api/sessions',{method:'POST',body:{...draft,scenario:$('#scenario').value}});}timer=setInterval(tick,700);}
 catch(e){toast(e.message);}finally{busy=false;render();}
});
$('#end-demo').addEventListener('click',async()=>{if(!active||busy)return;pause();busy=true;render();try{last=await api(`/api/demo/${active.id}/end`,{method:'POST'});active=null;await refresh();toast('Report saved as Needs review because the demonstration ended early.');}catch(e){toast(e.message);}finally{busy=false;render();}});
$('#new-pass').addEventListener('click',()=>{for(const [k,v] of Object.entries(draft))if($('#pass-form').elements[k])$('#pass-form').elements[k].value=v;$('#pass-dialog').showModal();});
$('#close-dialog').addEventListener('click',()=>$('#pass-dialog').close());
$('#pass-form').addEventListener('submit',e=>{e.preventDefault();const d=Object.fromEntries(new FormData(e.target));d.expected=Number(d.expected);if(!d.gatepass.trim()||!d.material.trim()){toast('Enter a gate-pass number and material.');return;}draft={...d,unit:'unit'};last=null;$('#pass-dialog').close();render();toast('Gate pass ready for demonstration.');});
async function loadModel(){if(!$('#sample-image').getAttribute('src'))$('#sample-image').src='/api/sample';try{const m=await api('/api/model');
 $('#model-state').textContent=m.phase==='completed_experimental'?'Experimental bag model ready':'Model unavailable';
 if(m.validation){const v=m.validation;$('#model-metrics').innerHTML=`<div class="metric-row"><span>Public validation precision</span><strong>${(v.precision*100).toFixed(1)}%</strong></div><div class="metric-row"><span>Public validation recall</span><strong>${(v.recall*100).toFixed(1)}%</strong></div><p class="small-note">${v.images} source-held-out public images. Confidence ≥0.5; IoU ≥0.5. Factory and counting accuracy are not established.</p>`;}
 else $('#model-metrics').textContent='No verified validation result available.';
 $('#sample-infer').disabled=inferenceBusy||m.phase!=='completed_experimental';
 }catch(e){$('#model-state').textContent='Model status unavailable';$('#sample-infer').disabled=true;}}
function drawPredictions(result){const canvas=$('#detection-canvas');canvas.width=result.width;canvas.height=result.height;const ctx=canvas.getContext('2d');ctx.clearRect(0,0,canvas.width,canvas.height);const scale=Math.max(1,result.width/500);ctx.lineWidth=2*scale;ctx.font=`${12*scale}px Segoe UI`;
 for(const d of result.detections){const [x1,y1,x2,y2]=d.box;ctx.strokeStyle=d.label==='bag'?'#245fc7':'#23745b';ctx.fillStyle=ctx.strokeStyle;ctx.strokeRect(x1,y1,x2-x1,y2-y1);const label=`${d.label} ${Math.round(d.score*100)}%`,w=ctx.measureText(label).width+12*scale,y=Math.max(0,y1-23*scale);ctx.fillRect(x1,y,w,23*scale);ctx.fillStyle='white';ctx.fillText(label,x1+6*scale,y+16*scale);}
 const counts={};for(const d of result.detections)counts[d.label]=(counts[d.label]||0)+1;
 $('#prediction-result').innerHTML=`<strong>${result.detections.length} detection${result.detections.length===1?'':'s'} above 50% confidence</strong><p class="small-note">${result.inference_ms} ms on local CPU · Predictions may be wrong.</p>${Object.entries(counts).map(([label,count])=>`<div class="detection-item"><span>${escapeHtml(label)}</span><strong>${count}</strong></div>`).join('')}${!result.detections.length?'<p>No objects met the threshold. This does not mean the image is empty.</p>':''}`;
}
async function runInference(){if(inferenceBusy)return;inferenceBusy=true;$('#sample-infer').disabled=true;$('#image-upload').disabled=true;$('#sample-infer').textContent='Running locally…';$('#prediction-result').textContent='Processing this image on your PC…';
 try{let result;if(imageSource==='sample')result=await api(`/api/model/sample?index=${sampleIndex}`,{method:'POST'});else{const form=new FormData();form.append('file',uploadedFile);result=await api('/api/model/image',{method:'POST',form});}drawPredictions(result);}
 catch(e){$('#prediction-result').textContent=e.message;toast(e.message);}finally{inferenceBusy=false;$('#image-upload').disabled=false;$('#sample-infer').textContent=imageSource==='sample'?'Run on sample image':'Run on your image';await loadModel();}
}
$('#sample-infer').addEventListener('click',runInference);
$('#image-upload').addEventListener('change',e=>{const file=e.target.files[0];if(!file)return;if(file.size>10*1024*1024){toast('Choose an image smaller than 10 MB.');e.target.value='';return;}if(objectUrl)URL.revokeObjectURL(objectUrl);objectUrl=URL.createObjectURL(file);uploadedFile=file;imageSource='upload';$('#sample-image').src=objectUrl;$('#sample-image').alt='Your selected image for local detection';const c=$('#detection-canvas');c.getContext('2d').clearRect(0,0,c.width,c.height);$('#sample-infer').textContent='Run on your image';$('#prediction-result').textContent='Image selected. Run the detector to see predictions.';});
window.addEventListener('beforeunload',()=>{if(objectUrl)URL.revokeObjectURL(objectUrl);});
showPage(location.hash.slice(1)||'current');render();
setInterval(()=>{if(!$('#model-page').hidden && !$('#account-page').hidden)loadModel();},5000);
let documentsCache=[],selectedDocumentId=null,documentGeneration=0;
function clearDocumentEditor(){
 documentGeneration++;documentsCache=[];selectedDocumentId=null;
 $('#document-list').replaceChildren();$('#document-review').replaceChildren();
}
document.addEventListener('gate-remote-unavailable',clearDocumentEditor);
async function loadDocuments(){
 const generation=++documentGeneration;
 try{const received=await api('/api/documents');if(generation!==documentGeneration)return;documentsCache=received;if(!selectedDocumentId)selectedDocumentId=documentsCache[0]?.id;
 $('#document-list').innerHTML=documentsCache.map(d=>`<button class="document-tab ${d.id===selectedDocumentId?'selected':''}" data-document="${escapeHtml(d.id)}"><span>${escapeHtml(d.issuer)}</span><strong>Pass ${escapeHtml(d.number)}</strong><small>${d.lines.map(l=>`${l.quantity} ${escapeHtml(l.unit)}${l.quantity===1?'':'s'}`).join(' + ')} · ${escapeHtml(d.direction)}</small><span class="pill ${d.status==='reviewed'?'matched':'warning'}">${d.status==='reviewed'?'Reviewed':'Check transcription'}</span></button>`).join('');
 document.querySelectorAll('[data-document]').forEach(b=>b.addEventListener('click',()=>{selectedDocumentId=b.dataset.document;loadDocuments();}));renderDocument();
 }catch(e){if(generation===documentGeneration)clearDocumentEditor();toast(e.message);}
}
function renderDocument(){
 const d=documentsCache.find(d=>d.id===selectedDocumentId);if(!d){$('#document-review').replaceChildren();return;}
 $('#document-review').innerHTML=`<div class="document-grid"><section class="document-photo"><div class="panel-head"><h2>Original photograph</h2><a href="/api/documents/${escapeHtml(d.id)}/image" target="_blank" rel="noreferrer">Open full size ↗</a></div><img src="/api/documents/${escapeHtml(d.id)}/image" alt="Original gate pass ${escapeHtml(d.number)} from ${escapeHtml(d.issuer)}"></section><section class="model-card document-fields"><p class="eyebrow">COUNTABLE QUANTITIES</p><h2>Check against the original</h2><p class="small-note">${escapeHtml(d.issuer)} → ${escapeHtml(d.recipient)}</p><form id="document-form"><div class="form-grid"><label>Gate-pass number<input name="number" value="${escapeHtml(d.number)}" maxlength="60" required></label><label>Date as written<input name="date_raw" value="${escapeHtml(d.date_raw)}" maxlength="60" required></label><label>Direction at factory<select name="direction" required><option value="">Choose direction</option><option ${d.direction==='Incoming'?'selected':''}>Incoming</option><option ${d.direction==='Outgoing'?'selected':''}>Outgoing</option></select></label><label>Carrier registration<input name="carrier" value="${escapeHtml(d.carrier)}" maxlength="60" placeholder="Not shown"></label></div><div class="document-note">${escapeHtml(d.notes)}</div>${d.lines.map((l,i)=>`<fieldset class="line-editor"><legend>Count target ${i+1}</legend><label>Material<input name="material-${i}" value="${escapeHtml(l.material)}" maxlength="150" required></label><div class="form-grid"><label>Quantity<input name="quantity-${i}" type="number" value="${l.quantity}" min="1" max="10000" required></label><label>Physical unit<select name="unit-${i}">${['bag','cone','beam','roll','bundle','carton','unit'].map(u=>`<option value="${u}" ${u===l.unit?'selected':''}>${u==='carton'?'box/carton':u}</option>`).join('')}</select></label></div></fieldset>`).join('')}<button class="button secondary" type="button" id="add-document-line">+ Add count line</button><button class="button primary" id="save-document" ${!d.lines.length?'disabled':''}>Save reviewed fields</button></form><div class="document-use" ${(window.GateDeskMobile||document.body.dataset.role==='worker')?'hidden':''}><strong>Use a count target</strong><p class="small-note">${d.lines.length>1?'These targets are checked separately. Matching bags does not establish that the cones also arrived.':'This starts a simulated movement using the document quantity. Real CCTV counting is not connected yet.'}</p>${d.lines.map(l=>`<button class="button secondary use-document" data-line="${escapeHtml(l.id)}" ${d.status!=='reviewed'?'disabled':''}>Try ${l.quantity} ${escapeHtml(l.unit)}${l.quantity===1?'':'s'} in demo →</button>`).join('')}</div></section></div>`;
 $('#add-document-line').addEventListener('click',()=>{
 const f=new FormData($('#document-form'));for(const key of ['number','date_raw','carrier','direction'])d[key]=f.get(key);
 d.lines=d.lines.map((l,i)=>({...l,material:f.get(`material-${i}`),quantity:Number(f.get(`quantity-${i}`)),unit:f.get(`unit-${i}`)}));
 d.lines.push({id:'line-'+Date.now()+'-'+d.lines.length,material:'',quantity:'',unit:'unit',weight_kg:''});renderDocument();
 });
 $('#document-form').addEventListener('submit',async e=>{e.preventDefault();const f=new FormData(e.target),button=$('#save-document');button.disabled=true;
 const body={number:f.get('number'),date_raw:f.get('date_raw'),carrier:f.get('carrier'),direction:f.get('direction'),lines:d.lines.map((l,i)=>({...l,material:f.get(`material-${i}`),quantity:Number(f.get(`quantity-${i}`)),unit:f.get(`unit-${i}`)}))};
 try{await api(`/api/documents/${d.id}/review`,{method:'POST',body});toast('Reviewed fields saved on this PC.');await loadDocuments();}catch(e){toast(e.message);button.disabled=false;}
 });
 document.querySelectorAll('.use-document').forEach(b=>b.addEventListener('click',()=>{if(window.GateDeskMobile||document.body.dataset.role==='worker')return;if(active){toast('Finish the active demonstration before choosing another document.');return;}const l=d.lines.find(l=>l.id===b.dataset.line);draft={gatepass:d.number,expected:l.quantity,material:l.material,unit:l.unit,direction:d.direction,carrier:d.carrier||'Registration not shown',document_id:d.id,document_line_id:l.id};last=null;$('#scenario').value='matched';render();showPage('workspace');window.scrollTo({top:0,behavior:'instant'});toast(`Selected ${l.quantity} ${l.unit}${l.quantity===1?'':'s'} from pass ${d.number}.`);}));
}
$('#health-form').addEventListener('submit',async e=>{
 e.preventDefault();const button=$('#health-compare'),form=new FormData(e.target);
 for(const name of ['reference','current'])if(form.get(name).size>10*1024*1024){toast('Each image must be smaller than 10 MB.');return;}
 button.disabled=true;button.textContent='Comparing locally…';
 try{const r=await api('/api/camera-health/compare',{method:'POST',form});$('#health-result').innerHTML=`<strong>${escapeHtml(r.message)}</strong><p class="small-note">${escapeHtml(r.limitation||'Use a suitable clean reference before relying on this comparison.')}</p><span class="pill ${r.needs_review?'warning':'neutral'}">${r.needs_review?'Inspect camera · count may be uncertain':'No degradation detected in this comparison'}</span>${r.assessable_tiles!==undefined?`<p class="small-note">${r.affected_tiles.length} affected areas out of ${r.assessable_tiles} assessable areas. This snapshot does not confirm persistent dust.</p>`:''}`;}catch(e){$('#health-result').textContent=e.message;}finally{button.disabled=false;button.textContent='Check image quality';}
});
$('#try-dust').addEventListener('click',()=>{if(window.GateDeskMobile||document.body.dataset.role==='worker')return;if(active){toast('Finish the active demonstration before changing the scenario.');return;}$('#scenario').value='dust';showPage('workspace');window.scrollTo({top:0,behavior:'instant'});toast('Lens-dirt scenario selected. Run the demonstration to see the alert.');});

$('#next-sample').addEventListener('click',()=>{if(inferenceBusy)return;sampleIndex=(sampleIndex+1)%8;imageSource='sample';uploadedFile=null;$('#sample-image').src='/api/sample?index='+sampleIndex;$('#sample-image').alt='Public bag validation image '+(sampleIndex+1);$('#sample-position').textContent='Test image '+(sampleIndex+1)+' of 8';$('#image-upload').value='';$('#sample-infer').textContent='Run on sample image';const c=$('#detection-canvas');c.getContext('2d').clearRect(0,0,c.width,c.height);$('#prediction-result').textContent='Run the detector to inspect this test image. Some images may produce no detections.';});

// Explicit document attachment; never releases prediction review holds.
let bindingSession=null,bindingChoices=[],bindingGeneration=0,bindingSaving=false;
function bindingSelection(){const value=$('#binding-line').value;return value===''?null:bindingChoices[Number(value)]||null;}
function updateBindingSelection(){
 const selected=bindingSelection();$('#binding-confirm').checked=false;
 $('#binding-details').textContent=selected?`Description: ${selected.line.material}. Quantity: ${selected.line.quantity} ${selected.line.unit}. Reviewed: ${selected.document.reviewed_at||'time not recorded'}. Weight is not used to calculate a count.`:'';
 $('#binding-submit').disabled=true;
}
async function loadBinding(sid){
 const generation=++bindingGeneration;bindingSession=null;bindingChoices=[];
 $('#binding-line').innerHTML='<option value="">Choose a line</option>';$('#binding-confirm').checked=false;$('#binding-submit').disabled=true;$('#binding-reload').disabled=true;
 $('#binding-details').textContent='';$('#binding-status').textContent='Loading current report and reviewed documents…';
 try{
  const [row,documents]=await Promise.all([api('/api/replay-sessions/'+encodeURIComponent(sid)),api('/api/documents')]);
  if(generation!==bindingGeneration||!$('#binding-dialog').open)return;
  $('#binding-target').textContent=`${row.gatepass} · ${row.material} · ${row.expected} ${row.unit} · ${row.direction}`;
  if(!GateDeskTrackerReports.canAttach(row))throw new Error('This report is closed or already has document evidence. Refresh the reports.');
  bindingSession=row;bindingChoices=GateDeskTrackerReports.candidates(row,documents);
  bindingChoices.forEach((choice,index)=>{const option=document.createElement('option');option.value=String(index);option.textContent=`${choice.document.number} / line ${choice.line.id} — ${choice.line.material} — ${choice.line.quantity} ${choice.line.unit}`;$('#binding-line').append(option);});
  $('#binding-status').textContent=bindingChoices.length?'Choose the matching material description. No line has been selected automatically.':'No eligible reviewed line. Review the gate pass first and check its quantity, unit and direction.';
 }catch(error){if(generation===bindingGeneration)$('#binding-status').textContent=error.message;}
 finally{if(generation===bindingGeneration)$('#binding-reload').disabled=false;}
}
$('#prediction-reports').addEventListener('click',event=>{
 const button=event.target.closest('button[data-session-id]');if(!button||bindingSaving)return;
 $('#binding-dialog').dataset.sessionId=button.dataset.sessionId;$('#binding-target').textContent='';$('#binding-dialog').showModal();loadBinding(button.dataset.sessionId);
});
$('#binding-line').addEventListener('change',updateBindingSelection);
$('#binding-confirm').addEventListener('change',()=>{$('#binding-submit').disabled=bindingSaving||!bindingSession||!bindingSelection()||!$('#binding-confirm').checked;});
$('#binding-reload').addEventListener('click',()=>{if(!bindingSaving)loadBinding($('#binding-dialog').dataset.sessionId);});
$('#binding-close').addEventListener('click',()=>{if(!bindingSaving)$('#binding-dialog').close();});
$('#binding-dialog').addEventListener('cancel',event=>{if(bindingSaving)event.preventDefault();});
$('#binding-dialog').addEventListener('close',()=>{bindingGeneration++;bindingSession=null;bindingChoices=[];});
$('#binding-form').addEventListener('submit',async event=>{
 event.preventDefault();const selected=bindingSelection();if(bindingSaving||!bindingSession||!selected||!$('#binding-confirm').checked)return;
 bindingSaving=true;$('#binding-submit').disabled=true;$('#binding-close').disabled=true;$('#binding-reload').disabled=true;$('#binding-line').disabled=true;$('#binding-confirm').disabled=true;
 $('#binding-status').textContent='Saving the reviewed line. Predicted counts will remain under review.';
 try{
  await api('/api/replay-sessions/'+encodeURIComponent(bindingSession.id)+'/document-binding',{method:'POST',body:{document_id:selected.document.id,line_id:selected.line.id,revision_sha256:selected.document.revision_sha256,confirmed_material_class:bindingSession.material}});
  $('#binding-dialog').close();toast('Document line attached. Predicted counts still need review.');await loadPredictionReports(predictionOffset);
 }catch(error){$('#binding-status').textContent=error.message+' Reload the lines before trying again.';$('#binding-confirm').checked=false;bindingSession=null;}
 finally{bindingSaving=false;$('#binding-close').disabled=false;$('#binding-reload').disabled=false;$('#binding-line').disabled=false;$('#binding-confirm').disabled=false;$('#binding-submit').disabled=true;}
});

let reconciliationGeneration=0;
$('#prediction-reports').addEventListener('click',async event=>{
 const button=event.target.closest('button[data-operation-id]');if(!button)return;
 const generation=++reconciliationGeneration;$('#reconciliation-dialog').showModal();
 $('#reconciliation-content').textContent='Loading saved document coverage...';
 try{
  const result=await api('/api/replay-sessions/tracker-imports/'+encodeURIComponent(button.dataset.operationId)+'/document-reconciliation');
  if(generation===reconciliationGeneration&&$('#reconciliation-dialog').open)$('#reconciliation-content').innerHTML=GateDeskTrackerReports.reconciliation(result);
 }catch(error){if(generation===reconciliationGeneration)$('#reconciliation-content').textContent=error.message;}
});
$('#reconciliation-close').addEventListener('click',()=>$('#reconciliation-dialog').close());
$('#reconciliation-dialog').addEventListener('close',()=>{reconciliationGeneration++;});
