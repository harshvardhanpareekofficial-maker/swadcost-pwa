"""Owner-only projected reads. No store initialization or transport enablement.

Both existing stores must be readable, including confirmation schema: a missing
store cannot prove that no attestation exists. Existing account authentication
retains its own schema/session access; report connections here are read-only.
"""
from contextlib import contextmanager
import hashlib
import json
from pathlib import Path
import re
import sqlite3
import time

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import JSONResponse

from app.accounts import enabled, local_peer, require_owner
from app.mobile_reports import ProjectionError, project_replay, project_reconciliation

router = APIRouter(prefix='/api/mobile/reports')
MAX_RECORD_BYTES = 2 * 1024 * 1024
MAX_PAGE_BYTES = 8 * 1024 * 1024
HEADERS = {'Cache-Control': 'no-store'}


def _bad_query():
    raise HTTPException(422, 'Invalid report query.', headers=HEADERS)


def _identity(value):
    # Producer IDs may contain colons; paths, percent aliases and control bytes
    # are deliberately excluded from the public identifier grammar.
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.:-]{0,79}', value):
        _bad_query()
    return value


def _owner(request):
    if not enabled(request) or not local_peer(request):
        raise HTTPException(403, 'Enabled local owner account required.', headers=HEADERS)
    require_owner(request)


def _query(request, detail=False):
    values = request.query_params.multi_items()
    allowed = set() if detail else {'limit', 'offset'}
    if len(request.scope.get('query_string', b'')) > 128:
        _bad_query()
    if any(key not in allowed for key, _ in values) or len({k for k, _ in values}) != len(values):
        _bad_query()
    result = {'limit': 50, 'offset': 0}
    for key, value in values:
        if not re.fullmatch(r'0|[1-9][0-9]{0,4}', value):
            _bad_query()
        result[key] = int(value)
    if not 1 <= result['limit'] <= 100 or not 0 <= result['offset'] <= 10000:
        _bad_query()
    return result


@contextmanager
def _stores(report_db=None):
    if report_db is None:
        from app.main import DB
        report_db = DB
    paths = [Path(report_db).resolve(), Path(report_db).resolve().with_name('operator-confirmations.sqlite3')]
    connections = []
    deadline = time.monotonic() + 2
    try:
        for path in paths:
            c = sqlite3.connect(path.as_uri() + '?mode=ro', uri=True, timeout=0.2)
            connections.append(c)
            c.row_factory = sqlite3.Row
            c.setlimit(sqlite3.SQLITE_LIMIT_LENGTH, MAX_RECORD_BYTES)
            c.set_progress_handler(lambda: int(time.monotonic() > deadline), 1000)
            c.execute('PRAGMA query_only=ON')
            c.execute('BEGIN')
        reports, confirmations = connections
        # Validate both schemas even for empty pages. Never treat an unreadable
        # confirmation store as evidence that a report was not confirmed.
        reports.execute('SELECT id,payload,closed_reason,ended_at FROM replay_sessions LIMIT 0')
        confirmations.execute('SELECT id,evidence,created_at FROM confirmations LIMIT 0')
        yield reports, confirmations
    finally:
        for c in reversed(connections):
            c.close()


def _charge(budget, size):
    if type(size) is not int or size < 0 or size > MAX_RECORD_BYTES or size > budget[0]:
        raise ProjectionError('Stored report evidence is invalid.')
    budget[0] -= size


def _project(reports, confirmations, sid, budget):
    if type(sid) is not str or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.:-]{0,79}', sid):
        raise ProjectionError('Stored report evidence is invalid.')
    key = hashlib.sha256(json.dumps([sid, 'reconciliation', None],
                                  separators=(',', ':'), ensure_ascii=False).encode()).hexdigest()
    row = confirmations.execute('SELECT id,evidence,created_at FROM confirmations WHERE id=?', (key,)).fetchone()
    if row is not None:
        _charge(budget, len(row['evidence'].encode('utf-8')))
        evidence = json.loads(row['evidence'])
        if type(evidence) is not dict or type(evidence.get('report_snapshot')) is not dict:
            raise ProjectionError('Stored report evidence is invalid.')
        snapshot = evidence['report_snapshot']
        if evidence.get('session_id') != sid or snapshot.get('id') != sid:
            raise ProjectionError('Stored report evidence is invalid.')
        return project_reconciliation(snapshot, {'id': row['id'], 'evidence': evidence,
                                                 'created_at': row['created_at']})
    # Bound input before existing report() materializes its event/provenance rows.
    queries = [
        ('SELECT coalesce(sum(length(CAST(payload AS BLOB))),0) FROM replay_events WHERE session_id=?', sid),
        ('SELECT length(CAST(payload AS BLOB)) FROM replay_sessions WHERE id=?', sid),
        ('SELECT length(CAST(snapshot AS BLOB)) FROM replay_document_bindings WHERE session_id=?', sid),
        ('''SELECT length(CAST(i.payload AS BLOB)) FROM replay_tracker_bindings b
            JOIN replay_tracker_imports i ON i.operation_id=b.operation_id WHERE b.session_id=?''', sid)]
    for query, identifier in queries:
        size = reports.execute(query, (identifier,)).fetchone()
        _charge(budget, size[0] if size is not None else 0)
    from app.movements import report
    result = project_replay(report(reports, sid))
    if result['id'] != sid:
        raise ProjectionError('Stored report evidence is invalid.')
    return result


def _read(request, sid=None):
    _owner(request)
    return read_authorized_report(request, sid)


def read_authorized_report(request, sid=None, *, report_db=None):
    """Internal projection after caller authorization; never register directly.

    Explicit report_db is a trusted single-factory deployment path, not request
    data. Existing local callers keep their existing owner/loopback checks.
    """
    # These endpoints have ASCII-only paths. Require the actual HTTP path to
    # equal the decoded route, so percent aliases cannot bypass its grammar.
    raw_path = request.scope.get('raw_path')
    if raw_path != request.url.path.encode('ascii', errors='replace'):
        _bad_query()
    params = _query(request, detail=sid is not None)
    if sid is not None:
        _identity(sid)
    try:
        with _stores(report_db) as (reports, confirmations):
            if sid is None:
                total = reports.execute('SELECT count(*) FROM replay_sessions').fetchone()[0]
                ids = [row[0] for row in reports.execute(
                    'SELECT id FROM replay_sessions ORDER BY id COLLATE BINARY LIMIT ? OFFSET ?',
                    (params['limit'], params['offset']))]
            else:
                if reports.execute('SELECT 1 FROM replay_sessions WHERE id=?', (sid,)).fetchone() is None:
                    raise HTTPException(404, 'Report not found.', headers=HEADERS)
                ids = [sid]
            budget = [MAX_PAGE_BYTES]
            rows = [_project(reports, confirmations, identifier, budget) for identifier in ids]
            payload = rows[0] if sid is not None else {'reports': rows, 'total': total, **params}
            return JSONResponse(payload, headers=HEADERS)
    except (sqlite3.Error, OSError, ValueError, TypeError, KeyError, AttributeError, RecursionError):
        # Includes projection/JSON errors; never silently replace corrupt
        # attestation evidence with an unconfirmed or apparently successful row.
        return JSONResponse({'detail': 'Report storage is unavailable. Try again later.'},
                            status_code=503, headers={**HEADERS, 'Retry-After': '1'})


@router.api_route('', methods=['GET', 'HEAD'])
def list_reports(request: Request):
    return _read(request)


@router.api_route('/{sid}', methods=['GET', 'HEAD'])
def read_report(sid: str, request: Request):
    return _read(request, sid)
