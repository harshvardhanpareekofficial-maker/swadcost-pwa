"""Trusted local launcher composition for camera drafts, never connection/capture."""
import json
from pathlib import Path

from app.camera_enrollment import EnrollmentError
from app.camera_enrollment_routes import install_camera_enrollment
from scripts.backup_runtime import PRIVATE_CAMERA_DIR, CAMERA_NOTICE, NOTICE_CONTENT


class LocalCameraPolicy:
    def __init__(self, runtime):
        raw = Path(runtime).absolute()
        if any(p.is_symlink() or p.is_junction() for p in (raw, *raw.parents)):
            raise ValueError('invalid_camera_runtime')
        self.runtime = raw.resolve(strict=True)
        self.directory = self.runtime/PRIVATE_CAMERA_DIR
        self.notice = self.runtime/CAMERA_NOTICE

    def check(self):
        for path in (self.runtime, self.directory, self.notice):
            if path.is_symlink() or path.is_junction():
                raise EnrollmentError('camera_private_path_invalid')
        if self.directory.exists() and not self.directory.is_dir():
            raise EnrollmentError('camera_private_path_invalid')
        database = self.directory/'camera-enrollment.sqlite3'
        if database.is_symlink() or database.is_junction():
            raise EnrollmentError('camera_private_path_invalid')
        if self.notice.exists():
            try:
                if self.notice.stat().st_size > 1024 or json.loads(self.notice.read_text(encoding='utf-8')) != NOTICE_CONTENT:
                    raise ValueError()
            except Exception:
                raise EnrollmentError('camera_reenrollment_notice_invalid') from None

    def status(self, *, saved=False):
        self.check()
        if saved and self.notice.exists():
            # This fixed, validated non-secret notice is retired only after the
            # draft and DPAPI ciphertext transaction has committed successfully.
            # A failed unlink leaves an explicit obligation, never a false clear.
            try:
                self.notice.unlink()
            except OSError:
                pass
        return {'provision_required': not self.directory.exists(),
                'reenrollment_required': self.notice.exists()}


def install_local_camera_setup(app, runtime, port):
    if not getattr(app.state, 'accounts_enabled', False):
        return False
    if type(port) is not int or not 1 <= port <= 65535:
        raise ValueError('invalid_camera_setup_port')
    policy = LocalCameraPolicy(runtime)
    # The same runtime owns accounts, documents, locks and the reserved secret
    # directory. No request or environment URL can choose an external location.
    if Path(app.state.accounts_db_path()).resolve().parent != policy.runtime:
        raise ValueError('camera_account_runtime_mismatch')
    install_camera_enrollment(app, directory=policy.directory,
        allowed_origin=f'http://127.0.0.1:{port}', host_policy=policy)
    app.state.camera_setup_enabled = True
    return True
