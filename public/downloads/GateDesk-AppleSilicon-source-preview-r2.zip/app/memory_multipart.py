"""Strict synchronous memory-only multipart component, deliberately uninstalled.

The caller owns scheduling, joins and the separate intake buffer. This function
never dispatches workers, closes intake leases, opens files or wraps UploadFile.
"""
from dataclasses import dataclass
from io import BytesIO
import re
import unicodedata

import python_multipart
from python_multipart import MultipartParser

MAX_BODY = 11 * 1024 * 1024
MAX_FILE = 10 * 1024 * 1024
MAX_CHUNK = 64 * 1024
TOKEN = rb"[!#$%&'*+.^_`|~0-9A-Za-z-]+"
BCHARS = set(b"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'()+_,-./:=? ")


class MultipartAdmissionError(Exception):
    def __init__(self, status, code):
        self.status, self.code = status, code
        super().__init__(code)


def _bad(code='invalid_multipart', status=400):
    raise MultipartAdmissionError(status, code)


@dataclass
class OwnedMemoryFile:
    filename: str
    content_type: str
    size: int
    file: BytesIO

    def close(self):
        self.file.close()


class _QuietLogger:
    def debug(self, *args, **kwargs): pass
    def warning(self, *args, **kwargs): pass
    def error(self, *args, **kwargs): pass


class _Envelope:
    """First closing marker decides; a later suffix cannot hide an epilogue."""
    def __init__(self, boundary):
        self.prefix = b'--' + boundary + b'\r\n'
        self.prefix_seen = 0
        self.marker = b'\r\n--' + boundary + b'--'
        self.tail = b''
        self.found = False
        self.suffix = b''

    def feed(self, data):
        n = min(len(data), len(self.prefix) - self.prefix_seen)
        if data[:n] != self.prefix[self.prefix_seen:self.prefix_seen+n]:
            _bad('invalid_opening')
        self.prefix_seen += n
        if self.found:
            if len(self.suffix) + len(data) > 2:
                _bad('invalid_epilogue')
            self.suffix += data
        else:
            window = self.tail + data  # One bounded chunk plus <=75 bytes.
            position = window.find(self.marker)
            if position < 0:
                self.tail = window[-(len(self.marker)-1):]
                return
            self.found = True
            self.suffix = window[position+len(self.marker):]
            self.tail = b''
        if len(self.suffix) > 2 or not b'\r\n'.startswith(self.suffix):
            _bad('invalid_epilogue')

    def finish(self):
        if (self.prefix_seen != len(self.prefix) or not self.found
                or self.suffix not in (b'', b'\r\n')):
            _bad('incomplete_multipart')


def _disposition(raw):
    """Bounded byte FSM; preserve duplicates before constructing a dictionary."""
    at, params = 0, {}
    def whitespace():
        nonlocal at
        while at < len(raw) and raw[at] in (32, 9): at += 1
    def token():
        nonlocal at
        match = re.match(TOKEN, raw[at:])
        if match is None: _bad('invalid_disposition')
        at += len(match[0])
        return match[0]
    whitespace()
    if token().lower() != b'form-data': _bad('invalid_disposition')
    while True:
        whitespace()
        if at == len(raw): break
        if raw[at] != 59: _bad('invalid_disposition')
        at += 1; whitespace()
        name = token().lower()
        if name not in (b'name', b'filename') or name in params:
            _bad('invalid_disposition')
        whitespace()
        if at >= len(raw) or raw[at] != 61: _bad('invalid_disposition')
        at += 1; whitespace()
        if at < len(raw) and raw[at] == 34:
            at += 1; start = at
            while at < len(raw) and raw[at] != 34:
                if raw[at] < 32 or raw[at] in (92, 127): _bad('invalid_disposition')
                at += 1
            if at == len(raw): _bad('invalid_disposition')
            value = raw[start:at]; at += 1
        else:
            value = token()
        params[name] = value
    if set(params) != {b'name', b'filename'} or params[b'name'] != b'file':
        _bad('invalid_disposition')
    name = params[b'filename']
    if not 1 <= len(name) <= 255: _bad('invalid_filename')
    try: filename = name.decode('utf-8', errors='strict')
    except UnicodeError: _bad('invalid_filename')
    if (filename in ('.', '..') or any(c in '/\\:' or unicodedata.category(c).startswith('C') for c in filename)):
        _bad('invalid_filename')
    return filename


class _Callbacks:
    def __init__(self):
        self.state = 'start'
        self.count = self.metadata = self.size = 0
        self.name = self.value = None
        self.value_started = False
        self.headers = {}
        self.file = None
        self.filename = None
        self.content_type = None

    def part_begin(self):
        if self.state != 'start': _bad('extra_part')
        self.state = 'headers'

    def header_begin(self):
        if self.state != 'headers' or self.name is not None: _bad()
        self.count += 1
        if self.count > 16: _bad('too_many_headers', 413)
        self._charge(2)
        self.name, self.value, self.value_started = bytearray(), bytearray(), False

    def _charge(self, amount):
        if amount > 8192 - self.metadata: _bad('metadata_too_large', 413)
        self.metadata += amount

    @staticmethod
    def _slice(data, start, end):
        if (type(data) is not bytes or type(start) is not int or type(end) is not int
                or not 0 <= start <= end <= len(data)):
            _bad()
        return memoryview(data)[start:end]

    def header_field(self, data, start, end):
        part = self._slice(data, start, end)
        if self.state != 'headers' or self.name is None or self.value_started: _bad()
        self._charge(len(part)); self.name.extend(part)

    def header_value(self, data, start, end):
        part = self._slice(data, start, end)
        if self.state != 'headers' or self.value is None: _bad()
        self._charge(len(part)); self.value_started = True; self.value.extend(part)

    def header_end(self):
        if self.state != 'headers' or self.name is None: _bad()
        name, value = bytes(self.name).lower(), bytes(self.value)
        if not re.fullmatch(TOKEN, name) or name in self.headers:
            _bad('invalid_part_header')
        if name not in (b'content-disposition', b'content-type'):
            _bad('unsupported_part_header')
        self.headers[name] = value
        self.name = self.value = None

    def headers_finished(self):
        if self.state != 'headers' or self.name is not None: _bad()
        self.filename = _disposition(self.headers.get(b'content-disposition', b''))
        content_type = self.headers.get(b'content-type', b'application/octet-stream').strip(b' \t').lower()
        if content_type not in (b'image/jpeg', b'image/png', b'image/webp', b'application/octet-stream'):
            _bad('unsupported_file_type', 415)
        self.content_type = content_type.decode('ascii')
        self.file = BytesIO()
        self.state = 'data'

    def part_data(self, data, start, end):
        piece = self._slice(data, start, end)
        if self.state != 'data': _bad()
        if len(piece) > MAX_FILE - self.size: _bad('file_too_large', 413)
        if self.file.write(piece) != len(piece): _bad('memory_write_failed', 503)
        self.size += len(piece)

    def part_end(self):
        if self.state != 'data': _bad()
        self.state = 'part_done'

    def end(self):
        if self.state != 'part_done': _bad()
        self.state = 'end'


def parse_memory_file(chunks, boundary, admitted_length, cancelled=None):
    """Parse synchronously; caller retains intake storage until real work ends."""
    callbacks = _Callbacks()
    transferred = False
    try:
        if python_multipart.__version__ != '0.0.32': _bad('unsupported_parser_version', 503)
        if (type(boundary) is not bytes or not 1 <= len(boundary) <= 70
                or boundary.endswith(b' ') or any(c not in BCHARS for c in boundary)):
            _bad('invalid_boundary')
        if type(admitted_length) is not int or not 0 <= admitted_length <= MAX_BODY:
            _bad('invalid_body_length', 413)
        envelope = _Envelope(boundary)
        names = ('part_begin', 'header_begin', 'header_field', 'header_value', 'header_end',
                 'headers_finished', 'part_data', 'part_end', 'end')
        parser = MultipartParser(boundary, {'on_'+name: getattr(callbacks, name) for name in names},
                                 max_size=MAX_BODY, max_header_count=16, max_header_size=8192)
        parser.logger = _QuietLogger()  # Instance only; no global logger changes.
        supplied = 0
        for data in chunks:
            if cancelled is not None and cancelled(): _bad('parse_cancelled', 499)
            if type(data) is not bytes or not 1 <= len(data) <= MAX_CHUNK: _bad('invalid_chunk')
            if len(data) > admitted_length - supplied: _bad('body_too_large', 413)
            supplied += len(data)
            envelope.feed(data)
            if parser.write(data) != len(data): _bad('parser_truncated')
        if cancelled is not None and cancelled(): _bad('parse_cancelled', 499)
        if supplied != admitted_length: _bad('body_length_mismatch')
        envelope.finish()
        parser.finalize()
        if callbacks.state != 'end' or callbacks.file is None or callbacks.size == 0:
            _bad('incomplete_multipart')
        callbacks.file.seek(0)
        result = OwnedMemoryFile(callbacks.filename, callbacks.content_type, callbacks.size, callbacks.file)
        transferred = True
        return result
    except Exception as error:
        if isinstance(error, MultipartAdmissionError): raise
        raise MultipartAdmissionError(400, 'invalid_multipart') from None
    finally:
        if not transferred and callbacks.file is not None:
            callbacks.file.close()
