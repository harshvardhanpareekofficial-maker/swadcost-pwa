"""Unregistered local owner enrollment endpoints; no camera transport.

Host must install accounts state, RuntimeOwner request admission and lifecycle
drain. All account/SQLite/DPAPI work here is owned off-loop work. Existing global
account middleware behavior is not modified by this optional installer.
"""
import json
from pathlib import Path
from urllib.parse import urlsplit
from weakref import WeakKeyDictionary

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import JSONResponse

from app import accounts
from app.camera_enrollment import CameraEnrollment, EnrollmentError, OwnerIdentity
from app.mobile_body import read_auth_body
from app.mobile_offload import owned_database_call
from app.runtime_resources import ResourceUnavailable
from app.upload_intake import UploadPool, IntakeError


# Only this installer records exact function identities for its three bounded
# handlers. This is a trusted-source inventory, not a general async opt-in API.
_OWNED_ENDPOINTS = WeakKeyDictionary()


def owned_endpoint_specs(app):
    return _OWNED_ENDPOINTS.get(app, ())


def _reply(value, status=200):
    return JSONResponse(value, status_code=status, headers={
        'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff'})


def _strict_object(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            raise ValueError()
        value[key] = item
    return value


def install_camera_enrollment(app, *, directory, allowed_origin, protection=None, host_policy=None):
    """Trusted-host installation only; path/origin/protection are never client data.

    Directory must be a distinct private production draft root, never the old
    research camera-supervisor root. Provisioning stays an explicit owner action.
    This function registers routes but does not open/create any database.
    """
    if app in _OWNED_ENDPOINTS:
        raise ValueError('camera_enrollment_already_installed')
    try:
        origin = urlsplit(allowed_origin)
        if (origin.scheme not in ('http', 'https') or origin.hostname not in
                ('localhost', '127.0.0.1', '::1') or origin.username or origin.password
                or origin.path or origin.query or origin.fragment
                or allowed_origin != f'{origin.scheme}://{origin.netloc}'
                or origin.netloc != origin.netloc.lower()
                or (origin.port is not None and not 1 <= origin.port <= 65535)):
            raise ValueError()
        root = Path(directory).resolve()
    except Exception:
        raise ValueError('invalid_camera_enrollment_host_binding') from None
    router = APIRouter(prefix='/api/camera-enrollment')
    body_pool = UploadPool()

    def boundary(request):
        # Duplicate security-sensitive headers fail closed rather than selecting
        # one differing value. Forwarded headers never establish peer identity.
        for key in ('host', 'x-gate-desk'):
            if len(request.headers.getlist(key)) != 1:
                return False
        origins = request.headers.getlist('origin')
        origin_ok = (origins == [allowed_origin] or
                     (not origins and request.method == 'GET'
                      and request.headers.getlist('sec-fetch-site') == ['same-origin']))
        return (accounts.local_peer(request)
                and request.scope.get('scheme') == origin.scheme
                and request.headers['host'] == origin.netloc
                and origin_ok
                and request.headers['x-gate-desk'] == 'local')

    def identity(request):
        # Called only inside owned synchronous workers, never on the event loop.
        if not accounts.enabled(request):
            raise HTTPException(403)
        user = accounts.require_owner(request)
        with accounts.database(request) as db:
            factory = db.execute('SELECT id FROM factory WHERE singleton=1').fetchone()
        if factory is None:
            raise HTTPException(403)
        return OwnerIdentity(user['id'], factory[0], user['role'], True, True)

    def perform(request, action, body):
        owner = identity(request)
        if host_policy is not None:
            host_policy.check()
        def result(draft, *, saved=False):
            if host_policy is None:
                return {'draft': draft}
            return {'draft': draft, **host_policy.status(saved=saved)}
        def authorize(_):
            return identity(request)
        options = dict(factory_id=owner.factory_id, authorize=authorize, protection=protection)
        if action == 'provision':
            service = CameraEnrollment.create_new(root, session=None, **options)
            return result(service.read(None))
        if action == 'read' and host_policy is not None and not root.exists():
            return result(None)
        service = CameraEnrollment(root/'camera-enrollment.sqlite3', **options)
        if action == 'read':
            return result(service.read(None))
        return result(service.save(None, **body), saved=True)

    async def dispatch(request, action):
        if not boundary(request):
            return _reply({'detail': 'local_owner_boundary_required'}, 403)
        if request.scope.get('query_string'):
            return _reply({'detail': 'invalid_enrollment_request'}, 400)
        try:
            # Reject unauthorized callers before receiving secret-bearing bodies.
            await owned_database_call(lambda: identity(request))
            body = None
            if action != 'read':
                if (len(request.headers.getlist('content-type')) != 1
                        or request.headers['content-type'].lower() != 'application/json'
                        or len(request.headers.getlist('content-length')) > 1
                        or request.headers.get('content-encoding')
                        or request.headers.get('transfer-encoding')):
                    return _reply({'detail': 'invalid_enrollment_request'}, 400)
                length = request.headers.get('content-length')
                if length is not None:
                    if not length.isascii() or not length.isdigit():
                        return _reply({'detail': 'invalid_enrollment_request'}, 400)
                    if len(length) > 10 or int(length) > 4096:
                        return _reply({'detail': 'enrollment_body_too_large'}, 413)
                raw = await read_auth_body(request.receive, body_pool)
                if length is not None and len(raw) != int(length):
                    return _reply({'detail': 'invalid_enrollment_body'}, 400)
                try:
                    body = json.loads(raw, object_pairs_hook=_strict_object,
                                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError()))
                    keys = set() if action == 'provision' else {
                        'draft', 'username', 'password', 'expected_revision'}
                    if not isinstance(body, dict) or set(body) != keys:
                        raise ValueError()
                except (ValueError, TypeError, RecursionError):
                    return _reply({'detail': 'invalid_enrollment_request'}, 422)
            return _reply(await owned_database_call(lambda: perform(request, action, body)))
        except HTTPException as exc:
            return _reply({'detail': 'owner_required'}, 401 if exc.status_code == 401 else 403)
        except IntakeError as exc:
            return _reply({'detail': 'invalid_enrollment_body'}, exc.status)
        except EnrollmentError as exc:
            code = str(exc)
            if code == 'owner_required':
                return _reply({'detail': 'owner_required'}, 403)
            if code == 'revision_conflict':
                return _reply({'detail': 'revision_conflict'}, 409)
            if code in {'invalid_camera_draft', 'invalid_camera_address', 'invalid_camera_port',
                        'invalid_stream_path', 'invalid_revision', 'invalid_credentials'}:
                return _reply({'detail': 'invalid_enrollment_request'}, 422)
            return _reply({'detail': 'enrollment_unavailable'}, 503)
        except ResourceUnavailable:
            return _reply({'detail': 'enrollment_unavailable'}, 503)
        except Exception:
            return _reply({'detail': 'enrollment_unavailable'}, 503)

    @router.get('/draft')
    async def read(request: Request):
        return await dispatch(request, 'read')

    @router.post('/provision')
    async def provision(request: Request):
        return await dispatch(request, 'provision')

    @router.post('/draft')
    async def save(request: Request):
        return await dispatch(request, 'save')

    app.include_router(router)
    _OWNED_ENDPOINTS[app] = tuple(
        (route.endpoint, route.path, frozenset(route.methods)) for route in router.routes)
    return router
