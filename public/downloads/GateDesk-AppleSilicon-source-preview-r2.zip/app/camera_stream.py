"""Bounded one-connection H.264/IDR packet segmentation. Local quarantine only.

No live camera is enabled here. The caller enforces reviewed source-clock/scope,
authorization, private credentials, process ownership and external stop bridging.
"""
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from fractions import Fraction
import hashlib
import json
import os
from pathlib import Path
import re
import time
import uuid

import av

from app.camera_ingest import IngestError, RTSPConfig, _atomic_json, _identifier, probe_video
from ml.video_triage import sha256
from app.recorder_progress import progress_lifetime


def _utc():
    return datetime.now(timezone.utc).isoformat()


def _ratio(value):
    return [value.numerator, value.denominator]


@dataclass(frozen=True)
class StreamLimits:
    target_seconds: int = 180
    max_segments: int = 10
    max_session_seconds: int = 1800
    keyframe_overrun_seconds: int = 10
    max_packet_bytes: int = 16 * 1024**2
    max_packets_per_segment: int = 100000

    def validate(self):
        for name, low, high in (("target_seconds", 1, 900), ("max_segments", 1, 10),
                               ("max_session_seconds", 1, 1800),
                               ("keyframe_overrun_seconds", 0, 10),
                               ("max_packet_bytes", 1, 16 * 1024**2),
                               ("max_packets_per_segment", 1, 100000)):
            if type(getattr(self, name)) is not int or not low <= getattr(self, name) <= high:
                raise IngestError("invalid_stream_bound")


def _annex_nals(data):
    starts = list(re.finditer(b"\x00\x00(?:\x00)?\x01", data))
    if not starts:
        raise IngestError("unsupported_h264_packetization")
    return [data[m.end():starts[i+1].start() if i+1 < len(starts) else len(data)]
            for i, m in enumerate(starts)]


def _avcc_nals(data, length_size):
    result, pos = [], 0
    while pos < len(data):
        if pos + length_size > len(data):
            raise IngestError("truncated_h264_nal")
        size = int.from_bytes(data[pos:pos+length_size], "big")
        pos += length_size
        if size < 1 or pos + size > len(data):
            raise IngestError("truncated_h264_nal")
        result.append(data[pos:pos+size])
        pos += size
    return result


def _h264_parameters(extradata):
    if not extradata:
        raise IngestError("missing_h264_parameter_sets")
    if extradata[0] == 1:
        try:
            length_size = (extradata[4] & 3) + 1
            pos, nals = 6, []
            for count in (extradata[5] & 31,):
                for _ in range(count):
                    size = int.from_bytes(extradata[pos:pos+2], "big"); pos += 2
                    nals.append(extradata[pos:pos+size]); pos += size
            count = extradata[pos]; pos += 1
            for _ in range(count):
                size = int.from_bytes(extradata[pos:pos+2], "big"); pos += 2
                nals.append(extradata[pos:pos+size]); pos += size
            if pos > len(extradata):
                raise ValueError()
        except (IndexError, ValueError):
            raise IngestError("invalid_h264_parameter_sets") from None
    else:
        length_size, nals = None, _annex_nals(extradata)
    parameters = {n for n in nals if n and n[0] & 31 in {7, 8}}
    if not {7, 8}.issubset({n[0] & 31 for n in parameters}):
        raise IngestError("missing_h264_parameter_sets")
    return length_size, parameters


def _first_mb(nal):
    data = nal[1:].replace(b"\x00\x00\x03", b"\x00\x00")
    bits = "".join(f"{b:08b}" for b in data[:16])
    zeros = len(bits) - len(bits.lstrip("0"))
    if zeros > 31 or len(bits) < 2 * zeros + 1:
        raise IngestError("invalid_h264_slice")
    return int(bits[zeros:2*zeros+1], 2) - 1


def _idr_access_unit(payload, length_size, parameters):
    nals = _avcc_nals(payload, length_size) if length_size else _annex_nals(payload)
    if any(n and n[0] & 31 in {7, 8} and n not in parameters for n in nals):
        raise IngestError("h264_parameter_change")
    slices = [n for n in nals if n and n[0] & 31 in {1, 5}]
    # Supported demux contract: one complete picture access unit per packet,
    # potentially multiple slices. Continuation-only/multiple-picture packets
    # are held, not guessed into independently decodable segments.
    if not slices or sum(_first_mb(n) == 0 for n in slices) != 1:
        raise IngestError("unsupported_h264_access_unit")
    types = {n[0] & 31 for n in slices}
    if len(types) != 1:
        raise IngestError("mixed_h264_access_unit")
    return types == {5}


def capture_stream(store, config: RTSPConfig, *, session_id, authorization_id,
                   clock_evidence_sha256, limits=None, stop=None, on_event=None, progress=None):
    """One RTSP input open; caller must gate configuration/source clock first."""
    limits = limits or StreamLimits(target_seconds=config.segment_seconds)
    config.validate(); limits.validate()
    # Resolve before network; no raw backend messages or URI in any receipt.
    endpoint = config.resolve_endpoint()
    with av.logging.Capture(local=True):
        return segment_input(None, store, camera_id=config.camera_id,
            session_id=session_id, authorization_id=authorization_id,
            clock_evidence_sha256=clock_evidence_sha256, limits=limits,
            stop=stop, on_event=on_event, progress=progress,
            _input_factory=lambda: av.open(endpoint, "r", options={"rtsp_transport": "tcp"},
                timeout=(config.connect_timeout_seconds, config.read_timeout_seconds)))


def segment_input(incoming, store, *, camera_id, session_id, authorization_id,
                  clock_evidence_sha256, limits=None, stop=None, on_event=None, _input_factory=None, progress=None):
    """Consume one already-open input. Tests use generated local H.264 fixtures."""
    limits = limits or StreamLimits()
    limits.validate()
    for value in (camera_id, session_id, authorization_id):
        _identifier(value)
    if not re.fullmatch(r"[0-9a-f]{64}", clock_evidence_sha256):
        raise IngestError("invalid_clock_evidence_hash")
    session_path = store.root / "sessions" / (session_id + ".json")
    events_dir = store.root / "sessions" / session_id
    with store.segment_session(), progress_lifetime(progress):
        if session_path.exists() or events_dir.exists():
            raise IngestError("stream_session_already_registered")
        store._check_stop(stop); store._space()
        events_dir.mkdir(parents=True)
        state = dict(version=1, session_id=session_id, camera_id=camera_id,
                     authorization_id=authorization_id, clock_evidence_sha256=clock_evidence_sha256,
                     state="running", started_at=_utc(), limits=asdict(limits),
                     same_connection=_input_factory is None, connections_opened=0 if _input_factory else 1, segments=[], events=[],
                     packet_count=0, written_packet_count=0, held_packet_count=0,
                     boundary_packets_not_recorded=0, gaps=[], continuity_verified=False,
                     source_clock_verified=False, split="quarantine_unassigned",
                     truth=None, model_exposure=False, training_admitted=False)
        def save():
            _atomic_json(session_path, state)
        def emit(kind, record=None, extra=None):
            event = dict(version=1, session_id=session_id, sequence=len(state["events"])+1,
                         camera_id=camera_id, authorization_id=authorization_id,
                         clock_evidence_sha256=clock_evidence_sha256,
                         kind=kind, observed_at=_utc(), same_connection=state["same_connection"])
            if record:
                receipt_path = store._path(record["attempt_id"])
                event.update(attempt_id=record["attempt_id"],
                             receipt_path=receipt_path.relative_to(store.root).as_posix(),
                             receipt_sha256=sha256(receipt_path))
            event.update(extra or {})
            event_path = events_dir / f"event-{event['sequence']:05d}.json"
            _atomic_json(event_path, event)
            state["events"].append({"path":event_path.relative_to(store.root).as_posix(),
                                    "sha256":sha256(event_path), "sequence":event["sequence"], "kind":kind})
            save()
            if on_event is not None:
                try:
                    if on_event(event) is False:
                        raise ValueError()
                except Exception:
                    raise IngestError("event_queue_pressure") from None
            return event
        save()
        output = ledger = active = None
        packet_rows = []
        start_dts = start_mono = first_session_dts = last_dts = last_duration = None
        previous_extradata = None
        session_mono = time.monotonic()
        outcome, reason = "held", "stream_ended_before_boundary"
        received_first = received_last = None
        packet_coverage = True

        def close_output():
            nonlocal output, ledger
            try:
                if output is not None:
                    closing, output = output, None
                    closing.close()
            finally:
                if ledger is not None:
                    closing, ledger = ledger, None
                    try:
                        closing.flush(); os.fsync(closing.fileno())
                    finally:
                        closing.close()

        def begin(video, dts):
            nonlocal active, output, ledger, packet_rows, start_dts, start_mono
            active = store.begin_segment_locked(attempt_id=str(uuid.uuid4()), camera_id=camera_id,
                request_identity={"session_id":session_id,"authorization_id":authorization_id,
                                  "clock_evidence_sha256":clock_evidence_sha256,
                                  "ordinal":len(state["segments"])+1})
            packet_rows = []; start_dts = dts; start_mono = time.monotonic()
            emit("segment_registered", active)
            output = av.open(str(store.root / active["staging_file"]), "w", format="matroska")
            target = output.add_stream_from_template(video)
            ledger_path = events_dir / (active["attempt_id"] + "-packets.jsonl")
            ledger = ledger_path.open("x", encoding="utf-8")
            return target, ledger_path

        def seal(ledger_path):
            nonlocal active
            close_output()
            store._check_stop(stop)
            part = store.root / active["staging_file"]
            metadata = {**probe_video(part), "codec_boundary_policy":"h264_idr_with_parameter_sets",
                "native_video_packets_remuxed":True,"audio_retained":False,
                "packet_count":len(packet_rows),"first_packet":packet_rows[0],"last_packet":packet_rows[-1],
                "packet_ledger":ledger_path.relative_to(store.root).as_posix(),
                "packet_ledger_sha256":sha256(ledger_path),"same_connection":True,
                "first_packet_received_at":packet_rows[0]["received_at"],
                "last_packet_received_at":packet_rows[-1]["received_at"],
                "first_packet_connection_elapsed_seconds":packet_rows[0]["connection_elapsed_seconds"],
                "last_packet_connection_elapsed_seconds":packet_rows[-1]["connection_elapsed_seconds"],
                "packet_timestamp_contiguous":packet_coverage,
                "container_timestamps_not_source_authority":True,
                "timestamp_policy":"source integers and rational time bases preserved in packet ledger; libav container rescaling is not camera time",
                "source_clock_verified":False,"continuity_verified":False}
            record = store.seal_segment_locked(active["attempt_id"], metadata)
            state["segments"].append({"attempt_id":record["attempt_id"],"state":record["state"],
                                      "source_sha256":record["source_sha256"]})
            active = None
            emit("segment_sealed", record, {"accepted":True,"source_sha256":record["source_sha256"],
                 "packet_count":metadata["packet_count"],"first_packet_received_at":metadata["first_packet_received_at"],
                 "last_packet_received_at":metadata["last_packet_received_at"],"continuity_verified":False})
            if progress is not None:
                progress.publish(state["written_packet_count"], record["attempt_id"])

        try:
            if _input_factory is not None:
                store._check_stop(stop)
                incoming = _input_factory()
                state["connections_opened"] = 1
                state["same_connection"] = True
                state["connection_opened_at"] = _utc()
                save()
            if not incoming.streams.video or incoming.streams.video[0].codec_context.name != "h264":
                raise IngestError("unsupported_stream_codec")
            video = incoming.streams.video[0]
            previous_extradata = bytes(video.codec_context.extradata or b"")
            length_size, parameters = _h264_parameters(previous_extradata)
            for packet in incoming.demux(video):
                store._check_stop(stop)
                if packet.size == 0:
                    continue
                now_mono = time.monotonic()
                state["packet_count"] += 1
                if now_mono - session_mono >= limits.max_session_seconds:
                    reason = "session_time_budget"; break
                if packet.size > limits.max_packet_bytes:
                    raise IngestError("packet_byte_limit")
                received_at = _utc()
                received_first = received_first or received_at; received_last = received_at
                if packet.dts is None or packet.pts is None or packet.time_base is None:
                    state["held_packet_count"] += 1
                    raise IngestError("missing_source_timestamp")
                source_pts, source_dts, source_duration = packet.pts, packet.dts, packet.duration
                tb = Fraction(packet.time_base); dts = source_dts * tb
                if last_dts is not None and dts <= last_dts:
                    state["held_packet_count"] += 1
                    raise IngestError("nonincreasing_source_dts")
                if bytes(video.codec_context.extradata or b"") != previous_extradata:
                    state["held_packet_count"] += 1
                    raise IngestError("h264_parameter_change")
                payload = bytes(packet)
                try:
                    idr = _idr_access_unit(payload, length_size, parameters)
                except IngestError:
                    state["held_packet_count"] += 1
                    raise
                if last_dts is not None:
                    if not last_duration:
                        packet_coverage = False
                        state["gaps"].append({"packet_sequence":state["packet_count"],"source_gap_seconds":None,
                                               "reason":"missing_packet_duration"})
                    else:
                        gap = dts - (last_dts + last_duration)
                        if gap:
                            packet_coverage = False
                            state["gaps"].append({"packet_sequence":state["packet_count"],
                                                   "source_gap_rational":_ratio(gap),"continuity_verified":False})
                last_dts, last_duration = dts, source_duration * tb if source_duration else None
                first_session_dts = first_session_dts if first_session_dts is not None else dts
                if active is None:
                    if now_mono - session_mono > limits.keyframe_overrun_seconds:
                        raise IngestError("initial_idr_timeout")
                    if not idr:
                        state["held_packet_count"] += 1
                        if now_mono - session_mono > limits.keyframe_overrun_seconds or dts-first_session_dts > limits.keyframe_overrun_seconds:
                            raise IngestError("initial_idr_timeout")
                        continue
                    target, ledger_path = begin(video, dts)
                elif (dts-start_dts > limits.target_seconds+limits.keyframe_overrun_seconds or
                      now_mono-start_mono > limits.target_seconds+limits.keyframe_overrun_seconds):
                    raise IngestError("segment_idr_timeout")
                elif dts - start_dts >= limits.target_seconds and idr:
                    seal(ledger_path)
                    if len(state["segments"]) >= limits.max_segments:
                        state["boundary_packets_not_recorded"] += 1
                        outcome, reason = "completed", "segment_budget_complete"
                        break
                    if dts-first_session_dts >= limits.max_session_seconds:
                        state["boundary_packets_not_recorded"] += 1
                        outcome, reason = "completed", "session_time_budget"
                        break
                    target, ledger_path = begin(video, dts)
                if dts-first_session_dts >= limits.max_session_seconds:
                    state["held_packet_count"] += 1
                    reason = "session_time_budget"; break
                if len(packet_rows) >= limits.max_packets_per_segment:
                    raise IngestError("segment_packet_limit")
                row = {"sequence":state["packet_count"],"pts":source_pts,"dts":source_dts,
                       "duration":source_duration,"time_base":_ratio(tb),"idr":idr,
                       "payload_sha256":hashlib.sha256(payload).hexdigest(),
                       "received_at":received_at,"connection_elapsed_seconds":round(now_mono-session_mono,6)}
                packet.stream = target
                output.mux(packet)
                row.update(mux_pts=packet.pts,mux_dts=packet.dts,mux_time_base=_ratio(Fraction(packet.time_base)))
                ledger.write(json.dumps(row,sort_keys=True)+"\n")
                packet_rows.append(row)
                state["written_packet_count"] += 1
                if progress is not None:
                    progress.publish(state["written_packet_count"])
                store._space()
                if (store.root / active["staging_file"]).stat().st_size > store.max_bytes:
                    raise IngestError("empty_or_oversize_source")
        except BaseException as exc:
            reason = str(exc) if isinstance(exc, IngestError) else "interrupted" if isinstance(exc,(KeyboardInterrupt,SystemExit)) else "stream_read_or_mux_failed"
            outcome = "interrupted" if reason == "interrupted" else "held"
        finally:
            try:
                close_output()
            except Exception:
                reason, outcome = "stream_close_failed", "held"
            if active is not None:
                record = store.interrupt_segment_locked(active["attempt_id"],reason)
                state["segments"].append({"attempt_id":record["attempt_id"],"state":record["state"]})
                try:
                    emit("segment_interrupted",record)
                except IngestError:
                    pass
            if _input_factory is not None and incoming is not None:
                try:
                    incoming.close()
                except Exception:
                    reason, outcome = "stream_close_failed", "held"
            # Every nonempty packet observed by this consumer is either written,
            # explicitly excluded at a terminal boundary, or retained as held.
            state["held_packet_count"] = (state["packet_count"] - state["written_packet_count"]
                                          - state["boundary_packets_not_recorded"])
            state.update(state=outcome,reason=reason,ended_at=_utc(),
                         first_packet_received_at=received_first,last_packet_received_at=received_last,
                         connection_elapsed_seconds=round(time.monotonic()-session_mono,6))
            state["gaps"].append({"reason":"connection_ended","source_gap_seconds":None,
                                   "continuity_verified":False})
            save()
            try:
                emit("connection_ended",extra={"state":outcome,"reason":reason})
            except IngestError:
                pass
        return state
