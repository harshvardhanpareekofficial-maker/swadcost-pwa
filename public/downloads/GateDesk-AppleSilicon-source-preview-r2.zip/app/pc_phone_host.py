"""Explicit assembly of an already-imported owner PC app and dormant phone API.

No app.main import, owner install, provisioning, environment edits or transport.
The host must supply its already-installed owner and a fresh, never-wrapped main
app generation. Returned pc_app is already admission wrapped; do not wrap again.
Restart/recovery requires a fresh app generation, not an owner swap on old routes.
Both apps belong on that owner's same loop. Mutable binding checks are diagnostic
fail-closed guards, not a sandbox against hostile Python or filesystem changes.
"""
from dataclasses import dataclass, field, replace
from pathlib import Path
import sys
import threading
from types import ModuleType
from weakref import WeakKeyDictionary

from fastapi import FastAPI
from fastapi.routing import _iter_routes_with_context
from app import runtime_owner as ro
from app.document_store import DocumentStore
from app.mobile_config import parse_mobile_config
from app.mobile_service import compose_mobile_service


_CLAIMED = WeakKeyDictionary()
_CLAIM_LOCK = threading.Lock()
_LOCK_TYPE = type(threading.Lock())


def _has_owner_wrapper(app):
    for route, context in _iter_routes_with_context(app.routes):
        for target in (route, context):
            call = getattr(getattr(target, 'dependant', None), 'call', None)
            seen = set()
            while call is not None and id(call) not in seen:
                seen.add(id(call))
                code = getattr(call, '__code__', None)
                if code is not None and code.co_filename == ro.wrap_application.__code__.co_filename and code.co_name in ('wrapped', 'async_wrapped'):
                    return True
                call = getattr(call, '__wrapped__', None)
    return False


@dataclass(frozen=True)
class PcPhoneHost:
    pc_app: object = field(repr=False)
    phone_service: object = field(repr=False)
    document_store: object = field(repr=False)
    owner: object = field(repr=False)


def compose_pc_phone_host(settings=None, *, main_module=None, owner=None, sessions_path=None):
    if parse_mobile_config(settings) is None:
        return None
    if (type(main_module) is not ModuleType or main_module.__name__ != 'app.main'
            or sys.modules.get('app.main') is not main_module):
        raise ValueError('pc_phone_existing_main_required')
    if type(owner) is not ro.RuntimeOwner or ro.current_owner() is not owner or not owner.accepting:
        raise ValueError('pc_phone_installed_owner_required')
    app = getattr(main_module, 'app', None)
    if not isinstance(app, FastAPI):
        raise ValueError('pc_phone_main_app_required')
    if (getattr(app.state, 'accounts_enabled', None) is not True
            or getattr(app.state, 'accounts_owner_only', None) is not True):
        raise ValueError('pc_phone_owner_only_accounts_required')
    account_path = getattr(app.state, 'accounts_db_path', None)
    document_lock = getattr(main_module, 'document_lock', None)
    if not callable(account_path) or type(document_lock) is not _LOCK_TYPE:
        raise ValueError('pc_phone_existing_bindings_required')
    try:
        db_raw, index_raw = main_module.DB, main_module.DOCUMENT_FILE
        db = Path(db_raw).resolve(strict=True)
        index = Path(index_raw).resolve(strict=True)
        accounts = Path(account_path()).resolve(strict=True)
        expected = db.with_name('accounts.sqlite3').resolve(strict=True)
        if accounts != expected or Path(account_path()).resolve(strict=True) != accounts:
            raise ValueError('pc_phone_account_path_mismatch')
    except (AttributeError, OSError, TypeError):
        raise ValueError('pc_phone_existing_storage_required') from None
    with _CLAIM_LOCK:
        if app in _CLAIMED or _has_owner_wrapper(app):
            raise ValueError('pc_phone_fresh_unwrapped_main_required')
    store = DocumentStore(index, document_lock)
    service = compose_mobile_service(settings, accounts_path=accounts, sessions_path=sessions_path,
                                     document_store=store, owner=owner, report_db=db)

    def binding_matches():
        return (sys.modules.get('app.main') is main_module and main_module.app is app
                and main_module.DB == db_raw and main_module.DOCUMENT_FILE == index_raw
                and main_module.document_lock is document_lock
                and app.state.accounts_enabled is True and app.state.accounts_owner_only is True
                and app.state.accounts_db_path is account_path and ro.current_owner() is owner)

    def guarded(target):
        async def invoke(scope, receive, send):
            # Shutdown must reach the original lifecycle even after binding drift.
            if scope['type'] == 'http':
                try:
                    matches = binding_matches()
                except (AttributeError, TypeError):
                    matches = False
                if not matches:
                    owner.fail('pc_phone_binding_changed')
                    owner.request_stop()
                    await send({'type': 'http.response.start', 'status': 503,
                                'headers': [(b'cache-control', b'no-store')]})
                    return await send({'type': 'http.response.body', 'body': b'Application binding changed.'})
            return await target(scope, receive, send)
        return invoke

    # wrap_application mutates route callables. Reserve the fresh generation
    # exactly once, including a partial wrapping failure; never silently retry.
    with _CLAIM_LOCK:
        if app in _CLAIMED or _has_owner_wrapper(app):
            raise ValueError('pc_phone_fresh_unwrapped_main_required')
        _CLAIMED[app] = True
        pc_app = ro.wrap_application(app, owner)
    service = replace(service, app=guarded(service.app))
    return PcPhoneHost(guarded(pc_app), service, store, owner)
