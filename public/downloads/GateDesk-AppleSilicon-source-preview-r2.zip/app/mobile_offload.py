"""Remote DB offload using existing physical-worker ownership; not activated."""
from app.runtime_owner import current_owner
from app.runtime_resources import ResourceUnavailable


async def owned_database_call(function):
    owner = current_owner()
    if owner is None:
        raise ResourceUnavailable('mobile_owner_required')
    result = []

    async def cleanup():
        # All DB handles must already be closed by the synchronous function.
        # Resource coordinator invokes this only after the physical thread joins.
        pass

    lease = owner.acquire_request_resource('mobile-db', cleanup)
    def work(cancel):
        try:
            if not cancel.is_set():
                try:
                    result.append((True, function()))
                except Exception as exc:
                    result.append((False, exc))
        finally:
            lease.request_close()
    try:
        lease.start_worker(work)
        await lease.wait_closed()
        if not result:
            raise ResourceUnavailable('mobile_work_not_started')
        success, value = result[0]
        if not success:
            raise value
        return value
    finally:
        # Cancellation ends observation only; owner retains the lease and worker.
        lease.request_close()
