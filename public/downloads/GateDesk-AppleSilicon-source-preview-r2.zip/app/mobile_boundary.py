"""Isolated API boundary; NOT installed in the launcher or local application.

Only for a direct TLS ASGI server with proxy headers disabled. The resolver must
look up an opaque remote cookie and recheck active membership on every request.
Never construct Session from client role/factory headers. A role=None session
is a short-lived pre-login CSRF challenge, not authenticated membership.
"""
from dataclasses import dataclass
import hmac
import math
import re
import time

from app.mobile_policy import remote_api_allowed


@dataclass(frozen=True)
class RemoteSession:
    role: str | None
    factory_id: str
    audience: str
    csrf: str
    expires_at: float
    user_id: str | None = None


class MobileBoundary:
    def __init__(self, app, config, resolve_session, *, clock=time.time):
        self.app, self.config, self.resolve = app, config, resolve_session
        self.clock = clock

    async def __call__(self, scope, receive, send):
        if scope['type'] == 'lifespan':
            return await self.app(scope, receive, send)
        if scope['type'] == 'websocket':
            return await send({'type': 'websocket.close', 'code': 1008})
        if scope['type'] != 'http':
            raise ValueError('unsupported_mobile_scope')

        async def deny():
            body = b'{"detail":"Remote access denied."}'
            await send({'type': 'http.response.start', 'status': 403,
                        'headers': [(b'content-type', b'application/json'),
                                    (b'cache-control', b'no-store')]})
            await send({'type': 'http.response.body', 'body': body})

        config = self.config
        headers = scope.get('headers', [])
        def single(name):
            values = [v for k, v in headers if k.lower() == name]
            return values[0] if len(values) == 1 else None

        if (config is None or scope.get('scheme') != 'https'
                or scope.get('root_path', '') != ''
                or single(b'host') != config.canonical_origin[8:].encode('ascii')):
            return await deny()
        method, path, raw = scope.get('method'), scope.get('path'), scope.get('raw_path')
        # Cookie ambiguity is rejected before the resolver can choose a value.
        if len([1 for k, _ in headers if k.lower() == b'cookie']) > 1:
            return await deny()
        session = await self.resolve(scope)
        if session is not None:
            if (type(session) is not RemoteSession
                    or session.factory_id != config.factory_id
                    or session.audience != config.canonical_origin
                    or type(session.expires_at) not in (int, float)
                    or not math.isfinite(session.expires_at)
                    or session.expires_at <= self.clock()):
                return await deny()
        role = session.role if session else None
        if not remote_api_allowed(method, path, role, raw_path=raw):
            return await deny()
        if method == 'POST':
            csrf = single(b'x-gate-desk-csrf')
            if (session is None or single(b'origin') != config.canonical_origin.encode('ascii')
                    or type(session.csrf) is not str
                    or not re.fullmatch(r'[A-Za-z0-9_-]{43}', session.csrf)
                    or not isinstance(csrf, bytes)
                    or not hmac.compare_digest(csrf, session.csrf.encode('ascii'))):
                return await deny()
        # Downstream must consume this server-resolved identity, not client role data.
        child = dict(scope)
        child['state'] = dict(scope.get('state', {}), mobile_session=session)
        await self.app(child, receive, send)
