"""Bounded, read-only single-factory document projection and verified bytes."""
import hashlib
import json
from pathlib import Path
import re


class DocumentReadStore:
    def __init__(self, index):
        self.index = Path(index).absolute()

    @staticmethod
    def _bytes(path, cap):
        if path.is_symlink() or (hasattr(path, 'is_junction') and path.is_junction()):
            raise ValueError('linked_document_path')
        with path.open('rb') as stream:
            data = stream.read(cap + 1)
        if len(data) > cap:
            raise ValueError('document_read_limit')
        return data

    def _rows(self):
        # Missing index is not proof of an empty factory.
        rows = json.loads(self._bytes(self.index, 8*1024*1024))
        if type(rows) is not list or len(rows) > 10000:
            raise ValueError('document_index_invalid')
        ids = []
        for row in rows:
            if (type(row) is not dict or type(row.get('id')) is not str
                    or not re.fullmatch(r'[A-Za-z0-9_-]{1,128}', row['id'])):
                raise ValueError('document_index_invalid')
            ids.append(row['id'])
        if len(set(ids)) != len(ids): raise ValueError('duplicate_document_id')
        return rows

    def page(self, offset=0, selected=None):
        if type(offset) is not int or not 0 <= offset <= 10000:
            raise ValueError('invalid_document_offset')
        rows = sorted(self._rows(), key=lambda row: row['id'])
        if selected is not None:
            if type(selected) is not str or not re.fullmatch(r'[A-Za-z0-9_-]{1,128}', selected):
                raise ValueError('invalid_selected_document')
            position=next((i for i,row in enumerate(rows) if row['id']==selected),None)
            if position is None: raise FileNotFoundError()
            offset=(position//100)*100
        result=[]
        for row in rows[offset:offset+100]:
            projected={}
            for key in ('id','status','number','direction','date_raw','carrier','reviewed_at','imported_at'):
                value=row.get(key,'')
                if type(value) is not str or len(value)>160: raise ValueError('document_field_invalid')
                projected[key]=value
            lines=row.get('lines',[])
            if type(lines) is not list or len(lines)>30: raise ValueError('document_lines_invalid')
            projected['lines']=[]
            for line in lines:
                if type(line) is not dict: raise ValueError('document_line_invalid')
                selected={k:line.get(k,'') for k in ('id','material','quantity','unit','weight_kg')}
                if type(selected['quantity']) is not int or not 1<=selected['quantity']<=10000:
                    raise ValueError('document_quantity_invalid')
                if any(type(v) is not str or len(v)>160 for k,v in selected.items() if k!='quantity'):
                    raise ValueError('document_line_invalid')
                projected['lines'].append(selected)
            result.append(projected)
        return {'documents':result,'total':len(rows),'offset':offset,'limit':100}

    def image(self, identifier, original=False):
        row=next((r for r in self._rows() if r['id']==identifier),None)
        if row is None: raise FileNotFoundError()
        source=row.get('source',{})
        if type(source) is not dict: raise ValueError('document_source_invalid')
        suffix=source.get('extension') if original else 'png'
        if suffix not in ('png','jpg','webp'): raise ValueError('document_format_invalid')
        folder=self.index.parent/('gatepass-originals' if original else 'gatepasses')
        if folder.is_symlink() or (hasattr(folder,'is_junction') and folder.is_junction()):
            raise ValueError('linked_document_path')
        path=folder/(identifier+'.'+suffix)
        if not path.resolve().is_relative_to(self.index.parent.resolve()): raise ValueError('document_path_invalid')
        data=self._bytes(path,10*1024*1024 if original else 64*1024*1024)
        expected=source.get('sha256' if original else 'preview_sha256')
        if type(expected) is not str or hashlib.sha256(data).hexdigest()!=expected:
            raise ValueError('document_checksum_mismatch')
        return data, {'jpg':'image/jpeg','png':'image/png','webp':'image/webp'}[suffix]
