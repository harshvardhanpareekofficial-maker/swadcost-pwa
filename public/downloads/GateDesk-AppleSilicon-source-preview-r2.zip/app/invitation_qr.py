"""Local-only QR rendering. Tokens never go to an external QR service."""
import base64
import io
from urllib.parse import urlsplit

import qrcode
from qrcode.image.pil import PilImage


def presentation(result, origin=None):
    result = dict(result, join_url=None, qr_data_url=None)
    if origin is None:
        return result
    url = urlsplit(origin)
    if (url.scheme != 'https' or not url.hostname or url.username or url.password
            or url.path or url.query or url.fragment):
        raise ValueError('A configured HTTPS factory origin is required')
    token = result['token']
    import re
    if not re.fullmatch(r'[A-Za-z0-9_-]{43}', token):
        raise ValueError('Invalid invitation token')
    link = origin+'/#join='+token
    # URL fragment avoids sending the token in HTTP navigation/access logs.
    qr = qrcode.QRCode(error_correction=qrcode.constants.ERROR_CORRECT_M, border=4, box_size=8)
    qr.add_data(link); qr.make(fit=True)
    output = io.BytesIO()
    qr.make_image(image_factory=PilImage, fill_color='black', back_color='white').save(output, format='PNG')
    return dict(result, join_url=link,
                qr_data_url='data:image/png;base64,'+base64.b64encode(output.getvalue()).decode('ascii'))
