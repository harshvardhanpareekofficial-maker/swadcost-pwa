"""Local recorder lifecycle API; capture remains privately configured and gated."""
from app.runtime_owner import start_thread, start_process, process_finished, forced_process_stop, register_queue
from pathlib import Path
import threading
from typing import Literal
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router=APIRouter(prefix='/api/recorder')

class DirectResume(BaseModel):
    direct_user_confirmation: Literal[True]

class RecorderService:
    def __init__(self, runtime):
        self.runtime=Path(runtime)
        self.supervisor=None
        self.error=None
        self.health_stop=threading.Event()
        self.health_thread=None
        self.health_state='not_started'
        self._health_guard=threading.RLock()
        self._health_adapter=None
        self._health_outbox=None
        self._health_suspended=False

    def start(self):
        try:
            from app.camera_supervisor import CameraSupervisor
            self.supervisor=CameraSupervisor(self.runtime)
            self.supervisor.start()
            self.health_thread=threading.Thread(target=self._health_loop,name='gate-camera-health',daemon=True)
            start_thread(self.health_thread, self.health_stop.set)
        except Exception:
            # No backend exceptions: they may contain endpoint credentials.
            self.error='recorder_start_failed'

    def status(self):
        if self.error or self.supervisor is None:
            return {'state':'needs_attention','error_code':self.error or 'recorder_not_started',
                    'camera_connected':False,'source_clock_verified':False}
        try:
            return {**self.supervisor.status(), 'health_bridge_state':self.health_state}
        except Exception:
            return {'state':'needs_attention','error_code':'recorder_status_unavailable',
                    'camera_connected':False,'source_clock_verified':False}

    def _health_loop(self):
        try:
            from app.camera_health_adapter import CameraHealthAdapter
            from app.notifications import NotificationOutbox
            with self._health_guard:
                self._health_adapter=CameraHealthAdapter(self.runtime/'camera-health.sqlite3')
                self._health_outbox=NotificationOutbox(self.runtime/'notifications.sqlite3')
        except Exception:
            self.health_state='needs_attention'
            return
        while not self.health_stop.is_set():
            self._health_tick()
            self.health_stop.wait(2)

    def _health_tick(self):
        # Large source/chain hashing must not hold the pause completion fence.
        prepared = None
        if not self._health_suspended and not self.health_stop.is_set() and hasattr(self.supervisor,'prepare_progress'):
            try:
                prepared = self.supervisor.prepare_progress()
            except Exception:
                self.health_state='needs_attention'
        # Serialize snapshot+observe+enqueue with pause/resume. A snapshot taken
        # before a completed pause cannot subsequently authorize an enqueue.
        with self._health_guard:
            if self.health_stop.is_set():
                return
            observed = False
            try:
                snapshot=self.supervisor.status()
                if snapshot.get('paused') is True:
                    self._health_suspended=True
                    self._health_adapter.suspend()
                self._health_adapter.observe(snapshot)
                observed = True
                self.health_state='running'
            except Exception:
                self.health_state='needs_attention'
            # New progress kind has no persisted delivery_allowed fallback.
            # Its parent-owned handshake is only reachable after this tick's
            # successful observation and while the pause fence is held.
            if observed and not self._health_suspended and not self.health_stop.is_set():
                try:
                    if hasattr(self.supervisor,'progress_health'):
                        progress = self.supervisor.progress_health(self._health_adapter,self._health_outbox,prepared)
                        if progress.get('error_code'):
                            self.health_state='needs_attention'
                except Exception:
                    self.health_state='needs_attention'
            try:
                if self._health_suspended:
                    return
                result=self._health_adapter.handoff(self._health_outbox,limit=10)
                if isinstance(result,dict) and result.get('error_code'):
                    self.health_state='needs_attention'
            except Exception:
                self.health_state='needs_attention'

    def pause(self):
        with self._health_guard:
            self._health_suspended=True
            # Suspend first so even a subsequent capture shutdown error cannot
            # leave health handoff enabled after a requested pause.
            try:
                if self._health_adapter is not None:
                    self._health_adapter.suspend()
            finally:
                self.supervisor.pause()
            return self.status()

    def resume(self):
        with self._health_guard:
            if self._health_adapter is not None:
                self._health_adapter.suspend()
            self.supervisor.resume()
            self._health_suspended=False
            return self.status()

    def stop(self):
        self.health_stop.set()
        try:
            if self.supervisor is not None:
                self.supervisor.stop(timeout=25)
        finally:
            if self.health_thread:
                self.health_thread.join(timeout=15)
                if self.health_thread.is_alive():
                    raise RuntimeError('Camera health worker has not stopped.')


def service():
    from app.main import app
    current=getattr(app.state,'recorder_service',None)
    if current is None:
        raise HTTPException(503,'Recorder service not started.')
    return current


@router.get('/status')
def status():
    return service().status()


@router.post('/pause')
def pause():
    current=service()
    if current.supervisor is None:
        raise HTTPException(503,'Recorder service unavailable.')
    try:
        return current.pause()
    except Exception:
        raise HTTPException(503,'Recorder pause could not be verified.') from None


@router.post('/resume')
def resume(body:DirectResume):
    current=service()
    if current.supervisor is None:
        raise HTTPException(503,'Recorder service unavailable.')
    try:
        return current.resume()
    except Exception:
        raise HTTPException(409,'Recorder remains gated; inspect local recorder status.') from None
