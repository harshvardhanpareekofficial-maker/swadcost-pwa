"""Dormant owner-host phone service composition, disabled by default.

The trusted host supplies its ONE shared DocumentStore and RuntimeOwner. This
module does not discover installation paths, provision accounts, install globals,
open transport, inspect certificates or change trust. The host must separately
own direct TLS admission, lifespan and stop/join. Checks are startup diagnostics,
not protection against a hostile local filesystem race or a second writer with
a different lock. No automatic activation follows from existing accounts.
The host must use its existing owner's SAME event loop; no second-thread loop
or global owner swap is supported. Current transports do not establish a LAN
activation path: this capability factory does not relax either bind policy.
"""
from dataclasses import dataclass, field
import json
from pathlib import Path
import sqlite3

from app.document_store import DocumentStore
from app.mobile_account_adapter import membership_reader
from app.mobile_auth import create_mobile_auth
from app.mobile_config import parse_mobile_config
from app.mobile_document_backend import document_backend
from app.mobile_runtime import MobileRuntime
from app.mobile_sessions import RemoteSessionStore
from app.mobile_shell import MobileShell
from app.runtime_owner import RuntimeOwner


_ACCOUNT_COLUMNS = {
    'factory': {'singleton', 'id', 'name'},
    'users': {'id', 'username', 'display_name', 'role', 'salt', 'password_hash', 'iterations', 'active'},
    'account_sessions': {'token_hash', 'user_id', 'expires_at'},
    'login_attempts': {'id', 'username', 'at'},
    'worker_invitations': {'id', 'token_hash', 'factory_id', 'created_by', 'created_at',
                           'expires_at', 'revoked_at', 'used_at', 'used_by'},
}
_SESSION_COLUMNS = {'token_hash', 'uid', 'factory', 'audience', 'csrf', 'expires'}


def _existing(path):
    value = Path(path).resolve(strict=True)
    if not value.is_file():
        raise ValueError('mobile_existing_file_required')
    return value


def _readonly(path, check):
    connection = sqlite3.connect(path.as_uri() + '?mode=ro', uri=True, timeout=0.2)
    try:
        connection.execute('PRAGMA query_only=ON')
        check(connection)
    finally:
        connection.close()


def _columns(connection, table, expected):
    # All identifiers are constants defined here, never request input.
    row = connection.execute('SELECT type FROM sqlite_master WHERE name=?', (table,)).fetchone()
    actual = {r[1] for r in connection.execute('PRAGMA table_info(' + table + ')')}
    if row != ('table',) or actual != expected:
        raise ValueError('mobile_database_schema_mismatch')


def _accounts(connection, config):
    for table, columns in _ACCOUNT_COLUMNS.items():
        _columns(connection, table, columns)
    if connection.execute('SELECT singleton,id FROM factory').fetchall() != [(1, config.factory_id)]:
        raise ValueError('mobile_factory_mismatch')
    if not connection.execute("SELECT 1 FROM users WHERE role='owner' AND active=1 LIMIT 1").fetchone():
        raise ValueError('mobile_active_owner_required')


def _sessions(connection, config):
    tables = {r[0] for r in connection.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")}
    if not tables <= {'remote_sessions_v1', 'remote_attempts_v1'} or 'remote_sessions_v1' not in tables:
        raise ValueError('mobile_session_schema_mismatch')
    _columns(connection, 'remote_sessions_v1', _SESSION_COLUMNS)
    if 'remote_attempts_v1' in tables:
        _columns(connection, 'remote_attempts_v1', {'name', 'at'})
    if connection.execute('SELECT 1 FROM remote_sessions_v1 WHERE factory IS NOT ? OR audience IS NOT ? LIMIT 1',
                          (config.factory_id, config.canonical_origin)).fetchone():
        raise ValueError('mobile_session_binding_mismatch')


@dataclass(frozen=True)
class MobileService:
    app: object = field(repr=False)
    shell: object = field(repr=False)
    owner: object = field(repr=False)
    sessions: object = field(repr=False)
    document_store: object = field(repr=False)
    config: object = field(repr=False)


def compose_mobile_service(settings=None, *, accounts_path=None, sessions_path=None,
                           document_store=None, owner=None, report_db=None):
    """Return None without I/O when disabled; otherwise validate and compose.

    settings uses parse_mobile_config's existing explicit enabled contract.
    sessions_path is a dedicated host-selected file with an existing parent;
    session persistence is initialized lazily by the authenticated API. Optional
    report_db is an existing trusted SQLite read capability. Returned shell can
    be wrapped by host lifespan observation before MobileRuntime if needed.
    """
    config = parse_mobile_config(settings)
    if config is None:
        return None
    if type(document_store) is not DocumentStore or type(owner) is not RuntimeOwner:
        raise ValueError('mobile_host_capabilities_required')
    if accounts_path is None or sessions_path is None:
        raise ValueError('mobile_explicit_paths_required')
    try:
        accounts = _existing(accounts_path)
        index = _existing(document_store.index)
        session = Path(sessions_path).resolve()
        if not session.parent.is_dir() or (session.exists() and not session.is_file()):
            raise ValueError('mobile_session_parent_required')
        report = _existing(report_db) if report_db is not None else None
        # Include the receipt DB even if it has not yet been created.
        protected = [accounts, index, index.parent / 'phone-submissions.sqlite3']
        if report is not None:
            protected.append(report)
        # Reserve SQLite's prospective sidecars as well as existing files. A
        # missing -wal/-shm/-journal is not a safe new session database path.
        suffixes = ('', '-wal', '-shm', '-journal')
        session_files = [Path(str(session) + suffix) for suffix in suffixes]
        protected_files = [Path(str(path) + suffix) for path in protected for suffix in suffixes]
        for candidate in session_files:
            for other in protected_files:
                if candidate == other or (candidate.exists() and other.exists() and candidate.samefile(other)):
                    raise ValueError('mobile_session_path_alias')
        _readonly(accounts, lambda db: _accounts(db, config))
        with document_store.lock:
            documents = json.loads(index.read_text(encoding='utf-8'))
        if not isinstance(documents, list) or any(not isinstance(row, dict) or not isinstance(row.get('id'), str) for row in documents):
            raise ValueError('mobile_document_index_invalid')
        if report is not None:
            _readonly(report, lambda db: db.execute('SELECT name FROM sqlite_master LIMIT 1').fetchone())
        if session.exists():
            _readonly(session, lambda db: _sessions(db, config))
    except (OSError, sqlite3.Error, TypeError, UnicodeError, json.JSONDecodeError):
        raise ValueError('mobile_storage_unavailable_or_invalid') from None
    sessions = RemoteSessionStore(session, config, membership_reader(accounts))
    backend = document_backend(config.factory_id, document_store)
    shell = MobileShell(create_mobile_auth(config, sessions, accounts,
                        report_db=report, document_backend=backend), config)
    return MobileService(MobileRuntime(shell, owner), shell, owner, sessions, document_store, config)
