"""Worker invitations behind the existing TLS, origin, CSRF and resource boundary."""
import json
import sqlite3

from fastapi import HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import ValidationError

from app.accounts import database_at, InvitationIssue, InvitationRedemption
from app.invitation_qr import presentation
from app.mobile_body import read_auth_body
from app.mobile_offload import owned_database_call
from app.upload_intake import IntakeError
from app import worker_invitations as invitations


def install_invitation_routes(app, config, store, accounts_path, pool):
    async def handle(request, action, invitation_id=None):
        session = request.state.mobile_session
        if action != 'redeem' and (session.role != 'owner' or not session.user_id):
            return JSONResponse({'detail':'Owner access required.'},403)
        body = None
        try:
            if action in ('issue','redeem'):
                model = InvitationIssue if action == 'issue' else InvitationRedemption
                body = model.model_validate(json.loads(await read_auth_body(request.receive, pool)))
            def perform():
                if action == 'redeem' and not store.reserve_login_attempt('invitation:'+body.username.lower()):
                    raise HTTPException(429, 'Too many enrollment attempts. Try again later.')
                with database_at(accounts_path) as c:
                    kw = {'expected_factory_id':config.factory_id}
                    if action == 'issue':
                        result = invitations.issue_invitation(c,session.user_id,body.expires_in_seconds,**kw)
                        return presentation(result, config.canonical_origin)
                    if action == 'list': return invitations.list_invitations(c,session.user_id,**kw)
                    if action == 'revoke': return invitations.revoke_invitation(c,session.user_id,invitation_id,**kw)
                    return invitations.redeem_invitation(c,body.token,body.model_dump(exclude={'token'}),**kw)
            result = await owned_database_call(perform)
            return JSONResponse(result, headers={'Cache-Control':'no-store'})
        except HTTPException as error:
            return JSONResponse({'detail':error.detail},error.status_code,headers={'Cache-Control':'no-store'})
        except IntakeError as error:
            return JSONResponse({'detail':'Invalid invitation request.'},error.status)
        except (ValidationError, ValueError, TimeoutError):
            return JSONResponse({'detail':'Invalid invitation request.'},400)
        except sqlite3.Error:
            return JSONResponse({'detail':'Invitations temporarily unavailable.'},503)

    @app.get('/api/account/worker-invitations')
    async def listing(request: Request): return await handle(request,'list')

    @app.post('/api/account/worker-invitations')
    async def issue(request: Request): return await handle(request,'issue')

    @app.post('/api/account/worker-invitations/redeem')
    async def redeem(request: Request): return await handle(request,'redeem')

    @app.post('/api/account/worker-invitations/{invitation_id}/revoke')
    async def revoke(invitation_id: str, request: Request): return await handle(request,'revoke',invitation_id)
