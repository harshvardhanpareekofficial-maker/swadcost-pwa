"""Admission for the isolated async mobile app; host owns global installation.

Does not start a server, install an owner, or replace physical server readiness.
Cancellation leaves resource coordinators owned by the supplied RuntimeOwner.
"""
from app import runtime_owner as ro


class MobileRuntime:
    def __init__(self, app, owner):
        self.app, self.owner = app, owner

    async def __call__(self, scope, receive, send):
        owner = self.owner
        if ro.current_owner() is not owner:
            raise RuntimeError('mobile_runtime_owner_mismatch')
        if scope['type'] == 'lifespan':
            async def observed_receive():
                message = await receive()
                if message['type'] == 'lifespan.shutdown':
                    owner.request_stop()
                return message

            async def observed_send(message):
                if message['type'] == 'lifespan.shutdown.complete':
                    # Never report cleanup merely because request observers ended.
                    await owner.drain_loop_resources()
                await send(message)
            try:
                return await self.app(scope, observed_receive, observed_send)
            finally:
                owner.request_stop()
        if scope['type'] == 'websocket':
            return await send({'type': 'websocket.close', 'code': 1008})
        if scope['type'] != 'http':
            raise ValueError('unsupported_mobile_scope')
        call = owner.admit()
        if call is None:
            await send({'type': 'http.response.start', 'status': 503,
                        'headers': [(b'cache-control', b'no-store')]})
            return await send({'type': 'http.response.body', 'body': b'Application is stopping.'})
        token = ro._CALL.set(call)
        try:
            return await self.app(scope, receive, send)
        finally:
            owner.request_ended(call)
            ro._CALL.reset(token)
