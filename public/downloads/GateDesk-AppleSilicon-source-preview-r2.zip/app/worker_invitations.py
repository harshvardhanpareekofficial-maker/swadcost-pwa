"""Single-factory, one-use worker enrollment; never grants a session or owner role.

Store functions take an idle accounts connection with this schema initialized.
Owner IDs must come from authenticated server state, never request body fields.
Each operation owns its transaction and rechecks authority inside its write lock.
"""
import re
import secrets
import time
import uuid

from fastapi import HTTPException

DEFAULT_SECONDS = 900
MAX_SECONDS = 3600


def initialize_schema(c):
    c.execute('''CREATE TABLE IF NOT EXISTS worker_invitations (
        id TEXT PRIMARY KEY, token_hash TEXT UNIQUE NOT NULL, factory_id TEXT NOT NULL,
        created_by TEXT NOT NULL REFERENCES users(id), created_at REAL NOT NULL,
        expires_at REAL NOT NULL, revoked_at REAL, used_at REAL,
        used_by TEXT REFERENCES users(id))''')


def _owner_factory(c, owner_id, expected_factory_id=None):
    if not c.execute("SELECT 1 FROM users WHERE id=? AND role='owner' AND active=1",
                     (owner_id,)).fetchone():
        raise HTTPException(403, 'Active owner account required.')
    factory = c.execute('SELECT id,name FROM factory WHERE singleton=1').fetchone()
    if factory is None:
        raise HTTPException(409, 'Factory setup is required.')
    if expected_factory_id is not None and factory['id'] != expected_factory_id:
        raise HTTPException(403, 'Factory binding no longer matches this server.')
    return factory


def _public(row, now):
    status = ('used' if row['used_at'] is not None else
              'revoked' if row['revoked_at'] is not None else
              'expired' if row['expires_at'] <= now else 'pending')
    return {**{k: row[k] for k in ('id', 'factory_id', 'created_by', 'created_at', 'expires_at')},
            'status': status}


def issue_invitation(c, owner_id, expires_in_seconds=DEFAULT_SECONDS, *, expected_factory_id=None):
    from app.accounts import token_hash
    if type(expires_in_seconds) is not int or not 60 <= expires_in_seconds <= MAX_SECONDS:
        raise HTTPException(422, 'Invitation duration must be 60 to 3600 seconds.')
    with c:
        c.execute('BEGIN IMMEDIATE')
        factory = _owner_factory(c, owner_id, expected_factory_id)
        now = time.time()
        token = secrets.token_urlsafe(32)
        invitation_id = str(uuid.uuid4())
        c.execute('''INSERT INTO worker_invitations
            (id,token_hash,factory_id,created_by,created_at,expires_at) VALUES (?,?,?,?,?,?)''',
                  (invitation_id, token_hash(token), factory['id'], owner_id, now, now+expires_in_seconds))
        row = c.execute('SELECT * FROM worker_invitations WHERE id=?', (invitation_id,)).fetchone()
        return {'invitation': _public(row, now), 'token': token}


def list_invitations(c, owner_id, *, expected_factory_id=None):
    with c:
        c.execute('BEGIN IMMEDIATE')
        factory = _owner_factory(c, owner_id, expected_factory_id)
        rows = c.execute('SELECT * FROM worker_invitations WHERE factory_id=? ORDER BY created_at DESC LIMIT 100',
                         (factory['id'],)).fetchall()
        return {'invitations': [_public(row, time.time()) for row in rows]}


def revoke_invitation(c, owner_id, invitation_id, *, expected_factory_id=None):
    with c:
        c.execute('BEGIN IMMEDIATE')
        factory = _owner_factory(c, owner_id, expected_factory_id)
        row = c.execute('SELECT * FROM worker_invitations WHERE id=? AND factory_id=?',
                        (invitation_id, factory['id'])).fetchone()
        if row is None:
            raise HTTPException(404, 'Invitation not found.')
        if row['used_at'] is not None:
            raise HTTPException(409, 'Invitation has already been used. Revoke the worker account instead.')
        c.execute('UPDATE worker_invitations SET revoked_at=COALESCE(revoked_at,?) WHERE id=?',
                  (time.time(), invitation_id))
        return {'revoked': True, 'invitation_id': invitation_id}


def redeem_invitation(c, token, body, *, expected_factory_id=None):
    from app.accounts import NewUser, insert_user, token_hash
    # Revalidate reusable-store input too: role/factory are never caller-selected.
    user_body = NewUser.model_validate(body.model_dump() if isinstance(body, NewUser) else body)
    if not isinstance(token, str) or not re.fullmatch(r'[A-Za-z0-9_-]{43}', token):
        raise HTTPException(400, 'Invitation is invalid or no longer available.')
    with c:
        c.execute('BEGIN IMMEDIATE')
        row = c.execute('SELECT * FROM worker_invitations WHERE token_hash=?', (token_hash(token),)).fetchone()
        factory = c.execute('SELECT id,name FROM factory WHERE singleton=1').fetchone()
        if (row is None or factory is None or row['factory_id'] != factory['id']
                or (expected_factory_id is not None and factory['id'] != expected_factory_id)
                or row['expires_at'] <= time.time() or row['revoked_at'] is not None
                or row['used_at'] is not None
                or not c.execute("SELECT 1 FROM users WHERE id=? AND role='owner' AND active=1",
                                 (row['created_by'],)).fetchone()):
            raise HTTPException(400, 'Invitation is invalid or no longer available.')
        user = insert_user(c, user_body, 'worker')
        c.execute('UPDATE worker_invitations SET used_at=?,used_by=? WHERE id=?',
                  (time.time(), user['id'], row['id']))
        return {'user': user, 'factory': dict(factory), 'sign_in_required': True}
