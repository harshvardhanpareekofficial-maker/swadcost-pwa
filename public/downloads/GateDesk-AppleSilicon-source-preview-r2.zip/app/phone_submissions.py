"""Durable phone receipt after original-image commit. Host supplies one store.

An interrupted image commit may precede the receipt; replay uses the document
store's existing content identity and never overwrites an operator review.
"""
import hashlib
import re
import sqlite3
from datetime import datetime, timezone
from fastapi import HTTPException


def submission_metadata(submission_id, digest, saved_at):
    if not isinstance(submission_id, str) or not re.fullmatch(r'[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}', submission_id):
        raise ValueError('invalid_submission_id')
    if not isinstance(digest, str) or not re.fullmatch(r'[a-f0-9]{64}', digest):
        raise ValueError('invalid_original_digest')
    if not isinstance(saved_at, str) or len(saved_at) > 40:
        raise ValueError('invalid_submission_time')
    try:
        parsed = datetime.fromisoformat(saved_at.replace('Z', '+00:00'))
        if parsed.tzinfo is None or parsed.utcoffset() is None:
            raise ValueError()
    except ValueError as exc:
        raise ValueError('invalid_submission_time') from exc
    # Preserve the exact reported value. It is a device claim, not verified loading time.
    return submission_id, digest, saved_at


class PhoneSubmissions:
    def __init__(self, store, factory_id):
        self.store, self.factory_id = store, factory_id
        self.path = store.index.parent / 'phone-submissions.sqlite3'

    def import_image(self, file, user_id, submission_id, digest, saved_at):
        submission_metadata(submission_id, digest, saved_at)
        if not isinstance(user_id, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,128}', user_id):
            raise ValueError('authenticated_user_required')
        data = file.file.read(10 * 1024 * 1024 + 1)
        if len(data) > 10 * 1024 * 1024:
            raise HTTPException(413, 'Original is too large.')
        if hashlib.sha256(data).hexdigest() != digest:
            raise HTTPException(422, 'Original digest does not match.')
        file.file.seek(0)
        if not self.store.index.is_file():
            raise HTTPException(409, 'Factory document index is unavailable; restore it before syncing.')
        connection = sqlite3.connect(self.path, timeout=0.2)
        try:
            connection.execute('PRAGMA synchronous=FULL')
            connection.execute('''CREATE TABLE IF NOT EXISTS phone_submissions_v1 (
                factory TEXT NOT NULL, submission TEXT NOT NULL, uid TEXT NOT NULL,
                digest TEXT NOT NULL, saved_at TEXT NOT NULL, document TEXT NOT NULL,
                received_at TEXT NOT NULL, PRIMARY KEY(factory, submission))''')
            connection.execute('BEGIN IMMEDIATE')
            previous = connection.execute('SELECT uid,digest,saved_at,document,received_at FROM phone_submissions_v1 WHERE factory=? AND submission=?',
                                          (self.factory_id, submission_id)).fetchone()
            if previous and previous[:3] != (user_id, digest, saved_at):
                raise HTTPException(409, 'Submission identity conflicts with an existing receipt.')
            # Even on retry verify that the retained original/preview remain intact.
            imported = self.store.import_image(file)
            document_id = imported['document']['id']
            if previous and previous[3] != document_id:
                raise HTTPException(409, 'Saved receipt does not match the original.')
            received_at = previous[4] if previous else datetime.now(timezone.utc).isoformat()
            if not previous:
                connection.execute('INSERT INTO phone_submissions_v1 VALUES (?,?,?,?,?,?,?)',
                                   (self.factory_id, submission_id, user_id, digest, saved_at, document_id, received_at))
            connection.commit()
            return {'id': submission_id, 'factoryId': self.factory_id, 'userId': user_id,
                    'digest': digest, 'savedAt': saved_at, 'documentId': document_id,
                    'receivedAt': received_at}
        finally:
            connection.close()
