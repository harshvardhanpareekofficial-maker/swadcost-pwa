"""Local, human-operated image annotation. No inference or auto-labeling."""
from pathlib import Path
import io, json, os, sqlite3, uuid, zipfile, math
from datetime import datetime, timezone
from fastapi import APIRouter, HTTPException, UploadFile
from fastapi.responses import FileResponse, Response
from pydantic import BaseModel, Field
from PIL import Image, ImageOps, UnidentifiedImageError

ROOT = Path(__file__).resolve().parents[1]
STORE = Path(os.environ.get("ANNOTATOR_STORE", str(ROOT / "data/annotator")))
router = APIRouter(prefix="/api/annotator")

def db():
    STORE.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(STORE / "projects.sqlite3", timeout=20)
    c.row_factory = sqlite3.Row
    c.execute("CREATE TABLE IF NOT EXISTS projects(id TEXT PRIMARY KEY, body TEXT NOT NULL)")
    return c

def get(c, pid):
    row = c.execute("SELECT body FROM projects WHERE id=?", (pid,)).fetchone()
    if not row: raise HTTPException(404, "Project not found")
    return json.loads(row[0])

def write(c, p):
    p["updated"] = datetime.now(timezone.utc).isoformat()
    c.execute("INSERT OR REPLACE INTO projects VALUES (?,?)", (p["id"], json.dumps(p)))

class NewProject(BaseModel):
    name: str = Field(min_length=1, max_length=100)

@router.get("/projects")
def projects():
    with db() as c:
        items = [json.loads(r[0]) for r in c.execute("SELECT body FROM projects")]
    return [{"id": p["id"], "name": p["name"], "count": len(p["images"])} for p in items]

@router.post("/projects")
def create(body: NewProject):
    if not body.name.strip(): raise HTTPException(422, "Enter a project name")
    p = dict(id=uuid.uuid4().hex, name=body.name.strip(), revision=0, schema=1,
             classes=["bag"], images=[], instructions="Box the visible extent of each eligible object. Flag uncertain images for review.")
    with db() as c: write(c, p)
    return p

@router.get("/projects/{pid}")
def project(pid: str):
    with db() as c: return get(c, pid)

@router.post("/projects/{pid}/images")
def add_image(pid: str, file: UploadFile):
    raw = file.file.read(20 * 1024 * 1024 + 1)
    if len(raw) > 20 * 1024 * 1024: raise HTTPException(413, "Each image must be under 20 MB")
    try:
        with Image.open(io.BytesIO(raw)) as src:
            if src.width * src.height > 24_000_000: raise HTTPException(413, "Use images below 24 megapixels")
            im = ImageOps.exif_transpose(src).convert("RGB")
            im.load()
    except (UnidentifiedImageError, OSError, Image.DecompressionBombError):
        raise HTTPException(422, "Choose readable JPG, PNG or WebP images")
    iid = uuid.uuid4().hex
    with db() as c:
        c.execute("BEGIN IMMEDIATE")
        p = get(c, pid)
        if len(p["images"]) >= 2000: raise HTTPException(409, "Use a new project after 2,000 images")
        dest = STORE / "images"; dest.mkdir(exist_ok=True)
        im.save(dest / (iid + ".png"))
        p["images"].append(dict(id=iid, name=Path((file.filename or "image").replace("\\", "/")).name[:200],
                                width=im.width, height=im.height, boxes=[], status="unreviewed", empty=False, note="", group=""))
        p["revision"] += 1; write(c, p)
    return p

@router.get("/images/{iid}")
def image(iid: str):
    if len(iid) != 32 or any(x not in "0123456789abcdef" for x in iid): raise HTTPException(404)
    path = STORE / "images" / (iid + ".png")
    if not path.is_file(): raise HTTPException(404)
    return FileResponse(path)

class SaveProject(BaseModel):
    revision: int
    classes: list[str] = Field(min_length=1, max_length=100)
    instructions: str = Field(max_length=5000)
    images: list[dict] = Field(max_length=2000)

def validate(body, old):
    if any(not isinstance(x,str) or not x.strip() or len(x)>80 for x in body.classes) or len(set(x.casefold() for x in body.classes)) != len(body.classes):
        raise HTTPException(422, "Classes must have unique, non-empty names (80 characters maximum)")
    if [i.get("id") for i in body.images] != [i["id"] for i in old["images"]]: raise HTTPException(422, "Image list changed; reload the project")
    for i, source in zip(body.images, old["images"]):
        for key in ("name", "width", "height"):
            if i.get(key) != source[key]: raise HTTPException(422, "Image metadata cannot change")
        if i.get("status") not in ("unreviewed", "in_progress", "needs_review", "reviewed"): raise HTTPException(422, "Invalid review state")
        if not isinstance(i.get("empty"), bool): raise HTTPException(422, "Explicit empty confirmation required")
        if any(not isinstance(i.get(k),str) or len(i[k])>2000 for k in ("note", "group")): raise HTTPException(422, "Invalid note or source group")
        boxes=i.get("boxes")
        if not isinstance(boxes,list) or len(boxes)>2000: raise HTTPException(422,"Invalid box list")
        ids=set()
        for b in boxes:
            if not isinstance(b,dict): raise HTTPException(422,"Invalid box")
            bid=b.get("id")
            if not isinstance(bid,str) or len(bid)>80 or bid in ids: raise HTTPException(422,"Box IDs must be unique")
            ids.add(bid)
            if type(b.get("classId")) is not int or not 0 <= b["classId"] < len(body.classes): raise HTTPException(422,"Invalid box class")
            if any(type(b.get(k)) not in (int,float) or not math.isfinite(b[k]) for k in ("x","y","w","h")): raise HTTPException(422,"Invalid box coordinates")
            if b["x"]<0 or b["y"]<0 or b["w"]<1 or b["h"]<1 or b["x"]+b["w"]>i["width"]+0.001 or b["y"]+b["h"]>i["height"]+0.001: raise HTTPException(422,"Box must stay within the image")
        if boxes and i["empty"]: raise HTTPException(422,"An image with boxes cannot be confirmed empty")
        if i["status"]=="reviewed" and not boxes and not i["empty"]: raise HTTPException(422,"Confirm an empty image explicitly before review")

@router.put("/projects/{pid}")
def save(pid: str, body: SaveProject):
    with db() as c:
        c.execute("BEGIN IMMEDIATE"); p=get(c,pid)
        if p["revision"] != body.revision: raise HTTPException(409,"Another tab changed this project. Download your draft, then reload before continuing.")
        validate(body,p)
        p.update(classes=body.classes,instructions=body.instructions,images=body.images,revision=p["revision"]+1)
        write(c,p)
    return {"revision":p["revision"],"updated":p["updated"]}

@router.get("/projects/{pid}/export/{format}")
def export(pid: str, format: str):
    if format not in ("coco","yolo","backup"): raise HTTPException(404)
    with db() as c: p=get(c,pid)
    selected=p["images"] if format=="backup" else [i for i in p["images"] if i["status"]=="reviewed"]
    if not selected: raise HTTPException(409,"Review at least one image before exporting training data")
    buf=io.BytesIO()
    with zipfile.ZipFile(buf,"w",zipfile.ZIP_DEFLATED) as z:
        z.writestr("project.json",json.dumps(p,indent=2))
        z.writestr("README.txt","Local human annotations. Training exports include reviewed images only. No automatic train/test split: group by original source/session before training. Images are orientation-normalized PNG copies; originals are unchanged. project.json contains all work, including unfinished annotations. A backup includes every image.")
        coco=dict(images=[],annotations=[],categories=[dict(id=n+1,name=name) for n,name in enumerate(p["classes"])])
        for n,i in enumerate(selected,1):
            name=i["id"]+".png"; z.write(STORE/"images"/name,"images/"+name)
            coco["images"].append(dict(id=n,file_name="images/"+name,width=i["width"],height=i["height"],source_group=i["group"],original_name=i["name"]))
            lines=[]
            for b in i["boxes"]:
                coco["annotations"].append(dict(id=len(coco["annotations"])+1,image_id=n,category_id=b["classId"]+1,bbox=[b[k] for k in ("x","y","w","h")],area=b["w"]*b["h"],iscrowd=0))
                lines.append(f"{b['classId']} {(b['x']+b['w']/2)/i['width']:.8f} {(b['y']+b['h']/2)/i['height']:.8f} {b['w']/i['width']:.8f} {b['h']/i['height']:.8f}")
            if format=="yolo": z.writestr("labels/"+i["id"]+".txt","\n".join(lines))
        if format=="coco": z.writestr("annotations.json",json.dumps(coco,indent=2))
        if format=="yolo": z.writestr("classes.txt","\n".join(p["classes"]))
    return Response(buf.getvalue(),media_type="application/zip",headers={"Content-Disposition":f'attachment; filename="annotations-{format}.zip"'})
