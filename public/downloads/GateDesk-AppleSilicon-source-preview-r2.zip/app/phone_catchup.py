"""Durable pending phone-pass work, with no recorder or inference capability.

The trusted host supplies existing review/receipt stores and an authorizer that
freshly checks an owner. Only receipt ID and exact current review revision are
selectors. The original job snapshot is immutable; supersession is a separate
append-only relation. This module cannot accept clock/coverage proofs, clear
blockers, fetch footage, infer counts, or complete a job.
"""
from contextlib import closing
from datetime import datetime, timezone
import hashlib
import json
import re
import sqlite3
import uuid

from app.camera_enrollment import OwnerIdentity
from app.phone_loading_candidate import HostPhoneLoadingCapability, plan_phone_loading_candidate
from app.phone_loading_review import PhoneLoadingReview, safe_path
from app.phone_submissions import submission_metadata

BLOCKERS = ('source_clock_review_required', 'recorder_retention_unverified',
            'footage_coverage_unknown', 'whole_operation_boundaries_unverified',
            'recorder_adapter_not_admitted')


class CatchupError(ValueError):
    pass


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False)


def fingerprint(value):
    return hashlib.sha256(encoded(value).encode('utf-8')).hexdigest()


class PhoneCatchup:
    def __init__(self, reviews, *, factory_id, authorize):
        if (type(reviews) is not PhoneLoadingReview or not callable(authorize)
                or not isinstance(factory_id, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,80}', factory_id)
                or reviews.submissions.factory_id != factory_id):
            raise CatchupError('catchup_factory_binding_invalid')
        self.reviews, self.factory_id, self.authorize = reviews, factory_id, authorize
        self.path = reviews.runtime / 'phone-catchup.sqlite3'

    def _owner(self):
        owner = self.authorize()
        if (type(owner) is not OwnerIdentity or owner.factory_id != self.factory_id
                or owner.role != 'owner' or owner.active is not True or owner.accounts_enabled is not True
                or not isinstance(owner.account_id, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,128}', owner.account_id)):
            raise CatchupError('catchup_owner_required')
        return owner.account_id

    def _paths(self):
        if self.reviews.submissions.factory_id != self.factory_id:
            raise CatchupError('catchup_factory_binding_invalid')
        self.reviews.check()
        for path in (self.path, self.reviews.path, self.reviews.submissions.path):
            for suffix in ('', '-journal', '-wal', '-shm'):
                safe_path(str(path)+suffix)

    def _snapshot(self, db, submission_id, revision):
        row = db.execute('SELECT revision,payload FROM phone_loading_reviews_v1 WHERE factory=? AND submission=? ORDER BY revision DESC LIMIT 1',
                         (self.factory_id, submission_id)).fetchone()
        if row is None:
            raise CatchupError('catchup_review_required')
        if row[0] != revision:
            raise CatchupError('catchup_revision_conflict')
        review = json.loads(row[1])
        if type(review) is not dict or review.get('revision') != revision:
            raise CatchupError('catchup_review_corrupt')
        receipts = self.reviews.receipts(submission_id=submission_id)
        if len(receipts) != 1:
            raise CatchupError('catchup_receipt_unavailable')
        receipt = receipts[0]
        association = {'factoryId':receipt['factoryId'], 'userId':receipt['userId'],
            'submissionId':receipt['id'], 'documentId':receipt['documentId'], 'originalDigest':receipt['digest'],
            'cameraId':review['camera_id'], 'direction':review['direction'],
            'reviewedBy':review['reviewed_by'], 'reviewedAt':review['reviewed_at'],
            'reviewBasis':'explicit_operator_camera_direction_review'}
        capability = HostPhoneLoadingCapability(self.reviews.submissions, self.factory_id,
            receipt['userId'], lambda _: association)
        candidate = plan_phone_loading_candidate(capability, submission_id)
        if candidate != review.get('candidate'):
            raise CatchupError('catchup_receipt_review_mismatch')
        return {'receipt':receipt, 'review':review}

    def _check_factory(self, db):
        rows = db.execute('SELECT version,factory FROM phone_catchup_meta').fetchall()
        if rows != [(1, self.factory_id)]:
            raise CatchupError('catchup_storage_binding_invalid')

    def _initialize(self, db):
        # Called only when this invocation observed no queue file, after owner
        # and current-review validation. Existing/corrupt files are never reset.
        db.execute('BEGIN IMMEDIATE')
        db.execute('CREATE TABLE IF NOT EXISTS phone_catchup_meta (singleton INTEGER PRIMARY KEY CHECK(singleton=1),version INTEGER NOT NULL,factory TEXT NOT NULL)')
        db.execute('INSERT OR IGNORE INTO phone_catchup_meta VALUES (1,1,?)', (self.factory_id,))
        self._check_factory(db)
        db.execute('CREATE TABLE IF NOT EXISTS phone_catchup_jobs (id TEXT PRIMARY KEY,submission TEXT NOT NULL,revision INTEGER NOT NULL,fingerprint TEXT NOT NULL UNIQUE,payload TEXT NOT NULL,UNIQUE(submission,revision))')
        db.execute('CREATE TABLE IF NOT EXISTS phone_catchup_supersessions (old_id TEXT PRIMARY KEY REFERENCES phone_catchup_jobs(id),new_id TEXT NOT NULL REFERENCES phone_catchup_jobs(id),at TEXT NOT NULL)')
        db.commit()

    def _public(self, db, row):
        if row is None:
            raise CatchupError('catchup_job_not_found')
        job_id, submission, revision, digest, raw = row
        job = json.loads(raw)
        fields = {'id','factory_id','submission_id','review_revision','fingerprint','snapshot',
                  'created_at','created_by','state','blocked_reasons','count','complete_operation',
                  'footage_coverage','completed_at','fetch_authorized'}
        if (type(job) is not dict or set(job) != fields or job.get('id') != job_id or job.get('submission_id') != submission
                or job.get('review_revision') != revision or job.get('factory_id') != self.factory_id
                or job.get('fingerprint') != digest or fingerprint(job['snapshot']) != digest
                or job.get('state') != 'pending' or job.get('blocked_reasons') != list(BLOCKERS)
                or job.get('count') is not None or job.get('complete_operation') is not None
                or job.get('completed_at') is not None or job.get('fetch_authorized') is not False
                or job.get('footage_coverage') != 'unknown'):
            raise CatchupError('catchup_job_corrupt')
        later = db.execute('SELECT new_id,at FROM phone_catchup_supersessions WHERE old_id=?', (job_id,)).fetchone()
        return {**job, 'state':'superseded' if later else 'pending',
                'superseded_by':later[0] if later else None, 'superseded_at':later[1] if later else None}

    def enqueue(self, submission_id, review_revision):
        submission_metadata(submission_id, '0'*64, '2000-01-01T00:00:00Z')
        if type(review_revision) is not int or not 1 <= review_revision <= 1000000:
            raise CatchupError('catchup_invalid_revision')
        owner_id = self._owner()
        self._paths()
        if not self.reviews.path.is_file():
            raise CatchupError('catchup_review_required')
        # Review writers use BEGIN IMMEDIATE too. Hold this short lock until
        # queue append commits, so an association cannot change mid-admission.
        with closing(sqlite3.connect(self.reviews.path.as_uri()+'?mode=rw', uri=True, timeout=.2)) as reviewed:
            reviewed.execute('BEGIN IMMEDIATE')
            snapshot = self._snapshot(reviewed, submission_id, review_revision)
            digest = fingerprint(snapshot)
            existed = self.path.exists()
            with closing(sqlite3.connect(self.path, timeout=.2)) as db:
                db.execute('PRAGMA foreign_keys=ON')
                db.execute('PRAGMA synchronous=FULL')
                if not existed:
                    self._initialize(db)
                db.execute('BEGIN IMMEDIATE')
                self._check_factory(db)
                previous = db.execute('SELECT id,submission,revision,fingerprint,payload FROM phone_catchup_jobs WHERE submission=? AND revision=?',
                                      (submission_id, review_revision)).fetchone()
                if previous is not None:
                    if previous[3] != digest:
                        raise CatchupError('catchup_fingerprint_conflict')
                    if self._owner() != owner_id:
                        raise CatchupError('catchup_owner_changed')
                    return self._public(db, previous)
                # Recheck the durable receipt and owner before append. No
                # caller-provided evidence can change this pending-only stage.
                if self._snapshot(reviewed, submission_id, review_revision) != snapshot:
                    raise CatchupError('catchup_receipt_review_mismatch')
                if self._owner() != owner_id:
                    raise CatchupError('catchup_owner_changed')
                now = datetime.now(timezone.utc).isoformat()
                job = {'id':str(uuid.uuid4()), 'factory_id':self.factory_id, 'submission_id':submission_id,
                    'review_revision':review_revision, 'fingerprint':digest, 'snapshot':snapshot,
                    'created_at':now, 'created_by':owner_id, 'state':'pending',
                    'blocked_reasons':list(BLOCKERS), 'count':None, 'complete_operation':None,
                    'footage_coverage':'unknown', 'completed_at':None, 'fetch_authorized':False}
                db.execute('INSERT INTO phone_catchup_jobs VALUES (?,?,?,?,?)',
                           (job['id'],submission_id,review_revision,digest,encoded(job)))
                db.execute('INSERT INTO phone_catchup_supersessions (old_id,new_id,at) SELECT id,?,? FROM phone_catchup_jobs WHERE submission=? AND revision<? AND id NOT IN (SELECT old_id FROM phone_catchup_supersessions)',
                           (job['id'],now,submission_id,review_revision))
                db.commit()
                return self._public(db, (job['id'],submission_id,review_revision,digest,encoded(job)))

    def get(self, job_id):
        if not isinstance(job_id, str) or not re.fullmatch(r'[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}', job_id):
            raise CatchupError('catchup_invalid_job_id')
        owner_id = self._owner()
        self._paths()
        if not self.path.is_file():
            raise CatchupError('catchup_job_not_found')
        with closing(sqlite3.connect(self.path.as_uri()+'?mode=ro',uri=True,timeout=.2)) as db:
            self._check_factory(db)
            result = self._public(db, db.execute('SELECT id,submission,revision,fingerprint,payload FROM phone_catchup_jobs WHERE id=?',(job_id,)).fetchone())
        if self._owner() != owner_id:
            raise CatchupError('catchup_owner_changed')
        return result
