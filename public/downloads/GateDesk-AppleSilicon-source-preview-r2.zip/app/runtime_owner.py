"""Physical work ownership for the installed local launcher.

Absent an installed owner, helpers retain development/test behavior. An installed
owner never infers physical completion from ASGI task completion or a timeout.
"""
from __future__ import annotations
from contextvars import ContextVar
from contextlib import contextmanager
from dataclasses import dataclass
import functools
import inspect
import multiprocessing
import threading
import time
import uuid
import asyncio

_CURRENT = None
_CALL = ContextVar('gate_runtime_call', default=None)


def current_owner():
    return _CURRENT


def install_owner(owner):
    global _CURRENT
    previous, _CURRENT = _CURRENT, owner
    return previous


@dataclass(eq=False)
class Call:
    state: str = 'QUEUED'
    thread: object = None
    request_ended: bool = False
    loop: object = None


class RuntimeOwner:
    def __init__(self):
        self.guard = threading.RLock()
        self.changed = threading.Condition(self.guard)
        self.accepting = True
        self.stop_requested = threading.Event()
        self.calls = set()
        self.workers = {}
        self.queues = []
        self.failures = set()
        self.bootstrap = 0
        self.baseline = set(threading.enumerate())
        self.pool_threads = set()
        self.wrapper_entries = 0
        self.signal_count = 0
        self.gate_closes = 0
        self._resources = {}
        self._resource_loop = None

    def fail(self, code):
        with self.guard:
            self.failures.add(code)

    def request_stop(self):
        # Signal handlers use signal_stop instead: no mutex or disk operations.
        with self.guard:
            if self.accepting:
                self.gate_closes += 1
            self.accepting = False
            self.stop_requested.set()
            resources = list(self._resources.values())
        for resource in resources:
            resource.request_close('owner_stop')
        self.changed_notify()

    def signal_stop(self, signum, frame):
        self.signal_count += 1
        # Python signal delivery occurs in main; Event.set takes a lock, so only
        # this scalar is touched. The observer/main loop latches request_stop.
        self.signal_pending = True

    def changed_notify(self):
        with self.changed:
            self.changed.notify_all()

    @contextmanager
    def importing(self):
        with self.guard:
            self.bootstrap += 1
        try:
            yield
        finally:
            with self.guard:
                self.bootstrap -= 1
                self.changed.notify_all()

    def admit(self):
        try: loop = asyncio.get_running_loop()
        except RuntimeError: loop = None
        with self.guard:
            if not self.accepting:
                return None
            token = Call(loop=loop)
            self.calls.add(token)
            return token

    def request_ended(self, token):
        with self.guard:
            token.request_ended = True
            if token.state == 'QUEUED':
                token.state = 'REVOKED'
                self.calls.discard(token)
            self.changed.notify_all()
            resources = [r for r in self._resources.values() if r._call is token]
        for resource in resources:
            resource.request_close('request_ended')

    def physical_call(self, token, function, *args, **kwargs):
        from fastapi import HTTPException
        with self.guard:
            if token is None or token.state != 'QUEUED' or token not in self.calls:
                raise HTTPException(503, 'Application is stopping.')
            token.state = 'RUNNING'
            token.thread = threading.current_thread()
            self.pool_threads.add(token.thread)
            self.wrapper_entries += 1
        try:
            result = function(*args, **kwargs)
            return self.checked_response(result)
        finally:
            with self.guard:
                token.state = 'DONE'
                self.calls.discard(token)
                self.changed.notify_all()

    def checked_response(self, result):
        from starlette.responses import Response, FileResponse, JSONResponse
        unsupported = isinstance(result, Response) and type(result) not in {Response, FileResponse, JSONResponse}
        if unsupported or getattr(result, 'background', None) is not None:
            self.fail('response_background_forbidden')
            self.request_stop()
            raise RuntimeError('Unowned response background work is forbidden')
        return result

    def start(self, handle, *, stop=None, control=False, completion=None):
        with self.guard:
            if not self.accepting:
                raise RuntimeError('Application is stopping; producer registration closed')
            if handle in self.workers:
                raise RuntimeError('Worker already registered')
            row = {'handle': handle, 'stop': stop, 'control': control,
                   'completion': completion, 'state': 'STARTING', 'hook_done': False}
            self.workers[handle] = row
            try:
                handle.start()
            except BaseException:
                self.failures.add('worker_start_failed')
                # A partially started handle stays owned. Only positive
                # never-started evidence retires it.
                never = (handle.ident is None and not handle._started.is_set()) if isinstance(handle, threading.Thread) else (handle.pid is None and handle._popen is None)
                if never:
                    row['state'] = 'NEVER_STARTED'
                raise
            else:
                row['state'] = 'STARTED'

    def observe_process_completion(self, handle):
        """Called before Process.close disposes observable handle state."""
        with self.guard:
            row = self.workers.get(handle)
            if row is None:
                return
            if handle.is_alive():
                raise RuntimeError('Cannot retire a live process')
            handle.join(timeout=0)
            if handle.exitcode is None:
                raise RuntimeError('Process exit not observed')
            row['exitcode'] = handle.exitcode
            row['clean_child'] = bool(handle.exitcode == 0 and row['completion'] is not None and row['completion'].is_set())
            row['state'] = 'JOINED'

    def forced(self):
        if self.stop_requested.is_set():
            self.fail('forced_shutdown_seen')

    def register_queue(self, channel):
        with self.guard:
            if not self.accepting:
                raise RuntimeError('Queue producer registration closed')
            self.queues.append(channel)

    def _audit_unknown(self):
        # Exact audited AnyIO class, never a name-prefix exemption. It only
        # executes wrapped app routes and pinned framework read/spool calls.
        from anyio._backends._asyncio import WorkerThread
        resource_threads = {r._worker.thread for r in self._resources.values() if r._worker is not None}
        known = self.baseline | set(self.workers) | self.pool_threads | resource_threads
        queue_threads = {q._thread for q in self.queues if q._thread is not None}
        for thread in threading.enumerate():
            if thread in known or thread in queue_threads:
                continue
            if type(thread) is WorkerThread:
                self.pool_threads.add(thread)
                continue
            self.fail('unknown_worker')
            self.workers[thread] = {'handle': thread, 'stop': None, 'control': False,
                                   'completion': None, 'state': 'STARTED', 'hook_done': True}
        for process in multiprocessing.active_children():
            if process not in self.workers:
                self.fail('unknown_child')
                self.workers[process] = {'handle': process, 'stop': None, 'control': False,
                                        'completion': None, 'state': 'STARTED', 'hook_done': True}

    def stop_producers(self, *, include_control=False):
        with self.guard:
            rows = [r for r in self.workers.values() if include_control or not r['control']]
        for row in rows:
            if row['hook_done']:
                continue
            try:
                if row['stop'] is not None:
                    row['stop']()
                row['hook_done'] = True
            except BaseException:
                self.fail('stop_hook_failed')

    def poll(self, *, include_control=False):
        """No joins/hooks while holding the mutex needed by real body finally."""
        self.request_stop()
        self.stop_producers(include_control=include_control)
        with self.guard:
            self._audit_unknown()
            rows = [r for r in self.workers.values() if include_control or not r['control']]
        for row in rows:
            if not row['hook_done']:
                try:
                    if row['stop'] is not None:
                        row['stop']()
                    row['hook_done'] = True
                except BaseException:
                    self.fail('stop_hook_failed')
                    continue
            if row['state'] in {'JOINED', 'NEVER_STARTED'}:
                continue
            handle = row['handle']
            try:
                handle.join(timeout=0)
                if handle.is_alive():
                    continue
                if isinstance(handle, threading.Thread):
                    row['state'] = 'JOINED'
                else:
                    self.observe_process_completion(handle)
            except BaseException:
                self.fail('worker_inspection_failed')
        with self.guard:
            ready = self.bootstrap == 0 and not self.calls and not self._resources and all(r['state'] in {'JOINED', 'NEVER_STARTED'} and r['hook_done'] for r in rows)
        if ready:
            # Producers are gone; close/join exact registered Queue feeders.
            for channel in self.queues:
                channel.close()
                thread = channel._thread
                if thread is not None:
                    thread.join(timeout=0)
                    if thread.is_alive():
                        ready = False
            for row in rows:
                if row['state'] == 'JOINED' and 'exitcode' in row and not row.get('clean_child'):
                    self.fail('child_cleanup_unverified')
        return ready

    def drain(self, *, include_control=False, tick=None):
        while True:
            try:
                if tick is not None:
                    tick()
                if self.poll(include_control=include_control):
                    return
                with self.changed:
                    self.changed.wait(.025)
            except BaseException:
                self.fail('keeper_exception')
                # Retain ownership, including through repeated KeyboardInterrupt.
                continue

    def summary(self):
        with self.guard:
            return {'calls': len(self.calls), 'bootstrap': self.bootstrap,
                    'unjoined': sum(r['state'] not in {'JOINED', 'NEVER_STARTED'} for r in self.workers.values()),
                    'failures': sorted(self.failures),
                    'resources': len(self._resources),
                    'resource_states': sorted(r._state for r in self._resources.values())}

    def acquire_request_resource(self, kind, loop_cleanup):
        from app.runtime_resources import acquire
        return acquire(self, _CALL.get(), current_owner(), kind, loop_cleanup)

    async def drain_loop_resources(self):
        from app.runtime_resources import drain
        await drain(self)


def start_thread(thread, stop=None, *, control=False):
    owner = current_owner()
    if owner is None:
        thread.start()
        return thread
    original = thread.run
    def run():
        try:
            original()
        except BaseException:
            owner.fail('worker_exception')
            raise
        finally:
            owner.changed_notify()
    thread.run = run
    owner.start(thread, stop=stop, control=control)
    return thread


def _child_entry(target, args, kwargs, completion):
    child = RuntimeOwner()
    install_owner(child)
    try:
        target(*args, **kwargs)
    except BaseException:
        child.fail('child_exception')
        raise
    finally:
        child.drain(include_control=True)
        if not child.failures:
            completion.set()


def start_process(process, stop=None):
    owner = current_owner()
    if owner is None:
        process.start()
        return process
    completion = multiprocessing.get_context('spawn').Event()
    process._target, process._args, process._kwargs = _child_entry, (process._target, process._args, process._kwargs, completion), {}
    owner.start(process, stop=stop, completion=completion)
    return process


def process_finished(process):
    owner = current_owner()
    if owner is not None:
        owner.observe_process_completion(process)


def forced_process_stop():
    owner = current_owner()
    if owner is not None:
        owner.forced()


def register_queue(channel):
    owner = current_owner()
    if owner is not None:
        owner.register_queue(channel)
    return channel


def wrap_application(app, owner):
    from fastapi.routing import APIRoute
    from starlette.routing import Mount
    from starlette.staticfiles import StaticFiles
    from fastapi.routing import _iter_routes_with_context
    def targets():
        found = []
        seen = set()
        for route, context in _iter_routes_with_context(app.routes):
            if isinstance(route, Mount) and isinstance(route.app, StaticFiles):
                found.append(route)
                continue
            if not isinstance(route, APIRoute):
                raise RuntimeError('Unsupported application route')
            for target in (route, context):
                if target is not None and id(target) not in seen:
                    seen.add(id(target))
                    found.append(target)
        return found
    selected = targets()
    asynchronous = [t for t in selected if not isinstance(t, Mount)
                    and inspect.iscoroutinefunction(t.dependant.call)]
    allowed = ()
    if asynchronous:
        # Lazy import preserves the synchronous-only installed source closure.
        # The trusted installer alone supplies exact function/path/method tuples.
        from app.camera_enrollment_routes import owned_endpoint_specs
        from app.phone_setup_routes import owned_endpoint_specs as phone_endpoint_specs
        from app.phone_loading_routes import owned_endpoint_specs as loading_endpoint_specs
        allowed = owned_endpoint_specs(app) + phone_endpoint_specs(app) + loading_endpoint_specs(app)
    for target in selected:
        if isinstance(target, Mount):
            continue
        original = target.dependant.call
        is_async = inspect.iscoroutinefunction(original)
        if (target.dependant.dependencies
                or (is_async and (original, target.path, frozenset(target.methods)) not in allowed)
                or inspect.isgeneratorfunction(original) or inspect.isasyncgenfunction(original)
                or target.dependant.background_tasks_param_name):
            raise RuntimeError('Unsupported endpoint ownership')
    for target in selected:
        if isinstance(target, Mount):
            continue
        original = target.dependant.call
        if inspect.iscoroutinefunction(original):
            @functools.wraps(original)
            async def async_wrapped(*args, __original=original, **kwargs):
                token = _CALL.get()
                with owner.guard:
                    admitted = (current_owner() is owner and owner.accepting
                                and token in owner.calls and token.state == 'QUEUED'
                                and not token.request_ended
                                and token.loop is asyncio.get_running_loop())
                if not admitted:
                    from fastapi import HTTPException
                    raise HTTPException(503, 'Application is stopping.')
                return owner.checked_response(await __original(*args, **kwargs))
            target.dependant.call = async_wrapped
            target.endpoint = async_wrapped
            continue
        @functools.wraps(original)
        def wrapped(*args, __original=original, **kwargs):
            return owner.physical_call(_CALL.get(), __original, *args, **kwargs)
        target.dependant.call = wrapped
        target.endpoint = wrapped
    def snapshot():
        return tuple((id(r), id(getattr(r, 'dependant', None)),
                      id(getattr(getattr(r, 'dependant', None), 'call', None)),
                      id(getattr(r, 'endpoint', None)), getattr(r, 'path', None),
                      frozenset(getattr(r, 'methods', ()) or ()),
                      tuple(id(d) for d in getattr(getattr(r, 'dependant', None), 'dependencies', ())),
                      getattr(getattr(r, 'dependant', None), 'background_tasks_param_name', None))
                     for r in targets())
    inventory = snapshot()
    async def admission(scope, receive, send):
        if scope['type'] == 'lifespan':
            async def observed_receive():
                message = await receive()
                if message['type'] == 'lifespan.shutdown':
                    owner.request_stop()
                return message

            async def observed_send(message):
                if message['type'] in ('lifespan.shutdown.complete', 'lifespan.shutdown.failed'):
                    await owner.drain_loop_resources()
                await send(message)
            try:
                return await app(scope, observed_receive, observed_send)
            finally:
                # Keep original-loop cleanup alive even on failed lifespan.
                await owner.drain_loop_resources()
        if scope['type'] != 'http':
            return await app(scope, receive, send)
        current = snapshot()
        if current != inventory:
            owner.fail('route_inventory_changed')
            owner.request_stop()
        token = owner.admit()
        if token is None:
            from starlette.responses import JSONResponse
            return await JSONResponse({'detail': 'Application is stopping.'}, status_code=503)(scope, receive, send)
        context = _CALL.set(token)
        try:
            return await app(scope, receive, send)
        finally:
            owner.request_ended(token)
            _CALL.reset(context)
    return admission
