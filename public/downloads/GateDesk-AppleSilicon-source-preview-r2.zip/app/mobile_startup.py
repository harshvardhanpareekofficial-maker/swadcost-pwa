"""Explicit console owner authorization; no listener, session or schema creation.

This protects supported startup, not hostile code running as the same OS user.
Only the shared bounded login-attempt ledger is written during authorization.
"""
from contextlib import contextmanager
from dataclasses import dataclass, field
import getpass
import hmac
import json
from pathlib import Path
import re
import sqlite3
import sys
import time
import warnings

from app.accounts import ITERATIONS, WINDOW_SECONDS, password_hash
from app.mobile_config import _path, parse_mobile_config

MAX_CONFIG_BYTES = 16 * 1024


def existing_local_path(value, *, directory=False):
    """Require absolute drive-local paths and reject every reparse component."""
    raw = str(value)
    # Check original segments before pathlib can normalize dot segments away.
    if any(part in ('.', '..') for part in re.split(r'[\\/]', raw)[1:]):
        raise ValueError('phone_startup_invalid_path')
    path = Path(_path(raw))
    for part in (path, *path.parents):
        info = part.lstat()
        if part.is_symlink() or getattr(info, 'st_file_attributes', 0) & 0x400:
            raise ValueError('phone_startup_linked_path')
    if not (path.is_dir() if directory else path.is_file()):
        raise ValueError('phone_startup_existing_path_required')
    return path.resolve(strict=True)


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('phone_startup_duplicate_field')
        result[key] = value
    return result


def read_phone_settings(path):
    try:
        path = existing_local_path(path)
        with path.open('rb') as stream:
            content = stream.read(MAX_CONFIG_BYTES + 1)
        if len(content) > MAX_CONFIG_BYTES:
            raise ValueError('phone_startup_config_too_large')
        value = json.loads(content.decode('utf-8'), object_pairs_hook=_unique_object,
                           parse_constant=lambda _: (_ for _ in ()).throw(ValueError()))
        if parse_mobile_config(value) is None:
            raise ValueError('phone_startup_enabled_config_required')
        return value
    except (OSError, ValueError, TypeError, RecursionError):
        raise ValueError('phone_startup_invalid_enabled_config') from None


def existing_runtime(runtime, document_dir=None):
    """Activation cannot provision a new runtime or silently reset document data."""
    runtime = existing_local_path(runtime, directory=True)
    marker = existing_local_path(runtime / 'runtime-layout.json')
    try:
        if marker.stat().st_size > 4096:
            raise ValueError()
        layout = json.loads(marker.read_text(encoding='utf-8'), object_pairs_hook=_unique_object)
        if (type(layout) is not dict or set(layout) != {'schema_version', 'documents_within_runtime'}
                or type(layout['schema_version']) is not int or layout['schema_version'] != 1
                or type(layout['documents_within_runtime']) is not bool):
            raise ValueError()
        if not layout['documents_within_runtime'] and document_dir is None:
            raise ValueError()
        documents = existing_local_path(document_dir if document_dir is not None else runtime / 'documents',
                                        directory=True)
        # An explicit changed folder must not rewrite the persisted layout.
        if layout['documents_within_runtime'] != (documents == runtime / 'documents'):
            raise ValueError()
        existing_local_path(documents / 'gatepasses.json')
        existing_local_path(runtime / 'reports.sqlite3')
        existing_local_path(runtime / 'accounts.sqlite3')
    except (OSError, ValueError, TypeError, RecursionError):
        raise ValueError('phone_startup_existing_runtime_required') from None
    return runtime, documents


@contextmanager
def _existing_accounts(path):
    # mode=rw prevents a missing account store from becoming a new empty DB.
    path = existing_local_path(path)
    # SQLite may open sidecars implicitly; reject linked existing sidecars too.
    for suffix in ('-wal', '-shm', '-journal'):
        sidecar = path.with_name(path.name + suffix)
        if sidecar.exists() or sidecar.is_symlink():
            existing_local_path(sidecar)
    connection = sqlite3.connect(path.as_uri() + '?mode=rw', uri=True, timeout=0.2)
    try:
        connection.row_factory = sqlite3.Row
        with connection:
            yield connection
    finally:
        connection.close()


@dataclass(frozen=True)
class OwnerAuthorization:
    accounts: Path = field(repr=False)
    factory_id: str
    user_snapshot: tuple = field(repr=False)


_USER_FIELDS = ('id', 'username', 'role', 'salt', 'password_hash', 'iterations', 'active')


def recheck_owner(authorization):
    """Recheck after obtaining runtime ownership, including password/role revocation."""
    if type(authorization) is not OwnerAuthorization:
        raise ValueError('phone_startup_owner_authorization_required')
    try:
        with _existing_accounts(authorization.accounts) as connection:
            connection.execute('BEGIN IMMEDIATE')
            factory = connection.execute('SELECT id FROM factory WHERE singleton=1').fetchone()
            row = connection.execute('SELECT * FROM users WHERE id=?',
                                     (authorization.user_snapshot[0],)).fetchone()
            if (factory is None or factory['id'] != authorization.factory_id or row is None
                    or tuple(row[name] for name in _USER_FIELDS) != authorization.user_snapshot
                    or row['role'] != 'owner' or row['active'] != 1):
                raise ValueError()
    except (OSError, sqlite3.Error, ValueError, KeyError, IndexError):
        raise ValueError('phone_startup_owner_authorization_changed') from None


def authorize_owner(runtime, factory_id):
    """One locally prompted attempt, no argv/env password or issued session."""
    if not sys.stdin.isatty() or not sys.stderr.isatty():
        raise ValueError('phone_startup_interactive_console_required')
    accounts = existing_local_path(Path(runtime) / 'accounts.sqlite3')
    try:
        name = input('Owner ID: ').strip().lower()
        with warnings.catch_warnings():
            warnings.simplefilter('error', getpass.GetPassWarning)
            password = getpass.getpass('Owner password: ')
        if not re.fullmatch(r'[a-z0-9_.-]{3,64}', name) or not 12 <= len(password) <= 128:
            raise ValueError()
        with _existing_accounts(accounts) as connection:
            connection.execute('BEGIN IMMEDIATE')
            factory = connection.execute('SELECT id FROM factory WHERE singleton=1').fetchone()
            if factory is None or factory['id'] != factory_id:
                raise ValueError()
            now = time.time()
            connection.execute('DELETE FROM login_attempts WHERE at<=?', (now - WINDOW_SECONDS,))
            count = connection.execute('SELECT COUNT(*) FROM login_attempts WHERE username=?', (name,)).fetchone()[0]
            total = connection.execute('SELECT COUNT(*) FROM login_attempts').fetchone()[0]
            if count >= 5 or total >= 20:
                raise ValueError()
            connection.execute('INSERT INTO login_attempts(username,at) VALUES (?,?)', (name, now))
            row = connection.execute('SELECT * FROM users WHERE username=? AND active=1', (name,)).fetchone()
        # Bound tampered KDF values; existing app-created accounts use ITERATIONS.
        if row is not None and (row['iterations'] != ITERATIONS or not re.fullmatch(r'[0-9a-f]{64}', row['salt'])
                                or not re.fullmatch(r'[0-9a-f]{64}', row['password_hash'])):
            raise ValueError()
        actual = password_hash(password, row['salt'] if row else '00' * 32, ITERATIONS)
        password = None
        if not hmac.compare_digest(actual, row['password_hash'] if row else '00' * 32) or row is None or row['role'] != 'owner':
            raise ValueError()
        authorization = OwnerAuthorization(accounts, factory_id, tuple(row[name] for name in _USER_FIELDS))
        recheck_owner(authorization)
        return authorization
    except (OSError, sqlite3.Error, ValueError, TypeError, EOFError, getpass.GetPassWarning, KeyError, IndexError):
        raise ValueError('phone_startup_owner_authorization_failed') from None
    finally:
        password = None
