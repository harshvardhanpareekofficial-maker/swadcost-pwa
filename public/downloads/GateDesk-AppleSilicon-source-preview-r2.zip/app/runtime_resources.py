"""Development-only resource leases; not wired into the production runner.

Only trusted fresh-coroutine factories and dedicated thread targets are accepted.
No timeout or caller-provided completion flag can retire ownership. The async
serve fence must remain on the original loop; cleanup failures intentionally hold.
"""
import asyncio
import inspect
import threading
import uuid

TICK = 0.01


class ResourceUnavailable(RuntimeError):
    pass


def _running(loop):
    if asyncio.get_running_loop() is not loop:
        raise ResourceUnavailable('resource_wrong_loop')


def _default_factory(loop):
    if loop.get_task_factory() is not None:
        raise ResourceUnavailable('unsupported_task_factory')


def _task(coroutine, loop):
    # Exact stdlib constructor with an unresolved gate; no user task factory.
    return asyncio.Task(coroutine, loop=loop)


class _Worker:
    def __init__(self, lease, target):
        self.state = 'RESERVED'
        self.cancel = threading.Event()
        self.ack = False
        self.failed = False
        self.rejected_result = None
        self.thread = threading.Thread(target=self._run, args=(lease, target),
                                       name='gate-resource-worker')

    def _run(self, lease, target):
        with lease._owner.guard:
            self.state = 'RUNNING'
        try:
            if not self.cancel.is_set():
                result = target(self.cancel)
                if inspect.isawaitable(result) or inspect.isgenerator(result) or inspect.isasyncgen(result):
                    self.rejected_result = result
                    if inspect.iscoroutine(result) or inspect.isgenerator(result): result.close()
                    raise ResourceUnavailable('synchronous_worker_required')
        except BaseException:
            self.failed = True
            lease._owner.fail('resource_worker_failed')
        finally:
            with lease._owner.guard:
                self.ack = True
            lease._wake()


class OwnedWorker:
    """Observation only. No public completion, close or force-retire operation."""
    def __init__(self, lease): self._lease = lease
    def snapshot(self): return self._lease.snapshot()['worker']


class RequestResourceLease:
    def __init__(self, owner, call, loop, kind, cleanup):
        self._owner, self._call, self._loop = owner, call, loop
        self._generation = uuid.uuid4().hex
        self._kind, self._cleanup = kind, cleanup
        self._state = 'OPEN'
        self._changed = asyncio.Event()
        self._closed = asyncio.Event()
        self._coordinator = None
        self._receive = None
        self._receive_starting = False
        self._receive_cancelled = False
        self._rejected_receive = None
        self._worker = None
        self._failure = None

    def _valid(self):
        return self._owner._resources.get(self._generation) is self

    def _open(self):
        if not self._valid() or self._state != 'OPEN' or not self._owner.accepting:
            raise ResourceUnavailable('resource_closed')

    def _wake_on_loop(self):
        with self._owner.guard:
            valid = self._valid()
        if valid: self._changed.set()

    def _wake(self):
        # No scheduling under the owner guard, including from worker finally.
        try: self._loop.call_soon_threadsafe(self._wake_on_loop)
        except RuntimeError: self._owner.fail('resource_loop_lost')
        self._owner.changed_notify()

    def request_close(self, reason='requested'):
        # Reason is never retained; callers cannot inject private diagnostics.
        with self._owner.guard:
            if not self._valid(): return
            if self._state == 'OPEN': self._state = 'CLOSING'
            worker = self._worker
            if worker is not None and worker.state == 'RESERVED':
                worker.state = 'NEVER_STARTED'
        if worker is not None: worker.cancel.set()
        self._wake()

    def snapshot(self):
        with self._owner.guard:
            worker = self._worker
            return {'state': self._state, 'failure': self._failure,
                    'receive_pending': self._receive_starting or (self._receive is not None and not self._receive.done()),
                    'worker': None if worker is None else {'state': worker.state, 'acknowledged': worker.ack}}

    def _held(self, code):
        with self._owner.guard:
            self._state, self._failure = 'HELD_UNVERIFIED', code
        self._owner.fail(code)
        self._wake()

    def start_receive(self, coroutine_factory):
        _running(self._loop)
        try: _default_factory(self._loop)
        except ResourceUnavailable:
            self._owner.fail('unsupported_task_factory')
            self.request_close()
            raise
        if not callable(coroutine_factory): raise ResourceUnavailable('fresh_coroutine_factory_required')
        with self._owner.guard:
            self._open()
            if self._receive_starting or (self._receive is not None and not self._receive.done()):
                raise ResourceUnavailable('receive_already_owned')
            if self._receive is not None: self._observe_receive()
            self._receive_starting = True
        gate = self._loop.create_future()
        async def run():
            await gate
            with self._owner.guard:
                if not self._valid() or self._state != 'OPEN': return
            # Factory invocation is inside registered work, outside the mutex.
            result = coroutine_factory()
            if not inspect.iscoroutine(result) or inspect.getcoroutinestate(result) != inspect.CORO_CREATED:
                self._rejected_receive = result
                self._held('prestarted_or_invalid_receive')
                raise ResourceUnavailable('fresh_coroutine_required')
            return await result
        coroutine = run()
        try: task = _task(coroutine, self._loop)
        except BaseException:
            coroutine.close()
            with self._owner.guard: self._receive_starting = False
            self._owner.fail('receive_construction_failed')
            self.request_close()
            raise
        with self._owner.guard:
            self._receive, self._receive_cancelled = task, False
            self._receive_starting = False
        gate.set_result(None)
        self._wake()
        return task

    def _observe_receive(self):
        # Only on original loop; retrieving exception observes, never signals completion.
        task = self._receive
        if self._receive_starting: return False
        if task is None: return True
        if not task.done(): return False
        if not task.cancelled() and task.exception() is not None:
            self._owner.fail('resource_receive_failed')
        return True

    def start_worker(self, target):
        _running(self._loop)
        if (not callable(target) or inspect.iscoroutinefunction(target)
                or inspect.iscoroutinefunction(getattr(target, '__call__', None))
                or inspect.isgeneratorfunction(target) or inspect.isasyncgenfunction(target)
                or inspect.isasyncgenfunction(getattr(target, '__call__', None))):
            raise ResourceUnavailable('synchronous_worker_required')
        with self._owner.guard:
            self._open()
            if self._worker is not None: raise ResourceUnavailable('worker_already_owned')
        worker = _Worker(self, target)
        with self._owner.guard:
            self._open()
            self._worker = worker
        try: self._loop.call_soon(self._launch_worker, worker)
        except BaseException:
            with self._owner.guard: worker.state = 'NEVER_STARTED'
            self._owner.fail('resource_start_schedule_failed')
            self.request_close()
            raise
        return OwnedWorker(self)

    def _launch_worker(self, worker):
        with self._owner.guard:
            if (not self._valid() or self._worker is not worker or worker.state != 'RESERVED'):
                return
            if self._state != 'OPEN' or not self._owner.accepting:
                worker.state = 'NEVER_STARTED'
                return
            worker.state = 'STARTING'
        try: worker.thread.start()
        except BaseException:
            self._owner.fail('resource_worker_start_failed')
            # CPython Thread.start registers in _limbo before native launch.
            # An interrupted _started.wait can leave ident unset while launch
            # is pending; ident/Event alone are NOT positive never-start proof.
            with threading._active_limbo_lock:
                never_started = (worker.thread.ident is None and not worker.thread._started.is_set()
                                 and worker.thread not in threading._limbo)
            with self._owner.guard:
                if never_started:
                    worker.state = 'NEVER_STARTED'
                elif worker.state == 'STARTING' and worker.thread._started.is_set():
                    worker.state = 'STARTED'
            self.request_close()
        else:
            with self._owner.guard:
                if worker.state == 'STARTING': worker.state = 'STARTED'
        self._wake()

    def _worker_settled(self):
        with self._owner.guard:
            worker = self._worker
            if worker is None or worker.state in ('NEVER_STARTED', 'JOINED'): return True
            if worker.state in ('RESERVED', 'STARTING'): return False
        # join(0) is nonblocking and outside the guard required by worker finally.
        worker.thread.join(0)
        if worker.thread.is_alive(): return False
        with self._owner.guard:
            worker.state = 'JOINED'
            if not worker.ack:
                missing = True
            else:
                missing = False
        if missing: self._held('resource_worker_ack_missing')
        elif worker.failed:
            self._held('resource_worker_cleanup_unverified')
            return False
        return not missing

    async def _coordinate(self, gate):
        await gate
        while True:
            try:
                self._changed.clear()
                with self._owner.guard: state = self._state
                if state == 'HELD_UNVERIFIED': self._observe_receive()
                if state == 'CLOSING':
                    task = self._receive
                    if task is not None and not task.done() and not self._receive_cancelled:
                        self._receive_cancelled = True
                        task.cancel()
                    if self._observe_receive() and self._worker_settled():
                        with self._owner.guard: self._state = 'CLEANING'
                        try:
                            await self._cleanup()
                        except BaseException:
                            self._held('resource_cleanup_failed')
                        else:
                            with self._owner.guard:
                                if self._valid():
                                    self._state = 'CLOSED'
                                    del self._owner._resources[self._generation]
                            self._closed.set()
                            self._owner.changed_notify()
                            return
                async with asyncio.timeout(TICK):
                    await self._changed.wait()
            except TimeoutError: pass
            except asyncio.CancelledError:
                self._owner.fail('resource_coordinator_cancelled')
                self.request_close()
            except BaseException:
                self._held('resource_coordinator_failed')
                await asyncio.sleep(TICK)

    async def wait_closed(self):
        _running(self._loop)
        await self._closed.wait()  # Cancels only this observation, never coordinator.


def acquire(owner, call, installed, kind, cleanup):
    loop = asyncio.get_running_loop()
    _default_factory(loop)
    if installed is not owner or not callable(cleanup) or kind not in ('upload', 'mobile-db', 'mobile-body'):
        raise ResourceUnavailable('resource_admission_unavailable')
    with owner.guard:
        if (not owner.accepting or call not in owner.calls or call.request_ended or call.loop is not loop
                or call.state not in ('QUEUED', 'RUNNING')
                or owner._resource_loop not in (None, loop)):
            raise ResourceUnavailable('resource_admission_unavailable')
        lease = RequestResourceLease(owner, call, loop, kind, cleanup)
        owner._resources[lease._generation] = lease
        owner._resource_loop = loop
    gate = loop.create_future()
    coroutine = lease._coordinate(gate)
    try: coordinator = _task(coroutine, loop)
    except BaseException:
        coroutine.close()
        with owner.guard: owner._resources.pop(lease._generation, None)
        raise
    with owner.guard: lease._coordinator = coordinator
    gate.set_result(None)
    return lease


async def drain(owner):
    loop = asyncio.get_running_loop()
    with owner.guard:
        if owner._resource_loop is not None and owner._resource_loop is not loop:
            raise ResourceUnavailable('resource_wrong_loop')
    while True:
        try:
            owner.request_stop()
            with owner.guard:
                resources = list(owner._resources.values())
            if not resources: return
            for lease in resources:
                lease.request_close()
                if lease._coordinator.done(): lease._held('resource_coordinator_lost')
        except BaseException:
            owner.fail('resource_drain_failed')
        try: await asyncio.sleep(TICK)
        except BaseException:
            owner.fail('resource_drain_interrupted')


async def serve_with_resource_fence(owner, serve):
    """Uninstalled helper: errors/cancellation cannot escape before resource drain."""
    try:
        return await serve()
    finally:
        await owner.drain_loop_resources()
