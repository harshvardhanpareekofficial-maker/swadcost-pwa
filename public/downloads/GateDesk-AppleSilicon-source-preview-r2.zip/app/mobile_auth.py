"""Isolated remote authentication app factory. No production registration.

Must run inside RuntimeOwner admission and MobileBoundary. Real transport/body
resource admission remains a separate activation gate.
"""
import hmac
import json
from pathlib import Path
import sqlite3

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from pydantic import ValidationError
from app.accounts import Login, password_hash, ITERATIONS
from app.mobile_account_adapter import COOKIE, remote_cookie, session_resolver
from app.mobile_boundary import MobileBoundary
from app.mobile_offload import owned_database_call
from app.mobile_body import read_auth_body
from app.upload_intake import UploadPool, IntakeError


def authenticate(accounts_path, factory_id, body):
    c = sqlite3.connect(Path(accounts_path).resolve().as_uri()+'?mode=ro', uri=True, timeout=0.2)
    c.row_factory = sqlite3.Row
    try:
        row = c.execute('''SELECT u.* FROM users u CROSS JOIN factory f WHERE
            u.username=? AND u.active=1 AND f.singleton=1 AND f.id=?''',
                        (body.username.lower(), factory_id)).fetchone()
    finally:
        c.close()
    actual = password_hash(body.password, row['salt'] if row else '00'*32,
                           row['iterations'] if row else ITERATIONS)
    if not hmac.compare_digest(actual, row['password_hash'] if row else '00'*32):
        return None
    return row['id'] if row else None


def create_mobile_auth(config, store, accounts_path, *, report_db=None, document_backend=None):
    app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)
    auth_body_pool = UploadPool()
    from app.mobile_invitations import install_invitation_routes
    install_invitation_routes(app, config, store, accounts_path, auth_body_pool)
    if document_backend is not None:
        from app.mobile_documents import install_document_routes
        install_document_routes(app, config, document_backend)
    if report_db is not None:
        from app.mobile_report_routes import read_authorized_report

        async def projected(request, sid=None):
            session = getattr(request.state, 'mobile_session', None)
            if (session is None or session.role != 'owner'
                    or session.factory_id != config.factory_id
                    or session.audience != config.canonical_origin):
                return reply({'detail': 'Owner access required.'}, 403)
            return await owned_database_call(
                lambda: read_authorized_report(request, sid, report_db=report_db))

        @app.api_route('/api/mobile/reports', methods=['GET', 'HEAD'])
        async def reports(request: Request):
            return await projected(request)

        @app.api_route('/api/mobile/reports/{sid}', methods=['GET', 'HEAD'])
        async def report(sid: str, request: Request):
            return await projected(request, sid)
    def reply(payload, code=200):
        return JSONResponse(payload, code, headers={'Cache-Control': 'no-store'})
    def cookie(response, token, seconds):
        response.set_cookie(COOKIE, token, max_age=seconds, path='/',
                            secure=True, httponly=True, samesite='strict')

    @app.get('/api/account')
    async def account(request: Request):
        session = request.state.mobile_session
        if session is not None:
            return reply({'authenticated': session.role is not None, 'role': session.role,
                          'factory_id': session.factory_id, 'user_id': session.user_id, 'csrf': session.csrf})
        try:
            token, csrf = await owned_database_call(store.challenge)
        except (sqlite3.Error, ValueError):
            return reply({'detail': 'Sign-in temporarily unavailable.'}, 503)
        response = reply({'authenticated': False, 'csrf': csrf})
        cookie(response, token, 300)
        return response

    @app.post('/api/account/login')
    async def login(request: Request):
        if request.state.mobile_session.role is not None:
            return reply({'detail': 'Already signed in.'}, 409)
        try:
            body = Login.model_validate(json.loads(await read_auth_body(request.receive, auth_body_pool)))
        except IntakeError as exc:
            return reply({'detail': 'Invalid sign-in request.'}, exc.status)
        except (TimeoutError, ValueError, ValidationError):
            return reply({'detail': 'Invalid sign-in request.'}, 400)
        def perform():
            if not store.reserve_login_attempt(body.username.lower()):
                return 429, None
            uid = authenticate(accounts_path, config.factory_id, body)
            if uid is None:
                return 401, None
            return 200, store.issue(uid, remote_cookie(request.scope))
        try:
            status, credentials = await owned_database_call(perform)
        except (sqlite3.Error, ValueError):
            return reply({'detail': 'Sign-in temporarily unavailable.'}, 503)
        if status != 200:
            return reply({'detail': 'Sign-in failed or attempt limit reached.'}, status)
        token, csrf = credentials
        response = reply({'authenticated': True, 'csrf': csrf})
        cookie(response, token, 28800)
        return response

    @app.post('/api/account/logout')
    async def logout(request: Request):
        try:
            await owned_database_call(lambda: store.revoke(remote_cookie(request.scope)))
        except sqlite3.Error:
            return reply({'detail': 'Sign-out temporarily unavailable.'}, 503)
        response = reply({'authenticated': False})
        response.delete_cookie(COOKIE, path='/', secure=True, httponly=True, samesite='strict')
        return response

    return MobileBoundary(app, config, session_resolver(store, owned_database_call))
