"""Durable operator attestations, separate from unvalidated tracker reports.

The confirmation transaction has no notification transport or outbox dependency.
An asynchronous reader may replay these immutable records after a queue failure.
"""
import hashlib
import json
import sqlite3
import os
import threading
import shutil
import uuid
from datetime import datetime, timezone
from app.runtime_owner import start_thread, start_process, process_finished, forced_process_stop, register_queue
from pathlib import Path
from typing import Literal

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

router = APIRouter(prefix='/api/notifications')


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False)


def confirmation_db():
    from app.main import DB
    path = Path(DB).with_name('operator-confirmations.sqlite3')
    c = sqlite3.connect(path, timeout=1)
    c.row_factory = sqlite3.Row
    c.execute('''CREATE TABLE IF NOT EXISTS confirmations (
        id TEXT PRIMARY KEY, request TEXT NOT NULL, evidence TEXT NOT NULL,
        created_at TEXT NOT NULL)''')
    c.execute('CREATE TABLE IF NOT EXISTS notification_handoffs (id TEXT PRIMARY KEY)')
    c.execute('CREATE TABLE IF NOT EXISTS health_incidents (health_key TEXT PRIMARY KEY, id TEXT NOT NULL, active INTEGER NOT NULL, event TEXT NOT NULL)')
    return c


class Confirmation(BaseModel):
    session_id: str = Field(min_length=1, max_length=80)
    kind: Literal['crossing', 'reconciliation']
    event_id: str | None = Field(default=None, min_length=1, max_length=120)
    counted: int | None = Field(default=None, ge=0, le=100000, strict=True)
    reviewer: str = Field(min_length=1, max_length=80)
    evidence_note: str = Field(min_length=10, max_length=1000)
    physically_verified: Literal[True]


@router.post('/confirmations')
def confirm(body: Confirmation):
    from app.movements import database, report
    if not body.reviewer.strip() or not body.evidence_note.strip():
        raise HTTPException(422, 'Reviewer and physical evidence note are required.')
    if body.kind == 'crossing' and (not body.event_id or body.counted is not None):
        raise HTTPException(422, 'Choose one crossing event; do not supply a total.')
    if body.kind == 'reconciliation' and (body.event_id is not None or body.counted is None):
        raise HTTPException(422, 'Supply the independently verified final count.')
    request = canonical(body.model_dump())
    key = hashlib.sha256(canonical([body.session_id, body.kind, body.event_id]).encode()).hexdigest()
    c = confirmation_db()
    try:
        old = c.execute('SELECT * FROM confirmations WHERE id=?', (key,)).fetchone()
        if old:
            if old['request'] != request:
                raise HTTPException(409, 'This confirmation is immutable; conflicting retry rejected.')
            return {'id': key, 'idempotent_retry': True, 'evidence': json.loads(old['evidence'])}
        with database() as source:
            saved = report(source, body.session_id)
            if not saved.get('prediction_source'):
                raise HTTPException(409, 'Choose an evidence-bound tracker report, not a demonstration.')
            if body.kind == 'crossing':
                row = source.execute('SELECT payload FROM replay_events WHERE session_id=? AND event_id=?',
                                     (body.session_id, body.event_id)).fetchone()
                event = json.loads(row['payload']) if row else None
                if not event or event['kind'] != 'crossing' or saved['unit'] != 'bag':
                    raise HTTPException(409, 'Only a saved bag crossing can be confirmed here.')
            else:
                event = None
                if saved['phase'] != 'completed' or not saved.get('document_evidence'):
                    raise HTTPException(409, 'Close the report and attach a reviewed document line first.')
        evidence = {'basis': 'operator_attestation', 'reviewer': body.reviewer.strip(),
                    'note': body.evidence_note.strip(), 'kind': body.kind,
                    'session_id': body.session_id, 'report_snapshot': saved,
                    'event': event, 'counted': body.counted,
                    'difference': body.counted - saved['expected'] if body.counted is not None else None,
                    'model_approved': False}
        with c:
            c.execute('BEGIN IMMEDIATE')
            old = c.execute('SELECT * FROM confirmations WHERE id=?', (key,)).fetchone()
            if old:
                if old['request'] != request:
                    raise HTTPException(409, 'Conflicting concurrent confirmation.')
                return {'id': key, 'idempotent_retry': True, 'evidence': json.loads(old['evidence'])}
            c.execute('INSERT INTO confirmations VALUES (?,?,?,?)',
                      (key, request, canonical(evidence), datetime.now(timezone.utc).isoformat()))
        return {'id': key, 'idempotent_retry': False, 'evidence': evidence}
    finally:
        c.close()


@router.get('/confirmations')
def confirmations():
    c = confirmation_db()
    try:
        return {'rows': [{'id': r['id'], 'created_at': r['created_at'], 'evidence': json.loads(r['evidence'])}
                         for r in c.execute('SELECT * FROM confirmations ORDER BY created_at DESC LIMIT 100')]}
    finally:
        c.close()


@router.get('/review-options')
def review_options():
    from app.movements import database, report
    with database() as c:
        sessions = []
        for row in c.execute('SELECT session_id FROM replay_tracker_bindings ORDER BY rowid DESC LIMIT 100'):
            saved = report(c, row['session_id'])
            events = [json.loads(r['payload']) for r in c.execute(
                'SELECT payload FROM replay_events WHERE session_id=?', (row['session_id'],))]
            sessions.append({'id': saved['id'], 'gatepass': saved['gatepass'], 'unit': saved['unit'],
                             'phase': saved['phase'], 'expected': saved['expected'],
                             'document_bound': bool(saved.get('document_evidence')),
                             'crossings': [e for e in events if e['kind'] == 'crossing' and saved['unit'] == 'bag']})
        return {'sessions': sessions}


def to_notification(row):
    evidence = json.loads(row['evidence'])
    saved = evidence['report_snapshot']
    common = {'event_id': row['id'], 'occurred_at': row['created_at'],
              'operation_id': saved['gatepass'], 'confirmed': True,
              'confirmation_method': 'operator'}
    if evidence['kind'] == 'crossing':
        return {**common, 'occurred_at': evidence['event']['occurred_at'],
                'kind': 'confirmed_crossing', 'material_class': 'bag',
                'direction': evidence['event']['direction']}
    return {**common, 'kind': 'finalized_pass', 'finalized': True,
            'counted': evidence['counted'], 'expected': saved['expected'], 'unit': saved['unit']}


def delivery_eligible(event):
    """Application policy: finalized discrepancies and serious health only."""
    from app.notifications import prepare_event, NotificationPolicyError
    try:
        payload = prepare_event(event)
    except (NotificationPolicyError, TypeError, AttributeError):
        return False
    return (payload['kind'] == 'serious_health' or
            (payload['kind'] == 'finalized_pass' and payload['difference'] != 0))


def handoff_confirmations(outbox):
    c = confirmation_db()
    try:
        rows = c.execute('''SELECT * FROM confirmations WHERE id NOT IN
            (SELECT id FROM notification_handoffs) ORDER BY created_at LIMIT 100''').fetchall()
        for row in rows:
            event = to_notification(row)
            if delivery_eligible(event):
                outbox.enqueue_event(event)
            with c:
                c.execute('INSERT OR IGNORE INTO notification_handoffs VALUES (?)', (row['id'],))
        return len(rows)
    finally:
        c.close()


def record_health_transition(health_key, *, active, message, occurred_at=None):
    """Internal sustained-health adapter, never called by raw image comparison.

    Caller supplies a persistent/verified fault, then a recovery transition.
    Repeated active observations retain one incident identity across restarts.
    """
    if health_key not in {'storage_critical', 'camera_missing', 'camera_degraded'}:
        raise ValueError('Unsupported serious health condition')
    c=confirmation_db()
    try:
        with c:
            c.execute('BEGIN IMMEDIATE')
            previous=c.execute('SELECT * FROM health_incidents WHERE health_key=?',(health_key,)).fetchone()
            if previous and bool(previous['active']) == active:
                return previous['id']
            if not active:
                c.execute('UPDATE health_incidents SET active=0 WHERE health_key=?',(health_key,))
                return None
            event_id=str(uuid.uuid4())
            event={'event_id':event_id,'kind':'serious_health','health_key':health_key,
                   'severity':'critical' if health_key=='storage_critical' else 'serious',
                   'message':message,'active':True,'confirmed':True,'confirmation_method':'health_monitor',
                   'occurred_at':occurred_at or datetime.now(timezone.utc).isoformat()}
            c.execute('INSERT OR REPLACE INTO health_incidents VALUES (?,?,?,?)',
                      (health_key,event_id,1,canonical(event)))
            return event_id
    finally:
        c.close()


def handoff_health(outbox):
    c=confirmation_db()
    try:
        rows=c.execute('SELECT * FROM health_incidents WHERE active=1 AND id NOT IN (SELECT id FROM notification_handoffs)').fetchall()
        for row in rows:
            outbox.enqueue_event(json.loads(row['event']))
            with c:
                c.execute('INSERT OR IGNORE INTO notification_handoffs VALUES (?)',(row['id'],))
        return len(rows)
    finally:
        c.close()


class NotificationService:
    """Background-only handoff and transport; failures never enter count routes."""
    def __init__(self):
        self.stop_event = threading.Event()
        self.thread = None
        self.outbox = None
        self.state = 'starting'
        self.external_enabled = os.environ.get('GATE_DESK_NOTIFY_SEND') == '1'
        self.health_ticks = 0

    def run(self):
        from app.main import DB
        while not self.stop_event.is_set():
            try:
                from app.notifications import NotificationOutbox, NotificationWorker, EmailAdapter
                if self.outbox is None:
                    self.outbox = NotificationOutbox(Path(DB).with_name('notifications.sqlite3'))
                handoff_confirmations(self.outbox)
                if self.health_ticks % 30 == 0:
                    # A measured critical capacity condition, not model output.
                    critical=shutil.disk_usage(Path(DB).parent).free < 256 * 1024**2
                    record_health_transition('storage_critical',active=critical,
                                             message='Gate Desk storage is critically low. Free disk space to protect local records.')
                self.health_ticks += 1
                handoff_health(self.outbox)
                if self.external_enabled:
                    adapter = EmailAdapter.from_env()
                    worker = NotificationWorker(self.outbox, {'email': adapter}, allow_external_send=True,
                                                delivery_policy=delivery_eligible)
                    worker.run_once()
                    self.state = 'running'
                else:
                    self.state = 'local_queue_only'
            except Exception:
                # Never disclose exception strings: provider errors can contain secrets.
                self.state = 'needs_attention'
            self.stop_event.wait(2)

    def start(self):
        self.thread = threading.Thread(target=self.run, name='gate-desk-notifications', daemon=True)
        start_thread(self.thread, self.stop_event.set)

    def stop(self):
        self.stop_event.set()
        if self.thread:
            self.thread.join(timeout=35)
            if self.thread.is_alive():
                self.state = 'shutdown_failed'
                raise RuntimeError('Notification worker has not stopped; keep runtime ownership until process exit.')


@router.get('/health-summary')
def health_summary():
    """Customer-safe unresolved incidents, never a camera-health certification.

    The durable incident state can outlive a monitor or its camera connection.
    Expose this limitation separately; a queue delivery is not a current fault.
    No provider configuration, recipient, report or filesystem path is returned.
    """
    from app.main import app
    service = getattr(app.state, 'notification_service', None)
    thread = getattr(service, 'thread', None)
    running = bool(thread and thread.is_alive() and
                   getattr(service, 'state', None) in {'running', 'local_queue_only'})
    c = confirmation_db()
    try:
        rows = c.execute('SELECT id,health_key,event FROM health_incidents WHERE active=1 ORDER BY health_key').fetchall()
        # Use product-owned wording, not arbitrary persisted event messages.
        messages = {
            'storage_critical': 'Low storage was recorded. Ask your factory administrator to check disk space.',
            'camera_missing': 'A camera interruption was recorded. Counts may need review.',
            'camera_degraded': 'A camera visibility issue was recorded. Counts may need review.',
        }
        incidents = []
        for row in rows:
            if row['health_key'] not in messages:
                continue
            event = json.loads(row['event'])
            incidents.append({'id': row['id'], 'health_key': row['health_key'],
                              'severity': 'critical' if row['health_key'] == 'storage_critical' else 'serious',
                              'message': messages[row['health_key']],
                              'occurred_at': event.get('occurred_at')})
        return {'monitor_state': 'available' if running else 'unavailable',
                'incidents': incidents, 'live_camera_health_verified': False,
                'scope': 'Recorded unresolved incidents; not a live camera-health guarantee.'}
    finally:
        c.close()


@router.get('/status')
def notification_status():
    from app.main import app
    from app.notifications import email_setup_status
    service = getattr(app.state, 'notification_service', None)
    setup = email_setup_status()
    thread = getattr(service, 'thread', None)
    running = bool(thread and thread.is_alive() and service.state in {'running', 'local_queue_only'})
    setup['worker_running'] = running
    setup['delivery_switch_enabled'] = bool(service and service.external_enabled)
    setup['blockers'] += ([] if setup['email_adapter_enabled'] else ['email_adapter_disabled'])
    setup['blockers'] += ([] if setup['delivery_switch_enabled'] else ['external_delivery_disabled'])
    setup['blockers'] += ([] if running else ['worker_not_running'])
    setup['state'] = 'configured_unverified' if not setup['blockers'] else 'needs_setup'
    return {'state': service.state if service else 'not_started',
            'external_send_enabled': bool(service and service.external_enabled),
            'provider': 'email', 'whatsapp': 'not_configured',
            'recipient_configured': setup['recipient_valid'], 'setup': setup,
            'counting_independent': True,
            'event_policy': 'finalized_discrepancies_and_serious_health_only'}


@router.get('/queue')
def notification_queue():
    from app.main import app
    service = getattr(app.state, 'notification_service', None)
    if not service or not service.outbox:
        return {'rows': [], 'state': 'not_started'}
    try:
        return {'rows': service.outbox.list_events(limit=100), 'state': service.state}
    except Exception:
        return {'rows': [], 'state': 'needs_attention'}
