"""Pure future LAN API permissions; NOT installed in the application.

This does not authenticate users or validate TLS, peers, origins, session audience,
request bodies or factory membership. An integration must enforce those separately
before using an authoritative server role here. Never pass a client-selected role.
Public shell assets and report DTO generation are outside this API-only policy.
"""
import re


_PATH = re.compile(r'/api(?:/[A-Za-z0-9_-]+)+', flags=re.ASCII)
_DOCUMENT_READ = re.compile(r'/api/documents/[A-Za-z0-9_-]{1,128}/(?:image|original)', flags=re.ASCII)
_DOCUMENT_REVIEW = re.compile(r'/api/documents/[A-Za-z0-9_-]{1,128}/review', flags=re.ASCII)
# Match the existing report route's producer-ID grammar only here. Documents
# and every other API keep their narrower path grammar.
_REPORT_READ = re.compile(r'/api/mobile/reports/[A-Za-z0-9][A-Za-z0-9_.:-]{0,79}', flags=re.ASCII)
_SHARED_READS = frozenset({
    '/api/account', '/api/documents', '/api/notifications/health-summary',
})


def remote_api_allowed(method: str, path: str, role: str | None, *, raw_path: bytes) -> bool:
    """Deny unknown roles/routes and noncanonical raw/decoded path pairs.

    Query strings belong in ASGI query_string, not either path argument. Their
    validation (including report pagination) is the future handler's responsibility.
    Reject encoded paths rather than decoding again; router normalization must not
    widen permissions. HEAD inherits only an approved GET, never a mutation.
    """
    if role not in (None, 'owner', 'worker'):
        return False
    if not isinstance(method, str) or method not in ('GET', 'HEAD', 'POST'):
        return False
    if not isinstance(path, str) or not isinstance(raw_path, bytes):
        return False
    if len(raw_path) > 512 or len(path) > 512:
        return False
    if not (_PATH.fullmatch(path) or _REPORT_READ.fullmatch(path)):
        return False
    if raw_path != path.encode('ascii'):
        return False
    read = method in ('GET', 'HEAD')
    if role is None:
        return (read and path == '/api/account') or (
            method == 'POST' and path in ('/api/account/login', '/api/account/worker-invitations/redeem'))
    if read and (path in _SHARED_READS or _DOCUMENT_READ.fullmatch(path)):
        return True
    if method == 'POST' and path == '/api/account/logout':
        return True
    if method == 'POST' and path == '/api/documents/submit':
        return True
    if role == 'worker':
        return method == 'POST' and bool(
            path == '/api/documents/import-image' or _DOCUMENT_REVIEW.fullmatch(path))
    if path == '/api/account/worker-invitations':
        return read or method == 'POST'
    if method == 'POST' and re.fullmatch(r'/api/account/worker-invitations/[A-Za-z0-9-]{1,80}/revoke', path):
        return True
    return read and bool(path == '/api/mobile/reports' or _REPORT_READ.fullmatch(path))
