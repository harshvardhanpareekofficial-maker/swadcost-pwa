"""Retained original-loop Uvicorn ownership for the local runtime.

This is a pinned lifecycle integration, not TLS/LAN activation. Unresolved
ownership intentionally keeps the loop alive; a timeout is not a release proof.
"""
import asyncio
from contextlib import contextmanager
from dataclasses import dataclass
import hashlib
import importlib
from pathlib import Path
import sys
import threading
import socket
from ipaddress import IPv4Address, IPv4Network

import uvicorn

SOURCE_PINS = {
    'uvicorn.server': '7c1dbd656835c9cdd6f92078ffc80bcc6007824ab322aff15435bd89c068e0be',
    'uvicorn.lifespan.on': '8844cf163e921613c33dc75e1b17dae372ca226254ecc2398bb41451ea4170f1',
    'asyncio.base_events': '53b71bbbd79e7fb2251460119afc379ebd71bbc599d9018313cc62ef218ae795',
    'asyncio.proactor_events': '62d15e99315cae52e8548f487391ae6c46827bf8e5b4bcf3382c777a494a759b',
}


def verify_lifecycle_runtime():
    if tuple(sys.version_info[:3]) != (3, 12, 14) or uvicorn.__version__ != '0.52.4':
        raise RuntimeError('unsupported_lifecycle_runtime')
    try:
        valid = all(hashlib.sha256(Path(importlib.import_module(name).__file__).read_bytes()).hexdigest() == sha
                    for name, sha in SOURCE_PINS.items())
    except Exception:
        raise RuntimeError('lifecycle_source_verification_failed') from None
    if not valid:
        raise RuntimeError('lifecycle_source_verification_failed')


def validate_tls_bind_address(address):
    """Permit exact loopback or explicit RFC1918 IPv4; never resolve a name."""
    try:
        if type(address) is not str:
            raise ValueError()
        ip = IPv4Address(address)
        if address != '127.0.0.1' and not any(
                ip in IPv4Network(network) for network in ('10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16')):
            raise ValueError()
    except ValueError:
        raise ValueError('invalid_tls_bind_address') from None
    return address


def _reserve_listener(address, port):
    """Own the exact socket across bind and server startup, with no rebind gap.

    The caller must retain and close this socket after server settlement. A
    bind failure occurs before app startup and cannot create an async listener.
    """
    if type(port) is not int or not 1 <= port <= 65535:
        raise ValueError('invalid_server_port')
    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        if sys.platform == 'win32':
            listener.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        listener.bind((address, port))
        listener.setblocking(False)
        return listener
    except BaseException:
        listener.close()
        raise


def reserve_loopback_listener(port):
    return _reserve_listener('127.0.0.1', port)


def reserve_private_listener(address, port):
    """Explicit private TLS reservation; caller retains ownership until fenced."""
    validate_tls_bind_address(address)
    if address == '127.0.0.1':
        raise ValueError('private_tls_bind_required')
    return _reserve_listener(address, port)


class PhysicalReadiness:
    """One generation, one existing off-loop control poller; no extra worker."""
    def __init__(self, owner, generation):
        self.owner, self.generation = owner, generation
        self.armed, self.ready = threading.Event(), threading.Event()

    def arm(self):
        self.owner.request_stop()
        self.armed.set()

    def poll(self):
        if not self.armed.is_set():
            return
        try:
            if self.owner.poll(include_control=False):
                self.ready.set()
        except BaseException:
            self.owner.fail('physical_readiness_poll_failed')


class LifespanObservation:
    def __init__(self, owner):
        self.owner = owner
        self.task = None
        self.exited = False
        self.startup = self.shutdown = 0
        self.failed = False

    def enter(self):
        if self.task is not None:
            self.owner.fail('duplicate_lifespan_invocation')
            raise RuntimeError('duplicate_lifespan_invocation')
        self.task = asyncio.current_task()

    def message(self, kind):
        if kind == 'lifespan.startup.complete':
            self.startup += 1
        elif kind == 'lifespan.shutdown.complete':
            self.shutdown += 1
        elif kind.endswith('.failed'):
            self.failed = True
            self.owner.fail('lifespan_failed')

    def exit(self):
        self.exited = True


@dataclass(frozen=True)
class Outcome:
    ok: bool
    error: str = ''


class LifespanProxy:
    def __init__(self, original, server):
        self.original, self.server = original, server
        self.startup_task = self.shutdown_task = None
        self.listener_expected = False

    def __getattr__(self, name):
        return getattr(self.original, name)

    async def startup(self):
        if self.startup_task is None:
            self.startup_task = self.server._retain(self.original.startup, 'lifespan_startup')
        result = await self.server._observe(self.startup_task)
        if not result.ok:
            raise RuntimeError('lifespan_startup_failed')
        self.listener_expected = not self.original.should_exit

    async def shutdown(self):
        if self.shutdown_task is None:
            async def invoke():
                observation = self.server.observation
                # An ended ASGI consumer cannot process another shutdown event.
                if observation.task is not None and observation.task.done():
                    if observation.shutdown != 1:
                        self.server.owner.fail('lifespan_ended_before_shutdown')
                    return
                await self.original.shutdown()
            self.shutdown_task = self.server._retain(invoke, 'lifespan_shutdown')
        return await self.server._observe(self.shutdown_task)


class OwnedServer(uvicorn.Server):
    def __init__(self, config, owner, observation, readiness, *, bound_socket=None,
                 bound_address='127.0.0.1'):
        verify_lifecycle_runtime()
        super().__init__(config)
        if readiness.owner is not owner or observation.owner is not owner:
            raise RuntimeError('lifecycle_owner_mismatch')
        self.owner, self.observation, self.readiness = owner, observation, readiness
        self.loop = None
        self.tasks = []
        self.listeners = []
        self.servers = []
        self.listener_waits = []
        self.startup_task = self.shutdown_task = self.serve_task = self.resource_task = None
        self.unknown_listener = False
        self.held_reason = None
        self.fence_complete = False
        self.bound_socket = bound_socket
        self.bound_address = validate_tls_bind_address(bound_address)
        if self.bound_address != '127.0.0.1' and bound_socket is None:
            raise ValueError('private_tls_prebound_required')

    @contextmanager
    def capture_signals(self):
        yield  # RuntimeOwner retains the existing signal/generation policy.

    def _retain(self, operation, label):
        if self.loop is not asyncio.get_running_loop() or self.loop.get_task_factory() is not None:
            raise RuntimeError('unsupported_lifecycle_task_factory_or_loop')
        async def guarded():
            try:
                await operation()
                return Outcome(True)
            except BaseException as error:
                self.owner.fail(label + '_failed')
                return Outcome(False, 'cancelled' if isinstance(error, asyncio.CancelledError) else 'exception')
        task = self.loop.create_task(guarded(), name='gate-' + label)
        self.tasks.append(task)
        return task

    def _stop(self):
        self.should_exit = True
        try:
            self.readiness.arm()
        except BaseException:
            self.owner.fail('lifecycle_stop_unverified')

    async def _observe(self, task):
        while not task.done():
            try:
                await asyncio.shield(task)
            except BaseException:
                self.owner.fail('lifecycle_observer_interrupted')
                self._stop()
        try:
            result = task.result()
        except BaseException:
            self.owner.fail('retained_task_unverified')
            return Outcome(False, 'unverified')
        return result

    async def _tick(self):
        try:
            await asyncio.sleep(.025)
        except BaseException:
            self.owner.fail('lifecycle_fence_interrupted')
            self._stop()

    async def _hold(self, reason):
        self.held_reason = reason
        self.owner.fail(reason)
        self._stop()
        while True:
            await self._tick()

    def _capture_listeners(self):
        for listener in self.servers:
            if not isinstance(listener, asyncio.Server) or listener.get_loop() is not self.loop:
                self.unknown_listener = True
            elif listener not in self.listeners:
                self.listeners.append(listener)

    async def startup(self, sockets=None):
        if (sockets is not None or self.config.fd is not None or self.config.uds is not None
                or self.config.host != self.bound_address or type(self.config.port) is not int
                or not 1 <= self.config.port <= 65535 or self.config.workers != 1):
            raise RuntimeError('unsupported_owned_startup_shape')
        if self.bound_address != '127.0.0.1':
            import ssl
            context = getattr(self.config, 'ssl', None)
            if (self.bound_socket is None or not isinstance(context, ssl.SSLContext)
                    or context.protocol != ssl.PROTOCOL_TLS_SERVER):
                raise RuntimeError('private_owned_tls_required')
        if self.bound_socket is not None:
            if (not isinstance(self.bound_socket, socket.socket)
                    or self.bound_socket.family != socket.AF_INET
                    or self.bound_socket.type != socket.SOCK_STREAM
                    or self.bound_socket.getsockname() != (self.bound_address, self.config.port)
                    or self.bound_socket.getblocking()):
                raise RuntimeError('invalid_reserved_listener')
        self.servers = []
        self.lifespan = LifespanProxy(self.lifespan, self)
        if self.startup_task is None:
            reserved = [self.bound_socket] if self.bound_socket is not None else None
            self.startup_task = self._retain(lambda: super(OwnedServer, self).startup(sockets=reserved), 'server_startup')
        result = await self._observe(self.startup_task)
        self._capture_listeners()
        if not result.ok:
            # Pinned create_server closes sockets on ordinary bind errors, but
            # later Server._start_serving/yield failures are indistinguishable
            # here. Missing return is NOT proof that no listener was created.
            if self.lifespan.listener_expected and not self.listeners:
                self.unknown_listener = True
            raise RuntimeError('owned_startup_failed')

    def _start_resources(self):
        self._stop()
        if self.resource_task is None:
            self.resource_task = self._retain(self.owner.drain_loop_resources, 'resource_drain')

    def _close_listeners(self):
        self._capture_listeners()
        if self.listener_waits:
            return
        for listener in self.listeners:
            try:
                listener.close()
            except BaseException:
                self.unknown_listener = True
                self.owner.fail('listener_close_failed')
            self.listener_waits.append(self._retain(listener.wait_closed, 'listener_wait'))

    async def shutdown(self, sockets=None):
        self._start_resources()
        self._close_listeners()
        if self.shutdown_task is None:
            self.shutdown_task = self._retain(lambda: super(OwnedServer, self).shutdown(sockets=None), 'server_shutdown')
        return await self._observe(self.shutdown_task)

    async def _fence(self):
        self._start_resources()
        self._close_listeners()
        if hasattr(self, 'lifespan') and isinstance(self.lifespan, LifespanProxy):
            await self.shutdown()
            # Original server shutdown can fail before reaching lifespan.
            await self.lifespan.shutdown()
        resources = await self._observe(self.resource_task)
        if not resources.ok:
            await self._hold('resource_drain_unverified')
        for waiter in self.listener_waits:
            if not (await self._observe(waiter)).ok:
                await self._hold('listener_wait_unverified')
        if self.unknown_listener:
            await self._hold('listener_return_ownership_unverified')
        observation = self.observation
        if observation.task is not None:
            while not observation.task.done():
                await self._tick()
            # Consume any exception without exposing application data.
            try:
                observation.task.result()
            except BaseException:
                self.owner.fail('lifespan_invocation_failed')
        elif isinstance(getattr(self, 'lifespan', None), LifespanProxy):
            await self._hold('lifespan_invocation_ownership_unverified')
        if isinstance(getattr(self, 'lifespan', None), LifespanProxy):
            original = self.lifespan.original
            if any(getattr(original, name, None) is not False for name in ('error_occurred', 'startup_failed', 'shutdown_failed')):
                self.owner.fail('lifespan_failed')
        if (observation.startup != 1 or observation.shutdown != 1
                or not observation.exited or observation.failed):
            self.owner.fail('lifespan_completion_unverified')
        # A raised shutdown or force_exit cannot bypass real HTTP task/transport
        # settlement. No cancellation/force-close is used as completion evidence.
        while self.server_state.tasks or self.server_state.connections:
            await self._tick()
        if self.force_exit:
            self.owner.fail('server_force_exit')
        while not self.readiness.ready.is_set():
            await self._tick()
        self.fence_complete = True

    async def serve(self, sockets=None):
        if self.loop is not None:
            raise RuntimeError('owned_server_single_use')
        self.loop = asyncio.get_running_loop()
        if self.loop.get_task_factory() is not None:
            raise RuntimeError('unsupported_lifecycle_task_factory')
        try:
            self.serve_task = self._retain(lambda: super(OwnedServer, self).serve(sockets=sockets), 'server_serve')
            await self._observe(self.serve_task)
        except BaseException:
            # Creation/observation failures cannot discard possible scheduled work.
            await self._hold('server_serve_ownership_unverified')
        # Inspection/fence errors never unwind the original loop or lock.
        try:
            await self._fence()
        except BaseException:
            await self._hold('lifecycle_fence_unverified')
