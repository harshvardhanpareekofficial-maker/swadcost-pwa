"""Bounded auth JSON receive using owned tasks; not a socket/header limit."""
import asyncio
from app.runtime_owner import current_owner
from app.runtime_resources import ResourceUnavailable
from app.upload_intake import IntakeError


async def read_auth_body(receive, pool, *, seconds=5):
    owner = current_owner()
    if owner is None:
        raise ResourceUnavailable('mobile_owner_required')
    token = pool.try_acquire()
    buffer = bytearray()
    async def cleanup():
        buffer[:] = b'\0' * len(buffer)
        buffer.clear()
        pool.release(token)
    try:
        lease = owner.acquire_request_resource('mobile-body', cleanup)
    except BaseException:
        pool.release(token)
        raise
    deadline = asyncio.get_running_loop().time() + seconds
    try:
        while True:
            pending = lease.start_receive(receive)
            done, _ = await asyncio.wait({pending}, timeout=max(0, deadline-asyncio.get_running_loop().time()))
            if not done or asyncio.get_running_loop().time() >= deadline:
                raise IntakeError(408, 'auth_body_timeout')
            message = pending.result()
            if not isinstance(message, dict) or message.get('type') != 'http.request':
                raise IntakeError(400, 'auth_body_disconnected')
            chunk = message.get('body', b'')
            if type(chunk) is not bytes or type(message.get('more_body', False)) is not bool:
                raise IntakeError(400, 'auth_body_invalid')
            if len(buffer) + len(chunk) > 4096:
                raise IntakeError(413, 'auth_body_too_large')
            buffer.extend(chunk)
            if not message.get('more_body', False):
                return bytes(buffer)
    finally:
        lease.request_close()
        # If this observation is cancelled again, the registered coordinator
        # still holds both receive and permit until actual receive settlement.
        await lease.wait_closed()
