"""Owned reader-publication telemetry. No inference about camera fault causes.

Monotonic samples measure unchanged published progress, including reader
scheduling and processing delays. Only the observer writes the bounded journal.
"""
from __future__ import annotations
from app.runtime_owner import start_thread, start_process, process_finished, forced_process_stop, register_queue

import hashlib
import json
import math
from pathlib import Path
import queue
import threading
import time
import uuid
from contextlib import contextmanager

from app.camera_ingest import _atomic_json

MESSAGE = ("The recorder did not publish a progress update for an observed interval "
           "of at least 30 seconds while recording was requested. The cause is "
           "undetermined; check the recorder and recording.")
NS = 1_000_000_000
MAX_MESSAGE = 32768


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def encode(value):
    raw = json.dumps(value, separators=(",", ":")).encode()
    if len(raw) > MAX_MESSAGE:
        raise ValueError("progress_transport_invalid")
    return raw


def decode(raw):
    if not isinstance(raw, bytes) or len(raw) > MAX_MESSAGE:
        raise ValueError("progress_transport_invalid")
    value = json.loads(raw)
    if not isinstance(value, dict):
        raise ValueError("progress_transport_invalid")
    return value


class Publication:
    """Only reader calls publish; any failed lock permanently poisons telemetry."""
    def __init__(self, session_id, epoch=None):
        self.session_id = session_id
        self.epoch = epoch or str(uuid.uuid4())
        self.lock = threading.Lock()
        self.invalid = threading.Event()
        self.value = dict(sequence=0, packets=0, accepted_segment=None, milestone=None)
        self.reader = None

    def publish(self, packets, accepted_segment=None):
        if self.invalid.is_set():
            return False
        if not self.lock.acquire(timeout=.01):
            self.invalid.set()
            return False
        try:
            owner = threading.get_ident()
            if self.reader is None:
                self.reader = owner
            if (self.reader != owner or type(packets) is not int or packets < self.value['packets']
                    or (accepted_segment is None and packets <= self.value['packets'])
                    or (accepted_segment is not None and not isinstance(accepted_segment, str))):
                self.invalid.set()
                return False
            self.value = dict(sequence=self.value['sequence'] + 1, packets=packets,
                              accepted_segment=accepted_segment or self.value['accepted_segment'],
                              milestone='segment' if accepted_segment else 'packet')
            return True
        finally:
            self.lock.release()

    def snapshot(self):
        if self.invalid.is_set() or not self.lock.acquire(timeout=.01):
            self.invalid.set()
            raise ValueError('progress_publication_invalid')
        try:
            if self.invalid.is_set():
                raise ValueError('progress_publication_invalid')
            return dict(self.value)
        finally:
            self.lock.release()


class Observer:
    def __init__(self, home, publication, identity, *, demand, requests=None, responses=None,
                 monotonic_ns=time.monotonic_ns, wall=time.time, max_session_seconds=1800):
        if type(max_session_seconds) is not int or not 1 <= max_session_seconds <= 1800:
            raise ValueError('progress_session_bound_invalid')
        self.home = Path(home)
        self.publication = publication
        self.identity = dict(identity, epoch=publication.epoch)
        self.demand = demand
        self.requests, self.responses = requests, responses
        self.mono, self.wall = monotonic_ns, wall
        self.origin, self.anchor = self.mono(), self.wall()
        self.max_session_ns = max_session_seconds*NS
        self.last_mono = self.last_wall = None
        self.last_sample = None
        self.baseline = None
        self.points = []
        self.wall_points = []
        self.window_key = None
        self.head = None
        self.ordinal = 0
        self.retired = False
        self.error_code = None
        self.stop_event = threading.Event()
        self.thread = None

    def retire(self, code):
        self.retired, self.error_code = True, code
        self.points = []
        self.wall_points = []
        self.last_sample = None

    def _active(self):
        return (not self.retired and not self.stop_event.is_set() and self.demand() is True
                and 0 <= self.mono()-self.origin < self.max_session_ns)

    def accept_baseline(self, baseline):
        # Sent only over the parent's owned channel after rehashing acceptance.
        current = self.publication.snapshot()
        if (not isinstance(baseline, dict) or set(baseline) != {'segment_id','source_sha256','receipt_sha256'}
                or any(not isinstance(baseline[k], str) or len(baseline[k]) != 64
                       or any(c not in '0123456789abcdef' for c in baseline[k])
                       for k in ('source_sha256','receipt_sha256'))):
            raise ValueError('progress_baseline_invalid')
        if baseline['segment_id'] != current['accepted_segment']:
            self.points, self.window_key, self.last_sample = [], None, None
            self.wall_points = []
            return False  # Normal race with a newly sealed, unacknowledged segment.
        if baseline != self.baseline:
            self.baseline = dict(baseline)
            self.points, self.window_key, self.last_sample = [], None, None
            self.wall_points = []
        return True

    def sample(self):
        try:
            if not self._active():
                self.retire('progress_lifecycle_retired')
                return
            now, wall = self.mono(), self.wall()
            elapsed = now - self.origin
            if (elapsed < 0 or elapsed > 1800 * NS or
                    (self.last_mono is not None and (now <= self.last_mono or
                     now-self.last_mono > 1.5*NS or wall < self.last_wall)) or
                    abs((wall-self.anchor)-elapsed/NS) > 2):
                self.retire('progress_clock_or_cadence_invalid')
                return
            self.last_mono, self.last_wall = now, wall
            current = self.publication.snapshot()
            if self.baseline is None:
                return
            # A new seal must be acknowledged by parent before another window.
            if current['accepted_segment'] != self.baseline['segment_id']:
                self.points, self.window_key, self.last_sample = [], None, None
                self.wall_points = []
                return
            key = (current['sequence'], digest(self.baseline))
            if key != self.window_key:
                self.points, self.window_key = [], key
                self.wall_points = []
            self.last_sample = dict(current, elapsed_ns=elapsed)
            self.points.append(elapsed)
            self.wall_points.append(wall)
            if len(self.points) > 16:
                raise ValueError('progress_sample_cap')
            if self.points[-1]-self.points[0] >= 5*NS:
                if self.ordinal >= 512:
                    raise ValueError('progress_record_cap')
                self.home.mkdir(parents=True, exist_ok=True)
                self.ordinal += 1
                record = dict(version=1, identity=self.identity, ordinal=self.ordinal,
                    previous=self.head, baseline=self.baseline, sequence=current['sequence'],
                    packets=current['packets'], samples=self.points, scope='reader_published_progress_unchanged')
                record.update(epoch_anchor_unix_seconds=self.anchor,wall_samples=self.wall_points)
                path = self.home / f'span-{self.ordinal:05d}.json'
                if path.exists():
                    raise ValueError('progress_record_collision')
                _atomic_json(path, record)
                self.head = dict(ordinal=self.ordinal, sha256=hashlib.sha256(path.read_bytes()).hexdigest())
                _atomic_json(self.home/'checkpoint.json', dict(identity=self.identity, head=self.head))
                self.points = [elapsed]
                self.wall_points = [wall]
        except Exception:
            self.retire('progress_observer_invalid')

    def reply(self, request):
        if set(request) != {'nonce','identity','baseline','head'} or request['identity'] != self.identity:
            raise ValueError('progress_request_invalid')
        if not isinstance(request['nonce'], str) or len(request['nonce']) != 32:
            raise ValueError('progress_request_invalid')
        if request['baseline'] is not None:
            self.accept_baseline(request['baseline'])
        current = self.publication.snapshot()
        now = self.mono()-self.origin
        valid = (self._active() and self.last_sample is not None and
                 current == {k:v for k,v in self.last_sample.items() if k != 'elapsed_ns'} and
                 0 <= now-self.last_sample['elapsed_ns'] <= 1.5*NS and
                 request['head'] == self.head and self.head is not None)
        return dict(nonce=request['nonce'], identity=self.identity, baseline=self.baseline,
                    head=self.head, current=current, sample_ns=self.last_sample['elapsed_ns'] if self.last_sample else None,
                    response_ns=now, eligible=bool(valid), error_code=self.error_code,
                    active=bool(self._active() and self.last_mono is not None
                                and 0 <= now-(self.last_mono-self.origin) <= 1.5*NS
                                and self.baseline is not None
                                and current['accepted_segment']==self.baseline['segment_id']))

    def _run(self):
        next_sample = self.mono()
        try:
            while not self.stop_event.wait(.025):
                if self.mono() >= next_sample:
                    self.sample()
                    next_sample = self.mono()+int(.5*NS)
                if self.requests is not None:
                    try:
                        request = decode(self.requests.get_nowait())
                    except queue.Empty:
                        continue
                    response = self.reply(request)
                    self.responses.put_nowait(encode(response))
        except Exception:
            self.retire('progress_transport_or_observer_invalid')
        finally:
            self.retire('progress_observer_stopped')

    def start(self):
        self.thread = threading.Thread(target=self._run, name='recorder-progress-observer', daemon=False)
        start_thread(self.thread, self.stop_event.set)

    def stop(self, *, retain_ownership=False):
        self.stop_event.set()
        if self.thread:
            self.thread.join(timeout=2)
            if self.thread.is_alive():
                if retain_ownership:
                    # Called under the child's ingest lock. Only completion or
                    # parent bounded process termination may release that lock.
                    while self.thread.is_alive():
                        self.thread.join(timeout=.1)
                raise RuntimeError('progress_observer_not_stopped')


@contextmanager
def progress_lifetime(publication):
    observer = getattr(publication, '_observer', None)
    if observer:
        observer.start()
    try:
        yield
    finally:
        if observer:
            observer.stop(retain_ownership=True)


def verify_chain(home, identity, baseline):
    """Bounded full chain check. No timestamps or booleans establish freshness."""
    home = Path(home)
    def read(path):
        with path.open('rb') as source:
            raw = source.read(MAX_MESSAGE+1)
        if len(raw) > MAX_MESSAGE:
            raise ValueError('progress_record_oversize')
        return json.loads(raw), hashlib.sha256(raw).hexdigest()
    checkpoint, _ = read(home/'checkpoint.json')
    if checkpoint['identity'] != identity:
        raise ValueError('progress_identity_invalid')
    head = checkpoint['head']
    if type(head['ordinal']) is not int or not 1 <= head['ordinal'] <= 512:
        raise ValueError('progress_record_cap')
    previous, key, start, end, spans, sequence, packets = None, None, None, None, 0, -1, -1
    anchor, last_wall = None, None
    for ordinal in range(1, head['ordinal']+1):
        row, sha = read(home/f'span-{ordinal:05d}.json')
        points = row['samples']
        walls, row_anchor = row['wall_samples'], row['epoch_anchor_unix_seconds']
        if (row['identity'] != identity or row['ordinal'] != ordinal or row['previous'] != previous
                or row['version'] != 1 or row['scope'] != 'reader_published_progress_unchanged'
                or not isinstance(points,list) or not 2 <= len(points) <= 16
                or any(type(p) is not int or not 0 <= p <= 1800*NS for p in points)
                or any(not 0 < b-a <= 1.5*NS for a,b in zip(points,points[1:]))
                or not 5*NS <= points[-1]-points[0] <= 6.5*NS
                or type(row['sequence']) is not int or row['sequence'] < sequence
                or type(row['packets']) is not int or row['packets'] < packets):
            raise ValueError('progress_chain_invalid')
        if (type(row_anchor) not in {int,float} or not math.isfinite(row_anchor)
                or (anchor is not None and row_anchor != anchor) or len(walls) != len(points)
                or any(type(w) not in {int,float} or not math.isfinite(w) for w in walls)
                or any(b < a for a,b in zip(walls,walls[1:]))
                or any(abs(w-row_anchor-p/NS)>2 for w,p in zip(walls,points))
                or (last_wall is not None and walls[0]<last_wall)):
            raise ValueError('progress_wall_epoch_invalid')
        anchor,last_wall=row_anchor,walls[-1]
        newkey=(row['sequence'],digest(row['baseline']))
        if newkey == key and end != points[0]:
            raise ValueError('progress_chain_gap')
        if end is not None and points[0] < end:
            raise ValueError('progress_chain_regression')
        if newkey != key:
            start, spans = points[0], 0
        key, end, spans = newkey, points[-1], spans+1
        sequence, packets = row['sequence'], row['packets']
        previous=dict(ordinal=ordinal,sha256=sha)
    if previous != head:
        raise ValueError('progress_head_invalid')
    return dict(identity=identity,baseline=baseline,head=head,sequence=sequence,packets=packets,
                start_ns=start,end_ns=end,qualified=(row['baseline']==baseline and spans>=2 and end-start>=30*NS))


class Grant:
    """In-memory, one-use authorization; no persistence and no cross-origin math."""
    def __init__(self, evidence, deadline, *, monotonic=time.monotonic):
        self.evidence, self.deadline, self.mono, self.used = evidence, deadline, monotonic, False
        self.valid = lambda: True

    def consume(self):
        if self.used or not self.valid() or self.mono() >= self.deadline:
            self.used = True
            raise ValueError('progress_grant_expired_or_used')
        self.used = True
        return self.evidence


def request_grant(requests, responses, identity, baseline, evidence, *, monotonic=time.monotonic, on_current=None):
    """One request/reply. Baseline priming also uses this bounded owned channel."""
    nonce = uuid.uuid4().hex
    deadline = monotonic()+.5
    requests.put_nowait(encode(dict(nonce=nonce,identity=identity,baseline=baseline,
                                   head=evidence['head'] if evidence else None)))
    response = decode(responses.get(timeout=max(0,deadline-monotonic())))
    if response.get('error_code'):
        raise ValueError('progress_observer_needs_attention')
    if (monotonic() >= deadline or response.get('nonce') != nonce or response.get('identity') != identity
            or response.get('baseline') != baseline or response.get('active') is not True):
        return None
    if on_current is not None:
        on_current()  # Fresh accepted recording can recover without a new stall.
    if (response.get('eligible') is not True or evidence is None or not evidence['qualified']
            or response.get('head') != evidence['head'] or response.get('baseline') != baseline
            or response['current']['sequence'] != evidence['sequence']
            or response['current']['packets'] != evidence['packets']
            or type(response.get('sample_ns')) is not int or type(response.get('response_ns')) is not int
            or not 0 <= response['response_ns']-response['sample_ns'] <= 1.5*NS
            or response['sample_ns'] < evidence['end_ns']):
        return None
    return Grant(evidence,deadline,monotonic=monotonic)
