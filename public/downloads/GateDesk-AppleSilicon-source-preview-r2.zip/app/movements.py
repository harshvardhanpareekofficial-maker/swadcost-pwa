"""Durable replay-event ledger. Accepts completed crossings, not detections.

Camera/tracker connection is not implemented here. Every report identifies replay
mode so injected test events cannot be mistaken for verified factory counts.
"""
import json
import csv
import io
import hashlib
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Literal

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import Response
from pydantic import BaseModel, Field, field_validator

router = APIRouter(prefix='/api/replay-sessions')


class SessionInput(BaseModel):
    id: str = Field(min_length=1, max_length=80)
    gatepass: str = Field(min_length=1, max_length=80)
    material: str = Field(min_length=1, max_length=80)
    unit: Literal['bag', 'beam', 'cone', 'roll', 'bundle', 'carton', 'unit']
    direction: Literal['Incoming', 'Outgoing']
    expected: int = Field(ge=1, le=10000, strict=True)

    @field_validator('id', 'gatepass', 'material')
    @classmethod
    def nonblank(cls, value):
        if not value.strip():
            raise ValueError('Value cannot be blank')
        return value.strip()


class EventInput(BaseModel):
    id: str = Field(min_length=1, max_length=120)
    kind: Literal['crossing', 'visibility_lost', 'visibility_restored', 'stream_gap', 'review_hold']
    occurred_at: datetime
    direction: Literal['Incoming', 'Outgoing'] | None = None
    track_id: str | None = Field(default=None, min_length=1, max_length=120)

    @field_validator('id', 'track_id')
    @classmethod
    def nonblank(cls, value):
        if value is not None and not value.strip():
            raise ValueError('Value cannot be blank')
        return value

    @field_validator('occurred_at')
    @classmethod
    def aware(cls, value):
        if value.tzinfo is None or value.utcoffset() is None:
            raise ValueError('A timezone is required')
        return value.astimezone(timezone.utc)


class CloseInput(BaseModel):
    reason: Literal['carrier_departed', 'operator_ended', 'interrupted']


class DocumentBindingInput(BaseModel):
    document_id: str = Field(min_length=1, max_length=100)
    line_id: str = Field(min_length=1, max_length=50)
    revision_sha256: str = Field(pattern=r'^[0-9a-f]{64}$')
    confirmed_material_class: str = Field(min_length=1, max_length=80)


class TrackerClassImport(BaseModel):
    """One material class per ledger session; raw predictions stay review held."""
    class_name: str = Field(min_length=1, max_length=80)
    session: SessionInput
    events: list[EventInput] = Field(max_length=100000)


class TrackerImportInput(BaseModel):
    operation_id: str = Field(min_length=1, max_length=200)
    source_sha256: str = Field(pattern=r'^[0-9a-f]{64}$')
    plan_sha256: str = Field(pattern=r'^[0-9a-f]{64}$')
    started_at: datetime
    provenance: dict
    classes: list[TrackerClassImport] = Field(min_length=1, max_length=32)

    @field_validator('started_at')
    @classmethod
    def aware(cls, value):
        if value.tzinfo is None or value.utcoffset() is None:
            raise ValueError('Source start requires a timezone')
        return value.astimezone(timezone.utc)


class ProducerStart(BaseModel):
    epoch: str = Field(min_length=1, max_length=100)
    occurred_at: datetime

    @field_validator('epoch')
    @classmethod
    def nonblank(cls, value):
        if not value.strip():raise ValueError('Epoch is required')
        return value

    @field_validator('occurred_at')
    @classmethod
    def aware(cls, value):
        if value.tzinfo is None or value.utcoffset() is None:raise ValueError('A timezone is required')
        return value.astimezone(timezone.utc)


@contextmanager
def database():
    # Reuse the configured local database, including isolated test databases.
    from app.main import conn
    c = conn()
    try:
        c.execute('PRAGMA foreign_keys=ON')
        c.execute('CREATE TABLE IF NOT EXISTS replay_sessions (id TEXT PRIMARY KEY, payload TEXT NOT NULL, closed_reason TEXT, ended_at TEXT)')
        c.execute('''CREATE TABLE IF NOT EXISTS replay_events (
            session_id TEXT NOT NULL REFERENCES replay_sessions(id),
            event_id TEXT NOT NULL, payload TEXT NOT NULL,
            PRIMARY KEY(session_id,event_id))''')
        c.execute('''CREATE TABLE IF NOT EXISTS replay_producers (
            session_id TEXT NOT NULL REFERENCES replay_sessions(id), epoch TEXT NOT NULL,
            payload TEXT NOT NULL, PRIMARY KEY(session_id,epoch))''')
        c.execute('''CREATE TABLE IF NOT EXISTS replay_tracker_imports (
            operation_id TEXT PRIMARY KEY, plan_sha256 TEXT NOT NULL,
            source_sha256 TEXT NOT NULL, payload TEXT NOT NULL)''')
        c.execute('''CREATE TABLE IF NOT EXISTS replay_tracker_bindings (
            session_id TEXT PRIMARY KEY REFERENCES replay_sessions(id),
            operation_id TEXT NOT NULL REFERENCES replay_tracker_imports(operation_id))''')
        c.execute('''CREATE TABLE IF NOT EXISTS replay_document_bindings (
            session_id TEXT PRIMARY KEY REFERENCES replay_sessions(id),
            operation_id TEXT NOT NULL REFERENCES replay_tracker_imports(operation_id),
            document_id TEXT NOT NULL, line_id TEXT NOT NULL,
            request TEXT NOT NULL, snapshot TEXT NOT NULL,
            UNIQUE(operation_id,document_id,line_id))''')
        c.commit()
        with c:
            yield c
    finally:
        c.close()


def session_row(c, sid):
    row = c.execute('SELECT * FROM replay_sessions WHERE id=?', (sid,)).fetchone()
    if row is None:
        raise HTTPException(404, 'Replay session not found')
    return row


def report(c, sid):
    row = session_row(c, sid)
    session = json.loads(row['payload'])
    events = [json.loads(r['payload']) for r in c.execute(
        'SELECT payload FROM replay_events WHERE session_id=?', (sid,))]
    incoming = sum(e['kind'] == 'crossing' and e['direction'] == 'Incoming' for e in events)
    outgoing = sum(e['kind'] == 'crossing' and e['direction'] == 'Outgoing' for e in events)
    net = incoming - outgoing if session['direction'] == 'Incoming' else outgoing - incoming
    reasons = sorted({e['kind'] for e in events if e['kind'] in ['visibility_lost', 'stream_gap', 'review_hold']})
    if net < 0:
        reasons.append('reverse_movement_exceeds_forward_count')
    if row['closed_reason'] == 'interrupted':
        reasons.append('interrupted')
    uncertain = bool(reasons)
    difference = None if uncertain else net - session['expected']
    status = 'In progress'
    if row['closed_reason']:
        status = ('Needs review' if uncertain else 'Matched' if difference == 0
                  else f'Missing {-difference}' if difference < 0 else f'Excess {difference}')
    result = {**session, 'mode': 'replay', 'camera_verified': False, 'incoming': incoming,
            'outgoing': outgoing, 'observed': net, 'difference': difference,
            'uncertain': uncertain, 'uncertainty_reasons': reasons, 'status': status,
            'phase': 'completed' if row['closed_reason'] else 'in_progress',
            'ended_at': row['ended_at'], 'completion_reason': row['closed_reason'],
            'event_count': len(events)}
    binding = c.execute('''SELECT i.operation_id,i.source_sha256,i.plan_sha256,i.payload
        FROM replay_tracker_bindings b JOIN replay_tracker_imports i ON i.operation_id=b.operation_id
        WHERE b.session_id=?''', (sid,)).fetchone()
    if binding:
        result['prediction_source'] = {'operation_id': binding['operation_id'],
                                       'source_sha256': binding['source_sha256'],
                                       'plan_sha256': binding['plan_sha256'],
                                       'review_hold_reason': 'model_unvalidated',
                                       'provenance': json.loads(binding['payload'])['provenance']}
    document_binding = c.execute('SELECT snapshot FROM replay_document_bindings WHERE session_id=?', (sid,)).fetchone()
    result['document_evidence'] = json.loads(document_binding['snapshot']) if document_binding else None
    result['expected_provenance'] = 'reviewed_document_line' if document_binding else 'caller_supplied_unverified'
    return result


@router.post('/{sid}/document-binding')
def bind_document(sid: str, body: DocumentBindingInput):
    """Explicit operator mapping of one reviewed line to one open class report.

    Does not alter the prediction plan, counts, expected quantity or review hold.
    An identical retry survives closure and later document edits.
    """
    from app.main import document_lock, find_document, document_record_sha256, document_line_snapshot
    request = body.model_dump_json()
    with database() as c:
        c.execute('BEGIN IMMEDIATE')
        row = session_row(c, sid)
        old = c.execute('SELECT request FROM replay_document_bindings WHERE session_id=?', (sid,)).fetchone()
        if old:
            if old['request'] != request:
                raise HTTPException(409, 'Reviewed document binding is immutable')
            return report(c, sid)
        if row['closed_reason']:
            raise HTTPException(409, 'Attach reviewed document evidence before closing the report')
        binding = c.execute('SELECT operation_id FROM replay_tracker_bindings WHERE session_id=?', (sid,)).fetchone()
        if not binding:
            raise HTTPException(409, 'Document binding requires a tracker prediction session')
        session = json.loads(row['payload'])
        if body.confirmed_material_class != session['material']:
            raise HTTPException(409, 'Explicit material mapping must match the tracker class')
        with document_lock:
            document = find_document(body.document_id)
            if document.get('status') != 'reviewed':
                raise HTTPException(409, 'Review the document before attaching it')
            if document_record_sha256(document) != body.revision_sha256:
                raise HTTPException(409, 'Document revision changed; inspect the current revision')
            line = next((line for line in document['lines'] if line['id'] == body.line_id), None)
            if not line or (line['quantity'],line['unit'],document['direction'],document['number']) != (
                    session['expected'],session['unit'],session['direction'],session['gatepass']):
                raise HTTPException(409, 'Reviewed line must match expected quantity, unit, direction and gate pass')
            snapshot = document_line_snapshot(document, line)
            snapshot['confirmed_material_class'] = body.confirmed_material_class
            snapshot['mapping_basis'] = 'explicit_operator_selection_not_automatic_semantic_match'
            snapshot['bound_at'] = datetime.now(timezone.utc).isoformat()
        if c.execute('SELECT 1 FROM replay_document_bindings WHERE operation_id=? AND document_id=? AND line_id=?',
                     (binding['operation_id'],body.document_id,body.line_id)).fetchone():
            raise HTTPException(409, 'This document line is already assigned within this operation')
        c.execute('INSERT INTO replay_document_bindings VALUES (?,?,?,?,?,?)',
                  (sid,binding['operation_id'],body.document_id,body.line_id,request,json.dumps(snapshot,sort_keys=True)))
        return report(c, sid)


@router.post('/tracker-imports')
def import_tracker_predictions(body: TrackerImportInput):
    """Atomically bind an immutable prediction plan, its holds and all events.

    A crash exposes either no import or all review-held sessions. This endpoint
    never asserts departure, completes an operation, or releases a review hold.
    """
    session_ids = [item.session.id for item in body.classes]
    class_names = [item.class_name for item in body.classes]
    if len(set(session_ids)) != len(session_ids) or len(set(class_names)) != len(class_names):
        raise HTTPException(422, 'Unique class names and session IDs required')
    if not body.operation_id.strip():
        raise HTTPException(422, 'Operation identity cannot be blank')
    if (body.provenance.get('kind') != 'unvalidated_tracker_predictions'
            or body.provenance.get('review_hold') is not True
            or body.provenance.get('ground_truth') is not False
            or body.provenance.get('camera_verified') is not False):
        raise HTTPException(422, 'Tracker provenance must explicitly remain unvalidated and review held')
    # Hash the complete normalized request excluding the digest itself. Nothing
    # supplied by a producer can silently replace a previously imported plan.
    normalized = body.model_dump(mode='json', exclude={'plan_sha256'})
    try:
        expected_sha = hashlib.sha256(json.dumps(normalized, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()
    except (ValueError, TypeError) as exc:
        raise HTTPException(422, 'Invalid tracker provenance values') from exc
    if expected_sha != body.plan_sha256:
        raise HTTPException(422, 'Tracker plan digest does not match contents')
    for item in body.classes:
        if item.session.material != item.class_name or not item.class_name.strip():
            raise HTTPException(422, 'Session material must preserve the exact detector class')
        if len({event.id for event in item.events}) != len(item.events):
            raise HTTPException(422, 'Duplicate event IDs in tracker plan')
        for event in item.events:
            if event.kind != 'crossing' or event.direction is None or event.track_id is None:
                raise HTTPException(422, 'Tracker imports accept explicit crossings only; holds are server controlled')
            if event.id.startswith(('_restart:', '_tracker_hold:')):
                raise HTTPException(422, 'Reserved event ID')
    payload = json.dumps(body.model_dump(mode='json'), sort_keys=True, separators=(',', ':'), allow_nan=False)
    with database() as c:
        c.execute('BEGIN IMMEDIATE')
        old = c.execute('SELECT payload FROM replay_tracker_imports WHERE operation_id=?', (body.operation_id,)).fetchone()
        if old:
            if old['payload'] != payload:
                raise HTTPException(409, 'Operation already bound to a different immutable tracker plan')
            return {'mode': 'tracker_prediction_replay', 'review_hold': True, 'idempotent_retry': True,
                    'sessions': [report(c, sid) for sid in session_ids]}
        for item in body.classes:
            if c.execute('SELECT 1 FROM replay_sessions WHERE id=?', (item.session.id,)).fetchone():
                raise HTTPException(409, 'Tracker import cannot attach to an existing unrelated session')
        for item in body.classes:
            sid = item.session.id
            c.execute('INSERT INTO replay_sessions(id,payload) VALUES (?,?)', (sid, item.session.model_dump_json()))
            hold = EventInput(id='_tracker_hold:'+hashlib.sha256((body.operation_id+'\0'+sid).encode()).hexdigest(),
                              kind='review_hold', occurred_at=body.started_at)
            c.execute('INSERT INTO replay_events(session_id,event_id,payload) VALUES (?,?,?)', (sid, hold.id, hold.model_dump_json()))
            for event in item.events:
                c.execute('INSERT INTO replay_events(session_id,event_id,payload) VALUES (?,?,?)', (sid, event.id, event.model_dump_json()))
        c.execute('INSERT INTO replay_tracker_imports(operation_id,plan_sha256,source_sha256,payload) VALUES (?,?,?,?)',
                  (body.operation_id, body.plan_sha256, body.source_sha256, payload))
        for sid in session_ids:
            c.execute('INSERT INTO replay_tracker_bindings(session_id,operation_id) VALUES (?,?)', (sid, body.operation_id))
        return {'mode': 'tracker_prediction_replay', 'review_hold': True, 'idempotent_retry': False,
                'sessions': [report(c, sid) for sid in session_ids]}


@router.get('/tracker-imports/{operation_id}/document-reconciliation')
def reconcile_documents(operation_id: str):
    """Enumerate frozen pass lines without certifying or pooling predictions.

    Never consult mutable document files to fill missing historical evidence.
    A single read transaction keeps bindings, closure and event counts consistent.
    """
    with database() as c:
        c.execute('BEGIN')
        operation = c.execute('SELECT plan_sha256 FROM replay_tracker_imports WHERE operation_id=?',
                              (operation_id,)).fetchone()
        if operation is None:
            raise HTTPException(404, 'Tracker operation not found')
        sessions = [report(c, row['session_id']) for row in c.execute(
            'SELECT session_id FROM replay_tracker_bindings WHERE operation_id=? ORDER BY session_id',
            (operation_id,))]
        groups = {}
        revisions = {}
        unbound = []
        for session in sessions:
            snapshot = session['document_evidence']
            if snapshot is None:
                unbound.append(session)
                continue
            key = (snapshot['document_id'], snapshot['document_sha256'])
            groups.setdefault(key, []).append(session)
            revisions.setdefault(key[0], set()).add(key[1])
        documents = []
        for (document_id, revision), linked in sorted(groups.items()):
            snapshots = [session['document_evidence'] for session in linked]
            rosters = [snapshot.get('document_lines') for snapshot in snapshots]
            roster_known = all(isinstance(roster, list) and roster for roster in rosters)
            roster_consistent = roster_known and all(roster == rosters[0] for roster in rosters)
            # Legacy snapshots can reveal only their bound lines. Keep the
            # scope explicitly unknown even if the current document exists.
            lines = rosters[0] if roster_consistent else [snapshot['line'] for snapshot in snapshots]
            linked_by_line = {session['document_evidence']['line']['id']: session for session in linked}
            conflict = len(revisions[document_id]) > 1
            issues = []
            if not roster_known:
                issues.append('historical_line_roster_unknown')
            elif not roster_consistent:
                issues.append('inconsistent_frozen_line_rosters')
            if conflict:
                issues.append('multiple_document_revisions_in_operation')
            result_lines = []
            for line in lines:
                session = linked_by_line.get(line['id'])
                result_lines.append({
                    'line': line, 'direction': snapshots[0]['direction'],
                    'binding_status': 'attached' if session else 'no_counting_evidence',
                    'session_id': session['id'] if session else None,
                    'material_class': session['material'] if session else None,
                    'predicted_incoming': session['incoming'] if session else None,
                    'predicted_outgoing': session['outgoing'] if session else None,
                    'predicted_net': session['observed'] if session else None,
                    'difference': None, 'verified_count': None,
                    'status': 'Needs review',
                    'uncertainty_reasons': session['uncertainty_reasons'] if session else ['no_counting_evidence'],
                })
            if any(line['binding_status'] == 'no_counting_evidence' for line in result_lines):
                issues.append('unbound_document_lines')
            documents.append({
                'document_id': document_id, 'document_sha256': revision,
                'number': snapshots[0]['number'], 'direction': snapshots[0]['direction'],
                'line_roster_known': bool(roster_consistent), 'revision_conflict': conflict,
                'all_lines_attached': all(line['binding_status'] == 'attached' for line in result_lines)
                                      if roster_consistent else None,
                'status': 'Needs review', 'issues': issues, 'lines': result_lines,
            })
        return {'operation_id': operation_id, 'plan_sha256': operation['plan_sha256'],
                'scope': 'attached_document_revisions_only', 'mode': 'tracker_prediction_replay',
                'camera_verified': False, 'review_hold': True, 'status': 'Needs review',
                'documents': documents, 'unbound_class_reports': unbound}


@router.get('')
def list_sessions(limit: int = Query(50, ge=1, le=200), offset: int = Query(0, ge=0)):
    with database() as c:
        c.execute('BEGIN')
        rows = c.execute('SELECT id FROM replay_sessions ORDER BY id LIMIT ? OFFSET ?', (limit, offset)).fetchall()
        total = c.execute('SELECT COUNT(*) FROM replay_sessions').fetchone()[0]
        return {'mode': 'replay', 'total': total, 'limit': limit, 'offset': offset,
                'sessions': [report(c, r['id']) for r in rows]}


@router.get('/reports.csv')
def export_reports():
    fields = ['id', 'gatepass', 'material', 'unit', 'direction', 'expected', 'observed',
              'incoming', 'outgoing', 'difference', 'status', 'uncertain',
              'uncertainty_reasons', 'completion_reason', 'ended_at', 'mode', 'camera_verified',
              'expected_provenance', 'document_evidence']
    stream = io.StringIO(newline='')
    writer = csv.DictWriter(stream, fieldnames=fields)
    writer.writeheader()
    with database() as c:
        c.execute('BEGIN')
        rows = c.execute('SELECT id FROM replay_sessions WHERE closed_reason IS NOT NULL ORDER BY ended_at,id').fetchall()
        for row in rows:
            result = report(c, row['id'])
            result['uncertainty_reasons'] = '; '.join(result['uncertainty_reasons'])
            result['document_evidence'] = json.dumps(result['document_evidence'],sort_keys=True) if result['document_evidence'] else ''
            values = {key: result[key] for key in fields}
            for key, value in values.items():
                if isinstance(value, str) and value.lstrip().startswith(('=', '+', '-', '@')):
                    values[key] = "'" + value
            writer.writerow(values)
    return Response('\ufeff' + stream.getvalue(), media_type='text/csv',
                    headers={'Content-Disposition': 'attachment; filename="gate-desk-replay-reports.csv"'})


@router.post('')
def create_session(body: SessionInput):
    payload = body.model_dump_json()
    with database() as c:
        c.execute('BEGIN IMMEDIATE')
        existing = c.execute('SELECT payload FROM replay_sessions WHERE id=?', (body.id,)).fetchone()
        if existing and existing['payload'] != payload:
            raise HTTPException(409, 'Session ID already has different contents')
        if not existing:
            c.execute('INSERT INTO replay_sessions(id,payload) VALUES (?,?)', (body.id, payload))
        return report(c, body.id)


@router.post('/{sid}/events')
def append_event(sid: str, body: EventInput):
    if body.id.startswith('_restart:'):
        raise HTTPException(422, 'Event ID prefix reserved for producer recovery')
    if body.kind == 'crossing' and (body.direction is None or body.track_id is None):
        raise HTTPException(422, 'Crossing needs direction and track identity')
    if body.kind != 'crossing' and (body.direction is not None or body.track_id is not None):
        raise HTTPException(422, 'Health events cannot specify a crossing')
    payload = body.model_dump_json()
    with database() as c:
        c.execute('BEGIN IMMEDIATE')
        row = session_row(c, sid)
        old = c.execute('SELECT payload FROM replay_events WHERE session_id=? AND event_id=?', (sid, body.id)).fetchone()
        if old:
            if old['payload'] != payload:
                raise HTTPException(409, 'Event ID already has different contents')
            return report(c, sid)  # Retry after close/restart must not count twice.
        if c.execute('SELECT 1 FROM replay_tracker_bindings WHERE session_id=?', (sid,)).fetchone():
            raise HTTPException(409, 'Immutable tracker prediction session cannot accept new events')
        if row['closed_reason']:
            raise HTTPException(409, 'Closed replay session cannot accept new events')
        c.execute('INSERT INTO replay_events(session_id,event_id,payload) VALUES (?,?,?)', (sid, body.id, payload))
        return report(c, sid)


@router.post('/{sid}/producer-start')
def start_producer(sid: str, body: ProducerStart):
    """Register a new process epoch before observations; repeat identical retries.

    A new epoch conservatively records a possible gap. This is caller-triggered
    recovery, not process monitoring or proof of continuous camera coverage.
    """
    payload=body.model_dump_json()
    with database() as c:
        c.execute('BEGIN IMMEDIATE')
        row=session_row(c,sid)
        old=c.execute('SELECT payload FROM replay_producers WHERE session_id=? AND epoch=?',(sid,body.epoch)).fetchone()
        if old:
            if old['payload']!=payload:raise HTTPException(409,'Producer epoch already has different contents')
            return report(c,sid)
        if c.execute('SELECT 1 FROM replay_tracker_bindings WHERE session_id=?', (sid,)).fetchone():
            raise HTTPException(409, 'Immutable tracker prediction session cannot start a live producer')
        if row['closed_reason']:raise HTTPException(409,'Closed replay session cannot start a producer')
        prior=c.execute('SELECT 1 FROM replay_producers WHERE session_id=? LIMIT 1',(sid,)).fetchone()
        prior_events=c.execute('SELECT 1 FROM replay_events WHERE session_id=? LIMIT 1',(sid,)).fetchone()
        c.execute('INSERT INTO replay_producers(session_id,epoch,payload) VALUES (?,?,?)',(sid,body.epoch,payload))
        if prior or prior_events:
            event_id='_restart:'+hashlib.sha256(body.epoch.encode()).hexdigest()
            event=EventInput(id=event_id,kind='stream_gap',occurred_at=body.occurred_at)
            c.execute('INSERT INTO replay_events(session_id,event_id,payload) VALUES (?,?,?)',(sid,event_id,event.model_dump_json()))
        return report(c,sid)


@router.get('/{sid}')
def read_session(sid: str):
    with database() as c:
        return report(c, sid)


@router.post('/{sid}/close')
def close_session(sid: str, body: CloseInput):
    with database() as c:
        c.execute('BEGIN IMMEDIATE')
        row = session_row(c, sid)
        if row['closed_reason'] and row['closed_reason'] != body.reason:
            raise HTTPException(409, 'Completion reason cannot be replaced')
        if not row['closed_reason']:
            c.execute('UPDATE replay_sessions SET closed_reason=?,ended_at=? WHERE id=?',
                      (body.reason, datetime.now(timezone.utc).isoformat(), sid))
        return report(c, sid)
