"""Owner-reviewed receipt associations; local planning only, never NVR access.

The host authorizes an owner before creating this service. Receipt identities
come from the factory's committed receipt store, never the review request.
Revisions are append-only; a camera label is not camera enrollment or clock proof.
"""
from contextlib import closing
from datetime import datetime, timezone
import json
from pathlib import Path
import sqlite3

from app.phone_loading_candidate import HostPhoneLoadingCapability, plan_phone_loading_candidate
from app.phone_submissions import PhoneSubmissions, submission_metadata


class LoadingReviewError(ValueError):
    pass


def safe_path(path):
    raw = Path(path).absolute()
    if any(p.is_symlink() or p.is_junction() for p in (raw, *raw.parents)):
        raise LoadingReviewError('phone_loading_unavailable')
    return raw


class PhoneLoadingReview:
    def __init__(self, runtime, submissions):
        if type(submissions) is not PhoneSubmissions:
            raise LoadingReviewError('phone_loading_unavailable')
        self.runtime = safe_path(runtime)
        if not self.runtime.is_dir():
            raise LoadingReviewError('phone_loading_unavailable')
        self.path = self.runtime / 'phone-loading.sqlite3'
        self.submissions = submissions

    def check(self):
        for path in (self.path, self.submissions.path, self.submissions.store.index):
            safe_path(path)
        if not self.submissions.store.index.is_file():
            raise LoadingReviewError('phone_loading_unavailable')

    def receipts(self, offset=0, submission_id=None):
        self.check()
        if type(offset) is not int or not 0 <= offset <= 10000:
            raise LoadingReviewError('invalid_loading_review')
        if submission_id is not None:
            submission_metadata(submission_id, '0'*64, '2000-01-01T00:00:00Z')
        if not self.submissions.path.exists():
            return []
        with closing(sqlite3.connect(self.submissions.path.as_uri()+'?mode=ro', uri=True, timeout=.2)) as db:
            query = 'SELECT factory,submission,uid,digest,saved_at,document,received_at FROM phone_submissions_v1 WHERE factory=?'
            args = [self.submissions.factory_id]
            if submission_id is not None:
                query += ' AND submission=?'; args.append(submission_id)
            query += ' ORDER BY received_at DESC,submission LIMIT 26 OFFSET ?'; args.append(offset)
            rows = db.execute(query, args).fetchall()
        values = []
        for row in rows:
            receipt = dict(zip(('factoryId','id','userId','digest','savedAt','documentId','receivedAt'), row))
            submission_metadata(receipt['id'], receipt['digest'], receipt['savedAt'])
            if receipt['documentId'] != 'scan-'+receipt['digest']:
                raise LoadingReviewError('phone_loading_unavailable')
            values.append(receipt)
        return values

    def latest(self, submission_id):
        self.check()
        if not self.path.exists():
            return None
        with closing(sqlite3.connect(self.path.as_uri()+'?mode=ro', uri=True, timeout=.2)) as db:
            row = db.execute('SELECT payload FROM phone_loading_reviews_v1 WHERE factory=? AND submission=? ORDER BY revision DESC LIMIT 1',
                             (self.submissions.factory_id, submission_id)).fetchone()
        return json.loads(row[0]) if row else None

    def page(self, offset):
        receipts = self.receipts(offset)
        result = []
        for receipt in receipts[:25]:
            review = self.latest(receipt['id'])
            if review:
                bound = review['candidate']['phone_receipt']
                if any(bound.get(k) != v for k,v in receipt.items()):
                    raise LoadingReviewError('phone_loading_unavailable')
            result.append({**receipt, 'review':review})
        return {'factory_id':self.submissions.factory_id, 'receipts':result,
                'next_offset':offset+25 if len(receipts)>25 and offset+25<=10000 else None}

    def save(self, submission_id, body, owner_id, authorize):
        if (type(body) is not dict or set(body) != {'expected_revision','camera_id','direction','confirmed'}
                or type(body['expected_revision']) is not int or not 0<=body['expected_revision']<1000000
                or body['confirmed'] is not True):
            raise LoadingReviewError('invalid_loading_review')
        authorize()
        rows = self.receipts(submission_id=submission_id)
        if not rows:
            raise LoadingReviewError('phone_receipt_not_found')
        receipt = rows[0]
        reviewed = datetime.now(timezone.utc).isoformat()
        association = {'factoryId':receipt['factoryId'], 'userId':receipt['userId'],
            'submissionId':receipt['id'], 'documentId':receipt['documentId'], 'originalDigest':receipt['digest'],
            'cameraId':body['camera_id'], 'direction':body['direction'], 'reviewedBy':owner_id,
            'reviewedAt':reviewed, 'reviewBasis':'explicit_operator_camera_direction_review'}
        # The separately authenticated owner grants review of this exact factory
        # receipt. Scope the existing adapter to its server-loaded submitter;
        # the browser cannot select a user, factory, digest or timestamp.
        capability = HostPhoneLoadingCapability(self.submissions, self.submissions.factory_id,
                                                receipt['userId'], lambda _: association)
        candidate = plan_phone_loading_candidate(capability, submission_id)
        saved = {'revision':body['expected_revision']+1, 'camera_id':body['camera_id'],
                 'direction':body['direction'], 'reviewed_by':owner_id, 'reviewed_at':reviewed,
                 'candidate':candidate}
        self.check()
        existed = self.path.exists()
        with closing(sqlite3.connect(self.path, timeout=.2)) as db:
            db.execute('PRAGMA synchronous=FULL')
            if not existed:
                # Initial owner authorization already succeeded. Retain an empty
                # valid schema even if the later authorization is revoked: a
                # rejected review must not strand this new database. IF NOT
                # EXISTS handles two first-save callers observing absence;
                # existing databases are never initialized or repaired here.
                db.execute('CREATE TABLE IF NOT EXISTS phone_loading_reviews_v1 (factory TEXT NOT NULL,submission TEXT NOT NULL,revision INTEGER NOT NULL,payload TEXT NOT NULL,PRIMARY KEY(factory,submission,revision))')
                db.commit()
            db.execute('BEGIN IMMEDIATE')
            old = db.execute('SELECT MAX(revision) FROM phone_loading_reviews_v1 WHERE factory=? AND submission=?',
                             (self.submissions.factory_id, submission_id)).fetchone()[0] or 0
            if old != body['expected_revision']:
                raise LoadingReviewError('revision_conflict')
            # Recheck receipt/authority immediately before append. No source
            # data is updated; a failed transaction retains all prior reviews.
            if self.receipts(submission_id=submission_id) != rows:
                raise LoadingReviewError('phone_loading_unavailable')
            authorize()
            db.execute('INSERT INTO phone_loading_reviews_v1 VALUES (?,?,?,?)',
                (self.submissions.factory_id, submission_id, saved['revision'],
                 json.dumps(saved, sort_keys=True, separators=(',',':'), ensure_ascii=False)))
            db.commit()
        return {'factory_id':self.submissions.factory_id, 'id':submission_id, 'review':saved}
