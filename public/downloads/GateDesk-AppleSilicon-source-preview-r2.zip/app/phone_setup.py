"""Local owner settings persistence; saving never reads keys or starts transport."""
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import threading
import uuid
from urllib.parse import urlsplit

from app.mobile_config import parse_mobile_config
from app.mobile_startup import existing_local_path

_LOCK = threading.Lock()
FIELDS = {'bind_address', 'port', 'canonical_origin', 'certificate_path', 'private_key_path'}


class SetupError(ValueError):
    pass


def strict_object(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            raise ValueError('duplicate_field')
        value[key] = item
    return value


def validated(settings, factory_id):
    try:
        if type(settings) is not dict or set(settings) != FIELDS:
            raise ValueError()
        value = dict(settings, enabled=True, factory_id=factory_id)
        config = parse_mobile_config(value)
        if urlsplit(config.canonical_origin).hostname.replace('.', '').isdigit():
            raise ValueError()
        return value
    except (ValueError, TypeError, AttributeError):
        raise SetupError('invalid_phone_settings') from None


def safe(path, *, missing=False):
    path = Path(path)
    if not path.is_absolute():
        raise SetupError('phone_setup_path_invalid')
    for part in (path, *path.parents):
        try:
            info = part.lstat()
        except FileNotFoundError:
            if missing and part == path:
                continue
            raise SetupError('phone_setup_path_invalid') from None
        if (getattr(info, 'st_file_attributes', 0) & 0x400 or part.is_symlink()
                or (part.is_file() and info.st_nlink != 1)):
            raise SetupError('phone_setup_path_invalid')
    return path


class PhoneSetupStore:
    def __init__(self, runtime):
        self.runtime = safe(existing_local_path(runtime, directory=True))
        self.root = self.runtime/'phone-setup'

    @contextmanager
    def locked(self, *, create=False):
        with _LOCK:
            safe(self.root, missing=True)
            if not self.root.exists():
                if not create:
                    yield False
                    return
                self.root.mkdir()
            safe(self.root)
            if sum(1 for _ in self.root.iterdir()) > 2048:
                raise SetupError('phone_setup_capacity_exceeded')
            lock = safe(self.root/'store.lock', missing=True)
            with lock.open('a+b') as stream:
                safe(lock)
                stream.seek(0, 2)
                if stream.tell() == 0:
                    stream.write(b'0'); stream.flush()
                stream.seek(0)
                import msvcrt
                msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
                try:
                    yield True
                finally:
                    stream.seek(0); msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)

    def _read(self, factory_id):
        pointer = safe(self.root/'state.json', missing=True)
        if not pointer.exists():
            return None
        if pointer.stat().st_size > 4096:
            raise SetupError('phone_setup_unavailable')
        state = json.loads(pointer.read_text(encoding='utf-8'), object_pairs_hook=strict_object)
        if (type(state) is not dict or set(state) != {'schema_version', 'revision', 'factory_id', 'updated_at', 'config_file', 'config_sha256'}
                or type(state['schema_version']) is not int or state['schema_version'] != 1
                or type(state['revision']) is not int or not 1 <= state['revision'] <= 10000
                or state['factory_id'] != factory_id or type(state['updated_at']) is not str
                or not isinstance(state['config_file'], str)
                or not re.fullmatch(r'configuration-'+str(state['revision'])+r'-[0-9a-f]{32}\.json', state['config_file'])):
            raise SetupError('phone_setup_unavailable')
        config_path = safe(self.root/state['config_file'])
        if config_path.stat().st_size > 16384:
            raise SetupError('phone_setup_unavailable')
        raw = config_path.read_bytes()
        if hashlib.sha256(raw).hexdigest() != state['config_sha256']:
            raise SetupError('phone_setup_unavailable')
        config = json.loads(raw, object_pairs_hook=strict_object)
        if (type(config) is not dict or set(config) != FIELDS | {'enabled', 'factory_id'}
                or config.get('enabled') is not True or config.get('factory_id') != factory_id
                or validated({key: config[key] for key in FIELDS}, factory_id) != config):
            raise SetupError('phone_setup_unavailable')
        return dict(state, config_path=str(config_path), settings={key: config[key] for key in FIELDS})

    def read(self, factory_id):
        with self.locked() as exists:
            return self._read(factory_id) if exists else None

    def save(self, settings, expected_revision, factory_id, authorize):
        if type(expected_revision) is not int or not 0 <= expected_revision < 10000:
            raise SetupError('invalid_phone_settings')
        config = validated(settings, factory_id)
        raw = (json.dumps(config, sort_keys=True, indent=2)+'\n').encode()
        with self.locked(create=True):
            authorize()
            previous = self._read(factory_id)
            if expected_revision != (previous['revision'] if previous else 0):
                raise SetupError('revision_conflict')
            revision = expected_revision + 1
            path = safe(self.root/f'configuration-{revision}-{uuid.uuid4().hex}.json', missing=True)
            # A failed previous write is retained, never silently overwritten.
            with path.open('xb') as stream:
                stream.write(raw); stream.flush(); os.fsync(stream.fileno())
            state = dict(schema_version=1, revision=revision, factory_id=factory_id,
                         updated_at=datetime.now(timezone.utc).isoformat(), config_file=path.name,
                         config_sha256=hashlib.sha256(raw).hexdigest())
            temp = self.root/('.state-'+uuid.uuid4().hex+'.tmp')
            try:
                with temp.open('xb') as stream:
                    stream.write((json.dumps(state, sort_keys=True)+'\n').encode())
                    stream.flush(); os.fsync(stream.fileno())
                authorize()
                safe(self.root/'state.json', missing=True)
                os.replace(temp, self.root/'state.json')
            finally:
                if temp.exists():
                    safe(temp); temp.unlink()
            return self._read(factory_id)


def live_generation(runtime, supplied):
    """Verify host-supplied current generation; never request stop or launch."""
    from scripts.runtime_control import ControlTree, ProcessWitness, _identity
    if type(supplied) is not dict:
        raise SetupError('restart_generation_unavailable')
    tree = ControlTree(runtime)
    record = tree.read('owner.json')
    identity = _identity(tree, record, owner=True)
    if (identity != supplied or record['state'] != 'running' or identity['pid'] != os.getpid()
            or tree.read('identity.json', generation=identity['generation']) != identity
            or tree.read('terminal.json', generation=identity['generation']) is not None
            or tree.read('stop.json', generation=identity['generation']) is not None):
        raise SetupError('restart_generation_unavailable')
    with ProcessWitness(identity['pid'], identity['created']) as process:
        if process.exited():
            raise SetupError('restart_generation_unavailable')
    return identity
