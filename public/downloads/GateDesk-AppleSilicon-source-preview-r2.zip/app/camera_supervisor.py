"""Disabled-by-default, local recorder process lifecycle; no implicit retries.

Each bounded connection requires its own reviewed clock evidence. Optional
continuous segmentation keeps one connection for a finite session. Process
liveness is never camera acceptance.
"""
from __future__ import annotations
from app.runtime_owner import start_thread, start_process, process_finished, forced_process_stop, register_queue

from dataclasses import asdict, dataclass, fields
from datetime import datetime, timedelta, timezone
import hashlib
import json
import multiprocessing
import os
from pathlib import Path
import re
import shutil
import threading
import time
import uuid

from app.camera_ingest import IngestError, IngestStore, RTSPConfig, _atomic_json, _identifier
from ml.video_triage import sha256
from scripts.runtime_lock import runtime_lock


def _utc():
    return datetime.now(timezone.utc)


def _date(value):
    result = datetime.fromisoformat(value)
    if result.tzinfo is None:
        raise ValueError("Timezone required")
    return result.astimezone(timezone.utc)


@dataclass(frozen=True)
class RecorderConfig:
    enabled: bool = False
    camera_id: str = "Camera2"
    endpoint_env: str = "GATE_CAMERA_RTSP_URL"
    segment_seconds: int = 180
    connection_id: str = ""
    authorization_id: str = ""
    clock_evidence_file: str = ""
    clock_evidence_sha256: str = ""
    max_clock_age_seconds: int = 300
    max_clock_offset_seconds: int = 5
    source_utc_offset_minutes: int = 330
    source_start_hour: int = 9
    source_end_hour: int = 21
    connect_timeout_seconds: int = 10
    read_timeout_seconds: int = 10
    max_bytes: int = 512 * 1024**2
    min_free_bytes: int = 512 * 1024**2
    protected_hashes: tuple = ()
    continuous_session: bool = False
    max_segments: int = 10
    max_session_seconds: int = 1800
    keyframe_overrun_seconds: int = 10
    native_stop_evidence_file: str = ""
    native_stop_evidence_sha256: str = ""

    def validate(self):
        if type(self.enabled) is not bool:
            raise ValueError("Invalid enable flag")
        if type(self.continuous_session) is not bool:
            raise ValueError("Invalid continuous session flag")
        RTSPConfig(self.camera_id, self.endpoint_env, self.segment_seconds,
                   self.connect_timeout_seconds, self.read_timeout_seconds).validate()
        for name, minimum, maximum in (
            ("max_clock_age_seconds", 1, 900), ("max_clock_offset_seconds", 0, 30),
            ("source_utc_offset_minutes", -720, 840),
            ("source_start_hour", 9, 20), ("source_end_hour", 10, 21),
            ("max_bytes", 1, 4 * 1024**3), ("min_free_bytes", 256 * 1024**2, 1024**4),
            ("max_segments", 1, 10), ("max_session_seconds", 1, 1800),
            ("keyframe_overrun_seconds", 0, 10),
        ):
            value = getattr(self, name)
            if type(value) is not int or not minimum <= value <= maximum:
                raise ValueError("Invalid recorder bound")
        if self.source_start_hour >= self.source_end_hour:
            raise ValueError("Invalid source hours")
        if self.continuous_session and self.max_session_seconds < self.segment_seconds:
            raise ValueError("Session bound cannot be shorter than a segment")


def _capture_worker(runtime, config, attempt_id, stop_event, progress_channels=None):
    """Top-level spawn target; no provider errors or secrets leave the process."""
    finished = threading.Event()
    parent = multiprocessing.parent_process()
    def parent_guard():
        while not finished.wait(.5):
            if parent is not None and not parent.is_alive():
                stop_event.set()
                if not finished.wait(config["read_timeout_seconds"] + 3):
                    os._exit(70)  # This recorder process only; retain partial bytes.
                return
    guardian = threading.Thread(target=parent_guard, name="recorder-parent-guard", daemon=True)
    start_thread(guardian, finished.set)
    observer = None
    try:
        cfg = RecorderConfig(**config)
        store = IngestStore(Path(runtime) / "camera-ingest", protected_hashes=cfg.protected_hashes,
                            max_bytes=cfg.max_bytes, min_free_bytes=cfg.min_free_bytes)
        rtsp = RTSPConfig(cfg.camera_id, cfg.endpoint_env, cfg.segment_seconds,
                          cfg.connect_timeout_seconds, cfg.read_timeout_seconds)
        if cfg.continuous_session:
            from app.camera_stream import StreamLimits, capture_stream
            from app.recorder_progress import Publication, Observer
            publication = None
            if progress_channels is not None:
                requests, responses, identity = progress_channels
                register_queue(requests)
                register_queue(responses)
                publication = Publication(attempt_id, identity['epoch'])
                def demand():
                    local = _utc() + timedelta(minutes=cfg.source_utc_offset_minutes)
                    return (not stop_event.is_set() and not store.is_paused() and
                            cfg.source_start_hour <= local.hour < cfg.source_end_hour)
                observer = Observer(store.root/'sessions'/attempt_id/'progress-health',
                                    publication, identity, demand=demand,
                                    requests=requests, responses=responses,
                                    max_session_seconds=cfg.max_session_seconds)
                publication._observer = observer  # Lifecycle inside ingest lock.
            capture_stream(store, rtsp, session_id=attempt_id,
                           authorization_id=cfg.authorization_id,
                           clock_evidence_sha256=cfg.clock_evidence_sha256,
                           limits=StreamLimits(target_seconds=cfg.segment_seconds,
                               max_segments=cfg.max_segments,
                               max_session_seconds=cfg.max_session_seconds,
                               keyframe_overrun_seconds=cfg.keyframe_overrun_seconds),
                           stop=stop_event.is_set, progress=publication)
        else:
            store.capture_once(rtsp, attempt_id=attempt_id, stop=stop_event.is_set)
    except BaseException:
        # Ingest persists sanitized terminal errors. Supervisor detects missing
        # or incomplete records if the worker failed before that transaction.
        return
    finally:
        finished.set()
        guardian.join()


class CameraSupervisor:
    """Private runtime child ownership, explicit starts and durable pause/holds.

    `start` is nonblocking. `pause`/`stop` wait for bounded child termination.
    Root must invoke `resume` only for a direct user resume. No network is opened
    without explicit config + environment opt-in + fresh reviewed clock evidence.
    """
    def __init__(self, runtime, config=None, *, _worker_target=None):
        self.runtime = Path(runtime).resolve()
        self.home = self.runtime / "camera-supervisor"
        self.home.mkdir(parents=True, exist_ok=True)
        self.config_path = self.home / "config.json"
        self.state_path = self.home / "state.json"
        self._provided_config = config
        self._worker_target = _worker_target or _capture_worker
        self._context = multiprocessing.get_context("spawn")
        self._guard = threading.RLock()
        self._stop_requested = threading.Event()
        self._owner = None
        self._thread = None
        self._worker = None
        self._child_stop = None
        self._record = None
        self._transient = None
        self._progress_channels = None
        self._progress_identity = None
        self._progress_error = None
        self._progress_session_deadline = None

    def _config(self):
        if self._provided_config is not None:
            cfg = self._provided_config
        elif not self.config_path.exists():
            cfg = RecorderConfig()
        else:
            values = json.loads(self.config_path.read_text(encoding="utf-8"))
            if not isinstance(values, dict) or set(values) - {f.name for f in fields(RecorderConfig)}:
                raise ValueError("Unexpected recorder configuration")
            cfg = RecorderConfig(**values)
        cfg.validate()
        return cfg

    def _load(self):
        if self.state_path.exists():
            state = json.loads(self.state_path.read_text(encoding="utf-8"))
            if not isinstance(state, dict) or state.get("version") != 1:
                raise ValueError("Unknown recorder state")
            if not all(isinstance(state.get(key), list) for key in ("attempts", "gaps", "consumed_clock_evidence")):
                raise ValueError("Invalid recorder state")
            if type(state.get("failure_count")) is not int or state["failure_count"] < 0:
                raise ValueError("Invalid failure budget")
            return state
        return dict(version=1, state="disabled", attempts=[], gaps=[], failure_count=0,
                    next_start_not_before=None, consumed_clock_evidence=[],
                    active_attempt_id=None, last_accepted_at=None,
                    health_observation=None, error_code=None)

    def _save(self, **changes):
        self._record.update(changes, updated_at=_utc().isoformat())
        _atomic_json(self.state_path, self._record)

    def _store(self, cfg):
        return IngestStore(self.runtime / "camera-ingest", protected_hashes=cfg.protected_hashes,
                           max_bytes=cfg.max_bytes, min_free_bytes=cfg.min_free_bytes)

    def _release_owner(self):
        if self._progress_channels is not None and (self._worker is None or not self._worker.is_alive()):
            for channel in self._progress_channels:
                channel.close()
                channel.cancel_join_thread()
            self._progress_channels = None
        if self._owner is not None:
            owner, self._owner = self._owner, None
            owner.__exit__(None, None, None)

    def _clock_gate(self, cfg, now, *, active_session=False):
        """Clock review is a hash-bound local artifact, never a boolean setting."""
        try:
            _identifier(cfg.connection_id)
            _identifier(cfg.authorization_id)
            evidence_path = (self.runtime / cfg.clock_evidence_file).resolve(strict=True)
            if not evidence_path.is_relative_to(self.runtime) or not evidence_path.is_file():
                return "clock_evidence_invalid"
            if sha256(evidence_path) != cfg.clock_evidence_sha256:
                return "clock_evidence_invalid"
            evidence = json.loads(evidence_path.read_text(encoding="utf-8"))
            if (not isinstance(evidence, dict) or evidence.get("camera_id") != cfg.camera_id or
                    evidence.get("connection_id") != cfg.connection_id or
                    evidence.get("authorization_id") != cfg.authorization_id or
                    evidence.get("method") != "actual_source_clock_visual_review" or
                    not evidence.get("reviewer")):
                return "clock_evidence_invalid"
            observed = _date(evidence["observed_at"])
            source = _date(evidence["source_time"])
            if not 0 <= (now - observed).total_seconds() <= cfg.max_clock_age_seconds:
                return "clock_evidence_stale"
            if abs((source - observed).total_seconds()) > cfg.max_clock_offset_seconds:
                return "clock_offset_out_of_bounds"
            original_source_time = datetime.fromisoformat(evidence["source_time"])
            if original_source_time.utcoffset() != timedelta(minutes=cfg.source_utc_offset_minutes):
                return "clock_timezone_mismatch"
            frame = (self.runtime / evidence["frame_file"]).resolve(strict=True)
            if not frame.is_relative_to(self.runtime) or not frame.is_file():
                return "clock_evidence_invalid"
            if sha256(frame) != evidence["frame_sha256"]:
                return "clock_evidence_invalid"
            if not active_session and cfg.clock_evidence_sha256 in self._record["consumed_clock_evidence"]:
                return "connection_clock_review_required"
            # Account for a segment plus connect/read overhead; do not start near
            # the end of the allowed source-time interval.
            offset = timedelta(minutes=cfg.source_utc_offset_minutes)
            local_now = (now + (source - observed) + offset).replace(tzinfo=None)
            capture_seconds = cfg.max_session_seconds if cfg.continuous_session else cfg.segment_seconds
            end = local_now if active_session else local_now + timedelta(seconds=capture_seconds + cfg.connect_timeout_seconds
                                        + cfg.read_timeout_seconds + (cfg.keyframe_overrun_seconds if cfg.continuous_session else 0))
            if (local_now.hour < cfg.source_start_hour or end.date() != local_now.date()
                    or end.hour >= cfg.source_end_hour):
                return "outside_source_hours"
        except (ValueError, KeyError, TypeError, OSError, IngestError):
            return "clock_evidence_invalid"
        return None

    def _native_stop_gate(self, cfg):
        """Require a reviewed local proof for this config; never probe native UI.

        A browser key handler is not a systemwide stop bridge. This review is a
        trust assertion by the local operator, not automatic capability discovery.
        """
        try:
            path = (self.runtime / cfg.native_stop_evidence_file).resolve(strict=True)
            if not path.is_relative_to(self.runtime) or not path.is_file():
                return "native_stop_unverified"
            if sha256(path) != cfg.native_stop_evidence_sha256:
                return "native_stop_unverified"
            review = json.loads(path.read_text(encoding="utf-8"))
            if (not isinstance(review, dict) or review.get("camera_id") != cfg.camera_id or
                    review.get("authorization_id") != cfg.authorization_id or
                    review.get("connection_id") != cfg.connection_id or
                    review.get("method") != "systemwide_escape_stop_review" or
                    review.get("stop_acknowledged") is not True or not review.get("reviewer")):
                return "native_stop_unverified"
            proof = (self.runtime / review["proof_file"]).resolve(strict=True)
            if not proof.is_relative_to(self.runtime) or not proof.is_file() or sha256(proof) != review["proof_sha256"]:
                return "native_stop_unverified"
        except (ValueError, KeyError, TypeError, OSError):
            return "native_stop_unverified"
        return None

    def _reconcile(self, cfg):
        self._store(cfg).reconcile()
        active = self._record.get("active_attempt_id")
        if active:
            for attempt in self._record["attempts"]:
                if attempt["attempt_id"] == active and attempt["state"] == "running":
                    attempt.update(state="interrupted", ended_at=_utc().isoformat(),
                                   error_code="supervisor_restarted")
                    self._record["gaps"].append(dict(kind="restart_boundary", attempt_id=active,
                                                    source_gap_seconds=None, continuity_verified=False))
            self._save(active_attempt_id=None, state="held", error_code="restart_reconciliation_required")

    def start(self):
        with self._guard:
            if self._thread and self._thread.is_alive():
                return self.status()
            self._transient = None
            try:
                cfg = self._config()
            except (ValueError, TypeError, OSError, IngestError):
                self._transient = "config_invalid"
                return self.status()
            owner = runtime_lock(self.home)
            try:
                owner.__enter__()
            except RuntimeError:
                self._transient = "owned_by_other_supervisor"
                return self.status()
            self._owner = owner
            try:
                self._record = self._load()
                self._reconcile(cfg)
                self._save(camera_id=cfg.camera_id, enabled=cfg.enabled,
                           capture_method="bounded_continuous_rtsp" if cfg.continuous_session else "bounded_rtsp_remux", boundary_gap_unknown=True,
                           continuity_verified=False, camera_connected=False, configured=False)
                if self._store(cfg).is_paused():
                    self._save(state="paused")
                elif not cfg.enabled or os.environ.get("GATE_CAMERA_CAPTURE_ENABLED") != "1":
                    self._save(state="disabled")
                elif self._native_stop_gate(cfg):
                    self._save(state="held", error_code="native_stop_unverified")
                elif self._record["failure_count"] >= 3:
                    self._save(state="held", error_code="failure_budget_exhausted")
                elif self._record.get("next_start_not_before") and _utc() < _date(self._record["next_start_not_before"]):
                    self._save(state="backoff", error_code="scheduled_start_not_due")
                else:
                    try:
                        RTSPConfig(cfg.camera_id, cfg.endpoint_env, cfg.segment_seconds,
                                   cfg.connect_timeout_seconds, cfg.read_timeout_seconds).resolve_endpoint()
                    except IngestError:
                        self._save(state="needs_setup", error_code="endpoint_not_configured")
                    else:
                        reason = self._clock_gate(cfg, _utc())
                        if reason:
                            self._save(state="outside_source_hours" if reason == "outside_source_hours" else "held",
                                       error_code=reason)
                        elif shutil.disk_usage(self.runtime).free < cfg.min_free_bytes:
                            self._save(state="held", error_code="disk_reserve_reached", health_observation={
                                "kind": "storage_reserve", "verified": True,
                                "incident_key": f"camera-ingest:{cfg.camera_id}:disk-reserve",
                                "evidence_attempt_id": None})
                        else:
                            self._launch(cfg)
                            return self.status()
            except Exception:
                self._transient = "supervisor_state_needs_attention"
                if self._worker is not None and self._worker.is_alive():
                    forced_process_stop()
                    self._worker.terminate()
                    self._worker.join(timeout=3)
                    if self._worker.is_alive():
                        return self.status()  # Keep ownership until child stops.
            self._release_owner()
            return self.status()

    def _launch(self, cfg):
        self._progress_error = None
        self._progress_session_deadline = time.monotonic()+cfg.max_session_seconds
        attempt_id = str(uuid.uuid4())
        attempt = dict(attempt_id=attempt_id, camera_id=cfg.camera_id, state="running", registered_at=_utc().isoformat(),
                       connection_id=cfg.connection_id, authorization_id=cfg.authorization_id,
                       clock_evidence_sha256=cfg.clock_evidence_sha256,
                       segment_seconds=cfg.segment_seconds, split="quarantine_unassigned")
        attempt.update(continuous_session=cfg.continuous_session,
                       max_segments=cfg.max_segments if cfg.continuous_session else 1,
                       max_session_seconds=cfg.max_session_seconds if cfg.continuous_session else cfg.segment_seconds,
                       stream_event_sequence=0, accepted_segment_count=0, accepted_segment_ids=[])
        prior = self._record["attempts"][-1] if self._record["attempts"] else None
        if prior:
            self._record["gaps"].append(dict(kind="reconnect_boundary", previous_attempt_id=prior["attempt_id"],
                                            next_attempt_id=attempt_id, source_gap_seconds=None,
                                            continuity_verified=False))
        self._record["attempts"].append(attempt)
        self._record["consumed_clock_evidence"].append(cfg.clock_evidence_sha256)
        self._save(state="starting", active_attempt_id=attempt_id, error_code=None,
                   configured=True, health_observation=None, stream_validation_error=None,
                   last_packet_received_at=None)
        self._stop_requested.clear()
        self._child_stop = self._context.Event()
        worker_args = (str(self.runtime), asdict(cfg), attempt_id, self._child_stop)
        if cfg.continuous_session and self._worker_target is _capture_worker:
            self._progress_identity = dict(session_id=attempt_id,camera_id=cfg.camera_id,
                authorization_id=cfg.authorization_id,clock_evidence_sha256=cfg.clock_evidence_sha256,
                connection_id=cfg.connection_id,
                config_sha256=hashlib.sha256(json.dumps(asdict(cfg),sort_keys=True).encode()).hexdigest(),
                epoch=str(uuid.uuid4()))
            self._progress_channels = (register_queue(self._context.Queue(maxsize=1)), register_queue(self._context.Queue(maxsize=1)))
            worker_args += ((*self._progress_channels,self._progress_identity),)
        self._worker = self._context.Process(target=self._worker_target,
            args=worker_args,
            name="gate-desk-camera-recorder", daemon=False)
        try:
            start_process(self._worker, self._child_stop.set)
        except Exception:
            attempt.update(state="failed", ended_at=_utc().isoformat(), error_code="worker_start_failed")
            self._save(state="held", active_attempt_id=None, error_code="worker_start_failed")
            raise RuntimeError("worker_start_failed") from None
        self._save(state="acquiring_unverified", worker_pid=self._worker.pid)
        self._thread = threading.Thread(target=self._monitor, args=(cfg, attempt_id),
                                        name="gate-desk-camera-supervisor", daemon=True)
        start_thread(self._thread, self._stop_requested.set)

    def _monitor(self, cfg, attempt_id):
        try:
            maximum = (cfg.max_session_seconds + cfg.keyframe_overrun_seconds if cfg.continuous_session else cfg.segment_seconds) + cfg.connect_timeout_seconds + cfg.read_timeout_seconds + 15
            deadline = time.monotonic() + maximum
            while self._worker.is_alive() and not self._stop_requested.wait(.1):
                if cfg.continuous_session:
                    with self._guard:
                        try:
                            self._consume_stream_events(cfg, attempt_id)
                        except Exception:
                            self._save(stream_validation_error="stream_evidence_invalid",
                                       health_observation=None)
                            self._stop_requested.set()
                            self._child_stop.set()
                if self._store(cfg).is_paused() or time.monotonic() >= deadline:
                    self._stop_requested.set()
                    self._child_stop.set()
            if self._worker.is_alive():
                self._child_stop.set()
                self._worker.join(timeout=cfg.read_timeout_seconds + 2)
            if self._worker.is_alive():
                forced_process_stop()
                self._worker.terminate()
                self._worker.join(timeout=3)
            if self._worker.is_alive():
                forced_process_stop()
                self._worker.kill()
                self._worker.join(timeout=3)
            with self._guard:
                if self._worker.is_alive():
                    self._save(state="shutdown_failed", error_code="worker_did_not_stop")
                    return  # Keep ownership while a child may still write.
                self._store(cfg).reconcile()
                self._finish(cfg, attempt_id)
                self._release_owner()
        except Exception:
            with self._guard:
                self._transient = "supervisor_state_needs_attention"
                if self._worker is None or not self._worker.is_alive():
                    self._release_owner()

    def _finish(self, cfg, attempt_id):
        if cfg.continuous_session:
            return self._finish_stream(cfg, attempt_id)
        attempt = next(a for a in self._record["attempts"] if a["attempt_id"] == attempt_id)
        receipt_path = self.runtime / "camera-ingest" / "attempts" / (attempt_id + ".json")
        receipt = json.loads(receipt_path.read_text(encoding="utf-8")) if receipt_path.exists() else {}
        paused = self._store(cfg).is_paused()
        stopped = self._stop_requested.is_set()
        final_state = receipt.get("state", "interrupted" if stopped else "failed")
        # A receipt is not current evidence until its committed bytes are verified.
        if final_state == "quarantined":
            original = (self.runtime / "camera-ingest" / receipt["original_file"]).resolve(strict=True)
            if (not original.is_relative_to(self.runtime / "camera-ingest") or
                    sha256(original) != receipt["source_sha256"]):
                final_state = "failed"
                receipt["error_code"] = "original_integrity_failure"
        if final_state not in {"quarantined", "failed", "interrupted"}:
            final_state = "interrupted"
        attempt.update(state=final_state, ended_at=_utc().isoformat(),
                       error_code=receipt.get("error_code"),
                       receipt_sha256=sha256(receipt_path) if receipt_path.exists() else None)
        self._record["gaps"].append(dict(kind="capture_boundary", attempt_id=attempt_id,
                                        source_gap_seconds=None, continuity_verified=False))
        changes = dict(active_attempt_id=None, worker_pid=None, last_attempt_state=final_state,
                       state="paused" if paused else "held", health_observation=None,
                       error_code="connection_clock_review_required")
        if final_state == "quarantined":
            changes.update(failure_count=0, next_start_not_before=None,
                           last_accepted_at=_utc().isoformat())
            attempt["source_sha256"] = receipt["source_sha256"]
        elif stopped:
            changes.update(state="paused" if paused else "stopped", error_code="interrupted")
        else:
            failures = self._record["failure_count"] + 1
            code = receipt.get("error_code", "worker_failed_without_receipt")
            local_material = code in {"disk_reserve_reached", "original_integrity_failure",
                                      "existing_original_integrity_failure"}
            changes.update(failure_count=failures, error_code=code,
                           next_start_not_before=(_utc() + timedelta(seconds=(60, 300, 900)[min(failures-1, 2)])).isoformat(),
                           state="paused" if paused else "held" if failures >= 3 or local_material else "backoff",
                           health_observation={"kind": "storage_integrity" if local_material else "capture_failure",
                             "verified": local_material, "confirmed_camera_outage": False,
                             "incident_key": f"camera-ingest:{cfg.camera_id}:" + ("storage" if local_material else "connection-health"),
                             "evidence_attempt_id": attempt_id})
        self._save(**changes)

    def _checked_ingest_file(self, relative, expected_hash):
        if (not isinstance(relative, str) or not isinstance(expected_hash, str) or
                not re.fullmatch(r"[0-9a-f]{64}", expected_hash)):
            raise IngestError("stream_evidence_invalid")
        root = (self.runtime / "camera-ingest").resolve()
        path = (root / relative).resolve(strict=True)
        if not path.is_relative_to(root) or not path.is_file():
            raise IngestError("stream_evidence_invalid")
        if sha256(path) != expected_hash:
            raise IngestError("stream_evidence_invalid")
        return path

    def _stream_manifest(self, cfg, attempt_id):
        path = self.runtime / "camera-ingest" / "sessions" / (attempt_id + ".json")
        if not path.exists():
            return None
        state = json.loads(path.read_text(encoding="utf-8"))
        if (state.get("version") != 1 or state.get("session_id") != attempt_id or
                state.get("camera_id") != cfg.camera_id or
                state.get("authorization_id") != cfg.authorization_id or
                state.get("clock_evidence_sha256") != cfg.clock_evidence_sha256 or
                type(state.get("connections_opened")) is not int or state["connections_opened"] not in {0, 1} or
                state.get("same_connection") is not (state["connections_opened"] == 1) or
                not isinstance(state.get("events"), list)):
            raise IngestError("stream_evidence_invalid")
        return state

    def _consume_stream_events(self, cfg, attempt_id):
        """Accept immutable hashed receipts while the owned child is running.

        Media is never decoded here. This validates the packet segmenter's local
        acceptance chain, not physical coverage, frame truth, or model accuracy.
        """
        manifest = self._stream_manifest(cfg, attempt_id)
        if manifest is None:
            return None
        if len(manifest["events"]) > 2 * cfg.max_segments + 2:
            raise IngestError("stream_evidence_invalid")
        attempt = next(a for a in self._record["attempts"] if a["attempt_id"] == attempt_id)
        last = attempt.get("stream_event_sequence", 0)
        changed = False
        for index, reference in enumerate(manifest["events"], 1):
            if reference.get("sequence") != index:
                raise IngestError("stream_evidence_invalid")
            if index <= last:
                continue
            event_path = self._checked_ingest_file(reference["path"], reference["sha256"])
            event = json.loads(event_path.read_text(encoding="utf-8"))
            if (event.get("version") != 1 or event.get("session_id") != attempt_id or
                    event.get("sequence") != index or event.get("kind") != reference.get("kind") or
                    event.get("camera_id") != cfg.camera_id or
                    event.get("authorization_id") != cfg.authorization_id or
                    event.get("clock_evidence_sha256") != cfg.clock_evidence_sha256 or
                    event.get("same_connection") is not (manifest["connections_opened"] == 1)):
                raise IngestError("stream_evidence_invalid")
            if event["kind"] == "segment_sealed":
                receipt_path = self._checked_ingest_file(event["receipt_path"], event["receipt_sha256"])
                receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
                identity, metadata = receipt.get("request_identity", {}), receipt.get("media", {})
                if (manifest["connections_opened"] != 1 or event.get("accepted") is not True or receipt.get("state") != "quarantined" or
                        receipt.get("camera_id") != cfg.camera_id or
                        receipt.get("kind") != "rtsp_stream_segment" or
                        receipt.get("attempt_id") != event.get("attempt_id") or
                        identity.get("session_id") != attempt_id or
                        identity.get("authorization_id") != cfg.authorization_id or
                        identity.get("clock_evidence_sha256") != cfg.clock_evidence_sha256 or
                        receipt.get("source_sha256") != event.get("source_sha256") or
                        receipt.get("original_integrity_verified") is not True or
                        metadata.get("native_video_packets_remuxed") is not True or
                        metadata.get("codec_boundary_policy") != "h264_idr_with_parameter_sets" or
                        metadata.get("same_connection") is not True or
                        type(metadata.get("packet_count")) is not int or metadata["packet_count"] < 1):
                    raise IngestError("stream_evidence_invalid")
                self._checked_ingest_file(receipt["original_file"], receipt["source_sha256"])
                self._checked_ingest_file(metadata["packet_ledger"], metadata["packet_ledger_sha256"])
                observed = _date(event["observed_at"])
                first_packet = _date(metadata["first_packet_received_at"])
                last_packet = _date(metadata["last_packet_received_at"])
                if first_packet > last_packet or last_packet > observed:
                    raise IngestError("stream_evidence_invalid")
                accepted_ids = attempt.setdefault("accepted_segment_ids", [])
                if receipt["attempt_id"] in accepted_ids:
                    raise IngestError("stream_evidence_invalid")
                accepted_ids.append(receipt["attempt_id"])
                attempt['progress_baseline'] = dict(segment_id=receipt['attempt_id'],
                    source_sha256=receipt['source_sha256'],receipt_sha256=event['receipt_sha256'])
                attempt['progress_baseline_receipt'] = event['receipt_path']
                attempt["accepted_segment_count"] = attempt.get("accepted_segment_count", 0) + 1
                self._record.update(last_accepted_at=event["observed_at"],
                    last_packet_received_at=metadata["last_packet_received_at"],
                    packet_timestamps_contiguous=metadata.get("packet_timestamp_contiguous") is True,
                    health_observation=dict(kind="accepted_segment", verified=True, accepted=True,
                        segment_id=receipt["attempt_id"], segment_sha256=receipt["source_sha256"],
                        observed_at=event["observed_at"], evidence_kind="verified_native_packet_segment",
                        session_id=attempt_id, clock_evidence_sha256=cfg.clock_evidence_sha256))
            attempt["stream_event_sequence"] = index
            changed = True
        if changed:
            self._save()
        return manifest

    def _finish_stream(self, cfg, attempt_id):
        attempt = next(a for a in self._record["attempts"] if a["attempt_id"] == attempt_id)
        try:
            manifest = self._consume_stream_events(cfg, attempt_id)
        except Exception:
            manifest = None
            self._record["stream_validation_error"] = "stream_evidence_invalid"
        error = self._record.get("stream_validation_error")
        paused = self._store(cfg).is_paused()
        stopped = self._stop_requested.is_set()
        completed = (manifest is not None and manifest.get("state") == "completed" and not error
                     and attempt.get("accepted_segment_count", 0) > 0
                     and isinstance(manifest.get("segments"), list)
                     and len(manifest["segments"]) == attempt["accepted_segment_count"]
                     and [s.get("attempt_id") for s in manifest["segments"]] == attempt.get("accepted_segment_ids", [])
                     and all(s.get("state") == "quarantined" for s in manifest["segments"]))
        terminal = "quarantined" if completed else "interrupted" if stopped and not error else "failed"
        receipt_path = self.runtime / "camera-ingest" / "sessions" / (attempt_id + ".json")
        attempt.update(state=terminal, ended_at=_utc().isoformat(),
                       receipt_sha256=sha256(receipt_path) if receipt_path.exists() else None,
                       error_code=error or (None if completed else "stream_interrupted" if stopped else "stream_session_held"))
        self._record["gaps"].append(dict(kind="connection_boundary", attempt_id=attempt_id,
                                        source_gap_seconds=None, continuity_verified=False))
        changes = dict(active_attempt_id=None, worker_pid=None, last_attempt_state=terminal,
                       state="paused" if paused else "stopped" if stopped else "held",
                       error_code="connection_clock_review_required" if completed else attempt["error_code"],
                       camera_connected=False)
        if completed:
            changes.update(failure_count=0, next_start_not_before=None)
        elif not stopped or error:
            failures = self._record["failure_count"] + 1
            changes.update(failure_count=failures,
                state="paused" if paused else "held" if failures >= 3 or error else "backoff",
                next_start_not_before=(_utc() + timedelta(seconds=(60, 300, 900)[min(failures-1, 2)])).isoformat(),
                health_observation={"kind":"capture_failure", "verified":False,
                                    "confirmed_camera_outage":False,"evidence_attempt_id":attempt_id})
        self._save(**changes)

    def prepare_progress(self):
        """Hash preparation outside service/supervisor pause fences."""
        from app.recorder_progress import verify_chain
        with self._guard:
            if self._record is None or not self._record.get('attempts'):
                return None
            attempt = self._record['attempts'][-1]
            identity = dict(self._progress_identity) if self._progress_identity else None
            baseline = attempt.get('progress_baseline')
            if baseline is None:
                return None
            baseline = dict(baseline)
            receipt_relative = attempt['progress_baseline_receipt']
            generation = self._record['attempts'].index(attempt)+1
            ordinal = attempt['accepted_segment_ids'].index(baseline['segment_id'])+1
            cfg = self._config()
        try:
            receipt_path = self._checked_ingest_file(receipt_relative,baseline['receipt_sha256'])
            receipt = json.loads(receipt_path.read_text(encoding='utf-8'))
            request_identity = receipt.get('request_identity',{})
            if (receipt.get('attempt_id') != baseline['segment_id'] or receipt.get('state') != 'quarantined'
                    or receipt.get('camera_id') != attempt['camera_id']
                    or receipt.get('source_sha256') != baseline['source_sha256']
                    or receipt.get('kind') != 'rtsp_stream_segment' or receipt.get('original_integrity_verified') is not True
                    or request_identity.get('session_id') != attempt['attempt_id']
                    or request_identity.get('authorization_id') != attempt['authorization_id']
                    or request_identity.get('clock_evidence_sha256') != attempt['clock_evidence_sha256']):
                raise ValueError('progress_accepted_receipt_invalid')
            self._checked_ingest_file(receipt['original_file'],baseline['source_sha256'])
            self._checked_ingest_file(receipt['media']['packet_ledger'],receipt['media']['packet_ledger_sha256'])
            home = self.runtime/'camera-ingest'/'sessions'/attempt['attempt_id']/'progress-health'
            live = self._worker is not None and self._worker.is_alive()
            clock_deadline = None
            if live:
                if self._clock_gate(cfg,_utc(),active_session=True) is not None:
                    raise ValueError('progress_clock_gate_invalid')
                with (self.runtime/cfg.clock_evidence_file).open('rb') as proof_file:
                    proof_bytes = proof_file.read(32769)
                if len(proof_bytes)>32768 or hashlib.sha256(proof_bytes).hexdigest()!=cfg.clock_evidence_sha256:
                    raise ValueError('progress_clock_proof_changed')
                clock_proof = json.loads(proof_bytes)
                clock_deadline = (_date(clock_proof['observed_at'])+timedelta(seconds=cfg.max_clock_age_seconds)).timestamp()
            evidence = verify_chain(home,identity,baseline) if live and identity and (home/'checkpoint.json').exists() else None
            return dict(identity=identity,session_id=attempt['attempt_id'],baseline=baseline,generation=generation,ordinal=ordinal,evidence=evidence,
                        clock_deadline=clock_deadline)
        except Exception:
            self._progress_error = 'progress_evidence_invalid'
            return None

    def progress_health(self, adapter, outbox, prepared):
        """Fresh owned-child grant, called only under the service pause guard."""
        from app.recorder_progress import request_grant
        with self._guard:
            status = self.status()
            if prepared is not None and not self._record.get('stream_validation_error'):
                latest_attempt = self._record['attempts'][-1]
                if (latest_attempt['attempt_id'] == prepared['session_id']
                        and latest_attempt.get('progress_baseline') == prepared['baseline']
                        and latest_attempt.get('state') in {'quarantined','interrupted'}
                        and (self._worker is None or not self._worker.is_alive())):
                    adapter.progress_accepted(latest_attempt['camera_id'],prepared['session_id'],
                        prepared['generation'],prepared['ordinal'],prepared['baseline'])
                    return {'status':'accepted_terminal_progress'}
            if (prepared is None or self._progress_channels is None or self._progress_error or self._stop_requested.is_set()
                    or any(status.get(k) is not True for k in ('enabled','configured','demand_active','within_hours'))
                    or status.get('paused') is not False or status.get('state') != 'acquiring_unverified'
                    or self._record.get('stream_validation_error')):
                return {'status':'suppressed','error_code':self._progress_error}
            identity, baseline = prepared['identity'], prepared['baseline']
            current_cfg = self._config()
            current_config_hash = hashlib.sha256(json.dumps(asdict(current_cfg),sort_keys=True).encode()).hexdigest()
            if identity is None or current_config_hash != identity['config_sha256']:
                self._progress_error = 'progress_configuration_changed'
                return {'status':'suppressed','error_code':self._progress_error}
            def scalar_gates():
                now = _utc()
                local = now+timedelta(minutes=current_cfg.source_utc_offset_minutes)
                return (prepared.get('clock_deadline') is not None and now.timestamp() <= prepared['clock_deadline']
                        and self._progress_session_deadline is not None and time.monotonic() < self._progress_session_deadline
                        and not self._stop_requested.is_set() and self._worker is not None and self._worker.is_alive()
                        and current_cfg.source_start_hour <= local.hour < current_cfg.source_end_hour)
            if not scalar_gates():
                self._progress_error = 'progress_clock_or_session_expired'
                return {'status':'suppressed','error_code':self._progress_error}
            attempt = next(a for a in self._record['attempts'] if a['attempt_id']==identity['session_id'])
            if identity != self._progress_identity or attempt.get('progress_baseline') != baseline:
                return {'status':'superseded_preparation'}
            try:
                def accepted_current():
                    latest = self.status()
                    if (not scalar_gates() or self._stop_requested.is_set() or any(latest.get(k) is not True
                            for k in ('enabled','configured','demand_active','within_hours'))
                            or latest.get('paused') is not False):
                        raise ValueError('progress_lifecycle_changed')
                    adapter.progress_accepted(identity['camera_id'],identity['session_id'],prepared['generation'],prepared['ordinal'],baseline)
                grant = request_grant(*self._progress_channels,identity,baseline,prepared['evidence'],on_current=accepted_current)
                if grant is None:
                    return {'status':'pending_or_suppressed'}
                grant.valid = scalar_gates
                latest = self.status()
                if (self._stop_requested.is_set() or any(latest.get(k) is not True
                        for k in ('enabled','configured','demand_active','within_hours')) or latest.get('paused') is not False):
                    return {'status':'suppressed'}
            except Exception:
                self._progress_error = 'progress_evidence_or_handshake_invalid'
                return {'status':'needs_attention','error_code':self._progress_error}
            try:
                return adapter.progress_handoff(outbox,grant,prepared['generation'])
            except Exception:
                return {'status':'deferred','error_code':'progress_outbox_deferred'}

    def stop(self, timeout=25):
        if not 1 <= timeout <= 60:
            raise ValueError("Stop timeout must be between 1 and 60 seconds")
        deadline = time.monotonic() + timeout
        if not self._guard.acquire(timeout=timeout):
            self._transient = "shutdown_failed"
            raise RuntimeError("Recorder shutdown did not obtain lifecycle ownership")
        try:
            self._stop_requested.set()
            if self._child_stop is not None:
                self._child_stop.set()
            thread, worker = self._thread, self._worker
        finally:
            self._guard.release()
        remaining = lambda: max(0., deadline - time.monotonic())
        if thread and thread.is_alive():
            thread.join(timeout=max(0., remaining() - 2))
        if worker and worker.is_alive():
            # Only this instance's dedicated child can be terminated. Share one
            # absolute deadline across graceful wait, terminate, kill and join.
            forced_process_stop()
            worker.terminate()
            worker.join(timeout=min(.75, remaining()))
            if worker.is_alive():
                forced_process_stop()
                worker.kill()
                worker.join(timeout=remaining())
        if thread and thread.is_alive():
            thread.join(timeout=remaining())
        if (worker and worker.is_alive()) or (thread and thread.is_alive()):
            self._transient = "shutdown_failed"
            raise RuntimeError("Recorder shutdown not acknowledged; retain runtime ownership")
        with self._guard:
            self._release_owner()
        return self.status()

    def pause(self):
        with self._guard:
            (self.runtime / "camera-ingest").mkdir(parents=True, exist_ok=True)
            (self.runtime / "camera-ingest" / "PAUSED").touch(exist_ok=True)
            self._stop_requested.set()
            if self._child_stop is not None:
                self._child_stop.set()
        return self.stop()

    def resume(self):
        # Refuse to remove another active supervisor's stop flag through this
        # object's resume call. Direct user authorization is the caller's duty.
        self.stop()
        if self._thread and self._thread.is_alive():
            return self.status()
        with self._guard:
            with runtime_lock(self.home):
                (self.runtime / "camera-ingest" / "PAUSED").unlink(missing_ok=True)
            return self.start()

    def status(self):
        with self._guard:
            try:
                state = self._load()
            except (ValueError, OSError):
                state = {"state": "state_invalid"}
            try:
                cfg = self._config()
                enabled = cfg.enabled and os.environ.get("GATE_CAMERA_CAPTURE_ENABLED") == "1"
                camera_id = cfg.camera_id
                continuous = cfg.continuous_session
                native_stop_reviewed = self._native_stop_gate(cfg) is None
                local_time = _utc() + timedelta(minutes=cfg.source_utc_offset_minutes)
                within_hours = cfg.source_start_hour <= local_time.hour < cfg.source_end_hour
            except (ValueError, TypeError, OSError, IngestError):
                enabled, camera_id = False, "unconfigured"
                cfg = None
                continuous = native_stop_reviewed = within_hours = False
            paused = (self.runtime / "camera-ingest" / "PAUSED").exists()
            worker_active = self._worker is not None and self._worker.is_alive()
            demand_active = enabled and not paused and bool(state.get("active_attempt_id")) and worker_active
            connected = False
            if demand_active and state.get("last_packet_received_at"):
                try:
                    age = (_utc() - _date(state["last_packet_received_at"])).total_seconds()
                    connected = 0 <= age <= cfg.read_timeout_seconds
                except (TypeError, ValueError):
                    pass
            return dict(enabled=enabled, state=self._transient or ("paused" if paused else state.get("state", "disabled")),
                        paused=paused, camera_id=camera_id,
                        configured=enabled and native_stop_reviewed and state.get("configured") is True,
                        demand_active=demand_active, within_hours=within_hours,
                        capture_method="bounded_continuous_rtsp" if continuous else "bounded_rtsp_remux",
                        camera_connected=connected, boundary_gap_unknown=True, continuity_verified=False,
                        active_attempt_id=state.get("active_attempt_id"),
                        last_attempt_state=state.get("last_attempt_state"),
                        last_accepted_at=state.get("last_accepted_at"),
                        last_packet_received_at=state.get("last_packet_received_at"),
                        native_stop_reviewed=native_stop_reviewed,
                        accepted_segment_count=sum(a.get("accepted_segment_count",0) for a in state.get("attempts",[])),
                        error_code=state.get("error_code"), failure_count=state.get("failure_count", 0),
                        next_start_not_before=state.get("next_start_not_before"),
                        health_observation=state.get("health_observation"),
                        attempt_count=len(state.get("attempts", [])), gap_count=len(state.get("gaps", [])),
                        source_clock_verified=False, persistent_stream_segmentation=continuous,
                        stream_segmentation_supported=True, measured_outage_supported=False,
                        progress_stall_supported=True, progress_health_error=self._progress_error)
