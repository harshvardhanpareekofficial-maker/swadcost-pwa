"""Isolated remote session persistence; no routes, cookies or listener installed.

Call synchronous methods off the ASGI event loop. membership(user_id, factory_id)
must query current authoritative membership and return owner/worker or None.
Only an authenticated login handler may call issue; never pass a client user ID.
"""
from contextlib import contextmanager
import hashlib
import re
import secrets
import sqlite3
import time

from app.mobile_boundary import RemoteSession


def digest(token):
    return hashlib.sha256(token.encode('ascii')).hexdigest()


class RemoteSessionStore:
    def __init__(self, path, config, membership, *, clock=time.time):
        if config is None:
            raise ValueError('remote_configuration_required')
        self.path, self.config, self.membership, self.clock = path, config, membership, clock

    @contextmanager
    def db(self):
        c = sqlite3.connect(self.path, timeout=0.2)
        try:
            c.execute('''CREATE TABLE IF NOT EXISTS remote_sessions_v1 (
                token_hash TEXT PRIMARY KEY, uid TEXT, factory TEXT NOT NULL,
                audience TEXT NOT NULL, csrf TEXT NOT NULL, expires REAL NOT NULL)''')
            c.execute('BEGIN IMMEDIATE')
            c.execute('DELETE FROM remote_sessions_v1 WHERE expires<=?', (self.clock(),))
            with c:
                yield c
        finally:
            c.close()

    def _new(self, c, uid):
        # Global bounded storage also bounds anonymous pre-login challenges.
        count = c.execute('SELECT COUNT(*) FROM remote_sessions_v1 WHERE uid IS NULL' if uid is None
                          else 'SELECT COUNT(*) FROM remote_sessions_v1 WHERE uid IS NOT NULL').fetchone()[0]
        if count >= (128 if uid is None else 1024):
            raise ValueError('remote_session_capacity')
        token, csrf = secrets.token_urlsafe(32), secrets.token_urlsafe(32)
        expiry = self.clock() + (300 if uid is None else 8 * 3600)
        c.execute('INSERT INTO remote_sessions_v1 VALUES (?,?,?,?,?,?)',
                  (digest(token), uid, self.config.factory_id, self.config.canonical_origin, csrf, expiry))
        return token, csrf

    def challenge(self):
        with self.db() as c:
            return self._new(c, None)

    def reserve_login_attempt(self, username):
        with self.db() as c:
            c.execute('CREATE TABLE IF NOT EXISTS remote_attempts_v1 (name TEXT, at REAL)')
            c.execute('DELETE FROM remote_attempts_v1 WHERE at<=?', (self.clock()-900,))
            total = c.execute('SELECT COUNT(*) FROM remote_attempts_v1').fetchone()[0]
            count = c.execute('SELECT COUNT(*) FROM remote_attempts_v1 WHERE name=?', (username,)).fetchone()[0]
            if count >= 5 or total >= 20:
                return False
            c.execute('INSERT INTO remote_attempts_v1 VALUES (?,?)', (username, self.clock()))
            return True

    def issue(self, uid, challenge_token):
        if type(uid) is not str or not uid or self.membership(uid, self.config.factory_id) not in ('owner', 'worker'):
            raise ValueError('remote_membership_required')
        if not self._token(challenge_token):
            raise ValueError('remote_challenge_required')
        with self.db() as c:
            challenge = c.execute('SELECT uid,factory,audience FROM remote_sessions_v1 WHERE token_hash=?',
                                  (digest(challenge_token),)).fetchone()
            if challenge != (None, self.config.factory_id, self.config.canonical_origin):
                raise ValueError('remote_challenge_required')
            c.execute('DELETE FROM remote_sessions_v1 WHERE token_hash=?', (digest(challenge_token),))
            return self._new(c, uid)

    @staticmethod
    def _token(token):
        return type(token) is str and re.fullmatch(r'[A-Za-z0-9_-]{43}', token) is not None

    def resolve(self, token):
        if not self._token(token):
            return None
        with self.db() as c:
            row = c.execute('SELECT uid,factory,audience,csrf,expires FROM remote_sessions_v1 WHERE token_hash=?',
                            (digest(token),)).fetchone()
        if not row or row[1:3] != (self.config.factory_id, self.config.canonical_origin):
            return None
        uid, factory, audience, csrf, expiry = row
        role = self.membership(uid, factory) if uid is not None else None
        if uid is not None and role not in ('owner', 'worker'):
            return None
        return RemoteSession(role, factory, audience, csrf, expiry, uid)

    def revoke(self, token):
        if self._token(token):
            with self.db() as c:
                c.execute('DELETE FROM remote_sessions_v1 WHERE token_hash=?', (digest(token),))

    def revoke_user(self, uid):
        with self.db() as c:
            c.execute('DELETE FROM remote_sessions_v1 WHERE uid=?', (uid,))
