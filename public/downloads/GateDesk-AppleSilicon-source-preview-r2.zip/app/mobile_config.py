"""Inert mobile configuration validation. Never opens files or listeners.

Initial deployment supports RFC1918 IPv4 only. Valid configuration is not
certificate validation, authentication, or permission to activate transport.
"""
from dataclasses import dataclass, field
from ipaddress import IPv4Address, IPv4Network
from pathlib import PureWindowsPath
import re
from urllib.parse import urlsplit


_NETWORKS = tuple(map(IPv4Network, ('10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16')))
_FIELDS = {'enabled', 'bind_address', 'port', 'canonical_origin', 'factory_id',
           'certificate_path', 'private_key_path'}


@dataclass(frozen=True)
class MobileConfig:
    bind_address: str
    port: int
    canonical_origin: str
    factory_id: str
    certificate_path: str = field(repr=False)
    private_key_path: str = field(repr=False)


def _path(value):
    if not isinstance(value, str) or not value or len(value) > 1024:
        raise ValueError('invalid_mobile_path')
    # Local drive only: exclude UNC, devices, alternate streams and traversal.
    if not re.match(r'^[A-Za-z]:[\\/]', value) or any(c in value for c in '<>"|?*'):
        raise ValueError('invalid_mobile_path')
    if any(ord(c) < 32 for c in value) or ':' in value[2:]:
        raise ValueError('invalid_mobile_path')
    path = PureWindowsPath(value)
    if any(p in ('.', '..') or p.endswith((' ', '.')) or PureWindowsPath(p).is_reserved()
           for p in path.parts[1:]) or len(path.parts) < 2:
        raise ValueError('invalid_mobile_path')
    return str(path)


def parse_mobile_config(value=None):
    """Return None for absent/disabled configuration; reject malformed input.

    Disabled configuration accepts no activation fields, preventing stale or
    misspelled security settings from being silently ignored. Errors omit input.
    """
    if value is None or value == {}:
        return None
    if type(value) is not dict or set(value) - _FIELDS:
        raise ValueError('invalid_mobile_fields')
    if type(value.get('enabled')) is not bool:
        raise ValueError('invalid_mobile_enabled')
    if not value['enabled']:
        if set(value) != {'enabled'}:
            raise ValueError('disabled_mobile_fields')
        return None
    if set(value) != _FIELDS:
        raise ValueError('missing_mobile_fields')
    address = value['bind_address']
    try:
        if type(address) is not str:
            raise ValueError()
        ip = IPv4Address(address)
        if not any(ip in network for network in _NETWORKS):
            raise ValueError()
    except ValueError:
        raise ValueError('invalid_mobile_bind') from None
    port = value['port']
    if type(port) is not int or not 1 <= port <= 65535:
        raise ValueError('invalid_mobile_port')
    origin = value['canonical_origin']
    if type(origin) is not str or len(origin) > 300 or not origin.isascii():
        raise ValueError('invalid_mobile_origin')
    try:
        parsed = urlsplit(origin)
        host = parsed.hostname or ''
        labels = host.split('.')
        valid_host = all(re.fullmatch(r'[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?', p) for p in labels)
        if host.replace('.', '').isdigit():
            valid_host = host == address
        expected = 'https://' + host + (f':{port}' if port != 443 else '')
        if not valid_host or host == 'localhost' or host.endswith('.localhost') or origin != expected:
            raise ValueError()
    except ValueError:
        raise ValueError('invalid_mobile_origin') from None
    factory = value['factory_id']
    if type(factory) is not str or not re.fullmatch(r'[A-Za-z0-9_-]{1,128}', factory):
        raise ValueError('invalid_mobile_factory')
    certificate, key = _path(value['certificate_path']), _path(value['private_key_path'])
    if certificate.casefold() == key.casefold():
        raise ValueError('distinct_mobile_key_path_required')
    return MobileConfig(address, port, origin, factory, certificate, key)
