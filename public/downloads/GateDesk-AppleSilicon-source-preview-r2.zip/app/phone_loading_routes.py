"""Optional local-owner receipt review routes, installed by the runtime host."""
import json
from pathlib import Path
import re
from weakref import WeakKeyDictionary

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import JSONResponse
from app import accounts
from app.document_store import DocumentStore
from app.mobile_body import read_auth_body
from app.mobile_offload import owned_database_call
from app.phone_loading_review import PhoneLoadingReview, LoadingReviewError
from app.phone_setup import strict_object
from app.phone_submissions import PhoneSubmissions
from app.phone_catchup import PhoneCatchup, CatchupError
from app.camera_enrollment import OwnerIdentity
from app.upload_intake import UploadPool, IntakeError

_OWNED_ENDPOINTS = WeakKeyDictionary()


def owned_endpoint_specs(app):
    return _OWNED_ENDPOINTS.get(app, ())


def install_local_phone_loading(app, runtime, port, *, main_module=None):
    if not getattr(getattr(app, 'state', None), 'accounts_enabled', False) or not getattr(app.state, 'accounts_owner_only', False):
        return False
    if main_module is None:
        import sys
        main_module = sys.modules.get('app.main')
    if (app in _OWNED_ENDPOINTS or type(port) is not int or not 1024<=port<=65535
            or main_module is None or getattr(main_module, 'app', None) is not app
            or Path(app.state.accounts_db_path()).resolve().parent != Path(runtime).resolve()):
        raise ValueError('phone_loading_host_binding_invalid')
    index, lock = main_module.DOCUMENT_FILE, main_module.document_lock
    store = DocumentStore(index, lock)
    origin = f'http://127.0.0.1:{port}'
    router = APIRouter(prefix='/api/phone-loading')
    pool = UploadPool()

    def boundary(request):
        origins = request.headers.getlist('origin')
        return (accounts.local_peer(request) and request.scope.get('scheme') == 'http'
                and request.headers.getlist('host') == [f'127.0.0.1:{port}']
                and request.headers.getlist('x-gate-desk') == ['local']
                and (origins == [origin] or (not origins and request.method == 'GET'
                     and request.headers.getlist('sec-fetch-site') == ['same-origin'])))

    def identity(request):
        if (not accounts.enabled(request) or not accounts.owner_pc(request)
                or main_module.app is not app or main_module.DOCUMENT_FILE != index
                or main_module.document_lock is not lock
                or Path(app.state.accounts_db_path()).resolve().parent != Path(runtime).resolve()):
            raise HTTPException(403)
        owner = accounts.require_owner(request)
        with accounts.database(request) as db:
            factory = db.execute('SELECT id FROM factory WHERE singleton=1').fetchone()
        if factory is None:
            raise HTTPException(403)
        return owner['id'], factory[0]

    def perform(request, submission_id, body, offset, job_id=None, enqueue=False):
        owner, factory = identity(request)
        service = PhoneLoadingReview(runtime, PhoneSubmissions(store, factory))
        def authorize():
            if identity(request) != (owner, factory):
                raise HTTPException(403)
            return OwnerIdentity(owner, factory, 'owner', True, True)
        if job_id is not None or enqueue:
            queue = PhoneCatchup(service, factory_id=factory, authorize=authorize)
            if enqueue:
                if type(body) is not dict or set(body) != {'review_revision'}:
                    raise LoadingReviewError('invalid_loading_review')
                job = queue.enqueue(submission_id, body['review_revision'])
            else:
                job = queue.get(job_id)
            return {'factory_id':factory, 'id':job['submission_id'], 'job':job}
        if submission_id is None:
            result = service.page(offset)
            authorize()
            return result
        return service.save(submission_id, body, owner, authorize)

    def reply(value, code=200):
        return JSONResponse(value, code, headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'})

    async def dispatch(request, submission_id=None, *, job_id=None, enqueue=False):
        if not boundary(request):
            return reply({'detail':'local_owner_boundary_required'},403)
        try:
            await owned_database_call(lambda: identity(request))
            body, offset = None, 0
            pairs = request.query_params.multi_items()
            if job_id is not None:
                if pairs:
                    raise LoadingReviewError('invalid_loading_review')
            elif submission_id is None:
                if len(pairs)>1 or any(k!='offset' or not re.fullmatch(r'0|[1-9][0-9]{0,4}',v) for k,v in pairs):
                    raise LoadingReviewError('invalid_loading_review')
                offset = int(request.query_params.get('offset','0'))
            else:
                if pairs or request.headers.getlist('content-type') != ['application/json'] or len(request.headers.getlist('content-length'))>1 or request.headers.get('content-encoding') or request.headers.get('transfer-encoding'):
                    raise LoadingReviewError('invalid_loading_review')
                length = request.headers.get('content-length')
                if length is not None and (not length.isascii() or not length.isdigit() or len(length)>6 or int(length)>4096):
                    return reply({'detail':'invalid_loading_review'},413)
                raw = await read_auth_body(request.receive,pool)
                if len(raw)>4096 or (length is not None and int(length)!=len(raw)):
                    return reply({'detail':'invalid_loading_review'},413)
                body = json.loads(raw, object_pairs_hook=strict_object,
                                  parse_constant=lambda _: (_ for _ in ()).throw(ValueError()))
            return reply(await owned_database_call(lambda: perform(request,submission_id,body,offset,job_id,enqueue)))
        except HTTPException as exc:
            return reply({'detail':'owner_required'},401 if exc.status_code==401 else 403)
        except LoadingReviewError as exc:
            code = str(exc)
            return reply({'detail':code}, {'revision_conflict':409,'phone_receipt_not_found':404,
                         'invalid_loading_review':422}.get(code,503))
        except CatchupError as exc:
            code = str(exc)
            status = (403 if code in ('catchup_owner_required','catchup_owner_changed')
                else 409 if code in ('catchup_revision_conflict','catchup_fingerprint_conflict')
                else 404 if code in ('catchup_job_not_found','catchup_receipt_unavailable','catchup_review_required')
                else 422 if code in ('catchup_invalid_revision','catchup_invalid_job_id') else 503)
            return reply({'detail':code},status)
        except IntakeError as exc:
            return reply({'detail':'invalid_loading_review'},exc.status)
        except (ValueError, TypeError, RecursionError):
            return reply({'detail':'invalid_loading_review'},422)
        except Exception:
            return reply({'detail':'phone_loading_unavailable'},503)

    @router.get('')
    async def listing(request: Request): return await dispatch(request)

    @router.post('/{submission_id}/review')
    async def review(submission_id: str, request: Request): return await dispatch(request,submission_id)

    @router.post('/{submission_id}/catchup')
    async def catchup(submission_id: str, request: Request): return await dispatch(request,submission_id,enqueue=True)

    @router.get('/catchup/{job_id}')
    async def job(job_id: str, request: Request): return await dispatch(request,job_id=job_id)

    app.include_router(router)
    _OWNED_ENDPOINTS[app] = ((listing,'/api/phone-loading',frozenset({'GET'})),
        (review,'/api/phone-loading/{submission_id}/review',frozenset({'POST'})),
        (catchup,'/api/phone-loading/{submission_id}/catchup',frozenset({'POST'})),
        (job,'/api/phone-loading/catchup/{job_id}',frozenset({'GET'})))
    return True
