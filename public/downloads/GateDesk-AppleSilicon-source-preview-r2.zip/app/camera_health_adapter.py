"""Durable camera-outage evidence gate. No capture, inference, or external send.

Trusted recorder integration supplies accepted segment receipts or actual measured
outage intervals. A failed process, stale frame, missing setup or clock passage is
not such a measurement. This module deliberately does not monitor disk capacity.
"""
from __future__ import annotations

import hashlib
import json
import math
import re
import sqlite3
import time
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path


OUTAGE_MESSAGE = (
    "A verified camera interruption was measured for at least 30 seconds while "
    "capture was required. Check current local camera status and the recording gap."
)


def _identifier(value):
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.:-]{0,119}", value):
        raise ValueError("Expected a safe local identifier, not a path or connection string")
    return value


def _timestamp(value):
    if not isinstance(value, str):
        raise ValueError("An aware ISO timestamp is required")
    result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if result.utcoffset() is None:
        raise ValueError("An aware ISO timestamp is required")
    return result.timestamp()


def _iso(value):
    return datetime.fromtimestamp(value, timezone.utc).isoformat()


class CameraHealthAdapter:
    def __init__(self, db_path, *, persistence_seconds=30, clock=time.time):
        if isinstance(persistence_seconds, bool) or not 30 <= persistence_seconds <= 3600:
            raise ValueError("Persistence must be 30..3600 seconds")
        self.db_path = Path(db_path)
        self.persistence_seconds = persistence_seconds
        self.clock = clock
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with self._db() as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.executescript("""
                CREATE TABLE IF NOT EXISTS camera_health_state (
                    camera_id TEXT PRIMARY KEY, verified_segment_id TEXT,
                    verified_segment_sha256 TEXT, verified_at REAL,
                    last_evidence_at REAL, pending_id TEXT, bad_since REAL,
                    last_failure_end REAL, failure_count INTEGER NOT NULL DEFAULT 0,
                    delivery_allowed INTEGER NOT NULL DEFAULT 0,
                    last_gate TEXT NOT NULL DEFAULT 'unverified'
                );
                CREATE TABLE IF NOT EXISTS camera_health_receipts (
                    camera_id TEXT NOT NULL, kind TEXT NOT NULL, evidence_id TEXT NOT NULL,
                    digest TEXT NOT NULL, PRIMARY KEY(camera_id,kind,evidence_id)
                );
                CREATE TABLE IF NOT EXISTS camera_health_episodes (
                    id TEXT PRIMARY KEY, camera_id TEXT NOT NULL, started_at REAL NOT NULL,
                    qualified_at REAL NOT NULL, prior_segment_id TEXT NOT NULL,
                    prior_segment_sha256 TEXT NOT NULL, event TEXT NOT NULL,
                    recovered_at REAL, recovery_segment_id TEXT,
                    handoff_status TEXT NOT NULL DEFAULT 'pending', outbox_id TEXT,
                    last_error_code TEXT
                );
                CREATE UNIQUE INDEX IF NOT EXISTS one_active_camera_episode
                    ON camera_health_episodes(camera_id) WHERE recovered_at IS NULL;
                CREATE TABLE IF NOT EXISTS recorder_progress_accepted (
                    camera_id TEXT PRIMARY KEY, session_id TEXT NOT NULL,
                    generation INTEGER NOT NULL, ordinal INTEGER NOT NULL, baseline TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS recorder_progress_episodes (
                    id TEXT PRIMARY KEY, camera_id TEXT NOT NULL, session_id TEXT NOT NULL,
                    generation INTEGER NOT NULL, baseline_ordinal INTEGER NOT NULL,
                    evidence TEXT NOT NULL, event TEXT NOT NULL,
                    recovery_segment_id TEXT, handoff_status TEXT NOT NULL DEFAULT 'pending', outbox_id TEXT
                );
                CREATE UNIQUE INDEX IF NOT EXISTS one_active_progress_episode
                    ON recorder_progress_episodes(camera_id) WHERE recovery_segment_id IS NULL;
            """)

    @contextmanager
    def _db(self):
        db = sqlite3.connect(self.db_path, timeout=0.25)
        db.row_factory = sqlite3.Row
        try:
            db.execute("PRAGMA synchronous=FULL")
            with db:
                yield db
        finally:
            db.close()

    @staticmethod
    def _reset_pending(db, camera_id, reason):
        db.execute("""UPDATE camera_health_state SET pending_id=NULL,bad_since=NULL,
            last_failure_end=NULL,failure_count=0,delivery_allowed=0,last_gate=? WHERE camera_id=?""",
                   (reason, camera_id))

    def observe(self, status: dict) -> dict:
        """Persist one trusted measurement; missing/unknown fields fail closed.

        accepted_segment: verified/accepted True, segment_id, segment_sha256,
        observed_at (local receipt time). camera_outage: verified True,
        evidence_attempt_id, measured_from, observed_at. A continuous verified
        interval must cover the gap since the preceding failure measurement.
        At least two distinct attempts and 30s AFTER the first failure are needed.
        """
        camera_id = _identifier(status.get("camera_id"))
        observation = status.get("health_observation")
        observation = observation if isinstance(observation, dict) else {}
        kind = observation.get("kind", "unverified")
        demand = (status.get("configured") is True and status.get("demand_active") is True
                  and status.get("within_hours") is True and status.get("paused") is False)
        with self._db() as db:
            db.execute("BEGIN IMMEDIATE")
            db.execute("INSERT OR IGNORE INTO camera_health_state(camera_id) VALUES (?)", (camera_id,))
            state = dict(db.execute("SELECT * FROM camera_health_state WHERE camera_id=?", (camera_id,)).fetchone())
            # Pausing suspends an active incident; it never proves recovery.
            if not demand:
                self._reset_pending(db, camera_id, "demand_inactive_or_unconfigured")
                if kind != "accepted_segment":
                    return {"status": "suppressed", "reason": "demand_inactive_or_unconfigured"}
            if kind not in {"accepted_segment", "camera_outage"} or observation.get("verified") is not True:
                self._reset_pending(db, camera_id, "unverified")
                return {"status": "suppressed", "reason": "unverified_measurement"}
            try:
                observed_at = _timestamp(observation.get("observed_at"))
                if not math.isfinite(observed_at) or observed_at > self.clock() + 5:
                    raise ValueError("Future measurement")
                if kind == "accepted_segment":
                    if observation.get("accepted") is not True:
                        raise ValueError("Segment not accepted")
                    evidence_id = _identifier(observation.get("segment_id"))
                    sha = observation.get("segment_sha256")
                    if not isinstance(sha, str) or not re.fullmatch(r"[0-9a-f]{64}", sha):
                        raise ValueError("Verified segment hash is required")
                    normalized = [kind, evidence_id, sha, observed_at]
                else:
                    evidence_id = _identifier(observation.get("evidence_attempt_id"))
                    start = _timestamp(observation.get("measured_from"))
                    if not math.isfinite(start) or start > observed_at:
                        raise ValueError("Invalid measured interval")
                    normalized = [kind, evidence_id, start, observed_at]
            except (ValueError, TypeError, OverflowError):
                self._reset_pending(db, camera_id, "invalid_measurement")
                return {"status": "suppressed", "reason": "invalid_measurement"}
            digest = hashlib.sha256(json.dumps(normalized, separators=(",", ":")).encode()).hexdigest()
            old = db.execute("SELECT digest FROM camera_health_receipts WHERE camera_id=? AND kind=? AND evidence_id=?", (camera_id, kind, evidence_id)).fetchone()
            if old:
                if old["digest"] != digest:
                    self._reset_pending(db, camera_id, "conflicting_evidence")
                    return {"status": "suppressed", "reason": "conflicting_evidence"}
                return {"status": "duplicate", "reason": "same_measurement"}
            if state["last_evidence_at"] is not None and observed_at <= state["last_evidence_at"]:
                return {"status": "ignored", "reason": "stale_measurement"}
            if kind == "accepted_segment":
                db.execute("INSERT INTO camera_health_receipts VALUES (?,?,?,?)", (camera_id, kind, evidence_id, digest))
                active = db.execute("SELECT id FROM camera_health_episodes WHERE camera_id=? AND recovered_at IS NULL", (camera_id,)).fetchone()
                db.execute("""UPDATE camera_health_episodes SET recovered_at=?,recovery_segment_id=?,
                    handoff_status=CASE WHEN handoff_status='pending' THEN 'recovered_before_handoff' ELSE handoff_status END
                    WHERE camera_id=? AND recovered_at IS NULL""", (observed_at, evidence_id, camera_id))
                self._reset_pending(db, camera_id, "verified_segment")
                db.execute("UPDATE camera_health_state SET verified_segment_id=?,verified_segment_sha256=?,verified_at=?,last_evidence_at=? WHERE camera_id=?", (evidence_id, sha, observed_at, observed_at, camera_id))
                return {"status": "recovered" if active else "baseline_verified", "episode_id": active["id"] if active else None}
            if state["verified_at"] is None:
                self._reset_pending(db, camera_id, "never_verified")
                return {"status": "suppressed", "reason": "camera_never_verified"}
            if start < state["verified_at"]:
                self._reset_pending(db, camera_id, "contradicts_verified_segment")
                return {"status": "suppressed", "reason": "outage_interval_overlaps_verified_segment"}
            db.execute("INSERT INTO camera_health_receipts VALUES (?,?,?,?)", (camera_id, kind, evidence_id, digest))
            continuous = state["pending_id"] is not None and start <= state["last_failure_end"]
            pending_id = state["pending_id"] if continuous else str(uuid.uuid4())
            bad_since = state["bad_since"] if continuous else observed_at
            count = state["failure_count"] + 1 if continuous else 1
            db.execute("""UPDATE camera_health_state SET pending_id=?,bad_since=?,last_failure_end=?,
                failure_count=?,last_evidence_at=?,delivery_allowed=0,last_gate='measured_outage' WHERE camera_id=?""",
                       (pending_id, bad_since, observed_at, count, observed_at, camera_id))
            duration = observed_at - bad_since
            if count < 2 or duration < self.persistence_seconds:
                return {"status": "pending_evidence", "measured_active_seconds": duration, "distinct_failures": count}
            active = db.execute("SELECT id FROM camera_health_episodes WHERE camera_id=? AND recovered_at IS NULL", (camera_id,)).fetchone()
            if active:
                episode_id, result = active["id"], "active"
            else:
                episode_id, result = pending_id, "episode_created"
                event = {"event_id": "camera-outage:" + episode_id, "kind": "serious_health",
                         "health_key": "camera_outage:" + camera_id, "severity": "serious",
                         "message": OUTAGE_MESSAGE, "active": True, "confirmed": True,
                         "confirmation_method": "health_monitor", "occurred_at": _iso(observed_at)}
                db.execute("""INSERT INTO camera_health_episodes
                    (id,camera_id,started_at,qualified_at,prior_segment_id,prior_segment_sha256,event)
                    VALUES (?,?,?,?,?,?,?)""", (episode_id, camera_id, bad_since, observed_at,
                                                state["verified_segment_id"], state["verified_segment_sha256"], json.dumps(event, sort_keys=True)))
            db.execute("UPDATE camera_health_state SET delivery_allowed=1 WHERE camera_id=?", (camera_id,))
            return {"status": result, "episode_id": episode_id, "measured_active_seconds": duration}

    def handoff(self, outbox, limit=100) -> dict:
        """Local durable enqueue+ack only. No delivery worker/provider is invoked.

        Stops on the first outbox/SQLite failure so retry remains bounded. The
        health lock fences concurrent recovery/pause while enqueue commits. A
        crash after enqueue before acknowledgement safely replays the event ID.
        """
        if type(limit) is not int or not 1 <= limit <= 100:
            raise ValueError("limit must be 1..100")
        result = {"handed_off": 0, "deferred": 0, "error_code": None}
        try:
            with self._db() as db:
                ids = [r[0] for r in db.execute("SELECT id FROM camera_health_episodes WHERE handoff_status='pending' AND recovered_at IS NULL ORDER BY qualified_at,id LIMIT ?", (limit,))]
            for episode_id in ids:
                with self._db() as db:
                    db.execute("BEGIN IMMEDIATE")
                    row = db.execute("""SELECT e.*,s.delivery_allowed FROM camera_health_episodes e
                        JOIN camera_health_state s ON s.camera_id=e.camera_id WHERE e.id=?""", (episode_id,)).fetchone()
                    if row["handoff_status"] != "pending" or row["recovered_at"] is not None or not row["delivery_allowed"]:
                        result["deferred"] += 1
                        continue
                    queued = outbox.enqueue_event(json.loads(row["event"]))
                    if queued.get("status") not in {"queued", "duplicate", "suppressed"} or not isinstance(queued.get("id"), str):
                        raise ValueError("Outbox did not acknowledge a durable enqueue")
                    db.execute("UPDATE camera_health_episodes SET handoff_status=?,outbox_id=?,last_error_code=NULL WHERE id=?", ("suppressed_by_outbox" if queued["status"] == "suppressed" else "handed_off", queued["id"], episode_id))
                result["handed_off"] += 1
        except Exception as exc:
            # No raw provider/connection strings or credential-bearing exception text.
            result["error_code"] = type(exc).__name__
        return result

    def list_episodes(self, limit=100):
        if type(limit) is not int or not 1 <= limit <= 1000:
            raise ValueError("limit must be 1..1000")
        with self._db() as db:
            rows = db.execute("SELECT * FROM camera_health_episodes ORDER BY qualified_at DESC,id LIMIT ?", (limit,)).fetchall()
        return [{**dict(row), "event": json.loads(row["event"])} for row in rows]

    def progress_accepted(self, camera_id, session_id, generation, ordinal, baseline):
        """Only parent rehashed receipts, ordered by durable recorder lifecycle."""
        _identifier(camera_id); _identifier(session_id)
        if type(generation) is not int or generation < 1 or type(ordinal) is not int or ordinal < 1:
            raise ValueError('Invalid recorder lifecycle order')
        encoded = json.dumps(baseline, sort_keys=True)
        with self._db() as db:
            db.execute('BEGIN IMMEDIATE')
            old = db.execute('SELECT * FROM recorder_progress_accepted WHERE camera_id=?',(camera_id,)).fetchone()
            if old:
                if (generation,ordinal) < (old['generation'],old['ordinal']):
                    raise ValueError('Stale accepted recorder receipt')
                if (generation,ordinal) == (old['generation'],old['ordinal']):
                    if old['baseline'] != encoded or old['session_id'] != session_id:
                        raise ValueError('Conflicting accepted recorder receipt')
                    return
            db.execute('INSERT OR REPLACE INTO recorder_progress_accepted VALUES (?,?,?,?,?)',
                       (camera_id,session_id,generation,ordinal,encoded))
            db.execute("""UPDATE recorder_progress_episodes SET recovery_segment_id=?,
                handoff_status=CASE WHEN handoff_status='pending' THEN 'recovered_before_handoff' ELSE handoff_status END
                WHERE camera_id=? AND recovery_segment_id IS NULL
                AND (generation<? OR (generation=? AND baseline_ordinal<?))""",
                (baseline['segment_id'],camera_id,generation,generation,ordinal))

    def progress_handoff(self, outbox, grant, generation):
        """New typed path; legacy handoff cannot drain these rows.

        Caller holds the service pause guard. A fresh grant is required even
        after commit-before-ack. Stored event bytes never change on retries.
        """
        from app.recorder_progress import MESSAGE
        evidence = grant.evidence
        camera_id = _identifier(evidence['identity']['camera_id'])
        session_id = _identifier(evidence['identity']['session_id'])
        with self._db() as db:
            db.execute('BEGIN IMMEDIATE')
            baseline = db.execute('SELECT * FROM recorder_progress_accepted WHERE camera_id=?',(camera_id,)).fetchone()
            if (baseline is None or baseline['generation'] != generation or baseline['session_id'] != session_id
                    or json.loads(baseline['baseline']) != evidence['baseline'] or not evidence['qualified']):
                raise ValueError('Progress baseline not verified')
            row = db.execute('SELECT * FROM recorder_progress_episodes WHERE camera_id=? AND recovery_segment_id IS NULL',
                             (camera_id,)).fetchone()
            if row is None:
                episode_id = str(uuid.uuid4())
                event = dict(event_id='recorder-progress:'+episode_id,kind='serious_health',
                    health_key='recorder_progress_stall:'+camera_id,severity='serious',message=MESSAGE,
                    active=True,confirmed=True,confirmation_method='health_monitor',occurred_at=_iso(self.clock()))
                db.execute('INSERT INTO recorder_progress_episodes (id,camera_id,session_id,generation,baseline_ordinal,evidence,event) VALUES (?,?,?,?,?,?,?)',
                    (episode_id,camera_id,session_id,generation,baseline['ordinal'],json.dumps(evidence,sort_keys=True),json.dumps(event,sort_keys=True)))
                row = db.execute('SELECT * FROM recorder_progress_episodes WHERE id=?',(episode_id,)).fetchone()
            if row['session_id'] != session_id or row['generation'] != generation:
                raise ValueError('Progress incident requires accepted recovery')
            episode_id = row['id']
        # Persist immutable incident/event before any outbox operation. A crash
        # after outbox commit can now retry the same bytes and event identity.
        with self._db() as db:
            db.execute('BEGIN IMMEDIATE')
            row = db.execute('SELECT * FROM recorder_progress_episodes WHERE id=?',(episode_id,)).fetchone()
            if row['recovery_segment_id'] is not None or row['handoff_status'] != 'pending':
                return {'status':'already_handed_off_or_recovered','episode_id':row['id']}
            # Database preparation can consume grant lifetime; check immediately
            # before enqueue initiation, never merely on response arrival.
            grant.consume()
            queued = outbox.enqueue_event(json.loads(row['event']))
            if queued.get('status') not in {'queued','duplicate','suppressed'} or not isinstance(queued.get('id'),str):
                raise ValueError('Outbox did not acknowledge durable enqueue')
            db.execute('UPDATE recorder_progress_episodes SET handoff_status=?,outbox_id=? WHERE id=?',
                       ('suppressed_by_outbox' if queued['status']=='suppressed' else 'handed_off',queued['id'],row['id']))
            return {'status':'handed_off','episode_id':row['id']}

    def suspend(self):
        """Synchronously fence all pending handoffs at a lifecycle boundary.

        The recorder service serializes this with status snapshot acquisition and
        enqueue. Suspension is not recovery and never recalls a committed outbox
        event. A new qualifying measurement window is needed after resume.
        """
        with self._db() as db:
            db.execute("BEGIN IMMEDIATE")
            db.execute("""UPDATE camera_health_state SET pending_id=NULL,bad_since=NULL,
                last_failure_end=NULL,failure_count=0,delivery_allowed=0,
                last_gate='lifecycle_suspended'""")
