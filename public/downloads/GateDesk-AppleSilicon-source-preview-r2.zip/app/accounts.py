"""Opt-in accounts for ONE loopback-only factory deployment.

This is not remote/mobile transport, multi-tenancy, or OS-user isolation.
No default credentials are created. Fresh prototypes remain opt-out; an existing
account store keeps authentication enabled across launches.
"""
import hashlib
import hmac
import ipaddress
import re
import secrets
import sqlite3
import time
import uuid
from pathlib import Path
from contextlib import contextmanager

from fastapi import APIRouter, HTTPException, Request, Response
from fastapi.responses import JSONResponse
from pydantic import BaseModel, ConfigDict, Field

COOKIE = 'gate_desk_session'
SESSION_SECONDS = 8 * 60 * 60
ITERATIONS = 600_000
WINDOW_SECONDS = 15 * 60
router = APIRouter(prefix='/api/account')


class Login(BaseModel):
    model_config = ConfigDict(extra='forbid')
    username: str = Field(min_length=3, max_length=64, pattern=r'^[A-Za-z0-9_.-]+$')
    password: str = Field(min_length=12, max_length=128)


class NewUser(Login):
    display_name: str = Field(min_length=1, max_length=80)


class Bootstrap(NewUser):
    factory_name: str = Field(min_length=1, max_length=100)


class InvitationIssue(BaseModel):
    model_config = ConfigDict(extra='forbid')
    expires_in_seconds: int = Field(default=900, ge=60, le=3600, strict=True)


class InvitationRedemption(NewUser):
    token: str = Field(pattern=r'^[A-Za-z0-9_-]{43}$')


def local_peer(request):
    try:
        return bool(request.client and ipaddress.ip_address(request.client.host).is_loopback)
    except ValueError:
        return False


def enabled(request):
    return request.app.state.accounts_enabled


def owner_pc(request):
    return bool(getattr(request.app.state, 'accounts_owner_only', False))


@contextmanager
def database(request):
    with database_at(request.app.state.accounts_db_path()) as c:
        yield c


@contextmanager
def database_at(path):
    """Shared account schema/connection for trusted local or remote adapters."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    # Authorization runs before request dispatch: never wait seconds on the
    # event loop for another writer. Contention fails closed with a retryable503.
    c = sqlite3.connect(path, timeout=0.2)
    try:
        c.row_factory = sqlite3.Row
        c.execute('PRAGMA foreign_keys=ON')
        c.executescript('''
        CREATE TABLE IF NOT EXISTS factory (singleton INTEGER PRIMARY KEY CHECK(singleton=1), id TEXT NOT NULL, name TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, username TEXT UNIQUE NOT NULL, display_name TEXT NOT NULL,
          role TEXT NOT NULL CHECK(role IN ('owner','worker')), salt TEXT NOT NULL, password_hash TEXT NOT NULL,
          iterations INTEGER NOT NULL, active INTEGER NOT NULL DEFAULT 1);
        CREATE TABLE IF NOT EXISTS account_sessions (token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id), expires_at REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS login_attempts (id INTEGER PRIMARY KEY, username TEXT NOT NULL, at REAL NOT NULL);
        ''')
        from app.worker_invitations import initialize_schema
        initialize_schema(c)
        with c:
            yield c
    finally:
        c.close()


def password_hash(password, salt, iterations=ITERATIONS):
    return hashlib.pbkdf2_hmac('sha256', password.encode(), bytes.fromhex(salt), iterations).hex()


def public_user(row):
    return {key: row[key] for key in ('id', 'username', 'display_name', 'role')}


def token_hash(token):
    return hashlib.sha256(token.encode()).hexdigest()


def current_user(request):
    token = request.cookies.get(COOKIE, '')
    if not re.fullmatch(r'[A-Za-z0-9_-]{43}', token):
        return None
    with database(request) as c:
        row = c.execute('''SELECT u.* FROM account_sessions s JOIN users u ON u.id=s.user_id
            WHERE s.token_hash=? AND s.expires_at>? AND u.active=1''', (token_hash(token), time.time())).fetchone()
    return public_user(row) if row else None


def require_owner(request):
    user = current_user(request)
    if not user:
        raise HTTPException(401, 'Sign in required.')
    if user['role'] != 'owner':
        raise HTTPException(403, 'Owner account required.')
    return user


def account_payload(request, user=None):
    if not enabled(request):
        return {'enabled': False}
    with database(request) as c:
        factory = c.execute('SELECT id,name FROM factory WHERE singleton=1').fetchone()
    if owner_pc(request) and user and user['role'] != 'owner':
        user = None
    return {'enabled': True, 'owner_only': owner_pc(request), 'bootstrap_required': factory is None,
            'authenticated': user is not None, 'user': user,
            'factory': dict(factory) if factory and user else None,
            'csrf_header': 'X-Gate-Desk: local', 'mobile_access_ready': False,
            'camera_setup_enabled': bool(user and user['role'] == 'owner'
                and getattr(request.app.state, 'camera_setup_enabled', False))}


def issue_session(c, uid, response, request):
    token = secrets.token_urlsafe(32)
    c.execute('DELETE FROM account_sessions WHERE expires_at<=?', (time.time(),))
    c.execute('INSERT INTO account_sessions VALUES (?,?,?)', (token_hash(token), uid, time.time()+SESSION_SECONDS))
    response.set_cookie(COOKIE, token, max_age=SESSION_SECONDS, httponly=True,
                        secure=request.url.scheme == 'https', samesite='strict', path='/')


def insert_user(c, body, role):
    if not body.display_name.strip():
        raise HTTPException(422, 'Display name cannot be blank.')
    salt = secrets.token_hex(32)
    uid = str(uuid.uuid4())
    try:
        c.execute('INSERT INTO users VALUES (?,?,?,?,?,?,?,1)',
                  (uid, body.username.lower(), body.display_name.strip(), role, salt,
                   password_hash(body.password, salt), ITERATIONS))
    except sqlite3.IntegrityError:
        raise HTTPException(409, 'Username is unavailable.') from None
    return public_user(c.execute('SELECT * FROM users WHERE id=?', (uid,)).fetchone())


@router.get('')
def status(request: Request):
    return account_payload(request, current_user(request) if enabled(request) else None)


@router.post('/bootstrap')
def bootstrap(body: Bootstrap, request: Request, response: Response):
    # Middleware also applies to direct HTTP calls; do not trust forwarded headers.
    if not local_peer(request) or request.url.hostname not in ('localhost', '127.0.0.1', '::1'):
        raise HTTPException(403, 'First owner setup requires this PC.')
    if not body.factory_name.strip():
        raise HTTPException(422, 'Factory name cannot be blank.')
    with database(request) as c:
        c.execute('BEGIN IMMEDIATE')
        if c.execute('SELECT 1 FROM factory').fetchone() or c.execute('SELECT 1 FROM users').fetchone():
            raise HTTPException(409, 'First owner is already configured.')
        user = insert_user(c, body, 'owner')
        c.execute('INSERT INTO factory VALUES (1,?,?)', (str(uuid.uuid4()), body.factory_name.strip()))
        issue_session(c, user['id'], response, request)
    return account_payload(request, user)


@router.post('/login')
def login(body: Login, request: Request, response: Response):
    # Reserve an attempt atomically before the expensive hash; concurrent requests
    # cannot bypass the bounded budget. Unknown accounts take the same hash path.
    name = body.username.lower()
    with database(request) as c:
        c.execute('BEGIN IMMEDIATE')
        c.execute('DELETE FROM login_attempts WHERE at<=?', (time.time()-WINDOW_SECONDS,))
        count = c.execute('SELECT COUNT(*) FROM login_attempts WHERE username=?', (name,)).fetchone()[0]
        total = c.execute('SELECT COUNT(*) FROM login_attempts').fetchone()[0]
        if count >= 5 or total >= 20:
            raise HTTPException(429, 'Too many sign-in attempts. Try again later.')
        c.execute('INSERT INTO login_attempts(username,at) VALUES (?,?)', (name, time.time()))
        row = c.execute('SELECT * FROM users WHERE username=? AND active=1', (name,)).fetchone()
    salt = row['salt'] if row else '00'*32
    expected = row['password_hash'] if row else '00'*32
    actual = password_hash(body.password, salt, row['iterations'] if row else ITERATIONS)
    if not hmac.compare_digest(actual, expected) or row is None:
        raise HTTPException(401, 'Username or password is incorrect.')
    if owner_pc(request) and row['role'] != 'owner':
        raise HTTPException(403, 'Use the phone app for worker access. This PC is for owners.')
    with database(request) as c:
        c.execute('BEGIN IMMEDIATE')
        # Recheck revocation while serializing session issuance.
        if not c.execute('SELECT 1 FROM users WHERE id=? AND active=1', (row['id'],)).fetchone():
            raise HTTPException(401, 'Username or password is incorrect.')
        issue_session(c, row['id'], response, request)
    return account_payload(request, public_user(row))


@router.post('/logout')
def logout(request: Request, response: Response):
    token = request.cookies.get(COOKIE, '')
    with database(request) as c:
        c.execute('DELETE FROM account_sessions WHERE token_hash=?', (token_hash(token),))
    response.delete_cookie(COOKIE, path='/', httponly=True, samesite='strict', secure=request.url.scheme == 'https')
    return account_payload(request)


@router.get('/workers')
def workers(request: Request):
    require_owner(request)
    with database(request) as c:
        rows = c.execute("SELECT * FROM users WHERE role='worker' ORDER BY username").fetchall()
    return {'users': [{**public_user(r), 'active': bool(r['active'])} for r in rows]}


@router.post('/worker-invitations')
def invite_worker(body: InvitationIssue, request: Request):
    from app.worker_invitations import issue_invitation
    from app.invitation_qr import presentation
    owner = require_owner(request)
    with database(request) as c:
        result = issue_invitation(c, owner['id'], body.expires_in_seconds)
    return presentation(result)


@router.get('/worker-invitations')
def invitations(request: Request):
    from app.worker_invitations import list_invitations
    owner = require_owner(request)
    with database(request) as c:
        return list_invitations(c, owner['id'])


@router.post('/worker-invitations/redeem')
def redeem_worker_invitation(body: InvitationRedemption, request: Request):
    if owner_pc(request):
        raise HTTPException(403, 'Redeem worker invitations in the phone app.')
    from app.worker_invitations import redeem_invitation
    with database(request) as c:
        return redeem_invitation(c, body.token, body.model_dump(exclude={'token'}))


@router.post('/worker-invitations/{invitation_id}/revoke')
def cancel_worker_invitation(invitation_id: str, request: Request):
    from app.worker_invitations import revoke_invitation
    owner = require_owner(request)
    with database(request) as c:
        return revoke_invitation(c, owner['id'], invitation_id)


@router.post('/workers')
def create_worker(body: NewUser, request: Request):
    require_owner(request)
    with database(request) as c:
        c.execute('BEGIN IMMEDIATE')
        user = insert_user(c, body, 'worker')
    return {'user': user}


@router.post('/workers/{uid}/revoke')
def revoke_worker(uid: str, request: Request):
    require_owner(request)
    with database(request) as c:
        c.execute('BEGIN IMMEDIATE')
        if not c.execute("SELECT 1 FROM users WHERE id=? AND role='worker'", (uid,)).fetchone():
            raise HTTPException(404, 'Worker account not found.')
        c.execute('UPDATE users SET active=0 WHERE id=?', (uid,))
        c.execute('DELETE FROM account_sessions WHERE user_id=?', (uid,))
    return {'revoked': True, 'user_id': uid}


def worker_allowed(method, path):
    if method == 'GET' and path in ('/api/account', '/api/documents', '/api/notifications/health-summary'):
        return True
    if method == 'POST' and path in ('/api/account/logout', '/api/documents/import-image'):
        return True
    if method == 'GET' and re.fullmatch(r'/api/documents/[^/]+/(image|original)', path):
        return True
    return method == 'POST' and bool(re.fullmatch(r'/api/documents/[^/]+/review', path))


def install_accounts(app, db_path, opted_in=False, owner_only=False):
    # Once this runtime has account storage, a missing/false launch environment
    # must not silently turn its protected APIs into demonstration APIs. Even a
    # damaged store or leftover SQLite sidecar keeps authentication enabled;
    # recovery is an explicit operation, never an automatic security downgrade.
    account_path = Path(db_path())
    existing_store = False
    for candidate in (account_path, Path(str(account_path)+'-wal'), Path(str(account_path)+'-shm')):
        try:
            candidate.lstat()
        except FileNotFoundError:
            continue
        existing_store = True
    app.state.accounts_enabled = bool(opted_in or existing_store or owner_only)
    app.state.accounts_owner_only = bool(owner_only)
    app.state.accounts_db_path = db_path

    def rejection(detail, code):
        return JSONResponse({'detail': detail}, code,
                            headers={'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff'})

    async def dispatch(request, call_next):
        path = request.url.path
        if not enabled(request):
            if path.startswith('/api/account') and not (path == '/api/account' and request.method == 'GET'):
                return rejection('Accounts are disabled for this local prototype.', 404)
            return await call_next(request)
        if not local_peer(request):
            return rejection('Accounts currently support this PC only.', 403)
        if path.startswith('/api/account') and request.method not in ('GET', 'HEAD', 'OPTIONS'):
            if (request.headers.get('x-gate-desk') != 'local'
                    or request.headers.get('origin') != str(request.base_url).rstrip('/')):
                return rejection('Same-origin account request required.', 403)
        if path == '/api' or path.startswith('/api/'):
            public = (request.method == 'GET' and path == '/api/account') or (
                request.method == 'POST' and path in ('/api/account/bootstrap', '/api/account/login',
                    '/api/account/worker-invitations/redeem'))
            if not public:
                from app.runtime_owner import current_owner
                if current_owner() is None:
                    # Explicit unowned development/TestClient path. Installed
                    # RuntimeOwner deployments never do authorization I/O here.
                    user = current_user(request)
                else:
                    from app.mobile_offload import owned_database_call
                    from app.runtime_resources import ResourceUnavailable
                    try:
                        user = await owned_database_call(lambda: current_user(request))
                    except ResourceUnavailable:
                        return rejection('Application is stopping.', 503)
                if not user:
                    return rejection('Sign in required.', 401)
                if owner_pc(request) and user['role'] != 'owner':
                    return rejection('This PC is for owner access. Use the phone app.', 403)
                if user['role'] != 'owner' and not worker_allowed(request.method, path):
                    return rejection('This action requires an owner account.', 403)
        response = await call_next(request)
        if path.startswith('/api/account'):
            response.headers['Cache-Control'] = 'no-store'
        return response

    @app.middleware('http')
    async def account_boundary(request, call_next):
        try:
            return await dispatch(request, call_next)
        except sqlite3.Error:
            if not enabled(request):
                raise
            return rejection('Local account storage is unavailable. Try again later.', 503)

    app.include_router(router)
