"""Local certificate admission before any phone listener, no network or trust edits.

Use the loaded server context in an in-memory TLS handshake against system trust
and the canonical DNS name. This proves this PC's current certificate check,
not phone trust, revocation freshness, off-site reachability or owner authority.
The console caller must authenticate the owner separately before calling here.
"""
from dataclasses import dataclass, field
import hashlib
from pathlib import Path
import ssl
import threading
import time
from urllib.parse import urlsplit
from weakref import WeakKeyDictionary

from app.mobile_config import parse_mobile_config

_ISSUED = WeakKeyDictionary()
_LOCK = threading.Lock()


@dataclass(frozen=True, eq=False)
class PreparedActivation:
    config: object
    tls_context: object = field(repr=False)
    certificate_sha256: str


def _file(path, maximum):
    value = Path(path)
    if not value.is_absolute() or any(p.is_symlink() or p.is_junction() for p in (value, *value.parents)):
        raise ValueError('phone_certificate_path_invalid')
    if not value.is_file() or not 0 < value.stat().st_size <= maximum:
        raise ValueError('phone_certificate_file_invalid')
    with value.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def _client_context():
    # Avoid create_default_context's SSLKEYLOGFILE environment side effect.
    client = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    client.minimum_version = ssl.TLSVersion.TLSv1_2
    client.hostname_checks_common_name = False
    client.load_default_certs(ssl.Purpose.SERVER_AUTH)
    return client


def _verify_identity(server, hostname):
    """Bounded synchronous MemoryBIO exchange; no DNS/socket/file write."""
    client = _client_context()
    if (client.verify_mode != ssl.CERT_REQUIRED or not client.check_hostname
            or client.hostname_checks_common_name or client.keylog_filename is not None):
        raise ValueError('phone_certificate_verifier_invalid')
    sin, sout, cin, cout = (ssl.MemoryBIO() for _ in range(4))
    left = server.wrap_bio(sin, sout, server_side=True)
    right = client.wrap_bio(cin, cout, server_side=False, server_hostname=hostname)
    done = [False, False]; moved = 0; deadline = time.monotonic() + 2
    for _ in range(64):
        if time.monotonic() >= deadline:
            raise ValueError('phone_certificate_handshake_bound')
        for i, endpoint in enumerate((left, right)):
            if not done[i]:
                try:
                    endpoint.do_handshake(); done[i] = True
                except (ssl.SSLWantReadError, ssl.SSLWantWriteError):
                    pass
        for outgoing, incoming in ((sout, cin), (cout, sin)):
            pending = outgoing.pending
            if moved + pending > 1024 * 1024:
                raise ValueError('phone_certificate_handshake_bound')
            if pending:
                incoming.write(outgoing.read()); moved += pending
        if all(done):
            cert = right.getpeercert()
            expiry = ssl.cert_time_to_seconds(cert['notAfter'])
            return hashlib.sha256(right.getpeercert(binary_form=True)).hexdigest(), expiry
    raise ValueError('phone_certificate_handshake_bound')


def prepare_activation(settings):
    config = parse_mobile_config(settings)
    if config is None:
        raise ValueError('phone_enabled_configuration_required')
    hostname = urlsplit(config.canonical_origin).hostname
    if not hostname or hostname.replace('.', '').isdigit():
        raise ValueError('phone_dns_identity_required')
    try:
        before = (_file(config.certificate_path, 256 * 1024), _file(config.private_key_path, 64 * 1024))
        server = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        server.minimum_version = ssl.TLSVersion.TLSv1_2
        def no_password():
            raise ValueError('phone_encrypted_key_not_supported')
        server.load_cert_chain(config.certificate_path, config.private_key_path, password=no_password)
        fingerprint, expiry = _verify_identity(server, hostname)
        after = (_file(config.certificate_path, 256 * 1024), _file(config.private_key_path, 64 * 1024))
        if before != after:
            raise ValueError('phone_certificate_files_changed')
    except (OSError, ValueError, KeyError):
        # Do not leak local paths, passwords, subject names or key-loader errors.
        raise ValueError('phone_certificate_admission_failed') from None
    prepared = PreparedActivation(config, server, fingerprint)
    with _LOCK:
        _ISSUED[prepared] = (config, server, time.monotonic() + 30, expiry, fingerprint)
    return prepared


def validate_prepared_activation(admission, config, tls_context):
    """Consume exact, short-lived preparation once, before transport I/O.

This is a capability guard against accidental caller mismatch/replay, not a
sandbox against malicious Python code or the local OS account administrator.
"""
    with _LOCK:
        record = _ISSUED.pop(admission, None) if type(admission) is PreparedActivation else None
    if record is None:
        raise ValueError('phone_prepared_activation_required')
    original, context, deadline, expiry, fingerprint = record
    if (config != original or tls_context is not context or admission.config != original
            or admission.tls_context is not context or time.monotonic() >= deadline or time.time() >= expiry
            or context.minimum_version < ssl.TLSVersion.TLSv1_2 or context.keylog_filename is not None):
        raise ValueError('phone_prepared_activation_mismatch')
    # SSLContext is mutable: exact object identity alone does not prove it still
    # contains the certificate that was prepared. Consume then verify again.
    try:
        current, current_expiry = _verify_identity(context, urlsplit(original.canonical_origin).hostname)
        if (current != fingerprint or current_expiry != expiry or time.monotonic() >= deadline):
            raise ValueError('changed_identity')
    except (OSError, ValueError, KeyError):
        raise ValueError('phone_prepared_activation_identity_changed') from None
