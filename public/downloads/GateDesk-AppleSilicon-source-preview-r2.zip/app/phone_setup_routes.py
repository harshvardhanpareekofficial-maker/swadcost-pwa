"""Trusted runtime installation of bounded local-owner phone settings endpoints."""
import json
from pathlib import Path
from weakref import WeakKeyDictionary

from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse
from starlette.requests import Request

from app import accounts
from app.mobile_body import read_auth_body
from app.mobile_offload import owned_database_call
from app.phone_setup import PhoneSetupStore, SetupError, live_generation, strict_object
from app.upload_intake import UploadPool, IntakeError

_OWNED_ENDPOINTS = WeakKeyDictionary()


def owned_endpoint_specs(app):
    return _OWNED_ENDPOINTS.get(app, ())


def install_local_phone_setup(app, runtime, port, *, generation_provider, running_provider=None):
    if not getattr(app.state, 'accounts_enabled', False) or not getattr(app.state, 'accounts_owner_only', False):
        return False
    if app in _OWNED_ENDPOINTS or type(port) is not int or not 1024 <= port <= 65535 or not callable(generation_provider):
        raise ValueError('phone_setup_host_binding_invalid')
    store = PhoneSetupStore(runtime)
    if Path(app.state.accounts_db_path()).resolve().parent != store.runtime:
        raise ValueError('phone_setup_account_runtime_mismatch')
    origin = f'http://127.0.0.1:{port}'
    host = f'127.0.0.1:{port}'
    pool = UploadPool()
    router = APIRouter(prefix='/api/phone-setup')

    def boundary(request):
        origins = request.headers.getlist('origin')
        return (accounts.local_peer(request) and request.scope.get('scheme') == 'http'
                and request.headers.getlist('host') == [host]
                and request.headers.getlist('x-gate-desk') == ['local']
                and (origins == [origin] or (not origins and request.method == 'GET'
                     and request.headers.getlist('sec-fetch-site') == ['same-origin'])))

    def identity(request):
        if not accounts.enabled(request) or not accounts.owner_pc(request):
            raise HTTPException(403)
        owner = accounts.require_owner(request)
        with accounts.database(request) as db:
            factory = db.execute('SELECT id FROM factory WHERE singleton=1').fetchone()
        if factory is None:
            raise HTTPException(403)
        return owner['id'], factory[0]

    def generation():
        try:
            return live_generation(store.runtime, generation_provider())
        except Exception:
            return None

    def public(saved):
        return None if saved is None else {key: saved[key] for key in ('revision', 'settings', 'factory_id', 'updated_at')}

    def status(saved):
        running = {'state': 'unknown', 'verified': False}
        if running_provider is not None:
            try:
                observed = running_provider()
                if type(observed) is dict and observed.get('verified') is True and observed.get('state') in ('not_started', 'running'):
                    running = observed
            except Exception:
                pass
        current = generation()
        return {'saved': public(saved), 'running': running,
                'restart': {'available': saved is not None and current is not None,
                            'reason': 'manual_owner_console_restart_required' if saved is not None and current is not None
                                      else 'save_settings_first' if saved is None else 'restart_generation_unavailable'}}

    def perform(request, action, body):
        owner_id, factory = identity(request)
        def authorize():
            if identity(request) != (owner_id, factory):
                raise HTTPException(403)
        if action == 'save':
            saved = store.save(body['settings'], body['expected_revision'], factory, authorize)
            return status(saved)
        saved = store.read(factory)
        if action == 'read':
            return status(saved)
        if saved is None or type(body['expected_revision']) is not int or body['expected_revision'] != saved['revision']:
            raise SetupError('revision_conflict')
        current = generation()
        if current is None:
            raise SetupError('restart_generation_unavailable')
        authorize()
        from app.phone_restart import prepare_handoff
        handoff = prepare_handoff(store.runtime, saved, current, owner_id, factory, port, authorize)
        return {**status(saved), 'handoff': handoff}

    def reply(value, code=200):
        return JSONResponse(value, code, headers={'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff'})

    async def dispatch(request, action):
        if not boundary(request):
            return reply({'detail': 'local_owner_boundary_required'}, 403)
        if request.scope.get('query_string'):
            return reply({'detail': 'invalid_phone_settings'}, 422)
        try:
            await owned_database_call(lambda: identity(request))
            body = None
            if action != 'read':
                if (request.headers.getlist('content-type') != ['application/json']
                        or len(request.headers.getlist('content-length')) > 1
                        or request.headers.get('content-encoding') or request.headers.get('transfer-encoding')):
                    return reply({'detail': 'invalid_phone_settings'}, 422)
                length = request.headers.get('content-length')
                if length is not None and (not length.isascii() or not length.isdigit() or len(length) > 6 or int(length) > 4096):
                    return reply({'detail': 'invalid_phone_settings'}, 413)
                raw = await read_auth_body(request.receive, pool)
                if len(raw) > 4096 or (length is not None and int(length) != len(raw)):
                    return reply({'detail': 'invalid_phone_settings'}, 413)
                try:
                    body = json.loads(raw, object_pairs_hook=strict_object,
                                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError()))
                    if type(body) is not dict or set(body) != ({'settings', 'expected_revision'} if action == 'save' else {'expected_revision'}):
                        raise ValueError()
                except (ValueError, TypeError, RecursionError):
                    return reply({'detail': 'invalid_phone_settings'}, 422)
            return reply(await owned_database_call(lambda: perform(request, action, body)))
        except HTTPException as exc:
            return reply({'detail': 'owner_required'}, 401 if exc.status_code == 401 else 403)
        except SetupError as exc:
            code = str(exc)
            status_code = 409 if code == 'revision_conflict' else 422 if code == 'invalid_phone_settings' else 503
            return reply({'detail': code if code in ('revision_conflict', 'invalid_phone_settings', 'restart_generation_unavailable') else 'phone_setup_unavailable'}, status_code)
        except IntakeError as exc:
            return reply({'detail': 'invalid_phone_settings'}, exc.status)
        except Exception:
            return reply({'detail': 'phone_setup_unavailable'}, 503)

    @router.get('')
    async def read(request: Request): return await dispatch(request, 'read')

    @router.post('')
    async def save(request: Request): return await dispatch(request, 'save')

    @router.post('/restart-handoff')
    async def handoff(request: Request): return await dispatch(request, 'handoff')

    app.include_router(router)
    _OWNED_ENDPOINTS[app] = ((read, '/api/phone-setup', frozenset({'GET'})),
                             (save, '/api/phone-setup', frozenset({'POST'})),
                             (handoff, '/api/phone-setup/restart-handoff', frozenset({'POST'})))
    app.state.phone_setup_enabled = True
    return True
