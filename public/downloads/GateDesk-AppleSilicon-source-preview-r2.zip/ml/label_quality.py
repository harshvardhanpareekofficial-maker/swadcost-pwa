"""Fail-closed two-pass review gates for image boxes and bounded native-frame events.

This checks review evidence, not visual accuracy. Reviews must be actually performed.
"""
import hashlib
import json
from datetime import datetime


def label_revision(record):
    payload={'image':record['pixel_sha256'],'boxes':record['boxes']}
    return hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(',',':')).encode()).hexdigest()


def require_two_visual_reviews(record):
    revision=label_revision(record)
    previous=None
    for number in (1,2):
        reviews=[r for r in record.get('quality_reviews',[]) if r.get('pass')==number and r.get('label_revision')==revision]
        if len(reviews)!=1:
            raise ValueError(f'Missing or ambiguous visual pass {number} for current labels')
        review=reviews[0]
        if review.get('method')!='visual_original_and_boxes' or review.get('result')!='passed' or not review.get('notes'):
            raise ValueError('Automatic validation or unresolved review is not visual approval')
        when=datetime.fromisoformat(review['completed_at'])
        if when.tzinfo is None or (previous is not None and when<=previous):
            raise ValueError('Visual passes must have distinct ordered timezone-aware timestamps')
        previous=when
    if record.get('unresolved_issues'):
        raise ValueError('Unresolved label issues remain')
    return revision


def require_two_event_visual_reviews(window, revision):
    """Check supplied review evidence for an independently computed event revision.

    Event coverage/geometry/events have their own truth revision and review method;
    they are never represented as image-box reviews. The caller computes revision
    from the frozen truth payload. This gate cannot perform or prove visual review,
    and nonempty notes still require substantive actual human/assistant observation.
    """
    if (not isinstance(revision, str) or len(revision) != 64
            or any(c not in '0123456789abcdef' for c in revision)
            or window.get('frozen_truth_sha256') != revision):
        raise ValueError('Frozen event truth revision missing/changed')
    reviews = window.get('quality_reviews', [])
    if not isinstance(reviews, list):
        raise ValueError('Separate event visual reviews must be a list')
    previous = None
    for number in (1, 2):
        matches = [r for r in reviews if isinstance(r, dict) and type(r.get('pass')) is int
                   and r['pass'] == number and r.get('truth_revision') == revision]
        if len(matches) != 1:
            raise ValueError(f'Separate actual event visual review pass {number} missing/ambiguous')
        review = matches[0]
        if (review.get('method') != 'visual_all_native_frames_and_events'
                or review.get('result') != 'passed' or not isinstance(review.get('notes'), str)
                or not review['notes'].strip()):
            raise ValueError('Event visual review method/result/notes invalid')
        try:
            when = datetime.fromisoformat(review['completed_at'])
            if when.tzinfo is None or when.utcoffset() is None or (previous is not None and when <= previous):
                raise ValueError()
        except (ValueError, KeyError, TypeError) as error:
            raise ValueError('Event visual passes require distinct ordered timezone-aware timestamps') from error
        previous = when
    if window.get('unresolved_issues'):
        raise ValueError('Unresolved event visual issues remain; exclude unknown coverage before scoring')
    return revision
