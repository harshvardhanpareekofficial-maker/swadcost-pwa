"""Compile supplied tracks into a deterministic replay plan, never camera counts.

The entire input is validated before returning any events. Plans can be saved as
an immutable outbox before delivery. No model, tracker, API write or auto-close
is performed here; track identity and coverage must come from the producer.
"""
import hashlib
import json
from datetime import datetime, timedelta
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

from ml.crossing import CrossingCounter


class Observation(BaseModel):
    model_config = ConfigDict(extra='forbid', frozen=True)
    frame: int = Field(ge=0, strict=True)
    kind: Literal['track', 'visibility_lost', 'visibility_restored', 'stream_gap'] = 'track'
    track_id: str | None = Field(default=None, min_length=1, max_length=120)
    x: float | None = Field(default=None, ge=0, le=1, allow_inf_nan=False)


class ReplayInput(BaseModel):
    model_config = ConfigDict(extra='forbid', frozen=True)
    source_sha256: str = Field(pattern=r'^[0-9a-f]{64}$')
    started_at: datetime
    fps: float = Field(gt=0, le=1000, allow_inf_nan=False)
    max_gap_frames: int = Field(ge=1, strict=True)
    line: float = Field(default=0.5, gt=0, lt=1, allow_inf_nan=False)
    margin: float = Field(default=0.04, gt=0, lt=0.5, allow_inf_nan=False)
    observations: tuple[Observation, ...] = Field(min_length=1, max_length=100000)

    @field_validator('started_at')
    @classmethod
    def aware(cls, value):
        from datetime import timezone
        if value.tzinfo is None or value.utcoffset() is None:
            raise ValueError('Source start requires a timezone')
        return value.astimezone(timezone.utc)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)


def compile_replay(raw: dict) -> str:
    """Return canonical JSON, including the input digest and stable event IDs.

    Caller must verify source_sha256 against media bytes. It identifies the
    source, not an independently verified physical operation or labeling truth.
    Revisions of a plan must not be appended to the same session without a
    manifest-binding check: an omitted old event cannot be undone by replay.
    """
    data = ReplayInput.model_validate(raw)
    counter = CrossingCounter(data.line, data.margin, data.max_gap_frames)
    seen = set()
    health_frames = set()
    last_frame = -1
    # Fail closed for malformed order/duplicate identity instead of silently
    # discarding samples and presenting a complete replay.
    for row in data.observations:
        if row.frame < last_frame:
            raise ValueError('Observations must be ordered by source frame')
        last_frame = row.frame
        key = (row.frame, row.kind, row.track_id)
        if key in seen:
            raise ValueError('Duplicate observation identity')
        seen.add(key)
        if row.kind == 'track':
            if row.track_id is None or not row.track_id.strip() or row.x is None:
                raise ValueError('Track observations need a nonblank ID and x')
        elif row.track_id is not None or row.x is not None:
            raise ValueError('Health observations cannot contain track geometry')
        elif row.frame in health_frames:
            raise ValueError('Conflicting health observations in one frame')
        else:
            health_frames.add(row.frame)
    # Health rows precede tracks at the same frame regardless of input tie order.
    rows = sorted(data.observations, key=lambda r: (r.frame, r.kind == 'track', r.kind, r.track_id or ''))
    events = []
    blocked = False

    def emit(row, kind, track_id=None, direction=None):
        identity = [data.source_sha256, row.frame, kind, track_id]
        event = dict(id='track-replay:' + hashlib.sha256(canonical(identity).encode()).hexdigest(),
                     kind=kind, occurred_at=(data.started_at + timedelta(seconds=row.frame/data.fps)).isoformat())
        if kind == 'crossing':
            event.update(track_id=track_id, direction=direction)
        events.append(event)

    for row in rows:
        if row.kind != 'track':
            emit(row, row.kind)
            if row.kind in ('visibility_lost', 'stream_gap'):
                counter.visibility_lost()
            if row.kind == 'visibility_lost':
                blocked = True
            elif row.kind == 'visibility_restored':
                blocked = False
            continue
        if blocked:
            continue
        was_uncertain = counter.uncertain
        crossing = counter.update(row.track_id, row.x, row.frame)
        if counter.uncertain and not was_uncertain:
            emit(row, 'stream_gap')
        if crossing:
            emit(row, 'crossing', crossing.track_id, crossing.direction)
    input_json = canonical(data.model_dump(mode='json'))
    return canonical(dict(schema_version=1, mode='supplied_track_replay', camera_verified=False,
                          source_sha256=data.source_sha256,
                          input_sha256=hashlib.sha256(input_json.encode()).hexdigest(),
                          observation_count=len(data.observations), events=events,
                          uncertain=counter.uncertain))
