"""Replay saved detections through an experimental local tracker/counter.

python -m ml.tracker_pipeline --detections predictions.jsonl --width 1920
    --height 1080 --fps 25 --out new-output-directory

Geometry is explicit and experimental; detector outputs are never ground truth.
No model, video decoder, remote service, or production default is started here.
"""
import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import time

from ml.crossing import CrossingCounter
from ml.object_tracker import ObjectTracker


class TrackerPipeline:
    def __init__(self, width, height, *, line=.5, margin=.04, max_gap_frames=3,
                 min_hits=2, min_score=.5, fps=None, axis='x'):
        if width <= 0 or height <= 0 or not math.isfinite(width) or not math.isfinite(height):
            raise ValueError('Positive finite source dimensions required')
        if axis not in ('x', 'y') or (fps is not None and (not math.isfinite(fps) or fps <= 0)):
            raise ValueError('Invalid axis/fps')
        self.width, self.height, self.axis, self.fps = width, height, axis, fps
        self.tracker = ObjectTracker(min_score=min_score, min_hits=min_hits, max_gap_frames=max_gap_frames)
        self.counter = CrossingCounter(line=line, margin=margin, max_gap_frames=1)
        self.events, self.counted, self.counts = [], set(), Counter()
        self.pending_crossings = {}
        self.latest_seconds = None
        self.latest_frame, self.frames_processed = None, 0
        self.gap_resets, self.missed_track_observations, self.duplicate_crossings_suppressed = 0, 0, 0

    def update(self, frame, detections, *, visibility_ok=True, seconds=None):
        if seconds is not None and (not math.isfinite(seconds) or seconds < 0):
            raise ValueError('Timestamp must be finite and nonnegative')
        if type(frame) is not int or frame < 0 or (self.latest_frame is not None and frame <= self.latest_frame):
            raise ValueError('Frames must be strictly increasing')
        if seconds is not None and self.latest_seconds is not None and seconds <= self.latest_seconds:
            raise ValueError('Supplied timestamps must be strictly increasing')
        timestamp_gap = (seconds is not None and self.latest_seconds is not None and self.fps is not None
                         and seconds-self.latest_seconds > 1.5/self.fps)
        timing_mode_changed = (self.latest_frame is not None
                               and (seconds is None) != (self.latest_seconds is None))
        if (not visibility_ok or timestamp_gap or timing_mode_changed
                or (self.latest_frame is not None and frame != self.latest_frame+1)):
            self.counter.visibility_lost()
            self.pending_crossings.clear()
            self.gap_resets += 1
            if not visibility_ok:
                self.tracker.reset()
        self.latest_frame = frame
        self.latest_seconds = seconds
        self.frames_processed += 1
        tracks = self.tracker.update(frame, detections if visibility_ok else [])
        # Identity may survive a short occlusion; counting history deliberately cannot.
        observed_ids = {track['track_id'] for track in tracks}
        missing = set(self.counter.tracks)-observed_ids
        for identity in missing:
            self.counter.tracks.pop(identity, None)
            self.pending_crossings.pop(identity, None)
        if missing:
            self.counter.uncertain = True
            self.missed_track_observations += len(missing)
        events = []
        for track in tracks:
            box = track['xyxy']
            center = (box[0]+box[2])/(2*self.width) if self.axis == 'x' else (box[1]+box[3])/(2*self.height)
            if not 0 <= center <= 1:
                self.counter.tracks.pop(track['track_id'], None)
                self.pending_crossings.pop(track['track_id'], None)
                self.counter.uncertain = True
                continue
            crossing = self.counter.update(track['track_id'], center, frame)
            if crossing:
                self.pending_crossings.setdefault(track['track_id'], []).append({
                    'event_id': f'{track["track_id"]}:{crossing.direction}',
                    'track_id': track['track_id'], 'class_name': track['label'],
                    'direction': crossing.direction, 'frame': frame, 'sequence': crossing.sequence,
                    'timestamp_seconds': seconds if seconds is not None else (frame/self.fps if self.fps else None)})
            if track['confirmed']:
                for event in self.pending_crossings.pop(track['track_id'], []):
                    self._admit_event(event, events)
        return {'frame': frame, 'timestamp_seconds': seconds if seconds is not None else (frame/self.fps if self.fps else None),
                'tracks': tracks, 'events': events, 'visibility_ok': visibility_ok}

    def _admit_event(self, event, events):
        key = (event['track_id'], event['direction'])
        if key in self.counted:
            self.duplicate_crossings_suppressed += 1
            self.counter.uncertain = True
            return
        self.counted.add(key)
        events.append(event)
        self.events.append(event)
        self.counts[(event['class_name'], event['direction'])] += 1

    def detect_frame(self, frame_index, image, detector_callable, *, seconds=None, visibility_ok=True):
        """Hook for an already-decoded frame; callable(image) returns labeled boxes."""
        detections = detector_callable(image) if visibility_ok else []
        return self.update(frame_index, detections, seconds=seconds, visibility_ok=visibility_ok)

    def summary(self):
        return {'status': 'experimental_predictions_not_ground_truth', 'frames_processed': self.frames_processed,
                'predicted_counts': [{'class_name': label, 'direction': direction, 'count': count}
                                     for (label, direction), count in sorted(self.counts.items())],
                'counting_metrics': None, 'ground_truth_status': 'not_supplied',
                'gap_resets': self.gap_resets, 'missed_track_observations': self.missed_track_observations,
                'duplicate_crossings_suppressed': self.duplicate_crossings_suppressed,
                'uncertain': self.counter.uncertain,
                'limitations': ['IDs may fragment or swap; no appearance re-identification.',
                               'Unobserved intervals never generate crossings.',
                               'Incoming means increasing configured axis; geometry needs camera-specific review.',
                               'Only one crossing per direction per ID is counted; re-entry needs review.',
                               'False detector classes remain false tracker classes; no count-accuracy claim.']}


def replay(detections_path, output_dir, *, provenance=None, **pipeline_options):
    source, out = Path(detections_path), Path(output_dir)
    if out.exists():
        raise ValueError('Output directory exists; choose a fresh replay output')
    pipeline = TrackerPipeline(**pipeline_options)
    out.mkdir(parents=True)
    started = time.perf_counter()
    digest = hashlib.sha256()
    with source.open('rb') as rows, (out/'tracks.jsonl').open('w', encoding='utf-8') as saved:
        for raw in rows:
            digest.update(raw)
            if not raw.strip():
                continue
            row = json.loads(raw)
            detections = row.get('detections')
            if detections is None:
                if 'bags' not in row:
                    raise ValueError('Expected detections or legacy bags field')
                detections = [{**box, 'label': 'bag'} for box in row['bags']]
            result = pipeline.update(row['frame'], detections, visibility_ok=row.get('visibility_ok', True), seconds=row.get('seconds'))
            saved.write(json.dumps(result)+'\n')
    result = {**pipeline.summary(), 'elapsed_seconds': time.perf_counter()-started,
              'source_detections_sha256': digest.hexdigest(), 'configuration': pipeline_options,
              'provenance': provenance or {}, 'provenance_verified': False}
    (out/'events.json').write_text(json.dumps(pipeline.events, indent=2), encoding='utf-8')
    (out/'summary.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--detections', '--source', dest='detections', type=Path, required=True)
    parser.add_argument('--out', '--output', dest='out', type=Path, required=True)
    parser.add_argument('--width', type=int, required=True)
    parser.add_argument('--height', type=int, required=True)
    parser.add_argument('--fps', type=float, required=True)
    parser.add_argument('--line', type=float, default=.5)
    parser.add_argument('--margin', type=float, default=.04)
    parser.add_argument('--axis', choices=['x', 'y'], default='x')
    parser.add_argument('--min-score', type=float, default=.5)
    parser.add_argument('--min-hits', type=int, default=2)
    parser.add_argument('--max-gap-frames', type=int, default=3)
    parser.add_argument('--provenance', type=Path, help='Existing JSON source/checkpoint provenance sidecar; copied, not asserted verified')
    args = vars(parser.parse_args())
    source, out = args.pop('detections'), args.pop('out')
    provenance = args.pop('provenance')
    args['provenance'] = json.loads(provenance.read_text(encoding='utf-8')) if provenance else None
    print(json.dumps(replay(source, out, **args), indent=2))


if __name__ == '__main__':
    main()
