"""Experimental local image degradation checks. Does not identify dust as a cause.
Use a clean, fixed-view baseline with comparable lighting. No external requests.
"""
import numpy as np
from PIL import Image, ImageOps

def features(image):
    gray=np.asarray(ImageOps.exif_transpose(image).convert('L').resize((256,256),Image.Resampling.BILINEAR),dtype=np.float32)
    stats=[]
    for y in range(0,256,64):
        for x in range(0,256,64):
            t=gray[y:y+64,x:x+64]
            lap=4*t[1:-1,1:-1]-t[:-2,1:-1]-t[2:,1:-1]-t[1:-1,:-2]-t[1:-1,2:]
            stats.append({'edge':float(np.var(lap)),'contrast':float(np.std(t)),'mean':float(np.mean(t))})
    return stats

def compare_images(clean,current):
    if abs(clean.width/clean.height-current.width/current.height)>0.03:
        return {'state':'unassessable','needs_review':True,'message':'Use images from the same camera view and aspect ratio.','affected_tiles':[]}
    baseline,observed=features(clean),features(current);valid=[];affected=[]
    for i,(a,b) in enumerate(zip(baseline,observed)):
        if a['edge']<15 or a['contrast']<8:continue
        valid.append(i)
        if b['edge']/(a['edge']+1)<0.30 and b['contrast']/(a['contrast']+1)<0.8:affected.append(i)
    mean=float(np.mean([s['mean'] for s in observed]))
    if mean<12 or mean>245:state='lighting_or_cover';message='View is too dark, too bright or covered. Inspect the camera and lighting.'
    elif len(valid)<4:state='unassessable';message='The clean reference has too little visible texture. Choose a clearer reference.'
    elif len(affected)>=max(2,int(np.ceil(len(valid)*0.20))):state='possible_degradation';message='Possible lens dirt, blur or obstruction. Inspect and clean the camera if needed.'
    else:state='no_change_detected';message='No substantial loss of detail detected against this reference.'
    return {'state':state,'needs_review':state!='no_change_detected','message':message,'affected_tiles':affected,'assessable_tiles':len(valid),'tile_grid':[4,4],'cause':'unconfirmed','method':'Experimental tiled detail and contrast comparison','limitation':'Changes in scene, lighting, focus or weather can resemble dirt. This is not a trained dust detector.'}

class CameraHealthMonitor:
    def __init__(self,baseline,persistence_seconds=10,recovery_seconds=10):
        self.baseline=baseline.copy();self.persistence=persistence_seconds;self.recovery=recovery_seconds;self.bad_since=None;self.good_since=None;self.alert=False;self.session_uncertain=False;self.last_time=None
    def update(self,frame,timestamp):
        if self.last_time is not None and timestamp<=self.last_time:raise ValueError('Frame timestamps must increase')
        self.last_time=timestamp
        if frame is None:result={'state':'missing_footage','needs_review':True,'message':'Camera footage unavailable.','affected_tiles':[]}
        else:result=compare_images(self.baseline,frame)
        was_alert=self.alert
        if result['needs_review']:
            self.session_uncertain=True;self.good_since=None
            if self.bad_since is None:self.bad_since=timestamp
            if timestamp-self.bad_since>=self.persistence:self.alert=True
        else:
            self.bad_since=None
            if self.good_since is None:self.good_since=timestamp
            if timestamp-self.good_since>=self.recovery:self.alert=False
        return {**result,'persistent_alert':self.alert,'new_alert':self.alert and not was_alert,'session_uncertain':self.session_uncertain}
