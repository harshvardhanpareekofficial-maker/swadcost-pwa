"""Plan bounded local CCTV retrieval; never infer loading, coverage or counts.

Request timestamps are timezone-aware ISO strings. ``received_at`` is the PC
receipt and is deliberately NOT an event anchor. ``uploaded_at`` is the original
phone submission action, not a later sync attempt. Prefer explicit operation
bounds, then document capture, then submission time. All are candidate windows.

Clock evidence: camera_id, method=actual_source_clock_visual_review, reviewer,
reviewed_at, reference_at (trusted wall clock), camera_at (visible overlay with
explicit camera timezone), valid_from/valid_until (reference time),
uncertainty_seconds (bound over that interval), frame_file, frame_sha256.
The loader verifies local bytes and metadata; it cannot perform visual review.
The reviewed validity interval must contain reference_at and be <=15 minutes.
That cap is conservative local policy, not a measured guarantee of clock drift.
Phone outbox.createdAt is local-save time: map only to uploaded_at fallback,
never to document_captured_at without separate actual capture-time evidence.
Neither a successful plan nor a matching digest authorizes camera access.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path


def _date(value):
    if not isinstance(value, str):
        raise ValueError("timestamp_must_be_aware_iso_string")
    try:
        result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError("timestamp_must_be_aware_iso_string") from exc
    if result.tzinfo is None or result.utcoffset() is None:
        raise ValueError("timestamp_must_be_aware_iso_string")
    return result


def _number(value, maximum):
    if isinstance(value, bool) or not isinstance(value, (float, int)):
        raise ValueError("invalid_seconds")
    if not math.isfinite(value) or not 0 <= value <= maximum:
        raise ValueError("invalid_seconds")
    return value


def _identifier(value):
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9_.:-]{1,128}", value):
        raise ValueError("invalid_camera_id")
    return value


def _local_file(root, name):
    if not isinstance(name, str) or not name:
        raise ValueError("invalid_evidence_path")
    path = Path(name)
    if path.is_absolute():
        raise ValueError("evidence_path_must_be_relative")
    path = (root / path).resolve(strict=True)
    if not path.is_relative_to(root) or not path.is_file():
        raise ValueError("evidence_path_escape")
    return path


def load_clock_evidence(evidence_root, evidence_file):
    """Read only a local reviewed receipt and its bound source-frame bytes."""
    root = Path(evidence_root).resolve(strict=True)
    path = _local_file(root, evidence_file)
    if path.stat().st_size > 32768:
        raise ValueError("clock_evidence_too_large")
    raw = path.read_bytes()
    proof = json.loads(raw)
    if not isinstance(proof, dict):
        raise ValueError("invalid_clock_evidence")
    frame = _local_file(root, proof.get("frame_file"))
    expected = proof.get("frame_sha256")
    if not isinstance(expected, str) or not re.fullmatch(r"[0-9a-f]{64}", expected):
        raise ValueError("invalid_frame_hash")
    digest = hashlib.sha256()
    with frame.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    if digest.hexdigest() != expected:
        raise ValueError("clock_frame_hash_mismatch")
    _validate_clock(proof)
    return {"proof": proof, "evidence_sha256": hashlib.sha256(raw).hexdigest()}


def _validate_clock(proof):
    _identifier(proof.get("camera_id"))
    if (proof.get("method") != "actual_source_clock_visual_review"
            or not isinstance(proof.get("reviewer"), str) or not proof["reviewer"].strip()):
        raise ValueError("actual_clock_review_required")
    reference, camera = _date(proof.get("reference_at")), _date(proof.get("camera_at"))
    start, end = _date(proof.get("valid_from")), _date(proof.get("valid_until"))
    reviewed = _date(proof.get("reviewed_at"))
    if not start <= reference <= end or not 0 < (end - start).total_seconds() <= 900:
        raise ValueError("invalid_clock_validity_interval")
    if reviewed < reference:
        raise ValueError("clock_review_precedes_observation")
    uncertainty = _number(proof.get("uncertainty_seconds"), 60)
    return reference, camera, start, end, uncertainty


def plan_loading_window(request, *, verified_clock=None):
    """Pure planner. verified_clock must come from load_clock_evidence.

The receipt is a candidate for a future authorized retrieval adapter, never
complete-operation truth or a training/evaluation admission.
"""
    camera_id = _identifier(request.get("camera_id"))
    before = _number(request.get("before_seconds"), 21600)
    after = _number(request.get("after_seconds"), 21600)
    received = _date(request["received_at"]) if request.get("received_at") is not None else None
    # Validate even unused timestamps so malformed device metadata is explicit.
    times = {key: _date(request[key]) for key in
             ("operation_started_at", "operation_ended_at", "document_captured_at", "uploaded_at")
             if request.get(key) is not None}
    if ("operation_started_at" in times) != ("operation_ended_at" in times):
        raise ValueError("both_operation_bounds_required")
    if "operation_started_at" in times:
        start, end = times["operation_started_at"], times["operation_ended_at"]
        anchor = "reported_operation_bounds"
    elif "document_captured_at" in times:
        start = end = times["document_captured_at"]
        anchor = "document_capture_candidate"
    elif "uploaded_at" in times:
        start = end = times["uploaded_at"]
        anchor = "submission_time_candidate"
    else:
        raise ValueError("event_anchor_missing_pc_receipt_is_not_loading_time")
    if end < start:
        raise ValueError("reversed_operation_bounds")
    if received is not None and any(time > received for time in times.values()):
        raise ValueError("device_timestamp_after_pc_receipt_needs_review")
    start, end = start - timedelta(seconds=before), end + timedelta(seconds=after)
    if not 0 < (end - start).total_seconds() <= 21600:
        raise ValueError("candidate_window_must_be_positive_and_at_most_six_hours")
    result = {
        "schema_version": 1, "status": "needs_clock_review", "camera_id": camera_id,
        "anchor_basis": anchor,
        "reference_window": {"start": start.astimezone(timezone.utc).isoformat(),
                             "end": end.astimezone(timezone.utc).isoformat()},
        "recorder_window": None, "clock_evidence_sha256": None,
        "received_at": received.isoformat() if received else None,
        "loading_confirmed": False, "complete_operation": None,
        "footage_coverage": "unknown", "count": None, "fetch_authorized": False,
        "limitations": ["Document capture/submission timing does not establish loading boundaries.",
                        "Receipt delay does not shift the candidate window.",
                        "Missing footage, recording gaps and physical events require separate evidence."]}
    if verified_clock is None:
        return result
    proof = verified_clock["proof"]
    reference, camera, valid_start, valid_end, uncertainty = _validate_clock(proof)
    if proof["camera_id"] != camera_id:
        raise ValueError("clock_camera_mismatch")
    evidence_hash = verified_clock.get("evidence_sha256")
    if not isinstance(evidence_hash, str) or not re.fullmatch(r"[0-9a-f]{64}", evidence_hash):
        raise ValueError("verified_clock_receipt_required")
    result["clock_evidence_sha256"] = evidence_hash
    if start < valid_start or end > valid_end:
        result["status"] = "clock_validity_does_not_cover_candidate"
        return result
    # Camera display offset is computed from two aware clocks; retain the camera
    # offset for the playback query. Expand both ends by the reviewed error bound.
    skew = camera - reference
    mapped_start = (start + skew - timedelta(seconds=uncertainty)).astimezone(camera.tzinfo)
    mapped_end = (end + skew + timedelta(seconds=uncertainty)).astimezone(camera.tzinfo)
    result.update(status="candidate_ready_for_authorized_retrieval",
                  recorder_window={"start": mapped_start.isoformat(), "end": mapped_end.isoformat()},
                  camera_skew_seconds=skew.total_seconds(), clock_uncertainty_seconds=uncertainty)
    return result


def plan_phone_submission_window(request, *, verified_clock=None):
    """Product default: original submission through ten minutes afterward.

    Applies equally to incoming/outgoing. This candidate does not establish
    when loading started or ended; activity outside it needs further review.
    Keep the general planner for separately reviewed operation bounds.
    """
    if request.get("direction") not in ("incoming", "outgoing"):
        raise ValueError("incoming_or_outgoing_direction_required")
    if request.get("uploaded_at") is None:
        raise ValueError("original_phone_submission_time_required")
    candidate = {"camera_id": request.get("camera_id"),
                 "uploaded_at": request["uploaded_at"],
                 "received_at": request.get("received_at"),
                 "before_seconds": 0, "after_seconds": 600}
    result = plan_loading_window(candidate, verified_clock=verified_clock)
    result.update(direction=request["direction"], window_policy="submission_plus_10_minutes",
                  after_submission_seconds=600)
    result["limitations"].append("Ten-minute cutoff is not completion evidence; continuing or earlier loading needs review.")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--request", type=Path, required=True)
    parser.add_argument("--clock-evidence", help="Path relative to evidence root")
    parser.add_argument("--evidence-root", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if bool(args.clock_evidence) != bool(args.evidence_root):
        parser.error("--clock-evidence and --evidence-root are required together")
    clock = load_clock_evidence(args.evidence_root, args.clock_evidence) if args.clock_evidence else None
    raw = args.request.read_bytes()
    result = plan_loading_window(json.loads(raw), verified_clock=clock)
    result["request_sha256"] = hashlib.sha256(raw).hexdigest()
    with args.output.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write("\n")


if __name__ == "__main__":
    main()
