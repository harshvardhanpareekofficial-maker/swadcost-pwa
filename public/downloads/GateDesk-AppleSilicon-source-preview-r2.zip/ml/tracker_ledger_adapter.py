"""Freeze tracker predictions for the existing review-held replay ledger.

CLI creates a local immutable outbox only. No camera, database, HTTP request,
departure assertion, model inference or automatic count approval is performed.
The existing POST /api/replay-sessions/tracker-imports accepts this exact plan.
"""
import argparse
from collections import Counter
from datetime import datetime, timedelta, timezone
import hashlib
import json
import math
from pathlib import Path

from app.movements import EventInput, SessionInput, TrackerImportInput
from ml.track_replay import canonical


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def compile_tracker_import(events, summary, *, source_sha256, operation_id, started_at,
                           bindings, artifact_hashes=None):
    """Validate all events before producing any writable plan.

    bindings maps exact class names to explicit gatepass/unit/direction/expected
    fields. Expected quantities must come from the caller's document; they are
    never inferred from predictions. One source/plan per operation is deliberate:
    overlapping clips cannot silently be summed into complete-operation counts.
    """
    start = datetime.fromisoformat(started_at.replace('Z', '+00:00')) if isinstance(started_at, str) else started_at
    if start.tzinfo is None or start.utcoffset() is None:
        raise ValueError('Source start must include a timezone')
    start = start.astimezone(timezone.utc)
    if not isinstance(operation_id, str) or not operation_id.strip():
        raise ValueError('Explicit operation identity required')
    if not bindings:
        raise ValueError('Explicit class/document bindings required')
    grouped = {label: [] for label in sorted(bindings)}
    seen = set()
    predicted = Counter()
    for event in events:
        label = event['class_name']
        if label not in grouped:
            raise ValueError(f'No document binding for detector class {label}')
        event_id = event['event_id']
        if not isinstance(event_id, str) or not event_id.strip() or event_id in seen:
            raise ValueError('Unique nonblank tracker event IDs required')
        seen.add(event_id)
        frame, seconds = event['frame'], event['timestamp_seconds']
        if type(frame) is not int or frame < 0 or isinstance(seconds, bool) or not isinstance(seconds, (int, float)) or not math.isfinite(seconds) or seconds < 0:
            raise ValueError('Explicit source frame and finite timestamp required')
        track_id = event['track_id']
        if not isinstance(track_id, str) or not track_id.strip():
            raise ValueError('Tracker identity required')
        identity = [source_sha256, label, event_id, frame]
        ledger_event = EventInput(id='tracker:'+hashlib.sha256(canonical(identity).encode()).hexdigest(),
                                  kind='crossing', direction=event['direction'],
                                  track_id='source-track:'+hashlib.sha256(canonical([source_sha256, label, track_id]).encode()).hexdigest(),
                                  occurred_at=start+timedelta(seconds=seconds))
        grouped[label].append(ledger_event.model_dump(mode='json'))
        predicted[(label, event['direction'])] += 1
    declared = Counter()
    for row in summary.get('predicted_counts', []):
        count = row['count']
        if type(count) is not int or count < 0:
            raise ValueError('Summary prediction count must be a nonnegative integer')
        declared[(row['class_name'], row['direction'])] += count
    if declared != predicted:
        raise ValueError('Event list does not match saved tracker prediction summary')
    classes = []
    for label, rows in grouped.items():
        fields = dict(bindings[label])
        if set(fields) != {'gatepass', 'unit', 'direction', 'expected'}:
            raise ValueError('Class bindings require exactly gatepass, unit, direction and expected')
        sid = 'tracker:'+hashlib.sha256(canonical([operation_id, label]).encode()).hexdigest()
        session = SessionInput(id=sid, material=label, **fields)
        classes.append({'class_name': label, 'session': session.model_dump(mode='json'),
                        'events': sorted(rows, key=lambda row: (row['occurred_at'], row['id']))})
    raw = {'operation_id': operation_id, 'source_sha256': source_sha256,
           'plan_sha256': '0'*64, 'started_at': start.isoformat(), 'classes': classes,
           'provenance': {'kind': 'unvalidated_tracker_predictions', 'review_hold': True,
                          'ground_truth': False, 'camera_verified': False,
                          'source_verification': 'caller_must_verify_media_hash',
                          'tracker_configuration': summary.get('configuration', {}),
                          'tracker_provenance': summary.get('provenance', {}),
                          'artifact_hashes': artifact_hashes or {},
                          'tracker_uncertainty': {key: summary.get(key) for key in
                             ('uncertain', 'gap_resets', 'missed_track_observations', 'duplicate_crossings_suppressed')},
                          'coverage': 'complete_operation_not_established',
                          'scope': 'one source plan; no automatic aggregation of overlapping clips'}}
    validated = TrackerImportInput.model_validate(raw)
    raw = validated.model_dump(mode='json')
    raw['plan_sha256'] = hashlib.sha256(canonical({key: value for key, value in raw.items() if key != 'plan_sha256'}).encode()).hexdigest()
    return canonical(raw)


def prepare_outbox(tracker_dir, source_path, output, *, operation_id, started_at, bindings):
    folder, source, output = Path(tracker_dir), Path(source_path), Path(output)
    if output.exists():
        raise ValueError('Preserve existing immutable outbox; choose a new path')
    summary = json.loads((folder/'summary.json').read_text(encoding='utf-8'))
    if summary.get('state', 'complete') != 'complete':
        raise ValueError('Only completed tracker outputs can be frozen')
    status_path = folder/'status.json'
    if status_path.exists():
        status = json.loads(status_path.read_text(encoding='utf-8'))
        if status.get('state') != 'complete' or status.get('summary_sha256') != sha(folder/'summary.json'):
            raise ValueError('Tracker completion status or summary hash does not verify')
    events = json.loads((folder/'events.json').read_text(encoding='utf-8'))
    source_digest = sha(source)
    provenance = summary.get('provenance', {})
    claimed = provenance.get('source', {}).get('source_sha256') or provenance.get('source_sha256')
    if claimed != source_digest:
        raise ValueError('Tracker source provenance must match actual local media bytes')
    event_digest = sha(folder/'events.json')
    bound_events = summary.get('artifacts', {}).get('events.json')
    if bound_events is not None and bound_events != event_digest:
        raise ValueError('Saved tracker events changed since completion')
    plan = compile_tracker_import(events, summary, source_sha256=source_digest,
                                  operation_id=operation_id, started_at=started_at, bindings=bindings,
                                  artifact_hashes={'summary.json': sha(folder/'summary.json'), 'events.json': event_digest})
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('x', encoding='utf-8') as stream:
        stream.write(plan+'\n')
    return json.loads(plan)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--tracker-dir', type=Path, required=True)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--operation-id', required=True)
    parser.add_argument('--started-at', required=True)
    parser.add_argument('--bindings', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    plan = prepare_outbox(args.tracker_dir, args.source, args.out,
                          operation_id=args.operation_id, started_at=args.started_at,
                          bindings=json.loads(args.bindings.read_text(encoding='utf-8')))
    print(json.dumps({'outbox': str(args.out), 'plan_sha256': plan['plan_sha256'],
                      'classes': len(plan['classes']), 'ledger_writes': 0, 'review_hold': True}))


if __name__ == '__main__':
    main()
