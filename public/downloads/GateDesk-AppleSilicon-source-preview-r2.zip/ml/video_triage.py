"""Local, review-first activity proposals for exported CCTV video.

Motion is not proof of loading, an object count, or a clean camera. Originals
are never edited or deleted. No network access or model download is performed.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import random
from pathlib import Path

import av
import numpy as np
from PIL import Image, ImageDraw


def activity_intervals(times, duration, context=15.0, merge_gap=30.0):
    """Merge motion samples with context, retaining pauses within sessions."""
    intervals = []
    for t in sorted(times):
        start, end = max(0.0, t - context), min(duration, t + context)
        if intervals and start <= intervals[-1][1] + merge_gap:
            intervals[-1][1] = max(intervals[-1][1], end)
        else:
            intervals.append([start, end])
    return intervals


def validate_roi(roi):
    if len(roi) != 4 or not all(math.isfinite(x) for x in roi):
        raise ValueError('ROI needs four finite normalized coordinates')
    x1, y1, x2, y2 = roi
    if not (0 <= x1 < x2 <= 1 and 0 <= y1 < y2 <= 1):
        raise ValueError('ROI must satisfy 0 <= x1 < x2 <= 1 and 0 <= y1 < y2 <= 1')
    return roi


def sha256(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def scan(source, output, camera, session_date, *, sample_seconds=1.0,
         pixel_delta=20, motion_fraction=0.01, context=15.0, merge_gap=30.0,
         roi=(0.0, 0.0, 1.0, 1.0), max_thumbnails=120,
         frame_gap_seconds=1.0):
    source, output = Path(source).resolve(), Path(output).resolve()
    validate_roi(roi)
    if not source.is_file():
        raise ValueError('Source must be a local video file')
    if not (math.isfinite(sample_seconds) and sample_seconds > 0):
        raise ValueError('Sample interval must be positive and finite')
    if not (0 < pixel_delta <= 255 and 0 < motion_fraction <= 1):
        raise ValueError('Invalid motion thresholds')
    if not all(math.isfinite(x) and x >= 0 for x in (context, merge_gap)):
        raise ValueError('Context and merge gap must be finite and nonnegative')
    if not isinstance(max_thumbnails, int) or not 0 <= max_thumbnails <= 1000:
        raise ValueError('Thumbnail limit must be between 0 and 1000')
    if not (math.isfinite(frame_gap_seconds) and frame_gap_seconds > 0):
        raise ValueError('Frame gap threshold must be positive and finite')
    # Deliberately fail closed instead of overwriting or mixing source sessions.
    output.mkdir(parents=True, exist_ok=False)
    stat_before = source.stat()
    digest = sha256(source)
    settings = dict(sample_seconds=sample_seconds, pixel_delta=pixel_delta,
                    motion_fraction=motion_fraction, context=context,
                    merge_gap=merge_gap, roi=list(roi), max_thumbnails=max_thumbnails,
                    frame_gap_seconds=frame_gap_seconds,
                    thumbnail_policy='seeded reservoir over all eligible samples', thumbnail_seed=0)
    manifest = dict(schema_version=1, state='processing', source=str(source),
                    source_sha256=digest, source_bytes=stat_before.st_size,
                    camera=camera, session_date=session_date,
                    clock_status='user-supplied date; recorder clock not verified',
                    settings=settings, labels_reviewed=False,
                    material=None, observed_quantity=None,
                    limitations=['Motion proposals require visual review; people, shadows and lighting can trigger them.',
                                 'No-motion results do not prove that all material movements were captured.',
                                 'No dust identification, hidden quantity estimation, or training accuracy is claimed.'])
    manifest_file = output / 'manifest.json'

    def save_manifest():
        manifest_file.write_text(json.dumps(manifest, indent=2), encoding='utf-8')

    save_manifest()
    motion_times, thumbnails = [], []
    thumbnail_rng = random.Random(0)
    eligible_thumbnails = 0
    timestamp_gaps = []
    previous_pts = None
    previous = None
    first_pts = last_pts = None
    next_sample = 0.0
    decoded_frames = samples = backwards = 0
    frame_step = 0.0
    try:
        with av.open(str(source)) as container, (output / 'samples.csv').open('w', newline='', encoding='utf-8') as sf:
            if not container.streams.video:
                raise ValueError('No video stream found')
            stream = container.streams.video[0]
            fps = float(stream.average_rate) if stream.average_rate else None
            frame_step = 1 / fps if fps and fps > 0 else 0.0
            manifest.update(width=stream.width, height=stream.height,
                            codec=stream.codec_context.name, average_fps=fps,
                            reported_duration_seconds=float(stream.duration * stream.time_base) if stream.duration else None)
            writer = csv.writer(sf)
            writer.writerow(['relative_seconds', 'source_pts_seconds', 'motion_fraction', 'brightness', 'review_flag'])
            for frame in container.decode(stream):
                decoded_frames += 1
                if frame.time is None:
                    raise ValueError('Video has no frame timestamp; manual timing review required')
                pts = float(frame.time)
                if not math.isfinite(pts):
                    raise ValueError('Non-finite frame timestamp')
                if first_pts is None:
                    first_pts = pts
                if previous_pts is not None and pts - previous_pts > max(frame_gap_seconds, 5 * frame_step):
                    timestamp_gaps.append([previous_pts-first_pts, pts-first_pts])
                    # Do not treat a comparison across a footage gap as movement evidence.
                    previous = None
                previous_pts = pts
                if last_pts is not None and pts < last_pts:
                    backwards += 1
                last_pts = pts if last_pts is None else max(last_pts, pts)
                t = pts - first_pts
                if t + 1e-6 < next_sample:
                    continue
                next_sample = t + sample_seconds
                gray = frame.reformat(width=320, height=180, format='gray').to_ndarray()
                x1, y1, x2, y2 = roi
                region = gray[int(y1*180):max(int(y1*180)+1, int(y2*180)),
                              int(x1*320):max(int(x1*320)+1, int(x2*320))].astype(np.int16)
                fraction = float(np.mean(np.abs(region-previous) >= pixel_delta)) if previous is not None else 0.0
                brightness = float(region.mean())
                flag = 'dark_or_blocked_candidate' if brightness < 8 else ('overexposed_candidate' if brightness > 247 else '')
                if fraction >= motion_fraction:
                    motion_times.append(t)
                if fraction >= motion_fraction or flag:
                    eligible_thumbnails += 1
                    # A bounded preview must not stop sampling after the first busy minute.
                    slot = (len(thumbnails) if len(thumbnails) < max_thumbnails
                            else thumbnail_rng.randrange(eligible_thumbnails))
                    if slot < max_thumbnails:
                        thumb = frame.reformat(width=320, height=180, format='rgb24').to_ndarray()
                        item = (t, Image.fromarray(thumb))
                        if len(thumbnails) < max_thumbnails:
                            thumbnails.append(item)
                        else:
                            thumbnails[slot] = item
                writer.writerow([round(t, 4), round(pts, 4), round(fraction, 6), round(brightness, 2), flag])
                previous = region
                samples += 1
            if decoded_frames == 0:
                raise ValueError('No decodable video frames')
        stat_after = source.stat()
        if (stat_before.st_size, stat_before.st_mtime_ns) != (stat_after.st_size, stat_after.st_mtime_ns):
            raise ValueError('Source changed during scan; export may still be downloading')
        duration = max(0.0, last_pts-first_pts+frame_step)
        intervals = activity_intervals(motion_times, duration, context, merge_gap)
        with (output / 'timing-review.csv').open('w', newline='', encoding='utf-8') as tf:
            writer = csv.writer(tf)
            writer.writerow(['start_seconds', 'end_seconds', 'status', 'reason'])
            for start, end in timestamp_gaps:
                writer.writerow([round(start, 4), round(end, 4), 'needs_review',
                                 'large timestamp gap; continuity unverified'])
        with (output / 'review.csv').open('w', newline='', encoding='utf-8') as rf:
            writer = csv.writer(rf)
            writer.writerow(['candidate_id', 'start_seconds', 'end_seconds', 'status', 'activity',
                             'material', 'quantity', 'visibility', 'notes'])
            for i, (start, end) in enumerate(intervals, 1):
                writer.writerow([f'candidate-{i:04d}', round(start, 3), round(end, 3),
                                 'needs_review', '', '', '', 'unverified', 'motion proposal only'])
        thumbnails.sort(key=lambda item: item[0])
        for page_start in range(0, len(thumbnails), 12):
            batch = thumbnails[page_start:page_start+12]
            sheet = Image.new('RGB', (960, math.ceil(len(batch)/3)*204), '#eeeeee')
            draw = ImageDraw.Draw(sheet)
            for i, (t, thumb) in enumerate(batch):
                x, y = (i % 3)*320, (i//3)*204
                draw.text((x+6, y+4), f'{t:.1f}s | candidate frame', fill='black')
                sheet.paste(thumb, (x, y+24))
            sheet.save(output / f'contact-{page_start//12+1:03d}.jpg', quality=88)
        manifest.update(state='complete', decoded_frames=decoded_frames, sampled_frames=samples,
                        decoded_duration_seconds=round(duration, 4), source_first_pts_seconds=first_pts,
                        nonmonotonic_timestamp_count=backwards, candidate_intervals=len(intervals),
                        thumbnail_count=len(thumbnails),
                        thumbnail_eligible_samples=eligible_thumbnails,
                        thumbnail_timestamps_seconds=[round(t, 4) for t, _ in thumbnails],
                        preview_is_exhaustive=len(thumbnails) == eligible_thumbnails,
                        timestamp_gap_count=len(timestamp_gaps),
                        timing_needs_review=bool(backwards or timestamp_gaps),
                        continuity_status='needs_review' if backwards or timestamp_gaps else 'not_established',
                        factory_usable_duration_seconds=None)
        save_manifest()
        return manifest
    except Exception as exc:
        manifest.update(state='failed', error_type=type(exc).__name__, error=str(exc),
                        decoded_frames=decoded_frames, sampled_frames=samples)
        save_manifest()
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--camera', required=True)
    parser.add_argument('--session-date', required=True, help='Recorder date, YYYY-MM-DD; verify clock separately')
    parser.add_argument('--sample-seconds', type=float, default=1)
    parser.add_argument('--roi', type=float, nargs=4, default=(0,0,1,1))
    args = parser.parse_args()
    from datetime import date
    date.fromisoformat(args.session_date)
    result = scan(args.source, args.output, args.camera, args.session_date,
                  sample_seconds=args.sample_seconds, roi=args.roi)
    print(json.dumps({k: result[k] for k in ('state', 'decoded_frames', 'sampled_frames', 'candidate_intervals')}))


if __name__ == '__main__':
    main()
