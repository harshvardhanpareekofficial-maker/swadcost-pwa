"""Local photo tester for an experimental bag checkpoint; never counts movements.

Run with --image PATH --out PATH for a saved preview, or without --image for a GUI.
"""
import argparse
import json
from pathlib import Path
import queue
import threading

import torch
from PIL import Image, ImageDraw, ImageOps
from torchvision.transforms.functional import pil_to_tensor

from ml.train_reviewed_bags import ROOT, build, sha


DEFAULT_MODEL = ROOT / 'models/reviewed-bags-20260920-run02'


def load_model(folder, checkpoint_name='last.pt'):
    folder = Path(folder)
    if checkpoint_name not in ('last.pt', 'best.pt'):
        raise ValueError('Select last.pt or best.pt explicitly')
    checkpoint_path = folder / checkpoint_name
    status = json.loads((folder / 'status.json').read_text())
    if status['phase'] != 'completed_experimental' or not status.get('checkpoint_reload_verified'):
        raise ValueError('This experiment has not finished its saved-checkpoint validation')
    if sha(checkpoint_path) != status['checkpoint_sha256']:
        raise ValueError('Checkpoint changed since validation')
    if sha(folder / 'dataset.json') != status['dataset_sha256']:
        raise ValueError('Frozen dataset manifest changed since validation')
    torch.set_num_threads(4)
    checkpoint = torch.load(checkpoint_path, map_location='cpu', weights_only=True)
    if checkpoint['dataset_sha256'] != status['dataset_sha256']:
        raise ValueError('Checkpoint and dataset manifest do not match')
    if 'recipe_sha256' in status:
        if (sha(folder / 'recipe.json') != status['recipe_sha256'] or
                checkpoint.get('recipe_sha256') != status['recipe_sha256']):
            raise ValueError('Checkpoint and frozen recipe do not match')
    if checkpoint_name == 'best.pt' and checkpoint.get('epoch') != status.get('selected_epoch'):
        raise ValueError('Checkpoint does not match selected epoch')
    net = build(False)
    net.load_state_dict(checkpoint['state_dict'])
    return net.eval()


def predict(net, path):
    with Image.open(path) as original:
        image = ImageOps.exif_transpose(original).convert('RGB')
    if image.width * image.height > 30_000_000:
        raise ValueError('Use an image under 30 megapixels for this CPU test')
    with torch.inference_mode():
        output = net([pil_to_tensor(image).float() / 255])[0]
    detections = [{'xyxy': box.tolist(), 'score': float(score)}
                  for box, score, label in zip(output['boxes'], output['scores'], output['labels'])
                  if int(label) == 1]
    return image, detections


def overlay(image, detections, threshold):
    result = image.copy()
    draw = ImageDraw.Draw(result)
    chosen = [d for d in detections if d['score'] >= threshold]
    width = max(2, round(min(image.size) / 250))
    for i, detection in enumerate(chosen, 1):
        box = detection['xyxy']
        draw.rectangle(box, outline='#22e6a8', width=width)
        draw.text((box[0]+3, box[1]+3), f"bag {i}  {detection['score']:.2f}", fill='#ff3565', stroke_width=1)
    return result, len(chosen)


def gui(folder):
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
    from PIL import ImageTk
    app = tk.Tk()
    app.title('Gate Desk | Local bag-model test')
    app.geometry('1100x780')
    app.minsize(720, 520)
    top = ttk.Frame(app, padding=16)
    top.pack(fill='x')
    ttk.Label(top, text='Try the bag detector', font=('Segoe UI', 20, 'bold')).pack(anchor='w')
    ttk.Label(top, text='Offline experimental photo test. Boxes are detections, not incoming/outgoing counts.').pack(anchor='w', pady=(6, 12))
    bar = ttk.Frame(top)
    bar.pack(fill='x')
    status = tk.StringVar(value='Loading and verifying the local checkpoint…')
    threshold = tk.DoubleVar(value=.5)
    messages = queue.Queue()
    state = {'net': None, 'image': None, 'detections': [], 'rendered': None, 'photo': None, 'busy': True}
    canvas = tk.Canvas(app, background='#121b29', highlightthickness=0)
    canvas.pack(fill='both', expand=True, padx=16)
    ttk.Label(app, textvariable=status, padding=16, wraplength=1000).pack(fill='x')

    def draw(*_):
        if state['image'] is None:
            return
        rendered, count = overlay(state['image'], state['detections'], threshold.get())
        state['rendered'] = rendered
        preview = rendered.copy()
        preview.thumbnail((max(1, canvas.winfo_width()-20), max(1, canvas.winfo_height()-20)))
        state['photo'] = ImageTk.PhotoImage(preview)
        canvas.delete('all')
        canvas.create_image(canvas.winfo_width()/2, canvas.winfo_height()/2, image=state['photo'])
        status.set(f'{count} bag detections at threshold {threshold.get():.2f}. Check for missed bags, duplicate boxes and people/wheels labeled as bags. This is not factory counting accuracy.')

    def worker(kind, path=None):
        try:
            result = load_model(folder) if kind == 'load' else predict(state['net'], path)
            messages.put((kind, result, None))
        except Exception as exc:
            messages.put((kind, None, str(exc)))

    def choose():
        path = filedialog.askopenfilename(title='Choose a local photo', filetypes=[('Images', '*.png *.jpg *.jpeg *.bmp *.webp'), ('All files', '*.*')])
        if not path:
            return
        state['busy'] = True
        select.configure(state='disabled')
        save.configure(state='disabled')
        status.set('Running locally on CPU…')
        threading.Thread(target=worker, args=('predict', Path(path)), daemon=True).start()

    def save_image():
        if state['rendered'] is None:
            return
        path = filedialog.asksaveasfilename(title='Save prediction preview locally', defaultextension='.png', filetypes=[('PNG', '*.png')])
        if path:
            state['rendered'].save(path)

    select = ttk.Button(bar, text='Open photo', command=choose, state='disabled')
    select.pack(side='left')
    save = ttk.Button(bar, text='Save preview', command=save_image, state='disabled')
    save.pack(side='left', padx=8)
    ttk.Label(bar, text='Confidence threshold').pack(side='left', padx=(20, 4))
    ttk.Scale(bar, from_=.1, to=.95, variable=threshold, command=draw, length=230).pack(side='left')
    canvas.bind('<Configure>', draw)

    def poll():
        try:
            kind, value, error = messages.get_nowait()
        except queue.Empty:
            app.after(100, poll)
            return
        state['busy'] = False
        if error:
            status.set(error)
            messagebox.showerror('Model test needs attention', error)
        elif kind == 'load':
            state['net'] = value
            status.set('Ready. Open a local photo; nothing is uploaded and your annotations are unchanged.')
        else:
            state['image'], state['detections'] = value
            draw()
            save.configure(state='normal')
        if state['net'] is not None:
            select.configure(state='normal')
        app.after(100, poll)

    threading.Thread(target=worker, args=('load',), daemon=True).start()
    app.after(100, poll)
    app.mainloop()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model-dir', type=Path, default=DEFAULT_MODEL)
    parser.add_argument('--image', type=Path)
    parser.add_argument('--out', type=Path)
    parser.add_argument('--threshold', type=float, default=.5)
    args = parser.parse_args()
    if not 0 <= args.threshold <= 1:
        parser.error('Threshold must be between 0 and 1')
    if args.image:
        if not args.out:
            parser.error('--out is required with --image')
        if args.out.exists():
            parser.error('Output already exists; choose a new path')
        image, detections = predict(load_model(args.model_dir), args.image)
        preview, count = overlay(image, detections, args.threshold)
        args.out.parent.mkdir(parents=True, exist_ok=True)
        preview.save(args.out)
        print(json.dumps({'output': str(args.out.resolve()), 'detections': count, 'threshold': args.threshold,
                          'movement_count': None, 'factory_accuracy': None}))
    else:
        gui(args.model_dir)


if __name__ == '__main__':
    main()
