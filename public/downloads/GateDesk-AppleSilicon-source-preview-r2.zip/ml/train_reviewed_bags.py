"""Offline, bounded bag-head experiment from an immutable two-pass review snapshot.

No draft labels, reserved video, automatic downloads or production approval.
"""
import argparse
import copy
import hashlib
import json
import random
import time
from datetime import datetime, timezone
from pathlib import Path

import torch
from PIL import Image
from torchvision.models.detection import fasterrcnn_mobilenet_v3_large_320_fpn
from torchvision.models.detection.faster_rcnn import FastRCNNPredictor
from torchvision.ops import box_iou
from torchvision.transforms.functional import pil_to_tensor

from ml.label_quality import require_two_visual_reviews

ROOT = Path(__file__).resolve().parents[1]
WEIGHTS = ROOT / 'models/fasterrcnn_mobilenet_v3_large_320_fpn-907ea3f9.pth'
WEIGHTS_SHA = '907ea3f91ff92242bc1baea8049276a3e76bca48ce7560bd268cc029f37977b5'
VALID_GROUPS = {'sackbag-v1-acquired:sackbag6youtube15112024',
                'sackbag-v1-acquired:sackbag12youtube15112024'}
ALLOWED_GROUPS = VALID_GROUPS | {'sackbag-v1-acquired:sackbag5youtube15112024',
    'jute-v3-acquired:jute_bag-1-', 'jute-v3-acquired:jute_bag-2-'}


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save_json(path, value):
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
    temporary.replace(path)


def admit(records, *, approved_groups=None):
    # Additional families require a separately recorded source-admission review.
    # The default remains the original experimental allowlist.
    allowed_groups = ALLOWED_GROUPS if approved_groups is None else set(approved_groups)
    rows, pixels = [], set()
    for record in records:
        r = copy.deepcopy(record)
        revision = require_two_visual_reviews(r)
        if r['review_status'] != 'assistant_visually_corrected' or not 2 <= r['task_id'] <= 17:
            raise ValueError('Only reviewed public image tasks are eligible')
        if r['source_group'] not in allowed_groups or not r['boxes']:
            raise ValueError('Unresolved source group or unreviewed negative')
        path = (ROOT / r['source']).resolve()
        if not path.is_relative_to((ROOT / 'data/public-bags').resolve()):
            raise ValueError('Source outside public image roots')
        with Image.open(path) as original:
            image = original.convert('RGB')
            digest = hashlib.sha256(str(image.size).encode() + image.tobytes()).hexdigest()
            if digest != r['pixel_sha256'] or digest in pixels:
                raise ValueError('Changed image or duplicate pixels')
            w, h = image.size
        for box in r['boxes']:
            x1, y1, x2, y2 = box['xyxy']
            if box['label'] != 'bag' or not 0 <= x1 < x2 <= w or not 0 <= y1 < y2 <= h:
                raise ValueError('Invalid bag rectangle')
        pixels.add(digest)
        # Both augmented jute source families stay together, conservatively.
        r['split_group'] = ('jute-v3-all' if r['source_group'].startswith('jute-v3')
                            else r['source_group'])
        r['split'] = 'validation' if r['source_group'] in VALID_GROUPS else 'train'
        r['frozen_label_revision'] = revision
        r['source_file_sha256'] = sha(path)
        rows.append(r)
    train = {r['split_group'] for r in rows if r['split'] == 'train'}
    valid = {r['split_group'] for r in rows if r['split'] == 'validation'}
    if not train or not valid or train & valid:
        raise ValueError('Missing or overlapping source groups')
    return rows


def build(pretrained):
    net = fasterrcnn_mobilenet_v3_large_320_fpn(weights=None, weights_backbone=None)
    if pretrained:
        if sha(WEIGHTS) != WEIGHTS_SHA:
            raise ValueError('Local foundation weights changed')
        net.load_state_dict(torch.load(WEIGHTS, map_location='cpu', weights_only=True))
    net.roi_heads.box_predictor = FastRCNNPredictor(net.roi_heads.box_predictor.cls_score.in_features, 2)
    return net


def examples(rows, split):
    output = []
    for r in rows:
        if r['split'] != split:
            continue
        with Image.open(ROOT / r['source']) as image:
            tensor = pil_to_tensor(image.convert('RGB')).float() / 255
        target = {'boxes': torch.tensor([b['xyxy'] for b in r['boxes']], dtype=torch.float32).reshape(-1, 4),
                  'labels': torch.ones(len(r['boxes']), dtype=torch.int64)}
        output.append((tensor, target, r))
    return output


def evaluate(net, samples):
    net.eval()
    tp = fp = fn = 0
    predictions = []
    with torch.inference_mode():
        for image, target, record in samples:
            pred = net([image])[0]
            keep = (pred['scores'] >= .5) & (pred['labels'] == 1)
            boxes, scores = pred['boxes'][keep], pred['scores'][keep]
            matched = set()
            for box in boxes:  # torchvision returns descending confidence
                overlaps = box_iou(box[None], target['boxes'])[0]
                choices = [j for j in range(len(overlaps)) if j not in matched and overlaps[j] >= .5]
                if choices:
                    matched.add(max(choices, key=lambda j: float(overlaps[j])))
                    tp += 1
                else:
                    fp += 1
            fn += len(target['boxes']) - len(matched)
            predictions.append({'task_id': record['task_id'], 'frame': record['frame'],
                                'boxes': boxes.tolist(), 'scores': scores.tolist()})
    return {'images': len(samples), 'score_threshold': .5, 'iou_threshold': .5,
            'true_positives': tp, 'false_positives': fp, 'false_negatives': fn,
            'precision': tp / (tp + fp) if tp + fp else 0,
            'recall': tp / (tp + fn) if tp + fn else 0,
            'scope': 'Tiny public source-group validation; not mAP, factory or counting accuracy',
            'predictions': predictions}


def run(out, epochs, reviewed_labels=None):
    if epochs < 1 or epochs > 30:
        raise ValueError('Bounded experiment requires 1-30 epochs')
    out.mkdir(parents=True, exist_ok=False)  # Never overwrite or duplicate an existing run.
    started = time.monotonic()
    status = {'phase': 'preparing', 'started_at': now(), 'epochs_planned': epochs,
              'device': 'cpu', 'history': [], 'factory_validated': False, 'counting_validated': False,
              'production_approved': False, 'classes': ['bag']}
    save_json(out / 'status.json', status)
    try:
        canonical_path = ROOT / 'data/assisted-labeling-20260917/reviewed-labels.json'
        canonical = json.loads(canonical_path.read_text())['records']
        records = json.loads(reviewed_labels.read_text())['records'] if reviewed_labels else canonical
        current = {(r['task_id'], r['frame']): r for r in canonical}
        for record in records:
            if record != current.get((record['task_id'], record['frame'])):
                raise ValueError('Snapshot differs from current reviewed record; reconcile before training')
        rows = admit(records)
        manifest = {'created_at': now(), 'purpose': 'Local experimental fine-tuning only',
                    'records': rows, 'production_approved': False,
                    'provenance': 'Publisher archive READMEs state CC BY 4.0 for both datasets; underlying video rights and production use remain unverified.',
                    'split_policy': 'All jute augmentation families together; hold entire trolley and warehouse source families out. No final test set.',
                    'excluded': 'All unreviewed images, released photos with unresolved grouping, all factory footage and user task35.',
                    'review_snapshot_sha256': sha(reviewed_labels or canonical_path),
                    'canonical_reviewed_images': len(canonical),
                    'reviewed_images_outside_snapshot': len(canonical) - len(records)}
        save_json(out / 'dataset.json', manifest)
        torch.set_num_threads(4)
        torch.manual_seed(20260920)
        random.seed(20260920)
        train, valid = examples(rows, 'train'), examples(rows, 'validation')
        net = build(True)
        for p in net.parameters():
            p.requires_grad = False
        for module in [net.roi_heads.box_head, net.roi_heads.box_predictor]:
            for p in module.parameters():
                p.requires_grad = True
        optimizer = torch.optim.AdamW([p for p in net.parameters() if p.requires_grad], lr=.0005, weight_decay=.0001)
        status.update(train_images=len(train), validation_images=len(valid),
                      train_boxes=sum(len(t['boxes']) for _, t, _ in train),
                      validation_boxes=sum(len(t['boxes']) for _, t, _ in valid),
                      dataset_sha256=sha(out / 'dataset.json'), foundation_sha256=WEIGHTS_SHA,
                      recipe='Frozen COCO MobileNetV3 Faster R-CNN backbone/RPN; train ROI head and new bag predictor',
                      phase='initial_validation')
        save_json(out / 'status.json', status)
        save_json(out / 'initial-validation.json', evaluate(net, valid))
        print(f'Training {len(train)} reviewed images; validation {len(valid)} source-held-out images', flush=True)
        for epoch in range(1, epochs + 1):
            net.train()
            net.backbone.eval()
            order = list(range(len(train)))
            random.shuffle(order)
            total = 0
            for step, index in enumerate(order, 1):
                image, target, _ = train[index]
                losses = net([image], [target])
                loss = sum(losses.values())
                if not torch.isfinite(loss):
                    raise RuntimeError('Nonfinite training loss')
                optimizer.zero_grad()
                loss.backward()
                torch.nn.utils.clip_grad_norm_([p for p in net.parameters() if p.requires_grad], 5)
                optimizer.step()
                total += float(loss.detach())
                status.update(phase='training', epoch=epoch, step=step, updated_at=now(),
                              elapsed_seconds=round(time.monotonic()-started, 2))
                save_json(out / 'status.json', status)
            status['history'].append({'epoch': epoch, 'mean_train_loss': total / len(train)})
            temporary = out / 'last.tmp'
            torch.save({'state_dict': net.state_dict(), 'optimizer': optimizer.state_dict(),
                        'epoch': epoch, 'classes': ['background', 'bag'],
                        'dataset_sha256': status['dataset_sha256'], 'production_approved': False}, temporary)
            temporary.replace(out / 'last.pt')
            print(f'Epoch {epoch}/{epochs}: loss {total/len(train):.4f}', flush=True)
        status['phase'] = 'validating_checkpoint'
        save_json(out / 'status.json', status)
        reloaded = build(False)
        reloaded.load_state_dict(torch.load(out / 'last.pt', map_location='cpu', weights_only=True)['state_dict'])
        result = evaluate(reloaded, valid)
        save_json(out / 'validation.json', result)
        status.update(phase='completed_experimental', checkpoint_reload_verified=True,
                      checkpoint_sha256=sha(out / 'last.pt'), completed_at=now(),
                      elapsed_seconds=round(time.monotonic()-started, 2),
                      validation={k: v for k, v in result.items() if k != 'predictions'})
        save_json(out / 'status.json', status)
        print(json.dumps(status['validation']), flush=True)
    except Exception as exc:
        status.update(phase='failed', error=str(exc), updated_at=now())
        save_json(out / 'status.json', status)
        raise


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--epochs', type=int, default=15)
    parser.add_argument('--reviewed-labels', type=Path,
                        help='Explicit subset of current reviewed records; every record must match exactly')
    args = parser.parse_args()
    run(args.out.resolve(), args.epochs, args.reviewed_labels.resolve() if args.reviewed_labels else None)
