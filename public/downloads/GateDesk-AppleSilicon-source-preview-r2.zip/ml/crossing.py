"""Conservative crossing rules for already-associated tracks.

The tracker supplies IDs. This module does not infer IDs from images.
A track must be observed on both sides, outside the hysteresis strip.
"""
from dataclasses import dataclass
import math

@dataclass
class Crossing:
    track_id: str
    direction: str
    sequence: int

class CrossingCounter:
    def __init__(self,line=0.5,margin=0.04,max_gap_frames=None):
        if not 0 < margin < min(line,1-line):raise ValueError('Invalid line geometry')
        if max_gap_frames is not None and (type(max_gap_frames) is not int or max_gap_frames<1):
            raise ValueError('max_gap_frames must be a positive integer')
        self.line=line;self.margin=margin;self.tracks={};self.sequence=0;self.uncertain=False
        self.max_gap_frames=max_gap_frames;self.latest_frame=None;self.resume_after_frame=None
    def visibility_lost(self):
        self.uncertain=True
        # Do not infer crossings across an unobserved interval.
        self.tracks.clear()
        self.resume_after_frame=self.latest_frame
    def update(self,track_id,x,frame):
        if not isinstance(track_id,str) or not track_id.strip():raise ValueError('Track ID is required')
        if type(frame) is not int or frame<0:raise ValueError('Frame must be a nonnegative integer')
        if not math.isfinite(x) or not 0<=x<=1:raise ValueError('Expected normalized x coordinate')
        if self.resume_after_frame is not None and frame<=self.resume_after_frame:return None
        # A stale frame must not resurrect a track cleared after missing footage.
        # Multiple tracks in the same source frame remain valid.
        if self.latest_frame is not None and frame<self.latest_frame:return None
        self.latest_frame=frame
        if self.max_gap_frames is not None:
            expired=[key for key,state in self.tracks.items() if frame-state['frame']>self.max_gap_frames]
            if expired:self.uncertain=True
            for key in expired:del self.tracks[key]
        side='outside' if x<self.line-self.margin else 'inside' if x>self.line+self.margin else None
        old=self.tracks.get(track_id)
        if old and frame<=old['frame']:return None
        if side is None:
            if old:old['frame']=frame
            return None
        self.tracks[track_id]={'side':side,'frame':frame}
        if not old or old['side']==side:return None
        self.sequence+=1
        return Crossing(track_id,'Incoming' if side=='inside' else 'Outgoing',self.sequence)
