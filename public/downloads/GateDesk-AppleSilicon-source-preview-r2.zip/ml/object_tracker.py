"""Dependency-free experimental tracking of local detector boxes.

Global one-to-one assignment uses motion-predicted boxes and a class gate. This
is an association baseline, not a validated identity or material classifier.
Only observed boxes are returned; predictions never become count observations.
"""
from dataclasses import dataclass
import math


def iou(a, b):
    area = max(0., min(a[2], b[2]) - max(a[0], b[0])) * max(0., min(a[3], b[3]) - max(a[1], b[1]))
    union = (a[2]-a[0])*(a[3]-a[1]) + (b[2]-b[0])*(b[3]-b[1]) - area
    return area / union if union else 0.


def minimum_assignment(costs):
    """Rectangular Hungarian minimization; returns (row, column) pairs.

    Callers provide at least as many columns as rows, including unmatched dummies.
    Deterministic ties use column order. Runs in O(rows**2 * columns).
    """
    if not costs:
        return []
    n, m = len(costs), len(costs[0])
    if m < n or any(len(row) != m for row in costs):
        raise ValueError('Assignment matrix requires columns >= rows')
    u, v, p, way = [0.]*(n+1), [0.]*(m+1), [0]*(m+1), [0]*(m+1)
    for row in range(1, n+1):
        p[0], j0 = row, 0
        minimum, used = [float('inf')]*(m+1), [False]*(m+1)
        while True:
            used[j0] = True
            i0, delta, j1 = p[j0], float('inf'), 0
            for j in range(1, m+1):
                if not used[j]:
                    current = costs[i0-1][j-1] - u[i0] - v[j]
                    if current < minimum[j]:
                        minimum[j], way[j] = current, j0
                    if minimum[j] < delta:
                        delta, j1 = minimum[j], j
            for j in range(m+1):
                if used[j]:
                    u[p[j]] += delta
                    v[j] -= delta
                else:
                    minimum[j] -= delta
            j0 = j1
            if p[j0] == 0:
                break
        while True:
            previous = way[j0]
            p[j0] = p[previous]
            j0 = previous
            if j0 == 0:
                break
    return [(p[j]-1, j-1) for j in range(1, m+1) if p[j]]


@dataclass
class Track:
    track_id: str
    label: str
    xyxy: list
    score: float
    frame: int
    hits: int = 1
    consecutive_hits: int = 1
    confirmed: bool = False
    velocity: tuple = (0., 0., 0., 0.)

    def predicted_box(self, frame):
        return [v + speed*(frame-self.frame) for v, speed in zip(self.xyxy, self.velocity)]


class ObjectTracker:
    def __init__(self, *, min_score=.5, min_hits=2, max_gap_frames=3,
                 min_iou=.05, max_center_distance=1.5, nms_iou=.85):
        if not 0 <= min_score <= 1 or not 0 <= min_iou <= 1 or not 0 < nms_iou <= 1:
            raise ValueError('Invalid score/IoU thresholds')
        if type(min_hits) is not int or min_hits < 1 or type(max_gap_frames) is not int or max_gap_frames < 1:
            raise ValueError('min_hits and max_gap_frames must be positive integers')
        if not math.isfinite(max_center_distance) or max_center_distance <= 0:
            raise ValueError('max_center_distance must be positive')
        self.min_score, self.min_hits, self.max_gap_frames = min_score, min_hits, max_gap_frames
        self.min_iou, self.max_center_distance, self.nms_iou = min_iou, max_center_distance, nms_iou
        self.tracks, self.next_id, self.latest_frame = {}, 1, None
        self.last_unobserved = set()

    def reset(self):
        """Forget identities after explicit visibility loss; never recycle IDs."""
        self.tracks.clear()

    def _detections(self, detections):
        valid = []
        for detection in detections:
            box = list(detection['xyxy'])
            score, label = float(detection['score']), detection['label']
            if (len(box) != 4 or any(not math.isfinite(v) for v in box)
                    or box[2] <= box[0] or box[3] <= box[1]):
                raise ValueError('Detection must have a finite positive-area xyxy box')
            if not math.isfinite(score) or not 0 <= score <= 1:
                raise ValueError('Detection score must be finite and in [0, 1]')
            if not isinstance(label, str) or not label.strip():
                raise ValueError('Detection label must be a nonempty class name')
            if score >= self.min_score:
                valid.append({'xyxy': box, 'score': score, 'label': label})
        kept = []
        for detection in sorted(valid, key=lambda item: -item['score']):
            if not any(other['label'] == detection['label'] and
                       iou(other['xyxy'], detection['xyxy']) >= self.nms_iou for other in kept):
                kept.append(detection)
        return kept

    def _cost(self, track, detection, frame):
        if track.label != detection['label']:
            return 1e6
        a, b = track.predicted_box(frame), detection['xyxy']
        overlap = iou(a, b)
        scale = max(math.hypot(a[2]-a[0], a[3]-a[1]), math.hypot(b[2]-b[0], b[3]-b[1]), 1.)
        distance = math.hypot((a[0]+a[2]-b[0]-b[2])/2, (a[1]+a[3]-b[1]-b[3])/2) / scale
        if overlap < self.min_iou and distance > self.max_center_distance:
            return 1e6
        return .6*(1-overlap) + .4*min(distance/self.max_center_distance, 1.)

    def update(self, frame, detections):
        if type(frame) is not int or frame < 0 or (self.latest_frame is not None and frame <= self.latest_frame):
            raise ValueError('Frames must be nonnegative strictly increasing integers')
        selected = self._detections(detections)
        self.latest_frame = frame
        self.tracks = {key: track for key, track in self.tracks.items()
                       if frame-track.frame <= self.max_gap_frames}
        active = list(self.tracks.values())
        costs = [[self._cost(track, detection, frame) for detection in selected] + [1.01]*len(active)
                 for track in active]
        assigned, observed = set(), []
        for row, column in minimum_assignment(costs):
            if column >= len(selected) or costs[row][column] >= 1.01:
                continue
            track, detection = active[row], selected[column]
            gap = frame-track.frame
            track.velocity = tuple((new-old)/gap for new, old in zip(detection['xyxy'], track.xyxy))
            track.consecutive_hits = track.consecutive_hits+1 if gap == 1 else 1
            track.hits += 1
            track.xyxy, track.score, track.frame = detection['xyxy'], detection['score'], frame
            track.confirmed = track.confirmed or track.consecutive_hits >= self.min_hits
            assigned.add(column)
            observed.append(track)
        for index, detection in enumerate(selected):
            if index not in assigned:
                track = Track(str(self.next_id), detection['label'], detection['xyxy'], detection['score'], frame,
                              confirmed=self.min_hits == 1)
                self.next_id += 1
                self.tracks[track.track_id] = track
                observed.append(track)
        observed_ids = {track.track_id for track in observed}
        self.last_unobserved = set(self.tracks)-observed_ids
        return [{'track_id': track.track_id, 'label': track.label, 'xyxy': list(track.xyxy),
                 'score': track.score, 'confirmed': track.confirmed, 'hits': track.hits}
                for track in sorted(observed, key=lambda item: int(item.track_id))]
