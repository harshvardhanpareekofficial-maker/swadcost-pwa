"""Explicit online Apple-silicon setup preview; no bundled binaries or models."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import shlex
import subprocess
import sys
import time
import venv

def run_retained(command, *, seconds):
    environment={k:v for k,v in os.environ.items() if not k.upper().startswith(('PIP_', 'PYTHON')) and not k.upper().endswith('_PROXY')}
    environment['PIP_CONFIG_FILE']=os.devnull
    environment['PIP_DISABLE_PIP_VERSION_CHECK']='1'
    process=None
    failure=None
    deadline=time.monotonic()+seconds
    try:
        process=subprocess.Popen(command,env=environment)
        code=process.wait(timeout=max(.001,deadline-time.monotonic()))
        if code or time.monotonic()>deadline:raise RuntimeError('setup_child_failed_or_late')
    except BaseException as error:
        failure=error
    finally:
        if process is not None:
            while True:
                try:
                    process.wait()
                    break
                except BaseException as error:
                    failure=failure or error
    if failure is not None:raise RuntimeError('setup_incomplete; exact child retained until exit') from failure

def verify(root):
    for row in json.loads((root/'source-manifest.json').read_text())['files']:
        path=root/row['path']
        if path.is_symlink() or not path.resolve().is_relative_to(root) or hashlib.sha256(path.read_bytes()).hexdigest()!=row['sha256']:
            raise ValueError('Source integrity mismatch')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--install',action='store_true',required=True)
    parser.parse_args()
    if platform.system()!='Darwin' or platform.machine()!='arm64' or sys.version_info[:3]!=(3,12,14):
        raise SystemExit('Use native arm64 Python 3.12.14 on the Apple-silicon Mac, not Rosetta.')
    root=Path(__file__).resolve().parents[2];verify(root)
    environment=root/'mac-python'
    if environment.exists():raise SystemExit('Existing environment preserved. Use a fresh extracted source bundle.')
    run_retained([sys.executable,'-m','venv',str(environment)],seconds=120)
    python=environment/'bin/python'
    run_retained([str(python),'-m','pip','install','--no-input','--index-url','https://pypi.org/simple','--only-binary=:all:','--require-hashes','--no-deps','-r',str(root/'native/macos/requirements-hashed.txt')],seconds=900)
    runtime=Path.home()/'Library/Application Support/Gate Desk'
    runtime.mkdir(mode=0o700,parents=True,exist_ok=True)
    if runtime.is_symlink() or runtime.stat().st_mode&0o077:
        raise SystemExit('Runtime must be private to this user (0700); existing permissions not changed automatically.')
    command=root/'Start Gate Desk.command'
    command.write_text('#!/bin/sh\nset -eu\ncd '+shlex.quote(str(root))+'\nexec '+shlex.quote(str(python))+' -I -B '+shlex.quote(str(root/'native/macos/launch.py'))+' "$@"\n')
    command.chmod(0o700)
    print('Setup complete. Native execution is not yet acceptance. Run Start Gate Desk.command; model remains unavailable.')

if __name__=='__main__':main()
