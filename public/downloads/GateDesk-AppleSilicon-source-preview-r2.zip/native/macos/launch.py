"""Owner-only Mac PC preview; explicit no capture/send/phone TLS authority."""
import argparse
import os
from pathlib import Path
import platform
import sys

def main():
    parser=argparse.ArgumentParser(description=__doc__,allow_abbrev=False)
    parser.add_argument('--port',type=int,default=8765)
    parser.add_argument('--request-stop',action='store_true')
    args=parser.parse_args()
    if platform.system()!='Darwin' or platform.machine()!='arm64':raise SystemExit('Native Apple-silicon Mac required')
    root=Path(__file__).resolve().parents[2]
    sys.path.insert(0,str(root))
    from native.macos.setup import verify
    verify(root)
    os.environ.update(GATE_DESK_ACCOUNTS='1',GATE_DESK_OWNER_PC='1',GATE_CAMERA_CAPTURE_ENABLED='0',GATE_DESK_NOTIFY_SEND='0',GATE_DESK_NOTIFY_EMAIL_ENABLED='false')
    runtime=Path.home()/'Library/Application Support/Gate Desk'
    if runtime.is_symlink() or not runtime.is_dir() or runtime.stat().st_mode&0o077:raise SystemExit('Private installed runtime required')
    sys.argv=['launch_offline_source','--runtime-dir',str(runtime),'--port',str(args.port)]+(['--request-stop'] if args.request_stop else [])
    from scripts.launch_offline_source import main as launch
    return launch()

if __name__=='__main__':raise SystemExit(main())
