"""Darwin control backend. Descriptor-relative files and retained kqueue identity.

No signals or PID-only process termination. Native Mac execution is still required.
"""
import ctypes
from contextlib import contextmanager, ExitStack
import hashlib
import json
import os
from pathlib import Path
import re
import select
import stat
import sys
import uuid
from scripts.runtime_control import ControlError, GENERATION, NAMES, MAX_BYTES

class BsdInfo(ctypes.Structure):
    _fields_=[(n,ctypes.c_uint32) for n in ('flags','status','xstatus','pid','ppid','uid','gid','ruid','rgid','svuid','svgid','rfu')]+[('comm',ctypes.c_char*16),('name',ctypes.c_char*32)]+[(n,ctypes.c_uint32) for n in ('nfiles','pgid','pjobc','tdev','tpgid')]+[('nice',ctypes.c_int32),('start_sec',ctypes.c_uint64),('start_usec',ctypes.c_uint64)]

def birth(pid):
    if sys.platform!='darwin':raise ControlError('darwin_required')
    lib=ctypes.CDLL('/usr/lib/libproc.dylib',use_errno=True)
    lib.proc_pidinfo.argtypes=[ctypes.c_int,ctypes.c_int,ctypes.c_uint64,ctypes.c_void_p,ctypes.c_int]
    lib.proc_pidinfo.restype=ctypes.c_int
    info=BsdInfo()
    if lib.proc_pidinfo(pid,3,0,ctypes.byref(info),ctypes.sizeof(info))!=ctypes.sizeof(info) or info.pid!=pid or info.uid!=os.getuid():raise ControlError('owner_process_unverified')
    return info.start_sec*1000000+info.start_usec

class ProcessWitness:
    def __init__(self,pid,expected=None):
        if type(pid)is not int or pid<=0:raise ControlError('invalid_owner_pid')
        self.queue=None;self.ended=False;self.pid=pid
        before=birth(pid)
        if expected is not None and before!=expected:raise ControlError('owner_process_identity_mismatch')
        try:
            self.queue=select.kqueue()
            self.queue.control([select.kevent(pid,filter=select.KQ_FILTER_PROC,flags=select.KQ_EV_ADD|select.KQ_EV_ENABLE,fflags=select.KQ_NOTE_EXIT)],0,0)
            if birth(pid)!=before:raise ControlError('owner_process_identity_mismatch')
            self.created=before
        except BaseException:self.close();raise
    def exited(self):
        if self.ended:return True
        for event in self.queue.control(None,1,0):
            if event.flags&select.KQ_EV_ERROR:raise ControlError('owner_wait_failed')
            if event.ident!=self.pid or event.filter!=select.KQ_FILTER_PROC or not event.fflags&select.KQ_NOTE_EXIT:raise ControlError('owner_event_unverified')
            self.ended=True
        return self.ended
    def close(self):
        if self.queue is not None:self.queue.close();self.queue=None
    def __enter__(self):return self
    def __exit__(self,*_):self.close()

class ControlTree:
    def __init__(self,runtime):
        raw=str(runtime)
        if not raw.startswith('/') or raw.startswith('//') or any(x in ('.','..') for x in raw.split('/')):raise ControlError('invalid_runtime_path')
        self.runtime=Path(raw);self.root=self.runtime/'shutdown-v2'
        self.binding=hashlib.sha256(str(self.runtime).encode()).hexdigest();self._runtime_identity=None
    @contextmanager
    def _directory(self,generation=None,create=False):
        if generation is not None and not GENERATION.fullmatch(generation):raise ControlError('invalid_generation')
        destination=self.root/generation if generation else self.root
        with ExitStack() as stack:
            fd=os.open('/',os.O_RDONLY|os.O_DIRECTORY);stack.callback(os.close,fd)
            for i,part in enumerate(destination.parts[1:],1):
                if create:
                    try:os.mkdir(part,0o700,dir_fd=fd)
                    except FileExistsError:pass
                try:nxt=os.open(part,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=fd)
                except OSError:raise ControlError('control_directory_missing') from None
                stack.callback(os.close,nxt);fd=nxt
                info=os.fstat(fd)
                if i==len(self.runtime.parts)-1:
                    identity=(info.st_dev,info.st_ino)
                    if self._runtime_identity is not None and identity!=self._runtime_identity:raise ControlError('runtime_directory_changed')
                    self._runtime_identity=identity
                if i>=len(self.runtime.parts)-1 and (info.st_uid!=os.getuid() or info.st_mode&0o022):raise ControlError('control_directory_not_private')
            if len(os.listdir(fd))>(31 if generation else 1025):raise ControlError('control_capacity_exceeded')
            yield fd,destination
    @contextmanager
    def directories(self,*,generation=None,create=False):
        with self._directory(generation,create) as (_,path):yield path
    def _check(self,name,generation,replace=False):
        if name not in NAMES or (name=='owner.json')!=(generation is None) or (replace and name!='owner.json'):raise ControlError('invalid_record_name')
    def _read(self,fd,name):
        try:record=os.open(name,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK,dir_fd=fd)
        except FileNotFoundError:return None
        try:
            info=os.fstat(record)
            if not stat.S_ISREG(info.st_mode) or info.st_nlink!=1 or info.st_uid!=os.getuid() or info.st_mode&0o077 or info.st_size>MAX_BYTES:raise ControlError('control_record_unverified')
            raw=os.read(record,MAX_BYTES+1)
        finally:os.close(record)
        if len(raw)>MAX_BYTES:raise ControlError('record_too_large')
        def pairs(rows):
            result={}
            for key,value in rows:
                if key in result:raise ControlError('duplicate_record_key')
                result[key]=value
            return result
        try:value=json.loads(raw,object_pairs_hook=pairs,parse_constant=lambda _:(_ for _ in ()).throw(ValueError()))
        except (ValueError,UnicodeError):raise ControlError('invalid_record_json') from None
        if not isinstance(value,dict):raise ControlError('invalid_record_schema')
        return value
    def read(self,name,*,generation=None):
        self._check(name,generation)
        with self._directory(generation) as (fd,_):return self._read(fd,name)
    def publish(self,name,value,*,generation=None,replace=False):
        self._check(name,generation,replace)
        raw=json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
        if len(raw)>MAX_BYTES:raise ControlError('record_too_large')
        with self._directory(generation,True) as (fd,_):
            temp='.tmp-'+uuid.uuid4().hex
            record=os.open(temp,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600,dir_fd=fd)
            try:
                with os.fdopen(record,'wb') as stream:stream.write(raw);stream.flush();os.fsync(stream.fileno())
                self._read(fd,name) # reject linked/untrusted existing target
                if replace:os.replace(temp,name,src_dir_fd=fd,dst_dir_fd=fd)
                else:
                    try:os.link(temp,name,src_dir_fd=fd,dst_dir_fd=fd,follow_symlinks=False)
                    except FileExistsError:
                        if self._read(fd,name)!=value:raise ControlError('record_conflict')
                    else:os.unlink(temp,dir_fd=fd)
                os.fsync(fd)
            finally:
                try:os.unlink(temp,dir_fd=fd)
                except FileNotFoundError:pass
    def new_generation(self):
        with self._directory(create=True) as (fd,_):
            if len(os.listdir(fd))>=1024:raise ControlError('generation_capacity_exceeded')
            generation='g-'+uuid.uuid4().hex;os.mkdir(generation,0o700,dir_fd=fd);return generation
