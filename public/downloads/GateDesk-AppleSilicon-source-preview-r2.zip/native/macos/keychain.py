"""Per-runtime AES-GCM key in macOS Keychain; no plaintext fallback or CLI secrets."""
import ctypes as C
import hashlib
import os
import sys
from pathlib import Path
from app.camera_enrollment import EnrollmentError

class KeychainStore:
    def __init__(self):
        if sys.platform!='darwin':raise EnrollmentError('macos_keychain_unavailable')
        self.cf=C.CDLL('/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation')
        self.sec=C.CDLL('/System/Library/Frameworks/Security.framework/Security')
        for name,args,ret in [('CFStringCreateWithCString',[C.c_void_p,C.c_char_p,C.c_uint32],C.c_void_p),('CFDataCreate',[C.c_void_p,C.c_void_p,C.c_long],C.c_void_p),('CFDictionaryCreateMutable',[C.c_void_p,C.c_long,C.c_void_p,C.c_void_p],C.c_void_p),('CFDictionarySetValue',[C.c_void_p,C.c_void_p,C.c_void_p],None),('CFDataGetLength',[C.c_void_p],C.c_long),('CFDataGetBytePtr',[C.c_void_p],C.c_void_p),('CFRelease',[C.c_void_p],None)]:
            fn=getattr(self.cf,name);fn.argtypes=args;fn.restype=ret
        self.sec.SecItemCopyMatching.argtypes=[C.c_void_p,C.POINTER(C.c_void_p)];self.sec.SecItemCopyMatching.restype=C.c_int32
        self.sec.SecItemAdd.argtypes=[C.c_void_p,C.c_void_p];self.sec.SecItemAdd.restype=C.c_int32
    def constant(self,name):return C.c_void_p.in_dll(self.sec,name).value
    def query(self,account,value=None):
        allocated=[]
        def string(v):
            ref=self.cf.CFStringCreateWithCString(None,v.encode(),0x08000100);allocated.append(ref);return ref
        q=self.cf.CFDictionaryCreateMutable(None,0,None,None);allocated.append(q)
        pairs=[('kSecClass',self.constant('kSecClassGenericPassword')),('kSecAttrService',string('GateDesk.camera.aes.v1')),('kSecAttrAccount',string(account)),('kSecUseAuthenticationUI',self.constant('kSecUseAuthenticationUIFail'))]
        if value is None:pairs.append(('kSecReturnData',C.c_void_p.in_dll(self.cf,'kCFBooleanTrue').value))
        else:
            buf=C.create_string_buffer(value);ref=self.cf.CFDataCreate(None,buf,len(value));allocated.append(ref)
            pairs.extend([('kSecValueData',ref),('kSecAttrAccessible',self.constant('kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly'))])
        for k,v in pairs:self.cf.CFDictionarySetValue(q,self.constant(k),v)
        return q,allocated
    def get(self,account):
        q,allocated=self.query(account);result=C.c_void_p()
        try:
            status=self.sec.SecItemCopyMatching(q,C.byref(result))
            if status==-25300:return None
            if status!=0:raise EnrollmentError('macos_keychain_read_denied')
            if self.cf.CFDataGetLength(result)!=32:raise EnrollmentError('macos_keychain_key_invalid')
            return C.string_at(self.cf.CFDataGetBytePtr(result),32)
        finally:
            if result:self.cf.CFRelease(result)
            for ref in reversed(allocated):self.cf.CFRelease(ref)
    def add(self,account,value):
        q,allocated=self.query(account,value)
        try:
            status=self.sec.SecItemAdd(q,None)
            if status not in (0,-25299):raise EnrollmentError('macos_keychain_write_denied')
        finally:
            for ref in reversed(allocated):self.cf.CFRelease(ref)

class MacUserProtection:
    def __init__(self,database,*,store=None,cipher=None):
        self.account=hashlib.sha256(str(Path(database).resolve()).encode()).hexdigest()
        self.store=store # Lazy native access; only an authorized save can provision a key.
        self.cipher=cipher
    def _key(self,create):
        if self.store is None:self.store=KeychainStore()
        key=self.store.get(self.account)
        if key is None and create:self.store.add(self.account,os.urandom(32));key=self.store.get(self.account)
        if not isinstance(key,bytes) or len(key)!=32:raise EnrollmentError('macos_keychain_key_unavailable')
        return key
    def _cipher(self,key):
        try:
            if self.cipher:return self.cipher(key)
            from cryptography.hazmat.primitives.ciphers.aead import AESGCM
            return AESGCM(key)
        except ImportError:raise EnrollmentError('macos_crypto_unavailable') from None
    def protect(self,value):
        if not isinstance(value,bytes) or not 1<=len(value)<=32768:raise EnrollmentError('invalid_secret_blob')
        nonce=os.urandom(12)
        return b'GDM1'+nonce+self._cipher(self._key(True)).encrypt(nonce,value,self.account.encode())
    def unprotect(self,value):
        if not isinstance(value,bytes) or not 33<=len(value)<=32800 or value[:4]!=b'GDM1':raise EnrollmentError('invalid_secret_blob')
        try:return self._cipher(self._key(False)).decrypt(value[4:16],value[16:],self.account.encode())
        except Exception:raise EnrollmentError('macos_secret_unavailable') from None
