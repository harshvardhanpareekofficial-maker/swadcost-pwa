# Apple-silicon Gate Desk setup preview

This source-only online installer is a development preparation artifact, not a tested Mac application, signed .app, DMG, or offline installer. It contains no model weights, customer records, camera footage, credentials or Python runtime.

This requires an existing reviewed native arm64 Python 3.12.14 interpreter. Python.org does not supply a binary installer for that security-only release, so this is not an ordinary download-and-run Mac app. Do not substitute a different version or disable lifecycle checks. On a Mac where that prerequisite is already satisfied, Extract into a new private folder, then from Terminal run:

    python3.12 native/macos/setup.py --install

Setup verifies the source manifest and creates a new local virtual environment. It downloads only pinned, hash-verified binary wheels from PyPI using normal TLS verification. Internet access is needed for setup. An existing environment is never overwritten. After success run:

    ./Start\ Gate\ Desk.command

The existing owner-account login, runtime lock, loopback-only PC interface, phone TLS disabled in this Mac preview, and shutdown settlement protocol remain. No administrative privileges, Gatekeeper disabling or automatic remote camera connection are requested. No model is included: counting reliability remains unestablished. Camera credentials use a per-runtime key in macOS Keychain and AES-GCM ciphertext; a denied/locked Keychain fails closed. Private data stays under ~/Library/Application Support/Gate Desk, owned by the current user. No automatic migration from Windows DPAPI data is possible: camera credentials must be entered again on Mac.

The Darwin backend uses descriptor-relative no-follow filesystem operations, libproc process birth identity, and retained kqueue process-exit observation. It never sends kill signals or assumes a reused PID identifies the original process. This code needs native Mac acceptance: process/exit races, Keychain behavior, filesystem rename/link checks, launch/stop/restart, TLS, originals/backup/restore, and actual phone/camera workflow. Windows synthetic tests are not substitutes.

The source preview is prepared for publication after final archive review. This does not establish native Mac acceptance or an Apple-signed release. A future packaged .app needs appropriate Developer ID signing and notarization. Do not publish a fake .dmg or claim Apple acceptance.

Configured phone TLS remains unsupported on Darwin: the existing dual-listener loop retains Windows-specific verified transport pins. Do not pass --phone-config or use phone restart on this preview. The plain PC loop also retains exact Python3.12.14/Uvicorn lifecycle source pins; drift fails closed and must be independently requalified.

After the local console reports ready, open http://127.0.0.1:8765 in the Mac browser. This is the local three-page owner workspace, not a cloud address. Use Control-C in its Terminal for owned graceful shutdown; do not force-kill unresolved work.

The isolated launch wrapper sets owner-only accounts and forces camera capture and external notification/email sending off. This preview is for PC workflow preparation; it does not connect a factory recorder or send messages. Phone TLS arguments are not accepted.

Bundled browser dependencies retain their original notices: jsQR (Apache-2.0) in app/static/vendor/jsqr/LICENSE and Archivo (SIL Open Font License) in app/static/fonts/OFL.txt; provenance files are adjacent. Python packages are downloaded separately from their upstream distributions and retain their respective licenses. No codec binaries or trained model are redistributed in this archive.

