"""Apple-silicon readiness inventory. Does not launch, install, or weaken security."""
import argparse
import importlib.metadata
import json
import platform
from pathlib import Path

DEPENDENCIES = ('torch', 'torchvision', 'av', 'fastapi', 'uvicorn', 'numpy', 'pillow', 'python-multipart')
BLOCKERS = (
    'Darwin process/file ownership adapter is source-prepared but not native-tested.',
    'macOS Keychain adapter is source-prepared but not native-tested; no plaintext fallback.',
    'Upstream wheel hashes are locked; native Apple-silicon resolution and installation remain untested.',
    'Native app build, signing, notarization and Mac lifecycle/device acceptance are unverified.',
    'Model redistribution rights and independent factory acceptance remain unresolved.',
)

def inspect(system=None, machine=None, versions=None):
    system = platform.system() if system is None else system
    machine = platform.machine() if machine is None else machine
    if versions is None:
        versions = {}
        for name in DEPENDENCIES:
            try: versions[name] = importlib.metadata.version(name)
            except importlib.metadata.PackageNotFoundError: versions[name] = None
    return {'kind':'macos_build_preparation_only', 'system':system, 'machine':machine,
            'apple_silicon_process':system=='Darwin' and machine=='arm64',
            'python':platform.python_version(), 'dependencies':versions,
            'missing_dependencies':[n for n in DEPENDENCIES if not versions.get(n)],
            'windows_cpu_wheels_present':any('+cpu' in (versions.get(n) or '') for n in ('torch','torchvision')),
            'production_launch_supported':False, 'native_mac_tested':False,
            'blockers':list(BLOCKERS), 'credentials_read':False, 'network_used':False}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    with args.output.open('x',encoding='utf-8') as stream:
        json.dump(inspect(),stream,indent=2);stream.write('\n')
    return 2  # Preparation cannot be mistaken for a supported production launch.

if __name__=='__main__':raise SystemExit(main())
