@echo off
setlocal
py -3.12 -I -B "%~dp0setup.py" %*
set "GATE_SETUP_EXIT=%ERRORLEVEL%"
echo.
echo Python 3.12.14 x64 and internet are required. See README.txt if setup failed.
pause
exit /b %GATE_SETUP_EXIT%
