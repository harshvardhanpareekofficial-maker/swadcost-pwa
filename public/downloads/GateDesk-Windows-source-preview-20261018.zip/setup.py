"""Windows source-preview setup. Downloads dependencies, never uploads user data."""
import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import platform
import shutil
import subprocess
import sys
import time


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def verify_package(root):
    root = Path(root).resolve(strict=True)
    manifest = json.loads((root / 'public-manifest.json').read_text(encoding='utf-8'))
    if manifest.get('kind') != 'windows_online_source_preview' or manifest.get('models_included') is not False:
        raise ValueError('Unexpected setup package')
    expected = set()
    for item in manifest['files']:
        name = item['path']
        parts = PurePosixPath(name).parts
        if (not parts or PurePosixPath(name).is_absolute() or any(p in ('..', '.') for p in parts)
                or '\\' in name or ':' in name or name in expected):
            raise ValueError('Unsafe package member')
        path = root.joinpath(*parts)
        if (not path.is_file() or not path.resolve().is_relative_to(root)
                or any(p.is_symlink() or p.is_junction() for p in (path, *path.parents))
                or path.stat().st_size != item['bytes'] or digest(path) != item['sha256']):
            raise ValueError('Package integrity check failed: ' + name)
        expected.add(name)
    actual = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    if actual != expected | {'public-manifest.json'}:
        raise ValueError('Unexpected files in setup package')
    return manifest


def run_owned(command, log_path, timeout):
    """A late child is a failed step; keep its exact handle until it exits."""
    child = None
    late = False
    start = time.monotonic()
    environment = {k: v for k, v in os.environ.items()
                   if not k.upper().startswith(('PIP_', 'PYTHON'))}
    environment['PIP_CONFIG_FILE'] = os.devnull
    environment['PYTHONNOUSERSITE'] = '1'
    with Path(log_path).open('xb') as log:
        try:
            child = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT,
                                     env=environment, creationflags=subprocess.CREATE_NO_WINDOW)
            try:
                child.wait(timeout=timeout)
            except BaseException:
                late = True
        finally:
            if child is not None:
                while True:
                    try:
                        child.wait(timeout=1)
                        break
                    except subprocess.TimeoutExpired:
                        pass
                    except BaseException:
                        late = True
    if child is None or child.returncode != 0 or late or time.monotonic() - start > timeout:
        raise RuntimeError('Setup step did not complete within its bound; inspect ' + str(log_path))


def install(root, destination):
    root = Path(root).resolve(strict=True)
    verify_package(root)
    if sys.platform != 'win32' or sys.version_info[:3] != (3, 12, 14) or platform.machine().lower() not in ('amd64', 'x86_64'):
        raise ValueError('This preview requires 64-bit Windows and Python 3.12.14 x64; its HTTP lifecycle is pinned to that patch version.')
    destination = Path(destination).absolute()
    if destination.resolve().is_relative_to(root):
        raise ValueError('Installation destination must be outside the extracted setup folder.')
    if any(p.is_symlink() or p.is_junction() for p in (destination, *destination.parents)):
        raise ValueError('Linked installation paths are not supported.')
    if destination.exists():
        raise ValueError('Destination already exists. It was preserved; choose a new --install-dir. No reset or overwrite is performed.')
    destination.mkdir(parents=True, exist_ok=False)
    application = destination / 'application'
    shutil.copytree(root, application)
    verify_package(application)
    runtime = destination / 'python-environment'
    run_owned([sys.executable, '-I', '-B', '-m', 'venv', str(runtime)], destination / 'create-environment.log', 120)
    python = runtime / 'Scripts/python.exe'
    print('Installing pinned dependencies from PyPI and the official PyTorch CPU index. This may take several minutes.', flush=True)
    run_owned([str(python), '-I', '-B', '-m', 'pip', 'install', '--disable-pip-version-check', '--no-input',
               '--index-url', 'https://pypi.org/simple', '--extra-index-url', 'https://download.pytorch.org/whl/cpu',
               '--requirement', str(application / 'source/requirements-lock.txt')], destination / 'install-dependencies.log', 1200)
    run_owned([str(python), '-I', '-B', str(application / 'source/scripts/launch_offline_source.py'),
               '--runtime-dir', str(destination / 'runtime-data'), '--verify-only'], destination / 'verify-environment.log', 60)
    for name, extra in (('Gate Desk Preview.cmd', ''), ('Stop Gate Desk Preview.cmd', ' --request-stop')):
        content = ('@echo off\r\nsetlocal\r\nset "GATE_DESK_ACCOUNTS=1"\r\nset "GATE_DESK_OWNER_PC=1"\r\n'
                   'set "GATE_DESK_NOTIFY_SEND=0"\r\nset "GATE_DESK_NOTIFY_EMAIL_ENABLED=false"\r\n'
                   'set "GATE_CAMERA_CAPTURE_ENABLED=0"\r\n'
                   'echo Gate Desk setup preview. No counting model is included.\r\n'
                   'echo Once started, open http://127.0.0.1:8765 in this PC browser.\r\n'
                   '"%~dp0python-environment\\Scripts\\python.exe" -I -B '
                   '"%~dp0application\\source\\scripts\\launch_offline_source.py" '
                   '--runtime-dir "%~dp0runtime-data"' + extra + '\r\n'
                   'set "GATE_PREVIEW_EXIT=%ERRORLEVEL%"\r\npause\r\nexit /b %GATE_PREVIEW_EXIT%\r\n')
        with (destination / name).open('x', encoding='utf-8', newline='') as stream:
            stream.write(content)
    (destination / 'setup-result.json').write_text(json.dumps({'installed': True, 'model_included': False,
        'runtime_data': 'runtime-data', 'scope': 'Online source preview; actual counting requires a separately authorized model and validation.'}, indent=2), encoding='utf-8')
    print('Setup complete. Open: ' + str(destination / 'Gate Desk Preview.cmd'))
    print('Originals and accounts stay in runtime-data. Do not delete that directory to update or troubleshoot.')


def main():
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    parser.add_argument('--install-dir', type=Path)
    parser.add_argument('--check-only', action='store_true')
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    if args.check_only:
        verify_package(root)
        print('Source-preview package verified. No installation or download was performed.')
        return
    destination = args.install_dir or Path(os.environ.get('LOCALAPPDATA', str(Path.home()))) / 'GateDeskPreview'
    install(root, destination)


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, RuntimeError) as error:
        print('Setup was not completed: ' + str(error), file=sys.stderr)
        raise SystemExit(1)
